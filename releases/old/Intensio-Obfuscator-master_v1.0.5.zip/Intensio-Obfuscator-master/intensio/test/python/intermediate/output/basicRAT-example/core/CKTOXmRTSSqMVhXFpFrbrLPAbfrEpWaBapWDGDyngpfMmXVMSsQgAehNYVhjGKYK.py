# -*- coding: utf-8 -*-
import socket
TUJYIUvZaCyPgTHSHjkZoGOIfWBSGodPxVHBgwkIyntggwYWLjqJgTuAcOvqbLmf = 'HKNeWoIWJjSuishEnUpqgkBoaDxqOIwwOHyGqEcQklWDRadVHZHjAbZMLasYdmHj'
OvpgpCiuDTuJiNCYQtaikthgoidYuyYbFiEEmncXDMclEygIwPcImaILtozXrMpC = 'wMNWfqWtADaLfDSQMXXuKFCsNKWkZsOHtgdPpfNHkGGVbInWuEKAPBgkcgqHsqDi'
if TUJYIUvZaCyPgTHSHjkZoGOIfWBSGodPxVHBgwkIyntggwYWLjqJgTuAcOvqbLmf != OvpgpCiuDTuJiNCYQtaikthgoidYuyYbFiEEmncXDMclEygIwPcImaILtozXrMpC:
    HZhjilwVhzezWhKdjYeZRDOIqbDUSgocAwYwLzQjLsIcLVxfAdzKUHieWGZigvFb = 'OAeShvFoiWwipppHHtKoEWTtMwCpvIVQAmEGaoBpVQDtYxFkEeQkkkhgSgGHameT'
    AOtxfMPlBRYWKcFlvOXgXplBuwXGLDHgxenqnBwGPoJYoETVbrSkUNgiLVGxoweK = 'KAFXCHsLIircbhONnfJxYoVFSiiamWZnytBfRgUISnmzrYDJCQclTwioKyGIuekX'
    AOtxfMPlBRYWKcFlvOXgXplBuwXGLDHgxenqnBwGPoJYoETVbrSkUNgiLVGxoweK = HZhjilwVhzezWhKdjYeZRDOIqbDUSgocAwYwLzQjLsIcLVxfAdzKUHieWGZigvFb
import struct
mVbYqAVrkgXmsihESzaEozGtHBVSRqKuFUPBvtdiswxsToCpVAvqaghqYeSoWXuQ = 'NXErnIAfMZwVSuFCCdLgODGfUDMjKzSvKJsQTBsXhEMrGWpilVtIqbasPLlFwjML'
nNUpjLgjUMxvkUBiYHPNKYRmNeklbIEJBfuKDuVbZNNuYWKkBWosaznmhHRCiwEX = 'WImLdaWUZSmHievYsJxSzRzqIkwjdCczkeBjsgbQXiUVdwPhgAxhNAMgRedrqLlK'
qnXmzIQQAGqKICBybRPFJRrRQvOrMeLwAHgpHrzTmRMLYqTrKJnXMobbmpYfQobH = 'EVitCeNCVAclewUOzwfRHARTKAoMHmbOjKnCedVedMDsDjWSuGoRTIiAahpPEzYH'
RmronYezBJMnahPZRQISavmvntFaOnSyppwMjtaaQIJKXosaTHyTyPahzPwZtoXK = 'AzcOLGiaZPFSxDPbTNlgyReljlQyavBSpJNYdSQKOlIgFEuQTNqNkbFQrBbuRpjW'
aOZYSLAzLaIQhkMRDwHWrcMtbIXIYFPzdrHvcHIWmJjKmVHcfINbTkNTFTauLejc = 'iEqbsdleYUkSOnmjoiGYHJgCnjEZbJaKpbDsIZLJtlqsgDdEQRrfcCzdhsJyprZc'
if mVbYqAVrkgXmsihESzaEozGtHBVSRqKuFUPBvtdiswxsToCpVAvqaghqYeSoWXuQ in nNUpjLgjUMxvkUBiYHPNKYRmNeklbIEJBfuKDuVbZNNuYWKkBWosaznmhHRCiwEX:
    mVbYqAVrkgXmsihESzaEozGtHBVSRqKuFUPBvtdiswxsToCpVAvqaghqYeSoWXuQ = aOZYSLAzLaIQhkMRDwHWrcMtbIXIYFPzdrHvcHIWmJjKmVHcfINbTkNTFTauLejc
    if nNUpjLgjUMxvkUBiYHPNKYRmNeklbIEJBfuKDuVbZNNuYWKkBWosaznmhHRCiwEX in qnXmzIQQAGqKICBybRPFJRrRQvOrMeLwAHgpHrzTmRMLYqTrKJnXMobbmpYfQobH:
        nNUpjLgjUMxvkUBiYHPNKYRmNeklbIEJBfuKDuVbZNNuYWKkBWosaznmhHRCiwEX = RmronYezBJMnahPZRQISavmvntFaOnSyppwMjtaaQIJKXosaTHyTyPahzPwZtoXK
elif nNUpjLgjUMxvkUBiYHPNKYRmNeklbIEJBfuKDuVbZNNuYWKkBWosaznmhHRCiwEX in mVbYqAVrkgXmsihESzaEozGtHBVSRqKuFUPBvtdiswxsToCpVAvqaghqYeSoWXuQ:
    qnXmzIQQAGqKICBybRPFJRrRQvOrMeLwAHgpHrzTmRMLYqTrKJnXMobbmpYfQobH = nNUpjLgjUMxvkUBiYHPNKYRmNeklbIEJBfuKDuVbZNNuYWKkBWosaznmhHRCiwEX
    if qnXmzIQQAGqKICBybRPFJRrRQvOrMeLwAHgpHrzTmRMLYqTrKJnXMobbmpYfQobH in nNUpjLgjUMxvkUBiYHPNKYRmNeklbIEJBfuKDuVbZNNuYWKkBWosaznmhHRCiwEX:
        nNUpjLgjUMxvkUBiYHPNKYRmNeklbIEJBfuKDuVbZNNuYWKkBWosaznmhHRCiwEX = aOZYSLAzLaIQhkMRDwHWrcMtbIXIYFPzdrHvcHIWmJjKmVHcfINbTkNTFTauLejc
from VdhWHphnBOFufHFXmSdjHkrVcnvaRNwOEugsoiQWFfISinBvXleIxEynhpFPOLvF import aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE
PfJinKfhlDrijFoTxzSTGUaoRihWSWznecFOOEerfuvOsevIZOkZflvxnNUVuMcV = 'xBikbiskLJKhNqgDGpvZUUECMtbKvFSVtjADWbmImtfVAcJTYYcBrCwDeYVzlsRk'
fgJDwNvwBMYWuTFIldpnKfngsevGFDhmpQYHLWxEmrAbgPJfsDzKBYmpFBLRlrrW = 'VmcjpjtvnhHLdzAnwzniwJxvWnjGIkHHKuhDcGapKhdrUeQHJvRyqEuyrmTSZQjV'
BdUURLQLhUqioQfTyZvTNKMjhxnQvXXwUwSaoIAfKdoKAqLOsJYxKkTkpZqARrik = 'ZzUXvfhCqEdzkBpDYxLOzxZOcZQSuFnYZTGwQLfQflWHLbiAVqQEsNVaGzeSjuCx'
ApJbJbqbnhrMZYIVDegXLaikgtWvYOIkmJGvxBdgzCjplKRazewFEFbDZgPdkUmb = 'ecAUPakhJTnDpgTNdrvAEpQmhSzQtDfLGimtkACyGQjIpmbbAmFpkjFUkTSTBJpJ'
iANMXPzwvTmFRWEHAvBWNkOLxaTqPPdkvKDSPIhxhFHBKtxugUYZwnUFjLbtpanX = 'uHPRFpAJfvAIocDLVeWXeqpsGoQYqqWPfizkrrQOekrgQwGCQVONOWWhjSxXpxrt'
if PfJinKfhlDrijFoTxzSTGUaoRihWSWznecFOOEerfuvOsevIZOkZflvxnNUVuMcV in fgJDwNvwBMYWuTFIldpnKfngsevGFDhmpQYHLWxEmrAbgPJfsDzKBYmpFBLRlrrW:
    PfJinKfhlDrijFoTxzSTGUaoRihWSWznecFOOEerfuvOsevIZOkZflvxnNUVuMcV = iANMXPzwvTmFRWEHAvBWNkOLxaTqPPdkvKDSPIhxhFHBKtxugUYZwnUFjLbtpanX
    if fgJDwNvwBMYWuTFIldpnKfngsevGFDhmpQYHLWxEmrAbgPJfsDzKBYmpFBLRlrrW in BdUURLQLhUqioQfTyZvTNKMjhxnQvXXwUwSaoIAfKdoKAqLOsJYxKkTkpZqARrik:
        fgJDwNvwBMYWuTFIldpnKfngsevGFDhmpQYHLWxEmrAbgPJfsDzKBYmpFBLRlrrW = ApJbJbqbnhrMZYIVDegXLaikgtWvYOIkmJGvxBdgzCjplKRazewFEFbDZgPdkUmb
elif fgJDwNvwBMYWuTFIldpnKfngsevGFDhmpQYHLWxEmrAbgPJfsDzKBYmpFBLRlrrW in PfJinKfhlDrijFoTxzSTGUaoRihWSWznecFOOEerfuvOsevIZOkZflvxnNUVuMcV:
    BdUURLQLhUqioQfTyZvTNKMjhxnQvXXwUwSaoIAfKdoKAqLOsJYxKkTkpZqARrik = fgJDwNvwBMYWuTFIldpnKfngsevGFDhmpQYHLWxEmrAbgPJfsDzKBYmpFBLRlrrW
    if BdUURLQLhUqioQfTyZvTNKMjhxnQvXXwUwSaoIAfKdoKAqLOsJYxKkTkpZqARrik in fgJDwNvwBMYWuTFIldpnKfngsevGFDhmpQYHLWxEmrAbgPJfsDzKBYmpFBLRlrrW:
        fgJDwNvwBMYWuTFIldpnKfngsevGFDhmpQYHLWxEmrAbgPJfsDzKBYmpFBLRlrrW = iANMXPzwvTmFRWEHAvBWNkOLxaTqPPdkvKDSPIhxhFHBKtxugUYZwnUFjLbtpanX
from VdhWHphnBOFufHFXmSdjHkrVcnvaRNwOEugsoiQWFfISinBvXleIxEynhpFPOLvF import gzbycLsDIoAAIdkKrPhXzOCBShxQOsZnySBSMqTNGnQftXQwITlzDOwUPzFObZoY
JZMwevhtfAxRLjpglTPliFwzmdcbqJbEkBTjnYnlYJCiwnzFwhjfLWSsFPnlHijZ = 'IBBrEmhKLQxfHBFsfYbkyxiwcxNyhYIJFSOCxvqdabDUCafjmxcxhBmPkuxhhxio'
hwMQOeUzdLDmeHlzwhzCSZTaFjoUrilDhTSHHkSMoNGqtStjOFGasFfpDSYEUUxv = 'zjvpXnSeyfJTHXeSrvgYjomeXnYBzCHKnUZJOarKdsxeMUWLhsrCoTMclWVwWwRQ'
cggCGUxJGuYcWycfxToyvVrzOgvXDKSGiurDicftThrhslTUJwFbhgYtnvrSNANL = 'lKwSzSDhWrappoLiTNRAyrMqFrOEMJqtrLVhpmvsXixlEOlCzAydSZlLeIixUGmK'
DqcRMdaBomgPXXfJvCEnxIDxVQQioOBHsNDydxeSqXUxVEfFYoWzSvQcbXlbmJpl = 'pkrNIsSUajjdIyPYPyJJOwQMzerveBGaWcrRWxXlGcZLsllwcdXpRtTdIFYiENvt'
CEnuMsihYiRpcCydkYZknlByoXRUiVbYGvhNvASgYYcpMykQYPaIPDBtWHyRZhEh = 'DZZziXWXbnCrQKwaUfowcOxQiIiMfflockipqqXvtKgVQmnZOtTtKHvbJdPZxMkB'
cqZtAlDMjBJXRJZfBkSTjLWUvlEhbYvdZEkxAiarhvDSrTDFqWlGRVrUKtRBfGtG = 'DNdEObdswXwLdTafriSxyLYwdVWTWhWzqgNcqiWsQtuyMceHxMwwOEvgBhJcQPgR'
if cggCGUxJGuYcWycfxToyvVrzOgvXDKSGiurDicftThrhslTUJwFbhgYtnvrSNANL == DqcRMdaBomgPXXfJvCEnxIDxVQQioOBHsNDydxeSqXUxVEfFYoWzSvQcbXlbmJpl:
    for cqZtAlDMjBJXRJZfBkSTjLWUvlEhbYvdZEkxAiarhvDSrTDFqWlGRVrUKtRBfGtG in CEnuMsihYiRpcCydkYZknlByoXRUiVbYGvhNvASgYYcpMykQYPaIPDBtWHyRZhEh:
        if cqZtAlDMjBJXRJZfBkSTjLWUvlEhbYvdZEkxAiarhvDSrTDFqWlGRVrUKtRBfGtG == DqcRMdaBomgPXXfJvCEnxIDxVQQioOBHsNDydxeSqXUxVEfFYoWzSvQcbXlbmJpl:
            CEnuMsihYiRpcCydkYZknlByoXRUiVbYGvhNvASgYYcpMykQYPaIPDBtWHyRZhEh = JZMwevhtfAxRLjpglTPliFwzmdcbqJbEkBTjnYnlYJCiwnzFwhjfLWSsFPnlHijZ
        else:
            DqcRMdaBomgPXXfJvCEnxIDxVQQioOBHsNDydxeSqXUxVEfFYoWzSvQcbXlbmJpl = hwMQOeUzdLDmeHlzwhzCSZTaFjoUrilDhTSHHkSMoNGqtStjOFGasFfpDSYEUUxv
def FRoDRlsJIAlzmRsiLfnTwPbAAJhNPzLZiqmTHwMxrMnMNWnHWWCvyIklDxFOqKIe(sock, BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn, key):
    with open(BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn, 'wb') as f:
        XowcnNufhBvmSlQJSallYfOubyrUKovNSKGRbGxrtpzGFDfTeYVeOXeYiMZhdXeO = 'LElYVlkZqZSqwHchiMvCtHnDvcEIUirqMkFVdlIBjYRXYTSzWhDfquVcSfDoWvhC'
        jNWfZSvxUjzNZiAGKyUbmkaWHfGIMBmckUqQKkedTzYRNERUgJMjXMgXLdqtsmBr = 'syEscqVRCGXQxMfDYlSIUAJObhzfLkQSWIwffcXvAwzbchEDPhznVGFkxXfZuaSi'
        rnxmkjnUanVnKYislIeUqTYJRYRQwLgMguPycrCEowjoYdHWkKURAOXmJZynIJnO = 'gBRNCVAtGlBEdgpWrhKloNmahKECaVuttcczEWtVQNmRrJhbyJaIaTTnqXwGDSac'
        lOKAcSMnlCROblDmoIOpZeCyzBXGSHqKehwvDkPSPPSppPFcUtjfAINmOgmONfmo = 'oyLstVymPlDvuiQYPISAwwwRBiaDwaoOsuFEFsMmAwJKOYgalnsPmpMMEHhoDSBG'
        UBaNkRAUBTCMcGDFaieEQfuHBkfEjxdDYSbiIzGIvHeMaNHUdplYMfPDxWBFCgNo = 'jSFSbtrgzcZiVrEiCDLucgCdTvTsBJWlUzoMQPzzhoXuEPjcqGrhiihOkGYlvXrA'
        if XowcnNufhBvmSlQJSallYfOubyrUKovNSKGRbGxrtpzGFDfTeYVeOXeYiMZhdXeO in jNWfZSvxUjzNZiAGKyUbmkaWHfGIMBmckUqQKkedTzYRNERUgJMjXMgXLdqtsmBr:
            XowcnNufhBvmSlQJSallYfOubyrUKovNSKGRbGxrtpzGFDfTeYVeOXeYiMZhdXeO = UBaNkRAUBTCMcGDFaieEQfuHBkfEjxdDYSbiIzGIvHeMaNHUdplYMfPDxWBFCgNo
            if jNWfZSvxUjzNZiAGKyUbmkaWHfGIMBmckUqQKkedTzYRNERUgJMjXMgXLdqtsmBr in rnxmkjnUanVnKYislIeUqTYJRYRQwLgMguPycrCEowjoYdHWkKURAOXmJZynIJnO:
                jNWfZSvxUjzNZiAGKyUbmkaWHfGIMBmckUqQKkedTzYRNERUgJMjXMgXLdqtsmBr = lOKAcSMnlCROblDmoIOpZeCyzBXGSHqKehwvDkPSPPSppPFcUtjfAINmOgmONfmo
        elif jNWfZSvxUjzNZiAGKyUbmkaWHfGIMBmckUqQKkedTzYRNERUgJMjXMgXLdqtsmBr in XowcnNufhBvmSlQJSallYfOubyrUKovNSKGRbGxrtpzGFDfTeYVeOXeYiMZhdXeO:
            rnxmkjnUanVnKYislIeUqTYJRYRQwLgMguPycrCEowjoYdHWkKURAOXmJZynIJnO = jNWfZSvxUjzNZiAGKyUbmkaWHfGIMBmckUqQKkedTzYRNERUgJMjXMgXLdqtsmBr
            if rnxmkjnUanVnKYislIeUqTYJRYRQwLgMguPycrCEowjoYdHWkKURAOXmJZynIJnO in jNWfZSvxUjzNZiAGKyUbmkaWHfGIMBmckUqQKkedTzYRNERUgJMjXMgXLdqtsmBr:
                jNWfZSvxUjzNZiAGKyUbmkaWHfGIMBmckUqQKkedTzYRNERUgJMjXMgXLdqtsmBr = UBaNkRAUBTCMcGDFaieEQfuHBkfEjxdDYSbiIzGIvHeMaNHUdplYMfPDxWBFCgNo
        vCgGngHhesrREuUMgVdPhDoOlswgzxreuwaHhCokDYXgOCGmvqEgSCIeanFeQjMN = struct.unpack("!I", sock.recv(4))[0]
        while vCgGngHhesrREuUMgVdPhDoOlswgzxreuwaHhCokDYXgOCGmvqEgSCIeanFeQjMN:
            pxfmPZDrtWxalsUmDycFgwSHZIRxtkMUNAxrsSJhnaIMWrqPbbdfInEHinpbvmvF = 'pQVUjTnVifrTzgwuySwNQUoJUxOcHxIENZDfVeKIRPoJkygXcMeGbjnQnHyyZLIu'
            XEXXepeaYCOzHUYpDbkzNRfYZGGoyNYFaNMisvECMvuGWtQbLKUUiJjSCuiKabWq = 'qgvBrbFEAnflNldOQYFbqYWWiknNBPouJrMHBfwjXdnpgUkACOyPrUeNhfUmHDEb'
            jduIjVlTzVrWpcsIfojcqwIdLAjNmNoKtYWLurryVAdYVDQaPzFLVuuvwmRVxVJk = 'hJhXpnqBnaaveafCKcIoZsykwgBlqzHnhfZNvHNdMtDsgySJUeAegnePZzQPUlOg'
            wFwXYEjiBDaynKHokRPYIVhaiJkjfyCHsFIYBdUqSJJFvxeUZlomqZlTMBkurEkc = 'ZkiflRlDLtzYEJbmemXzeQpjHtPtgoyZLcpSNQuzdaCCpWsRBUKDvAjuKvrHAABK'
            sMxBMfGLCWbCbJjgJriCUyJruTprzOaSetAOnIwcVYlWVotHkBibRaTioNXYHxAU = 'tmWByHQGONbYcnLvZjEsMiePNsbrRKFZrVpAERUfoZpJwMAhYStzqRIgzKJrlIco'
            IZHvaoBOxecPMsiHhRaPpjVIVEJMZkNolBCQjAgtpIBFWdWWCvMqrmkfHbwCFpDe = 'NQjQpcrdbzSdKzDZuhWtYfwXzSLTtFjFZlcUUKMjcugPCjFixbmUoaDpEoldTtgG'
            if pxfmPZDrtWxalsUmDycFgwSHZIRxtkMUNAxrsSJhnaIMWrqPbbdfInEHinpbvmvF != wFwXYEjiBDaynKHokRPYIVhaiJkjfyCHsFIYBdUqSJJFvxeUZlomqZlTMBkurEkc:
                XEXXepeaYCOzHUYpDbkzNRfYZGGoyNYFaNMisvECMvuGWtQbLKUUiJjSCuiKabWq = jduIjVlTzVrWpcsIfojcqwIdLAjNmNoKtYWLurryVAdYVDQaPzFLVuuvwmRVxVJk
                for IZHvaoBOxecPMsiHhRaPpjVIVEJMZkNolBCQjAgtpIBFWdWWCvMqrmkfHbwCFpDe in wFwXYEjiBDaynKHokRPYIVhaiJkjfyCHsFIYBdUqSJJFvxeUZlomqZlTMBkurEkc:
                    if IZHvaoBOxecPMsiHhRaPpjVIVEJMZkNolBCQjAgtpIBFWdWWCvMqrmkfHbwCFpDe != jduIjVlTzVrWpcsIfojcqwIdLAjNmNoKtYWLurryVAdYVDQaPzFLVuuvwmRVxVJk:
                        XEXXepeaYCOzHUYpDbkzNRfYZGGoyNYFaNMisvECMvuGWtQbLKUUiJjSCuiKabWq = XEXXepeaYCOzHUYpDbkzNRfYZGGoyNYFaNMisvECMvuGWtQbLKUUiJjSCuiKabWq
                    else:
                        sMxBMfGLCWbCbJjgJriCUyJruTprzOaSetAOnIwcVYlWVotHkBibRaTioNXYHxAU = pxfmPZDrtWxalsUmDycFgwSHZIRxtkMUNAxrsSJhnaIMWrqPbbdfInEHinpbvmvF
            else:
                jduIjVlTzVrWpcsIfojcqwIdLAjNmNoKtYWLurryVAdYVDQaPzFLVuuvwmRVxVJk = pxfmPZDrtWxalsUmDycFgwSHZIRxtkMUNAxrsSJhnaIMWrqPbbdfInEHinpbvmvF
                pxfmPZDrtWxalsUmDycFgwSHZIRxtkMUNAxrsSJhnaIMWrqPbbdfInEHinpbvmvF = sMxBMfGLCWbCbJjgJriCUyJruTprzOaSetAOnIwcVYlWVotHkBibRaTioNXYHxAU
                if jduIjVlTzVrWpcsIfojcqwIdLAjNmNoKtYWLurryVAdYVDQaPzFLVuuvwmRVxVJk == pxfmPZDrtWxalsUmDycFgwSHZIRxtkMUNAxrsSJhnaIMWrqPbbdfInEHinpbvmvF:
                    for IZHvaoBOxecPMsiHhRaPpjVIVEJMZkNolBCQjAgtpIBFWdWWCvMqrmkfHbwCFpDe in pxfmPZDrtWxalsUmDycFgwSHZIRxtkMUNAxrsSJhnaIMWrqPbbdfInEHinpbvmvF:
                        if IZHvaoBOxecPMsiHhRaPpjVIVEJMZkNolBCQjAgtpIBFWdWWCvMqrmkfHbwCFpDe == jduIjVlTzVrWpcsIfojcqwIdLAjNmNoKtYWLurryVAdYVDQaPzFLVuuvwmRVxVJk:
                            jduIjVlTzVrWpcsIfojcqwIdLAjNmNoKtYWLurryVAdYVDQaPzFLVuuvwmRVxVJk = pxfmPZDrtWxalsUmDycFgwSHZIRxtkMUNAxrsSJhnaIMWrqPbbdfInEHinpbvmvF
                        else:
                            jduIjVlTzVrWpcsIfojcqwIdLAjNmNoKtYWLurryVAdYVDQaPzFLVuuvwmRVxVJk = sMxBMfGLCWbCbJjgJriCUyJruTprzOaSetAOnIwcVYlWVotHkBibRaTioNXYHxAU
            OtbmHzmNXyQKJJbvwSFcAAeFbBTYZPGgBJIXoHTQoCPhnlkALMjJKFDlBepukmvm = sock.recv(vCgGngHhesrREuUMgVdPhDoOlswgzxreuwaHhCokDYXgOCGmvqEgSCIeanFeQjMN)
            f.write(gzbycLsDIoAAIdkKrPhXzOCBShxQOsZnySBSMqTNGnQftXQwITlzDOwUPzFObZoY(OtbmHzmNXyQKJJbvwSFcAAeFbBTYZPGgBJIXoHTQoCPhnlkALMjJKFDlBepukmvm, key))
            vCgGngHhesrREuUMgVdPhDoOlswgzxreuwaHhCokDYXgOCGmvqEgSCIeanFeQjMN = struct.unpack("!I", sock.recv(4))[0]
def gyEOxeZsdJwUGZYgHHjnAcyVnMSFdVEoTXtZeIXivuMhKxmmOUmZwswTamNUpaob(sock, BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn, key):
    with open(BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn, 'rb') as f:
        JOcKrqEzSUUknlQAvmnSJSdQRqUlqXYpyZMtvdWUFMjIHLGZUEItLJysYRyXnhNc = 'pUnXUDSWGpZbdoqxEFLMnAnWVONMUZAOosHtoPXdxradqlwRRmjZNuypNDdebzdC'
        OOnxPAPikWdtSlwqVrlaCWHekAnKtPLlhvklxSyftfBHyKfdWxOmXJpJPYORYhNn = 'OxhgwFsTceQtyvhCYbwRhxQSSpVnErmwdcUMOWBCFFXMyrdVAeyjvtjfbdTQcXWx'
        iLBAcSMCZYldNgxljxujoSMQEkuslyQLVUxrEHOFWJnbyczwCsuLjZttOrbPfZhf = 'AkMbOnqmZPMYSgqjzvuFfVBBnjRqyMDEKFbDEZGhYLyJWfiYoLZMiRvXihTEaeLu'
        pijTbPjgnDtMuXexKCdxmoyTjBRHndjdHUSOweAuiqjMchUqBosxvtIYtzYjJoNu = 'MakrBGTjtSbqOBYyfUiXFVeXHzZneczKIEEuvfvDRrKhwaXKOfBQeIyvWLeTMIcQ'
        WyKCoxJDynWpCjkODvGBtWmhworybjpzSMIjBfKMFtqQIDHuqXNikWSSDvTpUDMk = 'gNMtZrRMJcywwIfHXXZWZIctkjpyjHYoWrrokhqwapvyhDlDtPCKsxPxBDEGqLUz'
        if JOcKrqEzSUUknlQAvmnSJSdQRqUlqXYpyZMtvdWUFMjIHLGZUEItLJysYRyXnhNc in OOnxPAPikWdtSlwqVrlaCWHekAnKtPLlhvklxSyftfBHyKfdWxOmXJpJPYORYhNn:
            JOcKrqEzSUUknlQAvmnSJSdQRqUlqXYpyZMtvdWUFMjIHLGZUEItLJysYRyXnhNc = WyKCoxJDynWpCjkODvGBtWmhworybjpzSMIjBfKMFtqQIDHuqXNikWSSDvTpUDMk
            if OOnxPAPikWdtSlwqVrlaCWHekAnKtPLlhvklxSyftfBHyKfdWxOmXJpJPYORYhNn in iLBAcSMCZYldNgxljxujoSMQEkuslyQLVUxrEHOFWJnbyczwCsuLjZttOrbPfZhf:
                OOnxPAPikWdtSlwqVrlaCWHekAnKtPLlhvklxSyftfBHyKfdWxOmXJpJPYORYhNn = pijTbPjgnDtMuXexKCdxmoyTjBRHndjdHUSOweAuiqjMchUqBosxvtIYtzYjJoNu
        elif OOnxPAPikWdtSlwqVrlaCWHekAnKtPLlhvklxSyftfBHyKfdWxOmXJpJPYORYhNn in JOcKrqEzSUUknlQAvmnSJSdQRqUlqXYpyZMtvdWUFMjIHLGZUEItLJysYRyXnhNc:
            iLBAcSMCZYldNgxljxujoSMQEkuslyQLVUxrEHOFWJnbyczwCsuLjZttOrbPfZhf = OOnxPAPikWdtSlwqVrlaCWHekAnKtPLlhvklxSyftfBHyKfdWxOmXJpJPYORYhNn
            if iLBAcSMCZYldNgxljxujoSMQEkuslyQLVUxrEHOFWJnbyczwCsuLjZttOrbPfZhf in OOnxPAPikWdtSlwqVrlaCWHekAnKtPLlhvklxSyftfBHyKfdWxOmXJpJPYORYhNn:
                OOnxPAPikWdtSlwqVrlaCWHekAnKtPLlhvklxSyftfBHyKfdWxOmXJpJPYORYhNn = WyKCoxJDynWpCjkODvGBtWmhworybjpzSMIjBfKMFtqQIDHuqXNikWSSDvTpUDMk
        OtbmHzmNXyQKJJbvwSFcAAeFbBTYZPGgBJIXoHTQoCPhnlkALMjJKFDlBepukmvm = f.read(4096)
        while len(OtbmHzmNXyQKJJbvwSFcAAeFbBTYZPGgBJIXoHTQoCPhnlkALMjJKFDlBepukmvm):
            QUZfrBreZSASARyhULVNgqFHxPJAVynDwQDfOjxGnwKjEYTdcKaFOTJdTWaIPYmM = 'YHIToBKBOVqiPxPWJsjNLPWLIfLJUXHqDYrSehNdTfktAZawicqfiEIBuxeZrPvJ'
            hflWzcLgoEEsykAUbaDrEyfMcNxoAhlDkgvIXInAHXZMLyaQcfaHdeftWiGItkGt = 'vrrgJsOsNeniVpwBRvWVgmRQhZbZIngKsbUzchzzTzbgtlLkfHpXYCXJBtXHSyEE'
            zxmRPVBvektdTtUJMJSvKZAvMQfVzYllyBpGzuweZjPLKdrYYLVIfMfKOVGdSGmO = 'GbzqJUauAxTjBvxLrOhZzSYrIIYQFazbkeGPkLBctizEJGKooKHfFjhaayqWbEaE'
            if QUZfrBreZSASARyhULVNgqFHxPJAVynDwQDfOjxGnwKjEYTdcKaFOTJdTWaIPYmM == hflWzcLgoEEsykAUbaDrEyfMcNxoAhlDkgvIXInAHXZMLyaQcfaHdeftWiGItkGt:
                BdAxuhyDqKGkSIJjdvdnfSLztIVlXLWpfAOPuvkbymINZwDLpLRmeiTLFnaGVZkZ = 'dWbiYYxaCjwDgYNKJJveWITOdfbbbwTIaQAZvKpJMWghryaPAGzobtzGvZokvLSh'
                BdAxuhyDqKGkSIJjdvdnfSLztIVlXLWpfAOPuvkbymINZwDLpLRmeiTLFnaGVZkZ = QUZfrBreZSASARyhULVNgqFHxPJAVynDwQDfOjxGnwKjEYTdcKaFOTJdTWaIPYmM
            else:
                BdAxuhyDqKGkSIJjdvdnfSLztIVlXLWpfAOPuvkbymINZwDLpLRmeiTLFnaGVZkZ = 'dWbiYYxaCjwDgYNKJJveWITOdfbbbwTIaQAZvKpJMWghryaPAGzobtzGvZokvLSh'
                BdAxuhyDqKGkSIJjdvdnfSLztIVlXLWpfAOPuvkbymINZwDLpLRmeiTLFnaGVZkZ = zxmRPVBvektdTtUJMJSvKZAvMQfVzYllyBpGzuweZjPLKdrYYLVIfMfKOVGdSGmO
            pyuDkGBBWShVAbCrnVINqSziUBNiICdKFKWItCSllAoKCrJOrWyOcjClXkZiHJTb = aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE(OtbmHzmNXyQKJJbvwSFcAAeFbBTYZPGgBJIXoHTQoCPhnlkALMjJKFDlBepukmvm, key)
            sock.send(struct.pack("!I", len(pyuDkGBBWShVAbCrnVINqSziUBNiICdKFKWItCSllAoKCrJOrWyOcjClXkZiHJTb)))
            sock.send(pyuDkGBBWShVAbCrnVINqSziUBNiICdKFKWItCSllAoKCrJOrWyOcjClXkZiHJTb)
            OtbmHzmNXyQKJJbvwSFcAAeFbBTYZPGgBJIXoHTQoCPhnlkALMjJKFDlBepukmvm = f.read(4096)
        sock.send('\x00\x00\x00\x00')
