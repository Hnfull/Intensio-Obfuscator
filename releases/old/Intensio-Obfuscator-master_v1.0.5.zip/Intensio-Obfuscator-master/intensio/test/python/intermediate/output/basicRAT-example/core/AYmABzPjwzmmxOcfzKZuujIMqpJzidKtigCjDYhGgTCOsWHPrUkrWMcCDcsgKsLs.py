# -*- coding: utf-8 -*-
import datetime
hxwvtSZWIjBKPvUZGjExxHldKWvTektkPjAxhlNtfMHBUvEHqBfrMrdwjTYyfirL = 'mBCxyDWeZauSXmGePYJKYvlPrFwmrBZpHEpcxJRAzvtGnodZzJCcpGCxsWNHGsYF'
lImJRpxudnVnVaCQYOjORWMaKtvQplbEsAmZZEHwRVMrUpZZsFMICbewYJNlKgKS = 'jIwqaSKXygnxgdvfTGZMoieEljsednbMJOvOjiHEqKocHlzuZCeIqzBtgjZVaCcp'
hunTFtMTVKGffckejpbqdszmkQiXOYCMmtscutwniGQzYsiWIYTcKNEdacEkLVho = 'bpPEKegGdxGupsZnCnLwxweUDUDANSVukTkVsOcHnvIXCPjOBDtZyeanqNxyFgWf'
HnHHbLPNyLSuoHHWdfkrjAKvNDaNvBllcubAyQRTBmRNYaZuyDiwDTQtnZhiPHwp = 'sBAtHduplQzYIkPdVXvYdRzVilAmlcqWIbQYvFeWSJOzoJbtwogqYckGxdSxvsGC'
KAQfxCoFftyhKqLAKnggVqfMcYWcnUYVODpzlJNPwskIGKwvDUCfWSuvJWbbHGPQ = 'DyZwUHqARtLLpzOwLhdBbsQUiNrUgaVVheOjfJwmIvPXEjojIuFdOxqaXlZpqHIC'
if hxwvtSZWIjBKPvUZGjExxHldKWvTektkPjAxhlNtfMHBUvEHqBfrMrdwjTYyfirL in lImJRpxudnVnVaCQYOjORWMaKtvQplbEsAmZZEHwRVMrUpZZsFMICbewYJNlKgKS:
    hxwvtSZWIjBKPvUZGjExxHldKWvTektkPjAxhlNtfMHBUvEHqBfrMrdwjTYyfirL = KAQfxCoFftyhKqLAKnggVqfMcYWcnUYVODpzlJNPwskIGKwvDUCfWSuvJWbbHGPQ
    if lImJRpxudnVnVaCQYOjORWMaKtvQplbEsAmZZEHwRVMrUpZZsFMICbewYJNlKgKS in hunTFtMTVKGffckejpbqdszmkQiXOYCMmtscutwniGQzYsiWIYTcKNEdacEkLVho:
        lImJRpxudnVnVaCQYOjORWMaKtvQplbEsAmZZEHwRVMrUpZZsFMICbewYJNlKgKS = HnHHbLPNyLSuoHHWdfkrjAKvNDaNvBllcubAyQRTBmRNYaZuyDiwDTQtnZhiPHwp
elif lImJRpxudnVnVaCQYOjORWMaKtvQplbEsAmZZEHwRVMrUpZZsFMICbewYJNlKgKS in hxwvtSZWIjBKPvUZGjExxHldKWvTektkPjAxhlNtfMHBUvEHqBfrMrdwjTYyfirL:
    hunTFtMTVKGffckejpbqdszmkQiXOYCMmtscutwniGQzYsiWIYTcKNEdacEkLVho = lImJRpxudnVnVaCQYOjORWMaKtvQplbEsAmZZEHwRVMrUpZZsFMICbewYJNlKgKS
    if hunTFtMTVKGffckejpbqdszmkQiXOYCMmtscutwniGQzYsiWIYTcKNEdacEkLVho in lImJRpxudnVnVaCQYOjORWMaKtvQplbEsAmZZEHwRVMrUpZZsFMICbewYJNlKgKS:
        lImJRpxudnVnVaCQYOjORWMaKtvQplbEsAmZZEHwRVMrUpZZsFMICbewYJNlKgKS = KAQfxCoFftyhKqLAKnggVqfMcYWcnUYVODpzlJNPwskIGKwvDUCfWSuvJWbbHGPQ
import os
QKqJMxcdynUGhNiugkUzkexiyNygTFEwWQmXbGxiVQfqsXlMiHaWxeZwEsiWJLpO = 'VJparKcevdZqmaevwxcrEdpFJUFOwVZnByBhnihpaZaRbryfuIQWlRwUfGIKRqCg'
qskyuLAlZqAjcJRsdjWuiPcKxfmjYGwEbhBQqsamqGwZrpwrEPpgISQQQsrtieBS = 'JONXGCIIxQbwhXURnQTOKbRnYZpRDchLhuQBfGfdQVkODrQjNWNTaEPKnlMoDADK'
NckhwFICeucZsNuMTWkorxyuIMYhZpwcudrufoaDDRNZZAgwhDsTlHQIhdIgmzWZ = 'jdPHWPxkcZqSJkJkeoBHWLrcvJKLMjaCJFXGIAVHqzLdQouUOdrzGNEyNANthYyA'
sytLallMwiMdzicHRKlyumptElyaskKtZynONJnTzZOQpVlOptNMhcRyshxvuPEd = 'BwrRYLwuNOekKDYCRsKuGkxToxqrYATBlNZXzkoHVxXBoPbuuibXloHOHxyGsGfH'
eqCByhIBnxUruDDEhNOWwLbqgTqwadJEMnaNXcpCLWgmZhloKgtAWceiNRJKmqbk = 'MLUOmWTGYJlMevTmyJMnFYsUaRtXkmJOaNAtxNjkuFVDYdIDsgvYNTDpcjigxuIk'
IiftLIUfisuzoQgTEJCzSmTRLxrNJfpfweuaakzKlRgCwYNczYkDUmUbkkHyXacm = 'zJArKrAQWZStYuACcyZKdPBkktbcQvhpOlVUybdrROkrtFLQMgXigKCyoARKFcQN'
if NckhwFICeucZsNuMTWkorxyuIMYhZpwcudrufoaDDRNZZAgwhDsTlHQIhdIgmzWZ == sytLallMwiMdzicHRKlyumptElyaskKtZynONJnTzZOQpVlOptNMhcRyshxvuPEd:
    for IiftLIUfisuzoQgTEJCzSmTRLxrNJfpfweuaakzKlRgCwYNczYkDUmUbkkHyXacm in eqCByhIBnxUruDDEhNOWwLbqgTqwadJEMnaNXcpCLWgmZhloKgtAWceiNRJKmqbk:
        if IiftLIUfisuzoQgTEJCzSmTRLxrNJfpfweuaakzKlRgCwYNczYkDUmUbkkHyXacm == sytLallMwiMdzicHRKlyumptElyaskKtZynONJnTzZOQpVlOptNMhcRyshxvuPEd:
            eqCByhIBnxUruDDEhNOWwLbqgTqwadJEMnaNXcpCLWgmZhloKgtAWceiNRJKmqbk = QKqJMxcdynUGhNiugkUzkexiyNygTFEwWQmXbGxiVQfqsXlMiHaWxeZwEsiWJLpO
        else:
            sytLallMwiMdzicHRKlyumptElyaskKtZynONJnTzZOQpVlOptNMhcRyshxvuPEd = qskyuLAlZqAjcJRsdjWuiPcKxfmjYGwEbhBQqsamqGwZrpwrEPpgISQQQsrtieBS
import urllib
GpaxvVZanPLwYzBvcXwhLUFhTiRciOHLXNDBezwKQCGwFxvYrbsNsziMgqjmSVSi = 'lXampMpiuMHrCNibXuIGpOAjgQUqxXkiySAsPAFtyrSsSzsxeSzsHsdvggVbTxXy'
zYiflSQvevJHbuptSJPYwiriVFFThqubeutbhWqdmcEKAXzvBCiNafUFaiuAyXgy = 'zGfViHaRxMcTxCEkdYLZrmcthetSmeAiSkewWYRtCwYzQbPOzvfUlVaSlSYYeOcO'
tcJnVkWYDTrpKIKZAmMntWclgwkFFFlvRBNqVsLAWxIKfEDxmqRYWoPJrmCaDPFM = 'IEysvoOSBFQlOiQIeuhTrrzWlCQhZvQGFarNiQkopURgwDuWiaCVXoQQkRQXRwET'
if GpaxvVZanPLwYzBvcXwhLUFhTiRciOHLXNDBezwKQCGwFxvYrbsNsziMgqjmSVSi == zYiflSQvevJHbuptSJPYwiriVFFThqubeutbhWqdmcEKAXzvBCiNafUFaiuAyXgy:
    ylMoqKPyDeBrXJfcbQeftpzljdZgEnGkWlmnVGTYFMApeVGxAHWKRyFsGWScGPyx = 'SMJhIlZEojgDRlrDZkebQvljCCKKsyaxiOTGCsAJzYJwnkIKJbWhbMvLvLlSEtgg'
    ylMoqKPyDeBrXJfcbQeftpzljdZgEnGkWlmnVGTYFMApeVGxAHWKRyFsGWScGPyx = GpaxvVZanPLwYzBvcXwhLUFhTiRciOHLXNDBezwKQCGwFxvYrbsNsziMgqjmSVSi
else:
    ylMoqKPyDeBrXJfcbQeftpzljdZgEnGkWlmnVGTYFMApeVGxAHWKRyFsGWScGPyx = 'SMJhIlZEojgDRlrDZkebQvljCCKKsyaxiOTGCsAJzYJwnkIKJbWhbMvLvLlSEtgg'
    ylMoqKPyDeBrXJfcbQeftpzljdZgEnGkWlmnVGTYFMApeVGxAHWKRyFsGWScGPyx = tcJnVkWYDTrpKIKZAmMntWclgwkFFFlvRBNqVsLAWxIKfEDxmqRYWoPJrmCaDPFM
import zipfile
HSjLxNIGjGPuvERTTifMLMWyIIfLiThUlRGXKHYtYxMCvHROToEebVYntRAwcsQz = 'exPmetBgKKsdVunocsMKUcYKxyPVdmqdSXpzDFHFSnYjaFCaKAPQJJUBVsPRsyGa'
HYVcpXeUeWmFnPrTKrhftVWFGpAuqXQKstoFAXqFYZPUFhQCWiXUiovRTsjWqDKN = 'linmbAikWLgzOIzkJmNLDBgfdVvoGMzNkrLQcbqKzcrqUtEqSPpBYzVwcDpYEmiU'
if HSjLxNIGjGPuvERTTifMLMWyIIfLiThUlRGXKHYtYxMCvHROToEebVYntRAwcsQz != HYVcpXeUeWmFnPrTKrhftVWFGpAuqXQKstoFAXqFYZPUFhQCWiXUiovRTsjWqDKN:
    RqdkgAiUHJYUTBWvwwDEEcdxpiLibEPgFbYqcCOuOgBPbEQlMCVHbLDhaiKDqZQn = 'zdYHlJRboPFQnvrIXubLbJdiuOMxGhEWcHIoHQPcPDadaCxUQIvmKreeXwvtfBrP'
    aMdzFFFfEsPIwkXhskhVBjvoiuXzbkwISgLQnDdCGCnrndrKLFaCqaeajJmYEZgu = 'aFHmIEUvxFCxlcUNIkEfjLXfPLXdFGLCVSCTHyICFeXdHMPZqYCiLgNNhwCXvJDj'
    aMdzFFFfEsPIwkXhskhVBjvoiuXzbkwISgLQnDdCGCnrndrKLFaCqaeajJmYEZgu = RqdkgAiUHJYUTBWvwwDEEcdxpiLibEPgFbYqcCOuOgBPbEQlMCVHbLDhaiKDqZQn
def PaWZzpbpfTKwFKTszKjPMAaKVVnWBESorGAyTpBuTKufbJYlvVUoiWXaAGYgjFrj(f):
    if os.path.isfile(f):
        oAcyBxkmqFPfLJoMtqrsqEGEGXzBvOvBIZahgvbkyxsbtqDCDTDrWePJBoQSCjuz = 'GLAkfDUkImFxorWLgynmzhWlHNubHUOlmCEpPwxUjGJZQNADSDBxCDoDyJgHBojT'
        pvVVAHqIPUSuHgjoAlHWnZYaGwKMaqXIWmhPFyVJKLJtMKDvhMWlydiYvRlJrjSd = 'MUhkzOAnBtcxhZJIdwgrEJOvIifrSOBTfNxDRZaQTnEaakuuxsdEYeBaVhiPDrGr'
        BZwZuZOhATgQlCMkCrqxJLhmChfpymloKuMmiZlLSBboHVgDfJmrEWcksXtxPNar = 'KSoNEtzInEKPNCUxFAadcliAZJxHOXHbqmvhzoBmVIjlmEfPzNTaNguChFdKJfeS'
        eBRrgncTeRijTzraVPaQwfrvdmtFfLrHzWQAjMqToyyofnwKfvQGcNYZJUkDWCAt = 'MxVSRXOHfBAcVqpfRqPvpRrMLYXQMvAYAMyjxlBQkhpHViuLAvEreSEdbLSlcauE'
        eTADKuOrNrQScHMMbKiGuZiyYaLzChNsYNMVMRKrZUcctDcHhmuyTvhBugquqQRG = 'FeEzecZHmRKkRFcmsZBBZvEneeePTBinNKYKUluXqLbbjoMOOxvmOvvMNayTgeMJ'
        if oAcyBxkmqFPfLJoMtqrsqEGEGXzBvOvBIZahgvbkyxsbtqDCDTDrWePJBoQSCjuz in pvVVAHqIPUSuHgjoAlHWnZYaGwKMaqXIWmhPFyVJKLJtMKDvhMWlydiYvRlJrjSd:
            oAcyBxkmqFPfLJoMtqrsqEGEGXzBvOvBIZahgvbkyxsbtqDCDTDrWePJBoQSCjuz = eTADKuOrNrQScHMMbKiGuZiyYaLzChNsYNMVMRKrZUcctDcHhmuyTvhBugquqQRG
            if pvVVAHqIPUSuHgjoAlHWnZYaGwKMaqXIWmhPFyVJKLJtMKDvhMWlydiYvRlJrjSd in BZwZuZOhATgQlCMkCrqxJLhmChfpymloKuMmiZlLSBboHVgDfJmrEWcksXtxPNar:
                pvVVAHqIPUSuHgjoAlHWnZYaGwKMaqXIWmhPFyVJKLJtMKDvhMWlydiYvRlJrjSd = eBRrgncTeRijTzraVPaQwfrvdmtFfLrHzWQAjMqToyyofnwKfvQGcNYZJUkDWCAt
        elif pvVVAHqIPUSuHgjoAlHWnZYaGwKMaqXIWmhPFyVJKLJtMKDvhMWlydiYvRlJrjSd in oAcyBxkmqFPfLJoMtqrsqEGEGXzBvOvBIZahgvbkyxsbtqDCDTDrWePJBoQSCjuz:
            BZwZuZOhATgQlCMkCrqxJLhmChfpymloKuMmiZlLSBboHVgDfJmrEWcksXtxPNar = pvVVAHqIPUSuHgjoAlHWnZYaGwKMaqXIWmhPFyVJKLJtMKDvhMWlydiYvRlJrjSd
            if BZwZuZOhATgQlCMkCrqxJLhmChfpymloKuMmiZlLSBboHVgDfJmrEWcksXtxPNar in pvVVAHqIPUSuHgjoAlHWnZYaGwKMaqXIWmhPFyVJKLJtMKDvhMWlydiYvRlJrjSd:
                pvVVAHqIPUSuHgjoAlHWnZYaGwKMaqXIWmhPFyVJKLJtMKDvhMWlydiYvRlJrjSd = eTADKuOrNrQScHMMbKiGuZiyYaLzChNsYNMVMRKrZUcctDcHhmuyTvhBugquqQRG
        try:
            JaJseZbYnwddPwkAhRUwrLioerpcNZXHVwcFiWWMiJludeNMNklGRhYaaTevuppy = 'eVykFSwaqoepuusofPVfdBHLuQJEieLsvRrObuirMjObyMkQkVZkxkesqFCiKWEV'
            LBpnUJYpaYnylHGJGvauVtwRHaHaXMxLFlndrddrzSDsTycGFgDzmHUwiIHzzhSL = 'ObYTXbvWTSTwlcPrAuuRCVkrburUQJpOJedQGQOSzxuRCWvYzDTFMtDMKjcysKfQ'
            hYYievwHoyuXtCkeJYpzqTuOCAGAQuBVmCoPoRsEjRfHFNXgjdHcEIebxUDDdHNI = 'ASeCPDXEjPeVuKVAoBEvSwfiRztQDQjGnbaAgkgWVKXLJOxVcmtXlaDuVcAKAsEb'
            NEghAeigzhvUCDGcdjNAuKJRryIqLBcfJYaUheJEFvmPuuXfyEQgueSRYCPegmDf = 'kRVMpYElKbwVxauLiIBnUUcepbowXbHcVlYckHmHJIEqwDvyBbelxovrSDiVJYSq'
            thFzMxiucjkJudhfQWamBinlYLksNXqsdxoftnBljerzfEsdvTyPWEReOljsRYDS = 'aXjxgGNcBRPypKzKeantFfFBhzbKTOPzfyoHyCVeTRNPIdtkKFuSSjlpuzxJMCub'
            VjRzUTPLywUgsSyJtjZKsmFBgdYWWBIHqYMYdwjjbShpAAKXxAybCCQOeDOQTjfr = 'AtuGoLljdGxqvTABWXWurfParebFicmZHZkzBPkrMojeqBoifteCAsxmzeaYQfho'
            if JaJseZbYnwddPwkAhRUwrLioerpcNZXHVwcFiWWMiJludeNMNklGRhYaaTevuppy != NEghAeigzhvUCDGcdjNAuKJRryIqLBcfJYaUheJEFvmPuuXfyEQgueSRYCPegmDf:
                LBpnUJYpaYnylHGJGvauVtwRHaHaXMxLFlndrddrzSDsTycGFgDzmHUwiIHzzhSL = hYYievwHoyuXtCkeJYpzqTuOCAGAQuBVmCoPoRsEjRfHFNXgjdHcEIebxUDDdHNI
                for VjRzUTPLywUgsSyJtjZKsmFBgdYWWBIHqYMYdwjjbShpAAKXxAybCCQOeDOQTjfr in NEghAeigzhvUCDGcdjNAuKJRryIqLBcfJYaUheJEFvmPuuXfyEQgueSRYCPegmDf:
                    if VjRzUTPLywUgsSyJtjZKsmFBgdYWWBIHqYMYdwjjbShpAAKXxAybCCQOeDOQTjfr != hYYievwHoyuXtCkeJYpzqTuOCAGAQuBVmCoPoRsEjRfHFNXgjdHcEIebxUDDdHNI:
                        LBpnUJYpaYnylHGJGvauVtwRHaHaXMxLFlndrddrzSDsTycGFgDzmHUwiIHzzhSL = LBpnUJYpaYnylHGJGvauVtwRHaHaXMxLFlndrddrzSDsTycGFgDzmHUwiIHzzhSL
                    else:
                        thFzMxiucjkJudhfQWamBinlYLksNXqsdxoftnBljerzfEsdvTyPWEReOljsRYDS = JaJseZbYnwddPwkAhRUwrLioerpcNZXHVwcFiWWMiJludeNMNklGRhYaaTevuppy
            else:
                hYYievwHoyuXtCkeJYpzqTuOCAGAQuBVmCoPoRsEjRfHFNXgjdHcEIebxUDDdHNI = JaJseZbYnwddPwkAhRUwrLioerpcNZXHVwcFiWWMiJludeNMNklGRhYaaTevuppy
                JaJseZbYnwddPwkAhRUwrLioerpcNZXHVwcFiWWMiJludeNMNklGRhYaaTevuppy = thFzMxiucjkJudhfQWamBinlYLksNXqsdxoftnBljerzfEsdvTyPWEReOljsRYDS
                if hYYievwHoyuXtCkeJYpzqTuOCAGAQuBVmCoPoRsEjRfHFNXgjdHcEIebxUDDdHNI == JaJseZbYnwddPwkAhRUwrLioerpcNZXHVwcFiWWMiJludeNMNklGRhYaaTevuppy:
                    for VjRzUTPLywUgsSyJtjZKsmFBgdYWWBIHqYMYdwjjbShpAAKXxAybCCQOeDOQTjfr in JaJseZbYnwddPwkAhRUwrLioerpcNZXHVwcFiWWMiJludeNMNklGRhYaaTevuppy:
                        if VjRzUTPLywUgsSyJtjZKsmFBgdYWWBIHqYMYdwjjbShpAAKXxAybCCQOeDOQTjfr == hYYievwHoyuXtCkeJYpzqTuOCAGAQuBVmCoPoRsEjRfHFNXgjdHcEIebxUDDdHNI:
                            hYYievwHoyuXtCkeJYpzqTuOCAGAQuBVmCoPoRsEjRfHFNXgjdHcEIebxUDDdHNI = JaJseZbYnwddPwkAhRUwrLioerpcNZXHVwcFiWWMiJludeNMNklGRhYaaTevuppy
                        else:
                            hYYievwHoyuXtCkeJYpzqTuOCAGAQuBVmCoPoRsEjRfHFNXgjdHcEIebxUDDdHNI = thFzMxiucjkJudhfQWamBinlYLksNXqsdxoftnBljerzfEsdvTyPWEReOljsRYDS
            with zipfile.ZipFile(f) as zf:
                HIxEjasJGRqaiaepohhgHfMwMIVFlGDzqkdGTvPlnqymWpjhWhwMyVxymJXwBoHV = 'gnxAbqAjjaqGEHOqVGyADgwAENAznXiNxRAeDrwXIGkRCZdgGVCbDkwfpTMKPfXQ'
                dkDGAKAtKkilnposIeZNSCyyEufCfwIehfBtzxwTxOyaUydAMOmoDKbrqCsoXBkw = 'MmxLeIShBHzlbnsGPsKLXIfGiTCXJzQStAhjkCbdNNfizNWLXOjgdvQNpkeHzKWE'
                FZIWsrtGnXUoRVfHxSFZrBxjQFoNvwdjUjMKfxilPGZEeFrrfsfXJeMzzGogkGJd = 'ighCSfqvpYCKPVTqOBRuzOKpqXNXbziCBCrkOxaaAvwQoiTjDUlBuxgWTgybuFsO'
                RJHFhryiPvxnGvyKYpQsZoiHrmcpmSIgorecPNYODvXSlKqdubnbkWBBOZjSToEN = 'YznjSILuwcMMsvAgWNTqffpDwniQUbeZLFDRvXDFBARPtBMrlBrjobdmAteIcuPJ'
                PbhOQRZSXrYcwLbEnPBCsIPqjsdkqTcPijjDoaRieaRSRUKJUaNbryrnFsHtqVqX = 'OBGJIzPKjQTwGTPkXXcktJNEqeXPqyTqRvYAXYeVPqAiLGqtLDPUnoWdyUfAtjwV'
                tFQWSkDQcUTiiNOSRKjgATVukcslpVxItvNkpZZOwHfbKRbbtdJmSkVQyMEVQpFa = 'GOxKLbZguFoCTXxumcKMZtCIsOxapwXnbPZURcSLNHAtWiOfnPQoJCvzoUAbslIq'
                if HIxEjasJGRqaiaepohhgHfMwMIVFlGDzqkdGTvPlnqymWpjhWhwMyVxymJXwBoHV != RJHFhryiPvxnGvyKYpQsZoiHrmcpmSIgorecPNYODvXSlKqdubnbkWBBOZjSToEN:
                    dkDGAKAtKkilnposIeZNSCyyEufCfwIehfBtzxwTxOyaUydAMOmoDKbrqCsoXBkw = FZIWsrtGnXUoRVfHxSFZrBxjQFoNvwdjUjMKfxilPGZEeFrrfsfXJeMzzGogkGJd
                    for tFQWSkDQcUTiiNOSRKjgATVukcslpVxItvNkpZZOwHfbKRbbtdJmSkVQyMEVQpFa in RJHFhryiPvxnGvyKYpQsZoiHrmcpmSIgorecPNYODvXSlKqdubnbkWBBOZjSToEN:
                        if tFQWSkDQcUTiiNOSRKjgATVukcslpVxItvNkpZZOwHfbKRbbtdJmSkVQyMEVQpFa != FZIWsrtGnXUoRVfHxSFZrBxjQFoNvwdjUjMKfxilPGZEeFrrfsfXJeMzzGogkGJd:
                            dkDGAKAtKkilnposIeZNSCyyEufCfwIehfBtzxwTxOyaUydAMOmoDKbrqCsoXBkw = dkDGAKAtKkilnposIeZNSCyyEufCfwIehfBtzxwTxOyaUydAMOmoDKbrqCsoXBkw
                        else:
                            PbhOQRZSXrYcwLbEnPBCsIPqjsdkqTcPijjDoaRieaRSRUKJUaNbryrnFsHtqVqX = HIxEjasJGRqaiaepohhgHfMwMIVFlGDzqkdGTvPlnqymWpjhWhwMyVxymJXwBoHV
                else:
                    FZIWsrtGnXUoRVfHxSFZrBxjQFoNvwdjUjMKfxilPGZEeFrrfsfXJeMzzGogkGJd = HIxEjasJGRqaiaepohhgHfMwMIVFlGDzqkdGTvPlnqymWpjhWhwMyVxymJXwBoHV
                    HIxEjasJGRqaiaepohhgHfMwMIVFlGDzqkdGTvPlnqymWpjhWhwMyVxymJXwBoHV = PbhOQRZSXrYcwLbEnPBCsIPqjsdkqTcPijjDoaRieaRSRUKJUaNbryrnFsHtqVqX
                    if FZIWsrtGnXUoRVfHxSFZrBxjQFoNvwdjUjMKfxilPGZEeFrrfsfXJeMzzGogkGJd == HIxEjasJGRqaiaepohhgHfMwMIVFlGDzqkdGTvPlnqymWpjhWhwMyVxymJXwBoHV:
                        for tFQWSkDQcUTiiNOSRKjgATVukcslpVxItvNkpZZOwHfbKRbbtdJmSkVQyMEVQpFa in HIxEjasJGRqaiaepohhgHfMwMIVFlGDzqkdGTvPlnqymWpjhWhwMyVxymJXwBoHV:
                            if tFQWSkDQcUTiiNOSRKjgATVukcslpVxItvNkpZZOwHfbKRbbtdJmSkVQyMEVQpFa == FZIWsrtGnXUoRVfHxSFZrBxjQFoNvwdjUjMKfxilPGZEeFrrfsfXJeMzzGogkGJd:
                                FZIWsrtGnXUoRVfHxSFZrBxjQFoNvwdjUjMKfxilPGZEeFrrfsfXJeMzzGogkGJd = HIxEjasJGRqaiaepohhgHfMwMIVFlGDzqkdGTvPlnqymWpjhWhwMyVxymJXwBoHV
                            else:
                                FZIWsrtGnXUoRVfHxSFZrBxjQFoNvwdjUjMKfxilPGZEeFrrfsfXJeMzzGogkGJd = PbhOQRZSXrYcwLbEnPBCsIPqjsdkqTcPijjDoaRieaRSRUKJUaNbryrnFsHtqVqX
                zf.extractall('.')
                return 'File {} extracted.'.format(f)
        except zipfile.BadZipfile:
            eXCmGbkdGcoqRrEjGOwzenYtEYPQaedGaVmbXXYKNliTrKJNLvWvoWDMejJVQfnQ = 'VlAuvxPsRLlGMWtOFpQWcHAPxDHsZJhjlLXEcrhuHzLgyRqfwxPobBhUPlNAXmMO'
            VjnShhkaGMbIaGaIkbEsLZXelRDzBpDvCMUhlfROspDnbuJggrNxXDQSQNdnTFnp = 'OgorWLjEuomfDUJphxHnxnOovwusejIQCzpmBAJJtyRqtEPoETUtcRkDBeKXBWCg'
            jdbCbPfwsxquZEssUtJtlSQKAAIPUZyRCliBUpVBjmXkPLVrseolNhrPErReavha = 'SacdkxSrNBpWIUQvhsXvmrTjEiztcbYmjwCwyanZNIZlwQPKTeiLYFjpEWVGQpur'
            if eXCmGbkdGcoqRrEjGOwzenYtEYPQaedGaVmbXXYKNliTrKJNLvWvoWDMejJVQfnQ == VjnShhkaGMbIaGaIkbEsLZXelRDzBpDvCMUhlfROspDnbuJggrNxXDQSQNdnTFnp:
                OHwzocGlzxbSJandSIsVOIHHDOLnWWdQfOwYaywvrZcmdmHASPPWKFYXgUdMiUBL = 'htgJofjNvCajRVwszDOVuxnJxbwTJPTZntgsoDhoZqYZTrIRQHVDPwJxtsFtWFlQ'
                OHwzocGlzxbSJandSIsVOIHHDOLnWWdQfOwYaywvrZcmdmHASPPWKFYXgUdMiUBL = eXCmGbkdGcoqRrEjGOwzenYtEYPQaedGaVmbXXYKNliTrKJNLvWvoWDMejJVQfnQ
            else:
                OHwzocGlzxbSJandSIsVOIHHDOLnWWdQfOwYaywvrZcmdmHASPPWKFYXgUdMiUBL = 'htgJofjNvCajRVwszDOVuxnJxbwTJPTZntgsoDhoZqYZTrIRQHVDPwJxtsFtWFlQ'
                OHwzocGlzxbSJandSIsVOIHHDOLnWWdQfOwYaywvrZcmdmHASPPWKFYXgUdMiUBL = jdbCbPfwsxquZEssUtJtlSQKAAIPUZyRCliBUpVBjmXkPLVrseolNhrPErReavha
            return 'Error: Failed to PaWZzpbpfTKwFKTszKjPMAaKVVnWBESorGAyTpBuTKufbJYlvVUoiWXaAGYgjFrj file.'
    else:
        upmzJISSOZnKGflwjIJZaxDakuqcvbIjHcuzLJVRQMIRlRgbeEpLMGDaqhTWcEcJ = 'qgKGYwtqMFXwETDRjqjbbVomIYCDNetAhORjssBwofijTWqSAQeEcKIAeMebUKva'
        DfWkotLwQDgpYhdHTeYvZefiVUfejEtsADMfANGmKWBrQaUPnoJSszocasOiMbNd = 'HNLsvQZpNrSmVEgxpbDlxPeIMZEqSkvoTleCaUNqgoCkrnogLSmQUFDnUxrkyQaR'
        BrQkhNtfsCIeohUhophWQlUrSmFsvhjFeGbGnUQZOgCaQKCzutoimNascLoPknwd = 'EHPpIhoxBQeFSXRXKOmYiHaPtthlWWdtPbdwxPFYdAWAgNpGKPjlQIKXKmswdIMn'
        EXyfsVkLOlRSJqMuBZIfDboCieQUkJYuRqPkoEzQQRzhEcmDTTAvmcniTdwBGxDI = 'QNTBMzXuBdHAObvMOksOMvNgdhsSUjGpVWJVjXzsPsQcFprBuRklfAaRVCPzHmcU'
        BOoLjjUjZszhJGTfXteyGHgqdDCHfrErULDnCxuBJOxZMwMGgOvqkUBAFIlCoHPk = 'KzFyXqrFxVjJBVmvoESSkRFaNrfOVclZNDwPeacpvjgQLDzngkduDuRtyVqbPffi'
        if upmzJISSOZnKGflwjIJZaxDakuqcvbIjHcuzLJVRQMIRlRgbeEpLMGDaqhTWcEcJ in DfWkotLwQDgpYhdHTeYvZefiVUfejEtsADMfANGmKWBrQaUPnoJSszocasOiMbNd:
            upmzJISSOZnKGflwjIJZaxDakuqcvbIjHcuzLJVRQMIRlRgbeEpLMGDaqhTWcEcJ = BOoLjjUjZszhJGTfXteyGHgqdDCHfrErULDnCxuBJOxZMwMGgOvqkUBAFIlCoHPk
            if DfWkotLwQDgpYhdHTeYvZefiVUfejEtsADMfANGmKWBrQaUPnoJSszocasOiMbNd in BrQkhNtfsCIeohUhophWQlUrSmFsvhjFeGbGnUQZOgCaQKCzutoimNascLoPknwd:
                DfWkotLwQDgpYhdHTeYvZefiVUfejEtsADMfANGmKWBrQaUPnoJSszocasOiMbNd = EXyfsVkLOlRSJqMuBZIfDboCieQUkJYuRqPkoEzQQRzhEcmDTTAvmcniTdwBGxDI
        elif DfWkotLwQDgpYhdHTeYvZefiVUfejEtsADMfANGmKWBrQaUPnoJSszocasOiMbNd in upmzJISSOZnKGflwjIJZaxDakuqcvbIjHcuzLJVRQMIRlRgbeEpLMGDaqhTWcEcJ:
            BrQkhNtfsCIeohUhophWQlUrSmFsvhjFeGbGnUQZOgCaQKCzutoimNascLoPknwd = DfWkotLwQDgpYhdHTeYvZefiVUfejEtsADMfANGmKWBrQaUPnoJSszocasOiMbNd
            if BrQkhNtfsCIeohUhophWQlUrSmFsvhjFeGbGnUQZOgCaQKCzutoimNascLoPknwd in DfWkotLwQDgpYhdHTeYvZefiVUfejEtsADMfANGmKWBrQaUPnoJSszocasOiMbNd:
                DfWkotLwQDgpYhdHTeYvZefiVUfejEtsADMfANGmKWBrQaUPnoJSszocasOiMbNd = BOoLjjUjZszhJGTfXteyGHgqdDCHfrErULDnCxuBJOxZMwMGgOvqkUBAFIlCoHPk
        return 'Error: File not found.'
def evwfnnvaUOxIdMSgirgwaYEUBMkoGZPUXYRwwPpBxecmgtvpxuHAFbjKNjPJvTIt(WJdoQXqxSEsaPLIVoWyJpEdnEKGToGFMLANrRgBzbkUzwfTZXxERXXykcDmJEinQ):
    if not WJdoQXqxSEsaPLIVoWyJpEdnEKGToGFMLANrRgBzbkUzwfTZXxERXXykcDmJEinQ.startswith('http'):
        ewxUGodkMPmvzNiFdueblpiZvmBvkwDAFeMnQSPYeouPlWZbHEoPyeJNwsCmSCbH = 'QtlFrHPDnvmdgFmBVYEnTcFhqyjAOVZJOgEmrJVhWyVjLgXdmPJBHoKNWTNrqApf'
        IOtHJfOeMNTpJvSplGUuVcTDREYOHIcAnkhCkkfvDQzcSgtiOGzHziEXVvFfTAZL = 'KPQjfqtCoksHcNTOQlFvcEzeaFOKEhkJrntssfeLBSZRwlpPQirzwPGnakxyiFRd'
        qawiWlxYvqaejCEqfSFZKITbQPwDuLsGKeSeuUDVsOSzdxWPyqacozUtISUHPvkU = 'uJAaKUBtZaXksJJdwmynnXgUlAZUNLaiomuirAvDrCglnirqndRFmtuYcrmQqqdd'
        if ewxUGodkMPmvzNiFdueblpiZvmBvkwDAFeMnQSPYeouPlWZbHEoPyeJNwsCmSCbH == IOtHJfOeMNTpJvSplGUuVcTDREYOHIcAnkhCkkfvDQzcSgtiOGzHziEXVvFfTAZL:
            xHQHMvtedlyNAvXbhGoKTbOEikQWrbTVBeeJGSotrgoJgvqRvtrnSXdoovOtBbtD = 'UAiyirXUDWKNhfYkPLysrZJANyHmsClCfXSHAwZcjIiFYXfpHjdzstMGpFdAtAwC'
            xHQHMvtedlyNAvXbhGoKTbOEikQWrbTVBeeJGSotrgoJgvqRvtrnSXdoovOtBbtD = ewxUGodkMPmvzNiFdueblpiZvmBvkwDAFeMnQSPYeouPlWZbHEoPyeJNwsCmSCbH
        else:
            xHQHMvtedlyNAvXbhGoKTbOEikQWrbTVBeeJGSotrgoJgvqRvtrnSXdoovOtBbtD = 'UAiyirXUDWKNhfYkPLysrZJANyHmsClCfXSHAwZcjIiFYXfpHjdzstMGpFdAtAwC'
            xHQHMvtedlyNAvXbhGoKTbOEikQWrbTVBeeJGSotrgoJgvqRvtrnSXdoovOtBbtD = qawiWlxYvqaejCEqfSFZKITbQPwDuLsGKeSeuUDVsOSzdxWPyqacozUtISUHPvkU
        return 'Error: URL must begin with http:// or https:// .'
    BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn = WJdoQXqxSEsaPLIVoWyJpEdnEKGToGFMLANrRgBzbkUzwfTZXxERXXykcDmJEinQ.split('/')[-1]
    if not BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn:
        WnrgiYDXLJYGhvrQOGjmlojtTiJkdKBtdGoXFEoIftnTJnANDfggJnoZeRxCkrth = 'pDBRdnpQVrwPVaptahDiNTjSzEPjMpREeuUGezGQlvlqcLjWXtbSLcQuqtmZWqPW'
        tfVXyalZxgajDoehDIVHiIlKUROmwSkGLFDZkhGIZALwCAdVnNoaWoyImuqtQyur = 'FZbaVYFDhkloKyAqTkeuaEmvHiDtZZorqNEXoczEXnmXKjeKKkeoqusWUSMcpRro'
        gnoDVXEakdaHhhFGLhxlIlpRbElwucCVRLqZHXHvcoxMAwHGtFhDgODFQaXboRez = 'hyASnKTvTWwdgjXpGVuLXVKtBjcLMEIDYCTNblBRakKtcvwrMNmmWPsEFlpnyUkU'
        bccEtNHaeURGukhVcPSjvYAGWYDVgVAGIqAwaoOCHbxXefesIapeeAZCpSZvHIjg = 'emilwrHcFTGKwrBafjKJJTtvLfFzgrYLPXiwgZEHLtqcPDyWLeqcOemaLWnncXlj'
        mQFLhWCbPByoYxOKZDFlRbZfeTDNFfTzZhJuHavQobPJFwAAHxGSvDchHxBUXocW = 'NosIEohkFmpJMVOYoezlTGqVJBbClyIEGyLxCrcsGHFUeuiJYBAoRLgvNvSvyKZU'
        if WnrgiYDXLJYGhvrQOGjmlojtTiJkdKBtdGoXFEoIftnTJnANDfggJnoZeRxCkrth in tfVXyalZxgajDoehDIVHiIlKUROmwSkGLFDZkhGIZALwCAdVnNoaWoyImuqtQyur:
            WnrgiYDXLJYGhvrQOGjmlojtTiJkdKBtdGoXFEoIftnTJnANDfggJnoZeRxCkrth = mQFLhWCbPByoYxOKZDFlRbZfeTDNFfTzZhJuHavQobPJFwAAHxGSvDchHxBUXocW
            if tfVXyalZxgajDoehDIVHiIlKUROmwSkGLFDZkhGIZALwCAdVnNoaWoyImuqtQyur in gnoDVXEakdaHhhFGLhxlIlpRbElwucCVRLqZHXHvcoxMAwHGtFhDgODFQaXboRez:
                tfVXyalZxgajDoehDIVHiIlKUROmwSkGLFDZkhGIZALwCAdVnNoaWoyImuqtQyur = bccEtNHaeURGukhVcPSjvYAGWYDVgVAGIqAwaoOCHbxXefesIapeeAZCpSZvHIjg
        elif tfVXyalZxgajDoehDIVHiIlKUROmwSkGLFDZkhGIZALwCAdVnNoaWoyImuqtQyur in WnrgiYDXLJYGhvrQOGjmlojtTiJkdKBtdGoXFEoIftnTJnANDfggJnoZeRxCkrth:
            gnoDVXEakdaHhhFGLhxlIlpRbElwucCVRLqZHXHvcoxMAwHGtFhDgODFQaXboRez = tfVXyalZxgajDoehDIVHiIlKUROmwSkGLFDZkhGIZALwCAdVnNoaWoyImuqtQyur
            if gnoDVXEakdaHhhFGLhxlIlpRbElwucCVRLqZHXHvcoxMAwHGtFhDgODFQaXboRez in tfVXyalZxgajDoehDIVHiIlKUROmwSkGLFDZkhGIZALwCAdVnNoaWoyImuqtQyur:
                tfVXyalZxgajDoehDIVHiIlKUROmwSkGLFDZkhGIZALwCAdVnNoaWoyImuqtQyur = mQFLhWCbPByoYxOKZDFlRbZfeTDNFfTzZhJuHavQobPJFwAAHxGSvDchHxBUXocW
        BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn = 'file-'.format(str(datetime.datetime.now()).replace(' ', '-'))
    try:
        orFOQySgzUTWPneKObbmJzgETIiMPOgWMSkLiGIACgFJSzGUGRDGvdBXTzhTKpvd = 'gcQnVDIKyMheoJxVDhuWjXjGUAJWnkWLOjTXlTLpCiMnUzCCBPmKtiJxeYBScEsV'
        qKxZeDXRTsjnOiHBBolEzfLvLbHiQxlMcELHUQsHkvvoglvbbzUXvGhWMBdpsTBf = 'oVOPlsfyAOSWvLTgzaMEexCZuIBQmFgUKPrHnzTQSMWXwzQJBJeHqKqrGFKgVTEQ'
        if orFOQySgzUTWPneKObbmJzgETIiMPOgWMSkLiGIACgFJSzGUGRDGvdBXTzhTKpvd != qKxZeDXRTsjnOiHBBolEzfLvLbHiQxlMcELHUQsHkvvoglvbbzUXvGhWMBdpsTBf:
            yHZpiThKmHNYZMBRKUwhzENXxBBIAoFsMyrAnLrAlTZGbeqtuxRJXfWskWMwMUdo = 'gjntuSAOdxgUahtPaFdCfhRTasEUtWhWsXOrAZfrICzRaUjAZmXxnmHzPlOvtWEV'
            bHDGUymoNcqirioGzoIXXUaPWGneBjoSYPiVDiLExMxyYbvNBkvIhSIlkEexGaxk = 'VdRsnTloXQrIFDCczzYwMFhVExSMocfYKhBXDkYTHswcmKDIxwUWyxpyoNmnOSft'
            bHDGUymoNcqirioGzoIXXUaPWGneBjoSYPiVDiLExMxyYbvNBkvIhSIlkEexGaxk = yHZpiThKmHNYZMBRKUwhzENXxBBIAoFsMyrAnLrAlTZGbeqtuxRJXfWskWMwMUdo
        urllib.urlretrieve(WJdoQXqxSEsaPLIVoWyJpEdnEKGToGFMLANrRgBzbkUzwfTZXxERXXykcDmJEinQ, BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn)
    except IOError:
        XXvliUAwRruvNOOIPBsqCkSSphsNddnOesrUxsmRYrFrddNbfYoRKTuEgjmPudvF = 'doEERVPihJWqqGzDQCtBvFwEgJnDwCyjQrqmErXcVCJQQudFNvxTtiiDCNlqeEud'
        WSrftsWNIdIqvkaUiKNqokozFrfYvjjpVcNlrFRSxqQQtsFFAUhvgMOGaMDWtJuK = 'JoEDngLOsRauHWiWQKifyHCzxKhbSdrRXdtoJtNmSJWpLRWFWImEPsrcLqpSVLGi'
        JkrnqNKYVFhZHTsowxDlyoxrYHTytDqZidqcwCDkTrYwuzXWJtgrszwpfdIqgjGe = 'miLGzWmVubqVqIHqkhVoVJkhFaFknRhmYwtBBNSPSXMoOhnIEFUPLJmibQkbmYNI'
        JGtIoPVAwSwFvfPsvLTgOCJnsbwfxbdmDowMlobiOPErHeHawYuPEUaLtIYQKwuf = 'TVGHoVHnvLrIyInfHMtaazDXLPDYDwWkrNfTFOETPogqPlqVDXvgTTPpjaLXzwwU'
        kLOXXHIKnbcOKnGKjzVOqwdjEKgAHcuTCoebYpyddzpJbrhsfjoeveGfGSnYTCMq = 'OhrXkIHJzyMjnoqJEvnUauMIRgmltuzyVvVzwwGWjjcNOwaMwFEWixWZSfqqGVgQ'
        DDGGBYuzRmtsnwgFbDeVKlBuEBDcQFyJaeVdCgWAscQLhphxMJZNjPpoDwGXRuXp = 'BLSkjGvPTcMjcVpWURfkrvKFxOHXwomlppeTpEFHVVctKPWSbUIiLPitWZWBPqnB'
        if XXvliUAwRruvNOOIPBsqCkSSphsNddnOesrUxsmRYrFrddNbfYoRKTuEgjmPudvF != JGtIoPVAwSwFvfPsvLTgOCJnsbwfxbdmDowMlobiOPErHeHawYuPEUaLtIYQKwuf:
            WSrftsWNIdIqvkaUiKNqokozFrfYvjjpVcNlrFRSxqQQtsFFAUhvgMOGaMDWtJuK = JkrnqNKYVFhZHTsowxDlyoxrYHTytDqZidqcwCDkTrYwuzXWJtgrszwpfdIqgjGe
            for DDGGBYuzRmtsnwgFbDeVKlBuEBDcQFyJaeVdCgWAscQLhphxMJZNjPpoDwGXRuXp in JGtIoPVAwSwFvfPsvLTgOCJnsbwfxbdmDowMlobiOPErHeHawYuPEUaLtIYQKwuf:
                if DDGGBYuzRmtsnwgFbDeVKlBuEBDcQFyJaeVdCgWAscQLhphxMJZNjPpoDwGXRuXp != JkrnqNKYVFhZHTsowxDlyoxrYHTytDqZidqcwCDkTrYwuzXWJtgrszwpfdIqgjGe:
                    WSrftsWNIdIqvkaUiKNqokozFrfYvjjpVcNlrFRSxqQQtsFFAUhvgMOGaMDWtJuK = WSrftsWNIdIqvkaUiKNqokozFrfYvjjpVcNlrFRSxqQQtsFFAUhvgMOGaMDWtJuK
                else:
                    kLOXXHIKnbcOKnGKjzVOqwdjEKgAHcuTCoebYpyddzpJbrhsfjoeveGfGSnYTCMq = XXvliUAwRruvNOOIPBsqCkSSphsNddnOesrUxsmRYrFrddNbfYoRKTuEgjmPudvF
        else:
            JkrnqNKYVFhZHTsowxDlyoxrYHTytDqZidqcwCDkTrYwuzXWJtgrszwpfdIqgjGe = XXvliUAwRruvNOOIPBsqCkSSphsNddnOesrUxsmRYrFrddNbfYoRKTuEgjmPudvF
            XXvliUAwRruvNOOIPBsqCkSSphsNddnOesrUxsmRYrFrddNbfYoRKTuEgjmPudvF = kLOXXHIKnbcOKnGKjzVOqwdjEKgAHcuTCoebYpyddzpJbrhsfjoeveGfGSnYTCMq
            if JkrnqNKYVFhZHTsowxDlyoxrYHTytDqZidqcwCDkTrYwuzXWJtgrszwpfdIqgjGe == XXvliUAwRruvNOOIPBsqCkSSphsNddnOesrUxsmRYrFrddNbfYoRKTuEgjmPudvF:
                for DDGGBYuzRmtsnwgFbDeVKlBuEBDcQFyJaeVdCgWAscQLhphxMJZNjPpoDwGXRuXp in XXvliUAwRruvNOOIPBsqCkSSphsNddnOesrUxsmRYrFrddNbfYoRKTuEgjmPudvF:
                    if DDGGBYuzRmtsnwgFbDeVKlBuEBDcQFyJaeVdCgWAscQLhphxMJZNjPpoDwGXRuXp == JkrnqNKYVFhZHTsowxDlyoxrYHTytDqZidqcwCDkTrYwuzXWJtgrszwpfdIqgjGe:
                        JkrnqNKYVFhZHTsowxDlyoxrYHTytDqZidqcwCDkTrYwuzXWJtgrszwpfdIqgjGe = XXvliUAwRruvNOOIPBsqCkSSphsNddnOesrUxsmRYrFrddNbfYoRKTuEgjmPudvF
                    else:
                        JkrnqNKYVFhZHTsowxDlyoxrYHTytDqZidqcwCDkTrYwuzXWJtgrszwpfdIqgjGe = kLOXXHIKnbcOKnGKjzVOqwdjEKgAHcuTCoebYpyddzpJbrhsfjoeveGfGSnYTCMq
        return 'Error: Download failed.'
    return 'File {} downloaded.'.format(BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn)
