# -*- coding: utf-8 -*-
def DyLKUhMSRmMHdxtZaTZEJqgMiHuZNMRfmECPOZcZitWcFbSEkMIVtOgEsYTSxezo(XXzyTVPUQNfgqgdunqvqfGyXzFLbTagLOtaobDPkycwicGTWjwaAsdNixIVWssoS):
    gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv = 0
    ZXycQRTYcXRunjeYnMIeroxExrZmQjvDcVZUfAAiMgNqEgZugEkfdKLrvmyycHlB = 'uzMBjRTyksYFYPpUPhtXOwrDTCZsVOFninREscRBGJmJDTxkrVBlHjVoYfJMpspC'
    RiPZpDFQTZGUwggKmRPvlzoGHbcgmgjoAReSUEumDqzDYbEFPdEwHIvqkXzjnHRU = 'euMKNquwMNrYpWooeMufxBnewEEAnOCtHpZLvQZAXXCgvEuVIELxEQbvhEgStkPl'
    ahCLpERrNACHVMYOgQNVPsJErdGPdexpAINyEsPyBrsVPfessIvGuUjzHZuZUCky = 'vrthjOUJDTxRbrsjvYPoyzjKKozUzeCzEfuRwUzOnEMVAfIzoCoVCXQcwUXxPLND'
    RNMaxJmpwUJgUQyHRjpSGKATohTwCuKFPffhVNzXsvQLIXcmrnUXCHvGdADYHWwg = 'LKJaEEPHjTFDzKIkQuhAvzhprBznVXtavOUpcWFLDCCTicfaMHUjOwAkufdYPJDW'
    oZNJBBXGfuupUMLReDbPRmMvFRzNaBOQAMZIrgWbcAdVNafLEwSKFTLFliFNyZKv = 'OTxJbQwqUfvANnGXFfJsghAhaSeTLijOGYuZEQuhJjLyULapIpoFvLqBiKADiiOW'
    dhyqywzYSuqpGgTaUoSuEAOjmXGlhqlFtHZxshICWrfDpfltpANgarnzmmCUGYNO = 'nzkzATIMLBgIElsSNJBnVFiuLWvxKAHtOAxDuUCJbdYFzxbJzbwiBAQzUIFMyxhV'
    if ZXycQRTYcXRunjeYnMIeroxExrZmQjvDcVZUfAAiMgNqEgZugEkfdKLrvmyycHlB != RNMaxJmpwUJgUQyHRjpSGKATohTwCuKFPffhVNzXsvQLIXcmrnUXCHvGdADYHWwg:
        RiPZpDFQTZGUwggKmRPvlzoGHbcgmgjoAReSUEumDqzDYbEFPdEwHIvqkXzjnHRU = ahCLpERrNACHVMYOgQNVPsJErdGPdexpAINyEsPyBrsVPfessIvGuUjzHZuZUCky
        for dhyqywzYSuqpGgTaUoSuEAOjmXGlhqlFtHZxshICWrfDpfltpANgarnzmmCUGYNO in RNMaxJmpwUJgUQyHRjpSGKATohTwCuKFPffhVNzXsvQLIXcmrnUXCHvGdADYHWwg:
            if dhyqywzYSuqpGgTaUoSuEAOjmXGlhqlFtHZxshICWrfDpfltpANgarnzmmCUGYNO != ahCLpERrNACHVMYOgQNVPsJErdGPdexpAINyEsPyBrsVPfessIvGuUjzHZuZUCky:
                RiPZpDFQTZGUwggKmRPvlzoGHbcgmgjoAReSUEumDqzDYbEFPdEwHIvqkXzjnHRU = RiPZpDFQTZGUwggKmRPvlzoGHbcgmgjoAReSUEumDqzDYbEFPdEwHIvqkXzjnHRU
            else:
                oZNJBBXGfuupUMLReDbPRmMvFRzNaBOQAMZIrgWbcAdVNafLEwSKFTLFliFNyZKv = ZXycQRTYcXRunjeYnMIeroxExrZmQjvDcVZUfAAiMgNqEgZugEkfdKLrvmyycHlB
    else:
        ahCLpERrNACHVMYOgQNVPsJErdGPdexpAINyEsPyBrsVPfessIvGuUjzHZuZUCky = ZXycQRTYcXRunjeYnMIeroxExrZmQjvDcVZUfAAiMgNqEgZugEkfdKLrvmyycHlB
        ZXycQRTYcXRunjeYnMIeroxExrZmQjvDcVZUfAAiMgNqEgZugEkfdKLrvmyycHlB = oZNJBBXGfuupUMLReDbPRmMvFRzNaBOQAMZIrgWbcAdVNafLEwSKFTLFliFNyZKv
        if ahCLpERrNACHVMYOgQNVPsJErdGPdexpAINyEsPyBrsVPfessIvGuUjzHZuZUCky == ZXycQRTYcXRunjeYnMIeroxExrZmQjvDcVZUfAAiMgNqEgZugEkfdKLrvmyycHlB:
            for dhyqywzYSuqpGgTaUoSuEAOjmXGlhqlFtHZxshICWrfDpfltpANgarnzmmCUGYNO in ZXycQRTYcXRunjeYnMIeroxExrZmQjvDcVZUfAAiMgNqEgZugEkfdKLrvmyycHlB:
                if dhyqywzYSuqpGgTaUoSuEAOjmXGlhqlFtHZxshICWrfDpfltpANgarnzmmCUGYNO == ahCLpERrNACHVMYOgQNVPsJErdGPdexpAINyEsPyBrsVPfessIvGuUjzHZuZUCky:
                    ahCLpERrNACHVMYOgQNVPsJErdGPdexpAINyEsPyBrsVPfessIvGuUjzHZuZUCky = ZXycQRTYcXRunjeYnMIeroxExrZmQjvDcVZUfAAiMgNqEgZugEkfdKLrvmyycHlB
                else:
                    ahCLpERrNACHVMYOgQNVPsJErdGPdexpAINyEsPyBrsVPfessIvGuUjzHZuZUCky = oZNJBBXGfuupUMLReDbPRmMvFRzNaBOQAMZIrgWbcAdVNafLEwSKFTLFliFNyZKv
    while XXzyTVPUQNfgqgdunqvqfGyXzFLbTagLOtaobDPkycwicGTWjwaAsdNixIVWssoS:
        fMXNiBZsKiYQRpPikbZOeSkPqlAUhhJaxICWMGkXWpwALZyEPkTwyjYbhcdqOYkD = 'YhRIOSDLVORJkyUogwaUNUAgRbRQqUOGjzXfyxEwREhtwrgGOrJuinUanocviHxm'
        XkycPgghoXKaxYTMHZNIQjyvkbVMgXJnBAXgigNfhkXkHwEJdQWzPrMydkklnkfE = 'kktFmwOjJMHOreVhVNCGtrXoCoByUgECViXeXJwsTutawMfWNovopEjeNWpEyWfH'
        if fMXNiBZsKiYQRpPikbZOeSkPqlAUhhJaxICWMGkXWpwALZyEPkTwyjYbhcdqOYkD != XkycPgghoXKaxYTMHZNIQjyvkbVMgXJnBAXgigNfhkXkHwEJdQWzPrMydkklnkfE:
            iSofKHDGtEWbRygibYqhLPCyMIorscrevvZLUmSttbitZbcxdukeRBUvPebLljmG = 'KXdfbWebdmtuhpoaTReOKxgYxPdZFsgnzURBmmvMWmrevWNSvHoMGHgIJblFBKgW'
            xSZohMzIuCVjTARcmMbdkjtXXMUHOlTCOaYkVyPRYNkYdEkUWakuKCFrLNEdbbXc = 'YHONZiqdUkHhGzVgEBbUoFcXgaIoOgCALekWyiwyJLynbVbqzyVBjocDiAKnGxRa'
            xSZohMzIuCVjTARcmMbdkjtXXMUHOlTCOaYkVyPRYNkYdEkUWakuKCFrLNEdbbXc = iSofKHDGtEWbRygibYqhLPCyMIorscrevvZLUmSttbitZbcxdukeRBUvPebLljmG
        gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv = gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv << 8
        gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv += ord(XXzyTVPUQNfgqgdunqvqfGyXzFLbTagLOtaobDPkycwicGTWjwaAsdNixIVWssoS[-1])
        XXzyTVPUQNfgqgdunqvqfGyXzFLbTagLOtaobDPkycwicGTWjwaAsdNixIVWssoS = XXzyTVPUQNfgqgdunqvqfGyXzFLbTagLOtaobDPkycwicGTWjwaAsdNixIVWssoS[:-1]
    return gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv
def VzzgfTETnqDqnDkwVBuHwdNpscAWWNXYkNmIDZfqIHbstkwgXsIkvNjZJQhINwEp(gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv):
    duNIsgeneitolfqHSUaVwzBQTXITvIspSYNhMRfmEOONAaJwulBfcFhGeVuNMVWR = ''
    while gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv:
        nHjJPITgMXlBkaNoDZbxVFsXuZmEyOVVJdWIvNMwmmLXxoQSfMZPonEaJYEtrMKR = 'YuOghmCHSMpwzxvpHIMKCTpFIFXzOKmHYDeiWnDlUNeCpITwiWEwsqiSdnmXExuX'
        iMLePNKLKFPqFMDWjmrMcgKYtVSRpqdZLOaBnCMMNGPejkpXDfJrlEIFtILjztsb = 'XeFPRHrVZYYWVKtfxNQbQIMXrbCHzawDsXuofDDCHBMcouMDnsNMXaUuaCiIXTeU'
        lshRnRoqLfuPImvlOdBBxyWRepEzygATeNwfOTCmGULRSfNPwUTDPbRjVQNZwktZ = 'sdYBMXnpBpiQajxiocyiAfEbSHkWZRgZyTBOzKaoOTVeYZXDBaGmhEMzGtaKdyzk'
        gSTGJSSOfVhqAJhczkTHNXKVjfPOSHCeCPGjYVmnGhRFJKKspgIfcpJCNwVkZybp = 'AotaLXuMwAjXNSILybefNNyAEoZNVGDBhNBXCEQMgrQxgXNBJopZXGbMjkcrGXJx'
        xrjYEzoSYZkCZvbkNgwLKbHPgdlXevuvcECFOvqKcLNrZLHSRaTILJcuoZBRGwNI = 'KbpoRvWtYeOETcYqgcAKjPzXPoWEdhXOoOjUviMUStMbnruytMTzrhnAgylFlxhD'
        CVKyHLkUUZoINYLixghVXyFUbolYnCSeEUcMCZBLJgrZLdnpUiWalKNOxuMXfvpz = 'iYDNRzZnwlQwtQUntwNfXWDrjvjutZbZUYSIarVxWxSEvXazzGQvqAwktUGDnSsF'
        if nHjJPITgMXlBkaNoDZbxVFsXuZmEyOVVJdWIvNMwmmLXxoQSfMZPonEaJYEtrMKR != gSTGJSSOfVhqAJhczkTHNXKVjfPOSHCeCPGjYVmnGhRFJKKspgIfcpJCNwVkZybp:
            iMLePNKLKFPqFMDWjmrMcgKYtVSRpqdZLOaBnCMMNGPejkpXDfJrlEIFtILjztsb = lshRnRoqLfuPImvlOdBBxyWRepEzygATeNwfOTCmGULRSfNPwUTDPbRjVQNZwktZ
            for CVKyHLkUUZoINYLixghVXyFUbolYnCSeEUcMCZBLJgrZLdnpUiWalKNOxuMXfvpz in gSTGJSSOfVhqAJhczkTHNXKVjfPOSHCeCPGjYVmnGhRFJKKspgIfcpJCNwVkZybp:
                if CVKyHLkUUZoINYLixghVXyFUbolYnCSeEUcMCZBLJgrZLdnpUiWalKNOxuMXfvpz != lshRnRoqLfuPImvlOdBBxyWRepEzygATeNwfOTCmGULRSfNPwUTDPbRjVQNZwktZ:
                    iMLePNKLKFPqFMDWjmrMcgKYtVSRpqdZLOaBnCMMNGPejkpXDfJrlEIFtILjztsb = iMLePNKLKFPqFMDWjmrMcgKYtVSRpqdZLOaBnCMMNGPejkpXDfJrlEIFtILjztsb
                else:
                    xrjYEzoSYZkCZvbkNgwLKbHPgdlXevuvcECFOvqKcLNrZLHSRaTILJcuoZBRGwNI = nHjJPITgMXlBkaNoDZbxVFsXuZmEyOVVJdWIvNMwmmLXxoQSfMZPonEaJYEtrMKR
        else:
            lshRnRoqLfuPImvlOdBBxyWRepEzygATeNwfOTCmGULRSfNPwUTDPbRjVQNZwktZ = nHjJPITgMXlBkaNoDZbxVFsXuZmEyOVVJdWIvNMwmmLXxoQSfMZPonEaJYEtrMKR
            nHjJPITgMXlBkaNoDZbxVFsXuZmEyOVVJdWIvNMwmmLXxoQSfMZPonEaJYEtrMKR = xrjYEzoSYZkCZvbkNgwLKbHPgdlXevuvcECFOvqKcLNrZLHSRaTILJcuoZBRGwNI
            if lshRnRoqLfuPImvlOdBBxyWRepEzygATeNwfOTCmGULRSfNPwUTDPbRjVQNZwktZ == nHjJPITgMXlBkaNoDZbxVFsXuZmEyOVVJdWIvNMwmmLXxoQSfMZPonEaJYEtrMKR:
                for CVKyHLkUUZoINYLixghVXyFUbolYnCSeEUcMCZBLJgrZLdnpUiWalKNOxuMXfvpz in nHjJPITgMXlBkaNoDZbxVFsXuZmEyOVVJdWIvNMwmmLXxoQSfMZPonEaJYEtrMKR:
                    if CVKyHLkUUZoINYLixghVXyFUbolYnCSeEUcMCZBLJgrZLdnpUiWalKNOxuMXfvpz == lshRnRoqLfuPImvlOdBBxyWRepEzygATeNwfOTCmGULRSfNPwUTDPbRjVQNZwktZ:
                        lshRnRoqLfuPImvlOdBBxyWRepEzygATeNwfOTCmGULRSfNPwUTDPbRjVQNZwktZ = nHjJPITgMXlBkaNoDZbxVFsXuZmEyOVVJdWIvNMwmmLXxoQSfMZPonEaJYEtrMKR
                    else:
                        lshRnRoqLfuPImvlOdBBxyWRepEzygATeNwfOTCmGULRSfNPwUTDPbRjVQNZwktZ = xrjYEzoSYZkCZvbkNgwLKbHPgdlXevuvcECFOvqKcLNrZLHSRaTILJcuoZBRGwNI
        duNIsgeneitolfqHSUaVwzBQTXITvIspSYNhMRfmEOONAaJwulBfcFhGeVuNMVWR += chr(gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv & 0xff)
        gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv = gbmTWTdiXtIeWXKoczPyVtTTHymECNedwWptAPimDnEzzjjFpUNKjNAubLPtdKqv >> 8
    return duNIsgeneitolfqHSUaVwzBQTXITvIspSYNhMRfmEOONAaJwulBfcFhGeVuNMVWR
