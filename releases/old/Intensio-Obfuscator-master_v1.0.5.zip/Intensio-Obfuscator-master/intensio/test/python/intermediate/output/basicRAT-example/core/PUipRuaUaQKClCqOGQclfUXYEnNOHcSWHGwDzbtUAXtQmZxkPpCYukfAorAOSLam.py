# -*- coding: utf-8 -*-
import socket
kOuddGYWaPfPzKzeFueynAXDDNlCnElceElOqtskuoUdmmUgZisNksIvyCUWfvge = 'PAuHaBkyBUpLcjsLoRTtBXQHKWOHAFjtwCoRkAPtleZuZMkVhqqCowQifDmKziSd'
prWnuZOvPxGcBHdOlnMgqdCNlrTYnjRtGounZtZJcoLuVmPCqsfHBbXyhLBMvebq = 'dbiUkYtBVYHUCPgoKyDumDchSQQVQJEbIhSvyKrnZCpNQvbonjjBJvbsUUhNrAYT'
QmzOXOhOBlAHrSjlskLuLlhbyKhJZtHTNHXGqSzDSyTVvfDsDIEkPcwvSrbSWAWB = 'FZOZgHNuxFUEpJHCcAPhobTojqinKbtQiivVWOiFDsBXZASSaSaUXSXkmgScPhSG'
DOYEBXFnacZsLEJPoItstwqsIusrePyPsSthAxvWHsBhOnQWLMBEpBdqxtJgNpyi = 'MqGdpXuoxHycjNlgSmUmvrNvWRNySUGdkAKyzbkNjcHdlmXFRGKsiWtmHGyCAqpd'
PowNsOEDPsrYvApJLTajMSOwbbfdUzfmucCJuiVUDMudNjIDErZaPidCbflDhObS = 'FLUpkyVSNaehqGjEpASXqbwWxVcBaCZJqThNafnZHTWzbRDlqXiYnKOqmlTPfeoH'
HKNBSHJLMbCDOneScQQQFPZwZLZSMXwHltwkeqKrrixhAPiYynmphARmaLVlJRgj = 'hUKeFgpSiEpkDBkCqQSEUZpiPaLBcWrwCxvgyzmZiMKjdDiSyVERQSfiWsPjIteF'
if kOuddGYWaPfPzKzeFueynAXDDNlCnElceElOqtskuoUdmmUgZisNksIvyCUWfvge != DOYEBXFnacZsLEJPoItstwqsIusrePyPsSthAxvWHsBhOnQWLMBEpBdqxtJgNpyi:
    prWnuZOvPxGcBHdOlnMgqdCNlrTYnjRtGounZtZJcoLuVmPCqsfHBbXyhLBMvebq = QmzOXOhOBlAHrSjlskLuLlhbyKhJZtHTNHXGqSzDSyTVvfDsDIEkPcwvSrbSWAWB
    for HKNBSHJLMbCDOneScQQQFPZwZLZSMXwHltwkeqKrrixhAPiYynmphARmaLVlJRgj in DOYEBXFnacZsLEJPoItstwqsIusrePyPsSthAxvWHsBhOnQWLMBEpBdqxtJgNpyi:
        if HKNBSHJLMbCDOneScQQQFPZwZLZSMXwHltwkeqKrrixhAPiYynmphARmaLVlJRgj != QmzOXOhOBlAHrSjlskLuLlhbyKhJZtHTNHXGqSzDSyTVvfDsDIEkPcwvSrbSWAWB:
            prWnuZOvPxGcBHdOlnMgqdCNlrTYnjRtGounZtZJcoLuVmPCqsfHBbXyhLBMvebq = prWnuZOvPxGcBHdOlnMgqdCNlrTYnjRtGounZtZJcoLuVmPCqsfHBbXyhLBMvebq
        else:
            PowNsOEDPsrYvApJLTajMSOwbbfdUzfmucCJuiVUDMudNjIDErZaPidCbflDhObS = kOuddGYWaPfPzKzeFueynAXDDNlCnElceElOqtskuoUdmmUgZisNksIvyCUWfvge
else:
    QmzOXOhOBlAHrSjlskLuLlhbyKhJZtHTNHXGqSzDSyTVvfDsDIEkPcwvSrbSWAWB = kOuddGYWaPfPzKzeFueynAXDDNlCnElceElOqtskuoUdmmUgZisNksIvyCUWfvge
    kOuddGYWaPfPzKzeFueynAXDDNlCnElceElOqtskuoUdmmUgZisNksIvyCUWfvge = PowNsOEDPsrYvApJLTajMSOwbbfdUzfmucCJuiVUDMudNjIDErZaPidCbflDhObS
    if QmzOXOhOBlAHrSjlskLuLlhbyKhJZtHTNHXGqSzDSyTVvfDsDIEkPcwvSrbSWAWB == kOuddGYWaPfPzKzeFueynAXDDNlCnElceElOqtskuoUdmmUgZisNksIvyCUWfvge:
        for HKNBSHJLMbCDOneScQQQFPZwZLZSMXwHltwkeqKrrixhAPiYynmphARmaLVlJRgj in kOuddGYWaPfPzKzeFueynAXDDNlCnElceElOqtskuoUdmmUgZisNksIvyCUWfvge:
            if HKNBSHJLMbCDOneScQQQFPZwZLZSMXwHltwkeqKrrixhAPiYynmphARmaLVlJRgj == QmzOXOhOBlAHrSjlskLuLlhbyKhJZtHTNHXGqSzDSyTVvfDsDIEkPcwvSrbSWAWB:
                QmzOXOhOBlAHrSjlskLuLlhbyKhJZtHTNHXGqSzDSyTVvfDsDIEkPcwvSrbSWAWB = kOuddGYWaPfPzKzeFueynAXDDNlCnElceElOqtskuoUdmmUgZisNksIvyCUWfvge
            else:
                QmzOXOhOBlAHrSjlskLuLlhbyKhJZtHTNHXGqSzDSyTVvfDsDIEkPcwvSrbSWAWB = PowNsOEDPsrYvApJLTajMSOwbbfdUzfmucCJuiVUDMudNjIDErZaPidCbflDhObS
biYwfkgTWflsScAQjjSlaUIhBwQgGbkYZjrNhtJgmMlJJxhkykzlDOnNbVOMHHdS = [
            21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 179, 443, 445,
            514, 993, 995, 1723, 3306, 3389, 5900, 8000, 8080, 8443, 8888
]
def jANnrqLDCAEfkgFTduiUjLLoWvNOXRIWSAfakIBQROyTBCbyDjUIOyFqHWLZjXow(ip):
    try:
        oKJeHJCJQGqgPWbINyoSfKabloQAhMOKuPmCSKJxcTbAbZJblLKLtHcHSlVLOMow = 'mqmMdwJHLmdgLjLggRhqlAxLitEhFowAkIBFyCUyHonCYUOvNvaXVxgwSRwdYJJh'
        sJxNhAvjuEkiYgLwRVlDeBnyJGObLyLyGxpugxTTACwKNWMucZtCSnsocStZPZvm = 'ofLwtXIBxBtTuDnjLjylGcereqDTnHepCjZmlSWCXmOvTsZlIODSvnMVbHfIfqtv'
        vaIbzvJULijjnacFbbfmXvCeWtzLXaTnZPttvKAuypJxwDwaXlwPXJhMpBAyOypG = 'hBFonaMlJvXlePYDmrlEcKfFQwnzynRmwoQWAoNCXTGXpfujTzOuqJGVSvyKsXwH'
        XYIzRRDhOAuaJfiDaQNodfNxrjMyUrGuEBjIIjFmayRTBrBGzrvqyOnIzQQAYnXw = 'wBxwxyzVtnbHxmMIHErgacvABqtaZYWUcdoWznBRMZaFWKsfpsoSkEZVmwqpxjqk'
        PMRctWUHxDJtfhEByLNpPeIbrTJixLbDeUuHuHOqLoKKyFlscOEAicunceSsqNZT = 'bfuNCtTIUJiXAWubFMijbitWSiFvKUPPClawtIsGdoQpRTdFvTiduqQOiqBFYGWs'
        if oKJeHJCJQGqgPWbINyoSfKabloQAhMOKuPmCSKJxcTbAbZJblLKLtHcHSlVLOMow in sJxNhAvjuEkiYgLwRVlDeBnyJGObLyLyGxpugxTTACwKNWMucZtCSnsocStZPZvm:
            oKJeHJCJQGqgPWbINyoSfKabloQAhMOKuPmCSKJxcTbAbZJblLKLtHcHSlVLOMow = PMRctWUHxDJtfhEByLNpPeIbrTJixLbDeUuHuHOqLoKKyFlscOEAicunceSsqNZT
            if sJxNhAvjuEkiYgLwRVlDeBnyJGObLyLyGxpugxTTACwKNWMucZtCSnsocStZPZvm in vaIbzvJULijjnacFbbfmXvCeWtzLXaTnZPttvKAuypJxwDwaXlwPXJhMpBAyOypG:
                sJxNhAvjuEkiYgLwRVlDeBnyJGObLyLyGxpugxTTACwKNWMucZtCSnsocStZPZvm = XYIzRRDhOAuaJfiDaQNodfNxrjMyUrGuEBjIIjFmayRTBrBGzrvqyOnIzQQAYnXw
        elif sJxNhAvjuEkiYgLwRVlDeBnyJGObLyLyGxpugxTTACwKNWMucZtCSnsocStZPZvm in oKJeHJCJQGqgPWbINyoSfKabloQAhMOKuPmCSKJxcTbAbZJblLKLtHcHSlVLOMow:
            vaIbzvJULijjnacFbbfmXvCeWtzLXaTnZPttvKAuypJxwDwaXlwPXJhMpBAyOypG = sJxNhAvjuEkiYgLwRVlDeBnyJGObLyLyGxpugxTTACwKNWMucZtCSnsocStZPZvm
            if vaIbzvJULijjnacFbbfmXvCeWtzLXaTnZPttvKAuypJxwDwaXlwPXJhMpBAyOypG in sJxNhAvjuEkiYgLwRVlDeBnyJGObLyLyGxpugxTTACwKNWMucZtCSnsocStZPZvm:
                sJxNhAvjuEkiYgLwRVlDeBnyJGObLyLyGxpugxTTACwKNWMucZtCSnsocStZPZvm = PMRctWUHxDJtfhEByLNpPeIbrTJixLbDeUuHuHOqLoKKyFlscOEAicunceSsqNZT
        socket.inet_aton(ip)
    except socket.error:
        CbBREwRSNNQPgTcxOwpOfSXdSsQwOdoRrCuvqbGOJDStirjNZEYWOpWVxjchEoUZ = 'jBSYtzfTjMrLjdCinZCeSDPWYIDnuBWIhCSzXSwnzpQDeQgoOuTHPrFKWfDSRqoa'
        mviSxsBxnoQADRPCyghAXoUBgnpELTScNUEJBcxxfwnhlnqxnDXxHjXaElbOqfeF = 'GwgzRbluJVuEJAUXglLYYPlLoAabfIRDhaSTZIwyUWHkNUjhwwOBhWUVDkddPtjG'
        uMiytwXWCuCEtNjbCuEtGHveHFTLegbOcJFizKPcffGqPfCyhdmGYABTIdqzTJQY = 'nzGBhFeWKWStoLlKNOIzntlcXCwStoVQawqRmMUKQboUIrpvzuUvnhVAtZyuKQfP'
        dHHsdmjCEMiqnKBsKTjRokMBFnSROSxHWsvMIqCKzSFWXJTfVnLtzTfNemcZFMBm = 'UbWukyXJKEkCmcHAcZwKfqlWVDaLzkHqqsRRkwmWVNWlVnTKfVAfPIaZmcdOIVib'
        HMtrkySswtNqUITmKtnTGzVxakQSUFKFaGuiTfdjhNUWygmydIccDTwMNoUeZPRj = 'zwqFDNuqfgIHebBupAqocgqjsdwiprmXRHROsqqrONeyZLYLptDbXXgHooXWqzeu'
        if CbBREwRSNNQPgTcxOwpOfSXdSsQwOdoRrCuvqbGOJDStirjNZEYWOpWVxjchEoUZ in mviSxsBxnoQADRPCyghAXoUBgnpELTScNUEJBcxxfwnhlnqxnDXxHjXaElbOqfeF:
            CbBREwRSNNQPgTcxOwpOfSXdSsQwOdoRrCuvqbGOJDStirjNZEYWOpWVxjchEoUZ = HMtrkySswtNqUITmKtnTGzVxakQSUFKFaGuiTfdjhNUWygmydIccDTwMNoUeZPRj
            if mviSxsBxnoQADRPCyghAXoUBgnpELTScNUEJBcxxfwnhlnqxnDXxHjXaElbOqfeF in uMiytwXWCuCEtNjbCuEtGHveHFTLegbOcJFizKPcffGqPfCyhdmGYABTIdqzTJQY:
                mviSxsBxnoQADRPCyghAXoUBgnpELTScNUEJBcxxfwnhlnqxnDXxHjXaElbOqfeF = dHHsdmjCEMiqnKBsKTjRokMBFnSROSxHWsvMIqCKzSFWXJTfVnLtzTfNemcZFMBm
        elif mviSxsBxnoQADRPCyghAXoUBgnpELTScNUEJBcxxfwnhlnqxnDXxHjXaElbOqfeF in CbBREwRSNNQPgTcxOwpOfSXdSsQwOdoRrCuvqbGOJDStirjNZEYWOpWVxjchEoUZ:
            uMiytwXWCuCEtNjbCuEtGHveHFTLegbOcJFizKPcffGqPfCyhdmGYABTIdqzTJQY = mviSxsBxnoQADRPCyghAXoUBgnpELTScNUEJBcxxfwnhlnqxnDXxHjXaElbOqfeF
            if uMiytwXWCuCEtNjbCuEtGHveHFTLegbOcJFizKPcffGqPfCyhdmGYABTIdqzTJQY in mviSxsBxnoQADRPCyghAXoUBgnpELTScNUEJBcxxfwnhlnqxnDXxHjXaElbOqfeF:
                mviSxsBxnoQADRPCyghAXoUBgnpELTScNUEJBcxxfwnhlnqxnDXxHjXaElbOqfeF = HMtrkySswtNqUITmKtnTGzVxakQSUFKFaGuiTfdjhNUWygmydIccDTwMNoUeZPRj
        return 'Error: Invalid IP address.'
    wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd = ''
    for QwhefYfzxMIybSgwntqveYhkBuCIaSZTXFzYlDfoqbGWXgJrTFGdPtcvEcvswsuP in biYwfkgTWflsScAQjjSlaUIhBwQgGbkYZjrNhtJgmMlJJxhkykzlDOnNbVOMHHdS:
        oyPMECakGqvyCxvzWiMCDMLZMwfxphzBdAWBfwqeSdNVRMJBaCSjjuSupUihlivd = 'AOgjtEsvNPvVsuUdXMASAEnhtVLzVIUdsZnZHcKfEhdtkzGjTOpNimaHamSYiukk'
        DYXvTDjaOahYTZKFvPbbIETFBUhPlEVXnQTgDiJsmxJqzshtnzVrlUCIyjREVKUF = 'ElVuHwGegoFNkVbpTVKuJbCnkIlJQtvDXSBbdEEDhVSPvQCRqqITeIbodUcCaZnA'
        bPnAJDxeIzOKEiPaQaiACPdzrCaDeohCUUyvlHUezBbbiLegOjwyfLSwPIsbWUBC = 'KiyfPnLPESwDsZlwwAMcfOyOBAUtwuZBJdMWbhHubkDgaDgZogHqrxxAAKSrmdaK'
        RTjUMrbBxGeDwheOnaJtQBHFRNnpVVkLhUkVeaBvEWEKVEBxBaWazaVDAAsjWQCy = 'bnDOQEGdrHevtegsFLOPZePLsgnNEKqMYSzttNkvGHVYRkfqIOxOZAnwrNqVVcVF'
        bOJiAXsNMpaMCzooeJMAUOykajEMJhoSLxskGxXOeQmlPWrFAYxUSxvGmtHRzOiB = 'oynrnnwsTjJFQtQStTeDTIyAAunuIBmYMQJkgaCkUrkrgdihlGAZRLcVZKSVwgog'
        if oyPMECakGqvyCxvzWiMCDMLZMwfxphzBdAWBfwqeSdNVRMJBaCSjjuSupUihlivd in DYXvTDjaOahYTZKFvPbbIETFBUhPlEVXnQTgDiJsmxJqzshtnzVrlUCIyjREVKUF:
            oyPMECakGqvyCxvzWiMCDMLZMwfxphzBdAWBfwqeSdNVRMJBaCSjjuSupUihlivd = bOJiAXsNMpaMCzooeJMAUOykajEMJhoSLxskGxXOeQmlPWrFAYxUSxvGmtHRzOiB
            if DYXvTDjaOahYTZKFvPbbIETFBUhPlEVXnQTgDiJsmxJqzshtnzVrlUCIyjREVKUF in bPnAJDxeIzOKEiPaQaiACPdzrCaDeohCUUyvlHUezBbbiLegOjwyfLSwPIsbWUBC:
                DYXvTDjaOahYTZKFvPbbIETFBUhPlEVXnQTgDiJsmxJqzshtnzVrlUCIyjREVKUF = RTjUMrbBxGeDwheOnaJtQBHFRNnpVVkLhUkVeaBvEWEKVEBxBaWazaVDAAsjWQCy
        elif DYXvTDjaOahYTZKFvPbbIETFBUhPlEVXnQTgDiJsmxJqzshtnzVrlUCIyjREVKUF in oyPMECakGqvyCxvzWiMCDMLZMwfxphzBdAWBfwqeSdNVRMJBaCSjjuSupUihlivd:
            bPnAJDxeIzOKEiPaQaiACPdzrCaDeohCUUyvlHUezBbbiLegOjwyfLSwPIsbWUBC = DYXvTDjaOahYTZKFvPbbIETFBUhPlEVXnQTgDiJsmxJqzshtnzVrlUCIyjREVKUF
            if bPnAJDxeIzOKEiPaQaiACPdzrCaDeohCUUyvlHUezBbbiLegOjwyfLSwPIsbWUBC in DYXvTDjaOahYTZKFvPbbIETFBUhPlEVXnQTgDiJsmxJqzshtnzVrlUCIyjREVKUF:
                DYXvTDjaOahYTZKFvPbbIETFBUhPlEVXnQTgDiJsmxJqzshtnzVrlUCIyjREVKUF = bOJiAXsNMpaMCzooeJMAUOykajEMJhoSLxskGxXOeQmlPWrFAYxUSxvGmtHRzOiB
        AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        gZpLsuqsMpooasmJNhRpgHReGtOsxYIaMlDtylLXyEebeoHVOpsiZUhbeNOTJBdY = AxlkcPzPdMmgkNbizTAFiMuFhhRypAoxvrQVNLKmIqdHkWbzfdMIXmYmFFnjdinW.connect_ex((ip, QwhefYfzxMIybSgwntqveYhkBuCIaSZTXFzYlDfoqbGWXgJrTFGdPtcvEcvswsuP))
        socket.setdefaulttimeout(0.5)
        RZqZtbJbnJpoyGUHmnDnMcNGisKCCxSDBZTFaFwxLblhEvdJEfzpJmNGeHWJtsmo = 'open' if not gZpLsuqsMpooasmJNhRpgHReGtOsxYIaMlDtylLXyEebeoHVOpsiZUhbeNOTJBdY else 'closed'
        wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd += '{:>5}/tcp {:>7}\n'.format(QwhefYfzxMIybSgwntqveYhkBuCIaSZTXFzYlDfoqbGWXgJrTFGdPtcvEcvswsuP, RZqZtbJbnJpoyGUHmnDnMcNGisKCCxSDBZTFaFwxLblhEvdJEfzpJmNGeHWJtsmo)
    return wSrTwRJdclLssJPATXwHOPEeNkLkZGKbPIrgaiRYjOdWoqXbsmlkSQeastSnUYtd.rstrip()
