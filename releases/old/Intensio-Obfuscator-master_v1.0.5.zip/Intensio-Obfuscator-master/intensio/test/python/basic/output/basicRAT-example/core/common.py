# -*- coding: utf-8 -*-
def oQCtrrsXiorvXWPMkHrVwrWxAVkRAumh(MzjOivKyPKdILiznBreBuHCFLDBOavRE):
    yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC = 0
    while MzjOivKyPKdILiznBreBuHCFLDBOavRE:
        yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC = yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC << 8
        yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC += ord(MzjOivKyPKdILiznBreBuHCFLDBOavRE[-1])
        MzjOivKyPKdILiznBreBuHCFLDBOavRE = MzjOivKyPKdILiznBreBuHCFLDBOavRE[:-1]
    return yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC
def VRvIwKxuUZdGqypLAwFYJJOaqDQUkMiZ(yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC):
    lompryqHrKqfzOTTbxmSaDXZQYkYgePJ = ''
    while yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC:
        lompryqHrKqfzOTTbxmSaDXZQYkYgePJ += chr(yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC & 0xff)
        yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC = yUgtagPEWgZFwMNcuvyhbmhzBzVoIpvC >> 8
    return lompryqHrKqfzOTTbxmSaDXZQYkYgePJ
