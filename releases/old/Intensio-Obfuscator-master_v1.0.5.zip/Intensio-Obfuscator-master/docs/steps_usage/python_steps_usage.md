# Steps usage

1) Put your source code in directory dedicated at your project (directory source will scanned and obfuscated recursively)
2) Create empty directory for output code obfuscated
3) Read all the practices of coding that be ought respect absolutely [recommendations](../../docs/recommendations/python_code_recommendations.md)
4) Modify your source code if it's necessary after have reading [recommendations](../../docs/recommendations/python_code_recommendations.md)
5) Read [malfunctions](../../docs/malfunctions/python_code_malfunctions.md) to be informed
6) Obfuscate your code ! commands explained in [README](../../README.md)
