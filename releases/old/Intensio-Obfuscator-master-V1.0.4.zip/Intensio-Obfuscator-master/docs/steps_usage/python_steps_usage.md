# Steps usage

1) Place you source code in empty directory
2) Read the practices of code that ought respect respect all [recommendations](https://github.com/Hnfull/Intensio-Obfuscator/blob/master/docs/recommendations/python_code_recommendations.md)
3) Modify your source code if it's necessary after have reading [recommendations](https://github.com/Hnfull/Intensio-Obfuscator/blob/master/docs/recommendations/python_code_recommendations.md)
4) Read [malfunctions](https://github.com/Hnfull/Intensio-Obfuscator/blob/master/docs/malfunctions/python_code_malfunctions.md) to be informed
5) Obfuscate your code ! commands explained in [README](https://github.com/Hnfull/Intensio-Obfuscator/blob/master/README.md)
