# Demonstration of different examples of the project
