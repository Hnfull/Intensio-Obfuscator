# -*- coding: utf-8 -*-
import sys
QjDNQunkZJADUzlzbvvNbclhjnhqgaRU            = 0
eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN            = 1
ZIkcVBkuyTDfUcCQgUtzwpDVZopwTaZL    = 1
DaEhJTSNWpJGOlthFKNsnCvoaPoljAdN    = 1
QFQyfXrzUBwMtuRwbYJOcaBeDjBKwqKe   = 1
qnTLoHiXYWpCXPgDEmJAlAKcoKnkxAvH      = 1
aMqSHzUPyrzFYvLJwxQKmesJdEGTDsML       = 1
ZHrvguMIcLZctPskraFlIEZgEKrfwcsI        = 1
smuFJnbFkNisnWmjWCYNQvKJNklSNvel = 1
mjAzbNSKSWCWCpvXoHXtqXeXmyBTeOwP     = 1
gnGYywXmNVuGDYZlAyQwzBZuJIhCTFoF     = 1
vDBrdpWsXapHqxpZIFqnEKiPjAzigVOJ       = 1
xsYoBRshBtSTolMHxYJFMlbEehkMuMdt         = 1
qwJFYtbHGyUdRAerlmSAuNwlkXOOgtlz  = 1
tzvJrbLmpjsGgLSqPqSjMhjgzKxzARLv = 1
wBmnvZpFVAhYyceyZOZliCNPjeSJwXgs    = 1
JDdQbgMKFgRGidSHRgevLoDmNUJlWmUz     = 1
yGWZsMrpPFvUJkrtYyTuzwMfVxaUmdIl       = 1
ZygodNgQYPCAvCBSLxySzMNBUrIHLvNa      = 1
JDdQbgMKFgRGidSHRgevLoDmNUJlWmUz     = 1
class jUiietMMTkOLLCNnmuhBiVmsTeWtESMI (Exception):
    pass
