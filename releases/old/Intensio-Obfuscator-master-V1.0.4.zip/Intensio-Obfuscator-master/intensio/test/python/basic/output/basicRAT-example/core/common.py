# -*- coding: utf-8 -*-
def MvDXcRBMVZPJAprmOwKOTHmHaRGYVUpO(WHUrTIobQYycvTQaCkaAXsCuvHeuTmgJ):
    tknkraSeKCplXonScDzEvCvHGHSEDAAX = 0
    while WHUrTIobQYycvTQaCkaAXsCuvHeuTmgJ:
        tknkraSeKCplXonScDzEvCvHGHSEDAAX = tknkraSeKCplXonScDzEvCvHGHSEDAAX << 8
        tknkraSeKCplXonScDzEvCvHGHSEDAAX += ord(WHUrTIobQYycvTQaCkaAXsCuvHeuTmgJ[-1])
        WHUrTIobQYycvTQaCkaAXsCuvHeuTmgJ = WHUrTIobQYycvTQaCkaAXsCuvHeuTmgJ[:-1]
    return tknkraSeKCplXonScDzEvCvHGHSEDAAX
def CXsBBhgqrQFCzmvIhLeECTKpCiBraSyw(tknkraSeKCplXonScDzEvCvHGHSEDAAX):
    SJoDmXoaLDavjHvrQAmgiThthbnVDqYi = ''
    while tknkraSeKCplXonScDzEvCvHGHSEDAAX:
        SJoDmXoaLDavjHvrQAmgiThthbnVDqYi += chr(tknkraSeKCplXonScDzEvCvHGHSEDAAX & 0xff)
        tknkraSeKCplXonScDzEvCvHGHSEDAAX = tknkraSeKCplXonScDzEvCvHGHSEDAAX >> 8
    return SJoDmXoaLDavjHvrQAmgiThthbnVDqYi
