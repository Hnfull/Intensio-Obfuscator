# -*- coding: utf-8 -*-
import sys
class WcITwKqxWwGGboRFRdIfgIfIzbIrqKUe:
    def __init__(self):
        self.platform = sys.platform
    def dCeYfzipTqbrJmJaijrODObAJKfbeHLu(self):
        if self.platform == "win32":
            return "\\"
        else:
            return "/"
    def sWjDzsFbfkXTWdOqhbmzHIZUGsurTLex(self, dict1, dict2):
    	GWonrUgrQPcSPxuMqsVdrlfLVPTAQBeX = {**dict1, **dict2}
    	return GWonrUgrQPcSPxuMqsVdrlfLVPTAQBeX
