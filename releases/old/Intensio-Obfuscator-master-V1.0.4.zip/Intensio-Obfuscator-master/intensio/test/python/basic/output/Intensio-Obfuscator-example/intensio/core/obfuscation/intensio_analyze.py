 # -*- coding: utf-8 -*-
import shutil
import os
import glob
import re
from core.utils.intensio_utils import WcITwKqxWwGGboRFRdIfgIfIzbIrqKUe
from core.utils.intensio_error import QjDNQunkZJADUzlzbvvNbclhjnhqgaRU, ZIkcVBkuyTDfUcCQgUtzwpDVZopwTaZL, DaEhJTSNWpJGOlthFKNsnCvoaPoljAdN,wBmnvZpFVAhYyceyZOZliCNPjeSJwXgs,\
                                        gnGYywXmNVuGDYZlAyQwzBZuJIhCTFoF, mjAzbNSKSWCWCpvXoHXtqXeXmyBTeOwP, vDBrdpWsXapHqxpZIFqnEKiPjAzigVOJ, tzvJrbLmpjsGgLSqPqSjMhjgzKxzARLv, \
                                        yGWZsMrpPFvUJkrtYyTuzwMfVxaUmdIl, ZygodNgQYPCAvCBSLxySzMNBUrIHLvNa, eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN, JDdQbgMKFgRGidSHRgevLoDmNUJlWmUz
class PoLNsFGdmFkjiLIIUBlBzFkIIyFmKrHZ:
    def __init__(self):
        self.vGJEoZkcLPlcLzvtnAYvjdThCbVgYHSx = WcITwKqxWwGGboRFRdIfgIfIzbIrqKUe()
    def tEJwyHuhdMNRuyAzdQmiobZdtiwSaYjw(self, inputArg, codeArg, verboseArg):
        vrpSZyAyJhHtNwpkLIxSRFJrLywWPqrU      = []
        FUIbQogdBhuFIHVJxImDrOFDHrvDxDUu      = []
        NOiyyqPEQNLREpNyTwPnTNIYWuZhVJcA = 0
        kVibEHfDLFHwYCKiYsRqFxOsKrBoReTZ = 0
        if os.path.exists(inputArg) == True:
            if os.path.isdir(inputArg) == True:
                if codeArg == "python":
                    EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX  = "py"
                    GsYqMrcVbLKzVqkjlDAJKGAShTlvDgxf   = r"__pycache__"
                OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc = [zBToaJnWPwRMIJYneYfagoDJTPcHgwDa for zBToaJnWPwRMIJYneYfagoDJTPcHgwDa in glob.glob("{0}{1}**{1}*.{2}".format(inputArg, self.vGJEoZkcLPlcLzvtnAYvjdThCbVgYHSx.dCeYfzipTqbrJmJaijrODObAJKfbeHLu(), EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX), recursive=True)]
                if OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc == []:
                    print("[-] {0} directory empty".format(inputArg))
                    return JDdQbgMKFgRGidSHRgevLoDmNUJlWmUz
                print("\n[+] Running zmmdqpVvnvRKhLwIKMKndVklNNJVHcBn input...")
                for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
                    if re.match(GsYqMrcVbLKzVqkjlDAJKGAShTlvDgxf, NFHcSbQkteQPxqhirjubTMkOWDROIhiS):
                        continue
                    else:
                        if os.path.getsize(NFHcSbQkteQPxqhirjubTMkOWDROIhiS) > 0:
                            vrpSZyAyJhHtNwpkLIxSRFJrLywWPqrU.append(NFHcSbQkteQPxqhirjubTMkOWDROIhiS)
                            NOiyyqPEQNLREpNyTwPnTNIYWuZhVJcA += NOiyyqPEQNLREpNyTwPnTNIYWuZhVJcA + 1
                        else:
                            FUIbQogdBhuFIHVJxImDrOFDHrvDxDUu.append(NFHcSbQkteQPxqhirjubTMkOWDROIhiS)
                            kVibEHfDLFHwYCKiYsRqFxOsKrBoReTZ += kVibEHfDLFHwYCKiYsRqFxOsKrBoReTZ + 1
                if NOiyyqPEQNLREpNyTwPnTNIYWuZhVJcA >= 1 and kVibEHfDLFHwYCKiYsRqFxOsKrBoReTZ < NOiyyqPEQNLREpNyTwPnTNIYWuZhVJcA:
                    if verboseArg:
                        print("\n[+] File input found :\n")
                        if vrpSZyAyJhHtNwpkLIxSRFJrLywWPqrU == []:
                            print("-> no result")
                        else:
                            for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in vrpSZyAyJhHtNwpkLIxSRFJrLywWPqrU:
                                print("-> {0}".format(NFHcSbQkteQPxqhirjubTMkOWDROIhiS))
                            for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in FUIbQogdBhuFIHVJxImDrOFDHrvDxDUu:
                                print("-> {0} : empty".format(NFHcSbQkteQPxqhirjubTMkOWDROIhiS))
                        print("")
                    return QjDNQunkZJADUzlzbvvNbclhjnhqgaRU
                elif NOiyyqPEQNLREpNyTwPnTNIYWuZhVJcA == kVibEHfDLFHwYCKiYsRqFxOsKrBoReTZ and NOiyyqPEQNLREpNyTwPnTNIYWuZhVJcA > 0:
                    print("[-] All files in directory specified are emtpy !.")
                    return wBmnvZpFVAhYyceyZOZliCNPjeSJwXgs
                else:
                    print("[-] No NFHcSbQkteQPxqhirjubTMkOWDROIhiS available in '{0}'.".format(inputArg))
                    return ZIkcVBkuyTDfUcCQgUtzwpDVZopwTaZL
            else:
                print("[-] '{0}' is not a directory.".format(inputArg))
                return yGWZsMrpPFvUJkrtYyTuzwMfVxaUmdIl
        else:
            print("'{0}' not exists.".format(inputArg))
            return DaEhJTSNWpJGOlthFKNsnCvoaPoljAdN
    def qREZraLISiUbPzYZZdgaFuwblkfElVKt(self, inputArg, codeArg, outputArg, verboseArg):
        SrcfuKfvxhZumbdXeOzidPVAlWeGLxfh         = []
        GCFvXQICzUxBYxzVrSkJgExeeSWOoNBl         = []
        hOXQJYJXTwsAeARElVOwyGTqDCcuhlHp    = 0
        VyVmARuQQLfvbosMNgGqYTNTBmzvlKVO    = 0
        if os.path.exists(outputArg) == True:
            luVBdPtuBZvIMGheqaEyXXuiBmNTIBiu = input("[!] Output '{0}' already exists, do you want remove it ? (Y/N) : ".format(outputArg))
            luVBdPtuBZvIMGheqaEyXXuiBmNTIBiu = luVBdPtuBZvIMGheqaEyXXuiBmNTIBiu.upper()
            if luVBdPtuBZvIMGheqaEyXXuiBmNTIBiu == "Y":
                try:
                    shutil.rmtree(outputArg)
                    if os.path.exists(outputArg) == False:
                        shutil.copytree(inputArg, outputArg)
                        if os.path.exists(outputArg) == True:
                            if os.path.isdir(outputArg) == True:
                                if codeArg == "python":
                                    EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX  = "py"
                                    GsYqMrcVbLKzVqkjlDAJKGAShTlvDgxf   = r"__pycache__"
                                OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc = [zBToaJnWPwRMIJYneYfagoDJTPcHgwDa for zBToaJnWPwRMIJYneYfagoDJTPcHgwDa in glob.glob("{0}{1}**{1}*.{2}".format(inputArg, self.vGJEoZkcLPlcLzvtnAYvjdThCbVgYHSx.dCeYfzipTqbrJmJaijrODObAJKfbeHLu(), EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX), recursive=True)]
                                if OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc == []:
                                    print("[-] {0} directory empty".format(inputArg))
                                    return JDdQbgMKFgRGidSHRgevLoDmNUJlWmUz
                                print("\n[+] Running zmmdqpVvnvRKhLwIKMKndVklNNJVHcBn output...")
                                for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
                                    if re.match(GsYqMrcVbLKzVqkjlDAJKGAShTlvDgxf, NFHcSbQkteQPxqhirjubTMkOWDROIhiS):
                                        continue
                                    else:
                                        if os.path.getsize(NFHcSbQkteQPxqhirjubTMkOWDROIhiS) > 0:
                                            SrcfuKfvxhZumbdXeOzidPVAlWeGLxfh.append(NFHcSbQkteQPxqhirjubTMkOWDROIhiS)
                                            hOXQJYJXTwsAeARElVOwyGTqDCcuhlHp += hOXQJYJXTwsAeARElVOwyGTqDCcuhlHp + 1
                                        else:
                                            GCFvXQICzUxBYxzVrSkJgExeeSWOoNBl.append(NFHcSbQkteQPxqhirjubTMkOWDROIhiS)
                                            VyVmARuQQLfvbosMNgGqYTNTBmzvlKVO += VyVmARuQQLfvbosMNgGqYTNTBmzvlKVO + 1
                                if hOXQJYJXTwsAeARElVOwyGTqDCcuhlHp >= 1 and hOXQJYJXTwsAeARElVOwyGTqDCcuhlHp > VyVmARuQQLfvbosMNgGqYTNTBmzvlKVO:
                                    if verboseArg:
                                        print("\n[+] Ouput files copy :\n")
                                        if SrcfuKfvxhZumbdXeOzidPVAlWeGLxfh == []:
                                            print("-> no result")
                                        else:
                                            for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in SrcfuKfvxhZumbdXeOzidPVAlWeGLxfh:
                                                print("-> {0}".format(NFHcSbQkteQPxqhirjubTMkOWDROIhiS))
                                            for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in GCFvXQICzUxBYxzVrSkJgExeeSWOoNBl:
                                                print("-> {0} : empty".format(NFHcSbQkteQPxqhirjubTMkOWDROIhiS))
                                    return QjDNQunkZJADUzlzbvvNbclhjnhqgaRU
                                else:
                                    print("[-] No files available in '{0}'.".format(outputArg))
                                    return ZIkcVBkuyTDfUcCQgUtzwpDVZopwTaZL
                            else:
                                print("[-] Copy '{0}' to '{1}' failed, this is not a output directory copied !.".format(inputArg, outputArg))
                                return yGWZsMrpPFvUJkrtYyTuzwMfVxaUmdIl
                        else:
                            print("[-] Copy '{0}' to '{1}' failed.".format(inputArg, outputArg))
                            return vDBrdpWsXapHqxpZIFqnEKiPjAzigVOJ
                    else:
                        print("[-] ZCrPDbxSSuPVcqZjkkcyZEUFJaXegPGs '{0}' failed.".format(outputArg))
                        return tzvJrbLmpjsGgLSqPqSjMhjgzKxzARLv
                except Exception as QCrUqNsyvICLTTYhSodAKLfvWgqmADAm:
                    print("[-] {0}".format(QCrUqNsyvICLTTYhSodAKLfvWgqmADAm))
                    return eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN
            else:
                print("[-] ZCrPDbxSSuPVcqZjkkcyZEUFJaXegPGs '{0}' failed, the user has refused.".format(outputArg))
                return tzvJrbLmpjsGgLSqPqSjMhjgzKxzARLv
        else:
            try:
                shutil.copytree(inputArg, outputArg)
                if os.path.exists(outputArg) == True:
                    if os.path.isdir(outputArg) == True:
                        if codeArg == "python":
                            EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX  = "py"
                            GsYqMrcVbLKzVqkjlDAJKGAShTlvDgxf   = r"__pycache__"
                        OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc = [zBToaJnWPwRMIJYneYfagoDJTPcHgwDa for zBToaJnWPwRMIJYneYfagoDJTPcHgwDa in glob.glob("{0}{1}**{1}*.{2}".format(inputArg, self.vGJEoZkcLPlcLzvtnAYvjdThCbVgYHSx.dCeYfzipTqbrJmJaijrODObAJKfbeHLu(), EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX), recursive=True)]
                        if OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc == []:
                            print("[-] {0} directory empty".format(inputArg))
                            return JDdQbgMKFgRGidSHRgevLoDmNUJlWmUz
                        print("\n[+] Running zmmdqpVvnvRKhLwIKMKndVklNNJVHcBn output...")
                        for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
                            if re.match(GsYqMrcVbLKzVqkjlDAJKGAShTlvDgxf, NFHcSbQkteQPxqhirjubTMkOWDROIhiS):
                                continue
                            else:
                                if os.path.getsize(NFHcSbQkteQPxqhirjubTMkOWDROIhiS) > 0:
                                    SrcfuKfvxhZumbdXeOzidPVAlWeGLxfh.append(NFHcSbQkteQPxqhirjubTMkOWDROIhiS)
                                    hOXQJYJXTwsAeARElVOwyGTqDCcuhlHp += hOXQJYJXTwsAeARElVOwyGTqDCcuhlHp + 1
                                else:
                                    GCFvXQICzUxBYxzVrSkJgExeeSWOoNBl.append(NFHcSbQkteQPxqhirjubTMkOWDROIhiS)
                                    VyVmARuQQLfvbosMNgGqYTNTBmzvlKVO += VyVmARuQQLfvbosMNgGqYTNTBmzvlKVO + 1
                        if hOXQJYJXTwsAeARElVOwyGTqDCcuhlHp >= 1 and hOXQJYJXTwsAeARElVOwyGTqDCcuhlHp > VyVmARuQQLfvbosMNgGqYTNTBmzvlKVO:
                            if verboseArg:
                                print("\n[+] File output found :\n")
                                if SrcfuKfvxhZumbdXeOzidPVAlWeGLxfh == []:
                                    print("-> no result")
                                else:
                                    for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in SrcfuKfvxhZumbdXeOzidPVAlWeGLxfh:
                                        print("-> {0} : copy".format(NFHcSbQkteQPxqhirjubTMkOWDROIhiS))
                                    for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in GCFvXQICzUxBYxzVrSkJgExeeSWOoNBl:
                                        print("-> {0} : copy empty".format(NFHcSbQkteQPxqhirjubTMkOWDROIhiS))
                            return QjDNQunkZJADUzlzbvvNbclhjnhqgaRU
                        else:
                            print("[-] No files available in '{0}'.".format(outputArg))
                            return ZIkcVBkuyTDfUcCQgUtzwpDVZopwTaZL
                    else:
                        print("[-] Copy '{0}' to '{1}' failed, this is not a output directory copied !.".format(inputArg, outputArg))
                        return yGWZsMrpPFvUJkrtYyTuzwMfVxaUmdIl
                else:
                    print("[-] Copy '{0}' to '{1}' failed.".format(inputArg, outputArg))
                    return vDBrdpWsXapHqxpZIFqnEKiPjAzigVOJ
            except Exception as QCrUqNsyvICLTTYhSodAKLfvWgqmADAm:
                print("[-] {0}".format(QCrUqNsyvICLTTYhSodAKLfvWgqmADAm))
                return eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN
