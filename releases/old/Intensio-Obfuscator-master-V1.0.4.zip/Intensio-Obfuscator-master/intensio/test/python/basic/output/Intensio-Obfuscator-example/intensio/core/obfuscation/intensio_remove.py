# -*- coding: utf-8 -*-
import re
import fileinput
import glob
from tqdm import tqdm
from core.utils.intensio_error import QjDNQunkZJADUzlzbvvNbclhjnhqgaRU, eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN
from core.utils.intensio_utils import WcITwKqxWwGGboRFRdIfgIfIzbIrqKUe
class ZCrPDbxSSuPVcqZjkkcyZEUFJaXegPGs:
    def __init__(self):
        self.vGJEoZkcLPlcLzvtnAYvjdThCbVgYHSx = WcITwKqxWwGGboRFRdIfgIfIzbIrqKUe()
    def GadSFqCibBxqCSbGAnPnPxqqmOXZBkyn(self, codeArg, outputArg):
        LsRzXlOrKAuTxKlmxXtmTutbmBdXLDED       = 0
        oUswwfdXwoUGDXCMCGYbMGQAdDPxfMhI     = 0
        fsSMGkxhTFuCVtzLrSCkajadIkyiKaQT  = 0
        if codeArg == "python":
            EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX  = "py"
            AYtSbCraHpGtqFAjHAAJmzLUiQtXtYDg   = r"__pycache__"
        OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc = [zBToaJnWPwRMIJYneYfagoDJTPcHgwDa for zBToaJnWPwRMIJYneYfagoDJTPcHgwDa in glob.glob("{0}{1}**{1}*.{2}".format(outputArg, self.vGJEoZkcLPlcLzvtnAYvjdThCbVgYHSx.dCeYfzipTqbrJmJaijrODObAJKfbeHLu(), EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX), recursive=True)]
        for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
            if re.match(AYtSbCraHpGtqFAjHAAJmzLUiQtXtYDg, NFHcSbQkteQPxqhirjubTMkOWDROIhiS):
                continue
            else:
                with fileinput.FileInput(NFHcSbQkteQPxqhirjubTMkOWDROIhiS, inplace=True) as inputFile:
                    for CznIVPOvIZYawZeTxsCdYKWrjFtwFIQt in inputFile:
                        if CznIVPOvIZYawZeTxsCdYKWrjFtwFIQt.strip():
                            print(CznIVPOvIZYawZeTxsCdYKWrjFtwFIQt.rstrip())
        for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
            LsRzXlOrKAuTxKlmxXtmTutbmBdXLDED = 0
            if re.match(AYtSbCraHpGtqFAjHAAJmzLUiQtXtYDg, NFHcSbQkteQPxqhirjubTMkOWDROIhiS):
                continue
            else:
                with open(NFHcSbQkteQPxqhirjubTMkOWDROIhiS, "r") as readFile:
                    gOjJbBNMdzvuHgCeZUYHmaxRSWsFCpYe = readFile.readlines()
                    for LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj in gOjJbBNMdzvuHgCeZUYHmaxRSWsFCpYe:
                        if LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj == "\n":
                            LsRzXlOrKAuTxKlmxXtmTutbmBdXLDED += 1
                        if LsRzXlOrKAuTxKlmxXtmTutbmBdXLDED == 0:
                            fsSMGkxhTFuCVtzLrSCkajadIkyiKaQT += 1
                            oUswwfdXwoUGDXCMCGYbMGQAdDPxfMhI += 1
                        else:
                            fsSMGkxhTFuCVtzLrSCkajadIkyiKaQT += 0
                            oUswwfdXwoUGDXCMCGYbMGQAdDPxfMhI += 1
        if fsSMGkxhTFuCVtzLrSCkajadIkyiKaQT == oUswwfdXwoUGDXCMCGYbMGQAdDPxfMhI:
            return QjDNQunkZJADUzlzbvvNbclhjnhqgaRU
        else:
            return eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN
    def XWnAliWekqMHqUWUwlqEHPlieJakvZHH(self, codeArg, outputArg):
        xaoOYHNAnAgAWcXEINEtGDXXFSmfxGWi     = 0
        XZcKhSvhBnHIBwJwFNbEzsgIwmQlWWJR      = 0
        QRgluMdDfDNtlitwNSjEICVVIBEdlysF        = 0
        kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM        = 0
        dGAyTLoOIgoKfvrIbJgMuxWYkRwstIEh    = 0
        if codeArg == "python":
            uDCbRaFCYeYGAgPpoTHqrXfLuzYwwbpx               = r"^\#.*"
            brqpxirpwwUiMgxTEChSFodHAGAcljfe                        = r"\={1}\s*r[\"|\']{1}"
            fhjQCYThAbOskjYDmYNaHhWiZOyEJNIa          = r"[\"|\']{3}.*[\"|\']{3}$"
            KqORXLsBrtifTrtrBkfjXAlKZIsZAQJU    = r"^\s*[\"|\']{3}$"
            kmJszsvEpliBjfSaWchmRofhnOXiuizk = r"^\s*[\"|\']{3}\)?\.?"
            WJAVHEsEUkoVzPWwlDzxrYaQgjrfLaFx                   = r".*\={1}\s*\w*\.?\w*[\(|\.]{1}[\"|\']{3}|.*\={1}\s*[\"|\']{3}"
            krhdmRnADLSTIaItrQEkZYIYtjHoacZP               = r"\s*\#[^\"|^\'|^\.|^\?|^\*|^\!|^\]|^\[|^\\|^\)|^\(|^\{|^\}].*"
            EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX  = "py"
            AYtSbCraHpGtqFAjHAAJmzLUiQtXtYDg   = r"__pycache__"
        OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc = [zBToaJnWPwRMIJYneYfagoDJTPcHgwDa for zBToaJnWPwRMIJYneYfagoDJTPcHgwDa in glob.glob("{0}{1}**{1}*.{2}".format(outputArg, self.vGJEoZkcLPlcLzvtnAYvjdThCbVgYHSx.dCeYfzipTqbrJmJaijrODObAJKfbeHLu(), EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX), recursive=True)]
        for REqGysXhkGjocOcsRNbVsTmlWMnWgdba in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
            dGAyTLoOIgoKfvrIbJgMuxWYkRwstIEh += 1
        print("\n[+] Running remove commentaries in {0} NFHcSbQkteQPxqhirjubTMkOWDROIhiS(s)...\n".format(dGAyTLoOIgoKfvrIbJgMuxWYkRwstIEh))
        with tqdm(total=dGAyTLoOIgoKfvrIbJgMuxWYkRwstIEh) as pbar:
            for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
                pbar.update(1)
                if re.match(AYtSbCraHpGtqFAjHAAJmzLUiQtXtYDg, NFHcSbQkteQPxqhirjubTMkOWDROIhiS):
                    continue
                else:
                    with fileinput.input(NFHcSbQkteQPxqhirjubTMkOWDROIhiS, inplace=True) as inputFile:
                        for LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj in inputFile:
                            YNEFCSffsxRWrXTgXldOcJjqtOlCYhNe = re.search(krhdmRnADLSTIaItrQEkZYIYtjHoacZP, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                            SVsTqOajvjajJHtalBkDcXQUnUaEiORn = re.search(uDCbRaFCYeYGAgPpoTHqrXfLuzYwwbpx, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                            if codeArg == "python":
                                if "coding" in LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj or "#!" in LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj:
                                    print(LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                                    continue
                                if re.match(brqpxirpwwUiMgxTEChSFodHAGAcljfe, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                    continue
                                elif re.match(WJAVHEsEUkoVzPWwlDzxrYaQgjrfLaFx, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                    QRgluMdDfDNtlitwNSjEICVVIBEdlysF += 1
                                elif re.match(KqORXLsBrtifTrtrBkfjXAlKZIsZAQJU, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj) or re.match(kmJszsvEpliBjfSaWchmRofhnOXiuizk, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                    kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM += 1
                                else:
                                    pass
                                if re.match(fhjQCYThAbOskjYDmYNaHhWiZOyEJNIa, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                    XZcKhSvhBnHIBwJwFNbEzsgIwmQlWWJR += 1
                                    kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM = 0
                                    continue
                                elif kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM == 1 and QRgluMdDfDNtlitwNSjEICVVIBEdlysF == 0:
                                    XZcKhSvhBnHIBwJwFNbEzsgIwmQlWWJR += 1
                                    continue
                                elif kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM == 0 and QRgluMdDfDNtlitwNSjEICVVIBEdlysF == 1:
                                    print(LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                                    continue
                                elif kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM == 2:
                                    XZcKhSvhBnHIBwJwFNbEzsgIwmQlWWJR += 1
                                    kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM = 0
                                    continue
                                elif kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM == 1 and QRgluMdDfDNtlitwNSjEICVVIBEdlysF == 1:
                                    kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM = 0
                                    QRgluMdDfDNtlitwNSjEICVVIBEdlysF = 0
                                    print(LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                                    continue
                                else:
                                    pass
                            if SVsTqOajvjajJHtalBkDcXQUnUaEiORn is not None:
                                XZcKhSvhBnHIBwJwFNbEzsgIwmQlWWJR += 1
                                LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj = LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj.replace(SVsTqOajvjajJHtalBkDcXQUnUaEiORn.group(0), "")
                                print(LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                            elif YNEFCSffsxRWrXTgXldOcJjqtOlCYhNe is not None:
                                LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj = LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj.replace(YNEFCSffsxRWrXTgXldOcJjqtOlCYhNe.group(0), "")
                                XZcKhSvhBnHIBwJwFNbEzsgIwmQlWWJR += 1
                                print(LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                            else:
                                print(LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
        kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM = 0
        QRgluMdDfDNtlitwNSjEICVVIBEdlysF = 0
        for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
            xaoOYHNAnAgAWcXEINEtGDXXFSmfxGWi = 0
            if re.match(AYtSbCraHpGtqFAjHAAJmzLUiQtXtYDg, NFHcSbQkteQPxqhirjubTMkOWDROIhiS):
                continue
            else:
                with open(NFHcSbQkteQPxqhirjubTMkOWDROIhiS, "r") as readFile:
                    xaoOYHNAnAgAWcXEINEtGDXXFSmfxGWi = 0
                    gOjJbBNMdzvuHgCeZUYHmaxRSWsFCpYe           = readFile.readlines()
                    for LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj in gOjJbBNMdzvuHgCeZUYHmaxRSWsFCpYe:
                        YNEFCSffsxRWrXTgXldOcJjqtOlCYhNe = re.search(krhdmRnADLSTIaItrQEkZYIYtjHoacZP, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                        SVsTqOajvjajJHtalBkDcXQUnUaEiORn = re.search(uDCbRaFCYeYGAgPpoTHqrXfLuzYwwbpx, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                        if codeArg == "python":
                            if "coding" in LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj or "#!" in LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj:
                                continue
                            if re.match(brqpxirpwwUiMgxTEChSFodHAGAcljfe, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                continue
                            elif re.match(WJAVHEsEUkoVzPWwlDzxrYaQgjrfLaFx, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                QRgluMdDfDNtlitwNSjEICVVIBEdlysF += 1
                            elif re.match(KqORXLsBrtifTrtrBkfjXAlKZIsZAQJU, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj) or re.match(kmJszsvEpliBjfSaWchmRofhnOXiuizk, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM += 1
                            else:
                                pass
                            if re.match(fhjQCYThAbOskjYDmYNaHhWiZOyEJNIa, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM = 0
                                xaoOYHNAnAgAWcXEINEtGDXXFSmfxGWi += 1
                                continue
                            elif kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM == 1 and QRgluMdDfDNtlitwNSjEICVVIBEdlysF == 0:
                                xaoOYHNAnAgAWcXEINEtGDXXFSmfxGWi += 1
                                continue
                            elif kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM == 0 and QRgluMdDfDNtlitwNSjEICVVIBEdlysF == 1:
                                continue
                            elif kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM == 2:
                                kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM = 0
                                xaoOYHNAnAgAWcXEINEtGDXXFSmfxGWi += 1
                                continue
                            elif kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM == 1 and QRgluMdDfDNtlitwNSjEICVVIBEdlysF == 1:
                                kfPzpJgNEwKtCIeGYYsZhPgjrKPfWHbM = 0
                                QRgluMdDfDNtlitwNSjEICVVIBEdlysF = 0
                                continue
                            else:
                                pass
                        if SVsTqOajvjajJHtalBkDcXQUnUaEiORn is not None:
                            xaoOYHNAnAgAWcXEINEtGDXXFSmfxGWi += 1
                        elif YNEFCSffsxRWrXTgXldOcJjqtOlCYhNe is not None:
                            xaoOYHNAnAgAWcXEINEtGDXXFSmfxGWi += 1
                        else:
                            pass
        if (ZCrPDbxSSuPVcqZjkkcyZEUFJaXegPGs.GadSFqCibBxqCSbGAnPnPxqqmOXZBkyn(self, codeArg, outputArg) == 0):
            if xaoOYHNAnAgAWcXEINEtGDXXFSmfxGWi == 0:
                print("\n-> {0} lines of commentaries removed\n".format(XZcKhSvhBnHIBwJwFNbEzsgIwmQlWWJR))
                return QjDNQunkZJADUzlzbvvNbclhjnhqgaRU
            else:
                return eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN
        else:
            return eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN
    def cViujpNVjgNqGaZXcayMZHXlVanwzYVC(self, codeArg, outputArg):
        TpFMUSAJwLFIIxLcSVjsYzylcuQckhJE              = 0
        ZZSjnGeOVTKBTnGqGqZQakprLyElEgmS         = 0
        dGAyTLoOIgoKfvrIbJgMuxWYkRwstIEh            = 0
        LceSaDJrUShBwSjqtxXNwoxVcmLarOts  = 0
        mBgLMKKHwPESvCrkNjBkNjCdQIBEnNcW  = 0
        if codeArg == "python":
            ROjGnkxnJLzIjVKduuNvbDYJcThFfFXh = r"\s*print"
            EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX  = "py"
            AYtSbCraHpGtqFAjHAAJmzLUiQtXtYDg   = r"__pycache__"
        OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc = [zBToaJnWPwRMIJYneYfagoDJTPcHgwDa for zBToaJnWPwRMIJYneYfagoDJTPcHgwDa in glob.glob("{0}{1}**{1}*.{2}".format(outputArg, self.vGJEoZkcLPlcLzvtnAYvjdThCbVgYHSx.dCeYfzipTqbrJmJaijrODObAJKfbeHLu(), EwzRXZbupYYUpNHDqfzHzmFjRHIVHGfX), recursive=True)]
        for REqGysXhkGjocOcsRNbVsTmlWMnWgdba in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
            dGAyTLoOIgoKfvrIbJgMuxWYkRwstIEh += 1
        print("\n[+] Running remove print function in {0} NFHcSbQkteQPxqhirjubTMkOWDROIhiS(s)...\n".format(dGAyTLoOIgoKfvrIbJgMuxWYkRwstIEh))
        with tqdm(total=dGAyTLoOIgoKfvrIbJgMuxWYkRwstIEh) as pbar:
            for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
                pbar.update(1)
                if re.match(AYtSbCraHpGtqFAjHAAJmzLUiQtXtYDg, NFHcSbQkteQPxqhirjubTMkOWDROIhiS):
                    continue
                else:
                    with fileinput.input(NFHcSbQkteQPxqhirjubTMkOWDROIhiS, inplace=True) as inputFile:
                        for LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj in inputFile:
                            if re.match(ROjGnkxnJLzIjVKduuNvbDYJcThFfFXh, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                TpFMUSAJwLFIIxLcSVjsYzylcuQckhJE += 1
                                if re.match(r"\s*print\s*\({1}", LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                    if "(" in LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj and not ")" in LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj:
                                        LceSaDJrUShBwSjqtxXNwoxVcmLarOts += 1
                                        continue
                                    else:
                                        continue
                                elif re.match(r"\s*print\s*[\"|\']{1}", LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                    mBgLMKKHwPESvCrkNjBkNjCdQIBEnNcW += 1
                                    continue
                            else:
                                if LceSaDJrUShBwSjqtxXNwoxVcmLarOts == 1:
                                    if ")" in LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj and not "(" in LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj:
                                        LceSaDJrUShBwSjqtxXNwoxVcmLarOts = 0
                                        continue
                                    else:
                                        continue
                                elif mBgLMKKHwPESvCrkNjBkNjCdQIBEnNcW > 0:
                                    if re.match(r"^\s+[\"\']{1}\s*\w+|^[\"\']{1}\s*\w+", LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                                        mBgLMKKHwPESvCrkNjBkNjCdQIBEnNcW += 1
                                        continue
                                    else:
                                        mBgLMKKHwPESvCrkNjBkNjCdQIBEnNcW = 0
                                        print(LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
                                        continue
                                else:
                                    print(LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj)
        for NFHcSbQkteQPxqhirjubTMkOWDROIhiS in OLPXLJjTjHbKpYgnyclxvgLIGhCpocKc:
            if re.match(AYtSbCraHpGtqFAjHAAJmzLUiQtXtYDg, NFHcSbQkteQPxqhirjubTMkOWDROIhiS):
                continue
            else:
                with open(NFHcSbQkteQPxqhirjubTMkOWDROIhiS, "r") as readFile:
                    gOjJbBNMdzvuHgCeZUYHmaxRSWsFCpYe = readFile.readlines()
                    for LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj in gOjJbBNMdzvuHgCeZUYHmaxRSWsFCpYe:
                        if re.match(ROjGnkxnJLzIjVKduuNvbDYJcThFfFXh, LtmKeeQLTgjYKZQXIGqvevOwVlZvjxkj):
                            ZZSjnGeOVTKBTnGqGqZQakprLyElEgmS += 1
        if (ZCrPDbxSSuPVcqZjkkcyZEUFJaXegPGs.GadSFqCibBxqCSbGAnPnPxqqmOXZBkyn(self, codeArg, outputArg) == 0):
            if ZZSjnGeOVTKBTnGqGqZQakprLyElEgmS == 0:
                print("\n-> {0} print functions removed\n".format(TpFMUSAJwLFIIxLcSVjsYzylcuQckhJE))
                return QjDNQunkZJADUzlzbvvNbclhjnhqgaRU
            else:
                return eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN
        else:
            return eXQhFHuFKGQOrjWSstGkuDOgVFjZGhCN
