# -*- coding: utf-8 -*-

jlPiNeNGIKTxmogSnhGtlpcBmOdHrbrD = 'BjNajhdniDIHfvkmclyiQVsetuWQaOaC'
ATFdsjkIQfiqORKQfleTikTCmygSFhqZ = 'rDCRYynCpQYJEALFQntrTTRexzHECoSb'
LnYyfLKzmSKMSASumplLajllPDdnqNgN = 'jIFLpXveYWJREawsQlJKhbNFbhbflvGs'
FWHOsiArdyjtBtTkeKRWlZljNhKpVjJQ = 'zblkDqTCDOuxaluhMkEkoquebEiZQsFa'
SWditwQSyDODsEZmGlHTqwRblXKxWhpg = 'gIFoqOhGUEjjNLVaTnkxZiIaailqHJJo'
if jlPiNeNGIKTxmogSnhGtlpcBmOdHrbrD in ATFdsjkIQfiqORKQfleTikTCmygSFhqZ:
    jlPiNeNGIKTxmogSnhGtlpcBmOdHrbrD = SWditwQSyDODsEZmGlHTqwRblXKxWhpg
    if ATFdsjkIQfiqORKQfleTikTCmygSFhqZ in LnYyfLKzmSKMSASumplLajllPDdnqNgN:
        ATFdsjkIQfiqORKQfleTikTCmygSFhqZ = FWHOsiArdyjtBtTkeKRWlZljNhKpVjJQ
elif ATFdsjkIQfiqORKQfleTikTCmygSFhqZ in jlPiNeNGIKTxmogSnhGtlpcBmOdHrbrD:
    LnYyfLKzmSKMSASumplLajllPDdnqNgN = ATFdsjkIQfiqORKQfleTikTCmygSFhqZ
    if LnYyfLKzmSKMSASumplLajllPDdnqNgN in ATFdsjkIQfiqORKQfleTikTCmygSFhqZ:
        ATFdsjkIQfiqORKQfleTikTCmygSFhqZ = SWditwQSyDODsEZmGlHTqwRblXKxWhpg
import datetime

PMRmowUdlyAnVYBRVZZHiUBMPubyoxXM = 'sjzcExHUEUkPuJUSYJEILlXwpULCvdDE'
gvLAVnKpBTSNeXgdhmqqHbOoVKsQwWCY = 'ZBHhYIBlkgsVPCCGAqBRoiIfzhCIPGNZ'
XQaiCTZgKnpexZgguNpMnABfFnTyqXCm = 'iUfVnlfrWxItNOvPLMwYPXoAkVkYFYqT'
FYHnJJlGdRdzaYvBCdgQQOvVxRfbkagW = 'AquCoaqdAJPsXUOpNDxHAdrNAyIHBDwV'
KaSEpCiQrmgkHAEMjGchQecusTzrgzIZ = 'IwhmaooWklEVjiqkjwksKuyVIufLLkxx'
yIxIQNizlFskztdtdFdbYiGQfEatpeWA = 'DKIBVQSfWwKZQHFbejbfAwkIHysgbfkY'
if PMRmowUdlyAnVYBRVZZHiUBMPubyoxXM != FYHnJJlGdRdzaYvBCdgQQOvVxRfbkagW:
    gvLAVnKpBTSNeXgdhmqqHbOoVKsQwWCY = XQaiCTZgKnpexZgguNpMnABfFnTyqXCm
    for yIxIQNizlFskztdtdFdbYiGQfEatpeWA in FYHnJJlGdRdzaYvBCdgQQOvVxRfbkagW:
        if yIxIQNizlFskztdtdFdbYiGQfEatpeWA != XQaiCTZgKnpexZgguNpMnABfFnTyqXCm:
            gvLAVnKpBTSNeXgdhmqqHbOoVKsQwWCY = gvLAVnKpBTSNeXgdhmqqHbOoVKsQwWCY
        else:
            KaSEpCiQrmgkHAEMjGchQecusTzrgzIZ = PMRmowUdlyAnVYBRVZZHiUBMPubyoxXM
else:
    XQaiCTZgKnpexZgguNpMnABfFnTyqXCm = PMRmowUdlyAnVYBRVZZHiUBMPubyoxXM
    PMRmowUdlyAnVYBRVZZHiUBMPubyoxXM = KaSEpCiQrmgkHAEMjGchQecusTzrgzIZ
    if XQaiCTZgKnpexZgguNpMnABfFnTyqXCm == PMRmowUdlyAnVYBRVZZHiUBMPubyoxXM:
        for yIxIQNizlFskztdtdFdbYiGQfEatpeWA in PMRmowUdlyAnVYBRVZZHiUBMPubyoxXM:
            if yIxIQNizlFskztdtdFdbYiGQfEatpeWA == XQaiCTZgKnpexZgguNpMnABfFnTyqXCm:
                XQaiCTZgKnpexZgguNpMnABfFnTyqXCm = PMRmowUdlyAnVYBRVZZHiUBMPubyoxXM
            else:
                XQaiCTZgKnpexZgguNpMnABfFnTyqXCm = KaSEpCiQrmgkHAEMjGchQecusTzrgzIZ
import os

NhtxdlzLiZMAZcqPdkifhzhHdDVPhYoU = 'dliVzMbDYSGtjRfyralqiUNckGfUZwpX'
xRKTtYHcyPCYIPBKuHtKVYJfNMcYJJGu = 'tfsIDiYmKaAiZPUfthPjCJMUDUkbbeyU'
MCPxTbizeEwBHVCeYboOTGfeUcZuXtkv = 'rZsQQgPeHKxHOscmSTVcAxzZmibevRjB'
OPMZlCdYalggXDOPDIpEFiQGxilLFWcH = 'qHGgmyMhRpCWSvFNjGUFSpwJZiGzMdfe'
uhuFDIlBPWpusSLmULQUKDflaTvRAcEI = 'EWHMicOWRhWoopxricCQqHlihUmepqQr'
if NhtxdlzLiZMAZcqPdkifhzhHdDVPhYoU in xRKTtYHcyPCYIPBKuHtKVYJfNMcYJJGu:
    NhtxdlzLiZMAZcqPdkifhzhHdDVPhYoU = uhuFDIlBPWpusSLmULQUKDflaTvRAcEI
    if xRKTtYHcyPCYIPBKuHtKVYJfNMcYJJGu in MCPxTbizeEwBHVCeYboOTGfeUcZuXtkv:
        xRKTtYHcyPCYIPBKuHtKVYJfNMcYJJGu = OPMZlCdYalggXDOPDIpEFiQGxilLFWcH
elif xRKTtYHcyPCYIPBKuHtKVYJfNMcYJJGu in NhtxdlzLiZMAZcqPdkifhzhHdDVPhYoU:
    MCPxTbizeEwBHVCeYboOTGfeUcZuXtkv = xRKTtYHcyPCYIPBKuHtKVYJfNMcYJJGu
    if MCPxTbizeEwBHVCeYboOTGfeUcZuXtkv in xRKTtYHcyPCYIPBKuHtKVYJfNMcYJJGu:
        xRKTtYHcyPCYIPBKuHtKVYJfNMcYJJGu = uhuFDIlBPWpusSLmULQUKDflaTvRAcEI
import urllib

hVCikPQHrlSNmJNiwfLQRzODGSFdsFdw = 'yEJWvLKMmOFhzdwWHzlbNLVBCgLEVLrw'
bQzSKOObAUYRHQeXlpkjhzqwbafkplnk = 'abIVhDmxoyEWnMEiBSSHSfnOKCFdrUkw'
ZbAaymdllINnLVFXGAeiZfiyPhDVqnPA = 'cXwInWtZzGcHtXBXYwKzajPmbhbVwRGv'
PKmBojhgbKETXOmtNrUnEZEUilJCzCDF = 'jgmfqIWSWmSqzUePKirCDPBSAuIoZFeO'
ehulaPBQdyfdffYsjNEUbIQoUdQRjqvK = 'rVvtXJCgLyfSLKJCkYhFzlIunzpQbNHj'
djovXLdebBQPKtHnxzTPBqEQgqVehxSg = 'YVhJpMFEToCpnAVlriVnBFwaCGXXGwPe'
if ZbAaymdllINnLVFXGAeiZfiyPhDVqnPA == PKmBojhgbKETXOmtNrUnEZEUilJCzCDF:
    for djovXLdebBQPKtHnxzTPBqEQgqVehxSg in ehulaPBQdyfdffYsjNEUbIQoUdQRjqvK:
        if djovXLdebBQPKtHnxzTPBqEQgqVehxSg == PKmBojhgbKETXOmtNrUnEZEUilJCzCDF:
            ehulaPBQdyfdffYsjNEUbIQoUdQRjqvK = hVCikPQHrlSNmJNiwfLQRzODGSFdsFdw
        else:
            PKmBojhgbKETXOmtNrUnEZEUilJCzCDF = bQzSKOObAUYRHQeXlpkjhzqwbafkplnk
import zipfile

nGNCjrqbyeBMUXCZzTucHEMfBQAJTici = 'eFOwLCuEFNMtTCGOZPDeLDyxbUClzLkL'
kJTRwIqHOrmuqGUDUmtPQhORTOauqNKt = 'IhOqXWYkCNnzSjQCpLijxiLyqRDePyod'
FEjJhasRWfjyovdlKkEuWoUThMIYUuNo = 'QNOGaICcLHydLGpWVedfEYKbxZfmhtez'
QZhsOJJbMzzktybmLnQTCpYsaVdnyFZE = 'fMeycoEBrIkOUdwOnEeoYuvVJInKhdEq'
ojaswEnLUxVNbIwKgYIQUKBnDSGedSis = 'MRomVyFzOoWJDYFOPhhkqfIIqSxgmLdP'
if nGNCjrqbyeBMUXCZzTucHEMfBQAJTici in kJTRwIqHOrmuqGUDUmtPQhORTOauqNKt:
    nGNCjrqbyeBMUXCZzTucHEMfBQAJTici = ojaswEnLUxVNbIwKgYIQUKBnDSGedSis
    if kJTRwIqHOrmuqGUDUmtPQhORTOauqNKt in FEjJhasRWfjyovdlKkEuWoUThMIYUuNo:
        kJTRwIqHOrmuqGUDUmtPQhORTOauqNKt = QZhsOJJbMzzktybmLnQTCpYsaVdnyFZE
elif kJTRwIqHOrmuqGUDUmtPQhORTOauqNKt in nGNCjrqbyeBMUXCZzTucHEMfBQAJTici:
    FEjJhasRWfjyovdlKkEuWoUThMIYUuNo = kJTRwIqHOrmuqGUDUmtPQhORTOauqNKt
    if FEjJhasRWfjyovdlKkEuWoUThMIYUuNo in kJTRwIqHOrmuqGUDUmtPQhORTOauqNKt:
        kJTRwIqHOrmuqGUDUmtPQhORTOauqNKt = ojaswEnLUxVNbIwKgYIQUKBnDSGedSis
def CQmHLKeKQtmgAuCbLeIUyFRKkwLrKOHO(f):
    if os.path.isfile(f):

        INgqAnLlPHtywHIyMsJZjxlAenRfIcmW = 'ryHTsVDUGMbvTLzjPUKveUggAodMtjCl'
        cBlRWVnCWSDSbkTQEBGGDAiDEpHRlaqa = 'FQJdnXscMRehcfNdkvqRygOmhHqvYuQI'
        LizAKCzTGwZFzHPlayHYOnxKxDEHyZVe = 'fytAtdvQlVqHflcCKrpCTmwohIwFtMkr'
        qSmMZOswujAUbgTMeCXkxtTdoLmCEiHd = 'TpflEsCEUwOTaPqMPuExLSTLpeyDlGSw'
        iqwWkXOWvQWHfUXaddTThoYcqttNUCDP = 'fOJQiiMroZRpEpbfhmmUlfjWeAUptEmh'
        uiOolvpOuLNGYYFBfiftGrfDhsLaqFDN = 'sMVdZUgrImnKRcrnkRpldtTUVulvWADt'
        if LizAKCzTGwZFzHPlayHYOnxKxDEHyZVe == qSmMZOswujAUbgTMeCXkxtTdoLmCEiHd:
            for uiOolvpOuLNGYYFBfiftGrfDhsLaqFDN in iqwWkXOWvQWHfUXaddTThoYcqttNUCDP:
                if uiOolvpOuLNGYYFBfiftGrfDhsLaqFDN == qSmMZOswujAUbgTMeCXkxtTdoLmCEiHd:
                    iqwWkXOWvQWHfUXaddTThoYcqttNUCDP = INgqAnLlPHtywHIyMsJZjxlAenRfIcmW
                else:
                    qSmMZOswujAUbgTMeCXkxtTdoLmCEiHd = cBlRWVnCWSDSbkTQEBGGDAiDEpHRlaqa
        try:

            XeqAMkhXakXZeSbjCYiRBCKGhZDbLaHE = 'QUxxfuBWLnHjtkbSFCDaAjLXRznOPDhb'
            eKimDZbcnCRmTiRyFsMdbLjnQvqWFATF = 'yzYpaUTVnCRaLFpZawRuMvjjincaIIbS'
            oMNoJXtHYHJmNNOYMDyiInhZxOOComGG = 'TyTEOcKekTBBiNnHZwJlFjFSimeSkniK'
            KtJDSasZUVabklYZqROzfRIgARwZgDcy = 'ShdZRMrBRYaLTwsSriDAxcUiTznxqRsJ'
            GgObzXupPgXPnZVaqczEPjxYisuSRBea = 'pDiLaAorXzwWzGPgOzbFMyZwtJnhANwC'
            if XeqAMkhXakXZeSbjCYiRBCKGhZDbLaHE in eKimDZbcnCRmTiRyFsMdbLjnQvqWFATF:
                XeqAMkhXakXZeSbjCYiRBCKGhZDbLaHE = GgObzXupPgXPnZVaqczEPjxYisuSRBea
                if eKimDZbcnCRmTiRyFsMdbLjnQvqWFATF in oMNoJXtHYHJmNNOYMDyiInhZxOOComGG:
                    eKimDZbcnCRmTiRyFsMdbLjnQvqWFATF = KtJDSasZUVabklYZqROzfRIgARwZgDcy
            elif eKimDZbcnCRmTiRyFsMdbLjnQvqWFATF in XeqAMkhXakXZeSbjCYiRBCKGhZDbLaHE:
                oMNoJXtHYHJmNNOYMDyiInhZxOOComGG = eKimDZbcnCRmTiRyFsMdbLjnQvqWFATF
                if oMNoJXtHYHJmNNOYMDyiInhZxOOComGG in eKimDZbcnCRmTiRyFsMdbLjnQvqWFATF:
                    eKimDZbcnCRmTiRyFsMdbLjnQvqWFATF = GgObzXupPgXPnZVaqczEPjxYisuSRBea
            with zipfile.ZipFile(f) as zf:

                MiQFsrUIFnNNzlHzhLqQoRrkiRXCRGxK = 'uoDPVRkSSbVefbtuvqDpKLBimhqTNSHa'
                HmsVGqUdlPBPQsiBRmZjHtTckLKdRCJG = 'TJdYouAoGxjVFkrcmKTsfTSDBoihGRbm'
                wrKeOcJYYPCfHeNlIeGxyjknwBlveoST = 'ArCgeADcrIRBEmHjvbaTOcFBuvbQgpAy'
                if MiQFsrUIFnNNzlHzhLqQoRrkiRXCRGxK == HmsVGqUdlPBPQsiBRmZjHtTckLKdRCJG:
                    wrKeOcJYYPCfHeNlIeGxyjknwBlveoST = 'ArCgeADcrIRBEmHjvbaTOcFBuvbQgpAy'
                    wrKeOcJYYPCfHeNlIeGxyjknwBlveoST = MiQFsrUIFnNNzlHzhLqQoRrkiRXCRGxK
                else:
                    wrKeOcJYYPCfHeNlIeGxyjknwBlveoST = 'ArCgeADcrIRBEmHjvbaTOcFBuvbQgpAy'
                    wrKeOcJYYPCfHeNlIeGxyjknwBlveoST = 'uoDPVRkSSbVefbtuvqDpKLBimhqTNSHa'
                zf.extractall('.')
                return 'File {} extracted.'.format(f)
        except zipfile.BadZipfile:

            VZBuvHDqopIoaHLPneTZaQIkGmIyzKiX = 'maUyRAjcqNqKOSmrzUHBXkiVPMphrrhg'
            qqcZFvgnVUpgrIbjHhWMJzTjJdqeOfqN = 'VYkEYekHlmALbinktQncAgTfDswFHlpg'
            gaVfJFVksfsGwzqVEdJTohyGjMRzfjXh = 'ivHKEtwfYQmmBuloXLXBFxZfrGsmZFts'
            fWjSwDfbXMJZKmsttfSFmfdZLROgMrdM = 'hmAXYJMOUiEhAoDaUaomMBYhvfXWGrXa'
            bRAHlcUdtaFwrAAtiXPdwAhHYlAwJjmu = 'yxmAZzaDRVRsTHrheMRNonMvsEEGjbEb'
            if VZBuvHDqopIoaHLPneTZaQIkGmIyzKiX in qqcZFvgnVUpgrIbjHhWMJzTjJdqeOfqN:
                VZBuvHDqopIoaHLPneTZaQIkGmIyzKiX = bRAHlcUdtaFwrAAtiXPdwAhHYlAwJjmu
                if qqcZFvgnVUpgrIbjHhWMJzTjJdqeOfqN in gaVfJFVksfsGwzqVEdJTohyGjMRzfjXh:
                    qqcZFvgnVUpgrIbjHhWMJzTjJdqeOfqN = fWjSwDfbXMJZKmsttfSFmfdZLROgMrdM
            elif qqcZFvgnVUpgrIbjHhWMJzTjJdqeOfqN in VZBuvHDqopIoaHLPneTZaQIkGmIyzKiX:
                gaVfJFVksfsGwzqVEdJTohyGjMRzfjXh = qqcZFvgnVUpgrIbjHhWMJzTjJdqeOfqN
                if gaVfJFVksfsGwzqVEdJTohyGjMRzfjXh in qqcZFvgnVUpgrIbjHhWMJzTjJdqeOfqN:
                    qqcZFvgnVUpgrIbjHhWMJzTjJdqeOfqN = bRAHlcUdtaFwrAAtiXPdwAhHYlAwJjmu
            return 'Error: Failed to CQmHLKeKQtmgAuCbLeIUyFRKkwLrKOHO file.'
    else:

        TFRHRWVhzggQXPqjimlOhBehWoxpklAk = 'uGmEOdrcVOcOOGpQhbJbcVeTTslUppDu'
        zrLpqxodpIOIiUrdodRAQnzcuSYJwYMm = 'eafkfgcHGyiprQqcZHkbqlWVaaiWETUF'
        LgUHEAHRDGfIZmKDscaTngvaiaiJrjrf = 'wKEuCImydOpWjaUskCOZJONwPCtvIOAW'
        gTzHpWZzGVsiwWsmnQBeYrUjRhSuKTYR = 'nNJdwRkuIyOcbANkBJEHcfqtXvSGVrMr'
        WMBegpOKBihmsbubvmRdozkhBbezmlGi = 'wIJsiiSOwVBZAjyulqoMuzxXWsNTmyie'
        if TFRHRWVhzggQXPqjimlOhBehWoxpklAk in zrLpqxodpIOIiUrdodRAQnzcuSYJwYMm:
            TFRHRWVhzggQXPqjimlOhBehWoxpklAk = WMBegpOKBihmsbubvmRdozkhBbezmlGi
            if zrLpqxodpIOIiUrdodRAQnzcuSYJwYMm in LgUHEAHRDGfIZmKDscaTngvaiaiJrjrf:
                zrLpqxodpIOIiUrdodRAQnzcuSYJwYMm = gTzHpWZzGVsiwWsmnQBeYrUjRhSuKTYR
        elif zrLpqxodpIOIiUrdodRAQnzcuSYJwYMm in TFRHRWVhzggQXPqjimlOhBehWoxpklAk:
            LgUHEAHRDGfIZmKDscaTngvaiaiJrjrf = zrLpqxodpIOIiUrdodRAQnzcuSYJwYMm
            if LgUHEAHRDGfIZmKDscaTngvaiaiJrjrf in zrLpqxodpIOIiUrdodRAQnzcuSYJwYMm:
                zrLpqxodpIOIiUrdodRAQnzcuSYJwYMm = WMBegpOKBihmsbubvmRdozkhBbezmlGi
        return 'Error: File not found.'
def toaJpGhohWQJmFciVMtksgdjtmmLxJpZ(uEeycrPvTKJsHsbxlUNfEFHcvBGqkffT):
    if not uEeycrPvTKJsHsbxlUNfEFHcvBGqkffT.startswith('http'):

        FqoVVWCAigTEiKrxTHTSUNsqCWGaYRim = 'wqgGlTQHorigYwWxguJstMrEuScBQDbR'
        hbjtgDzQeYsEInYRElVPAaHBPMyFaURb = 'SdemSSDKWgFNuqGXRtfNcCTiWpjHrvJs'
        QzneDgTpuxMwrCvbkVVkrJQnMjdQPSYa = 'jiqijsKlmeoxZFGNCGcBIxDNbOjrRiAO'
        if FqoVVWCAigTEiKrxTHTSUNsqCWGaYRim == hbjtgDzQeYsEInYRElVPAaHBPMyFaURb:
            QzneDgTpuxMwrCvbkVVkrJQnMjdQPSYa = 'jiqijsKlmeoxZFGNCGcBIxDNbOjrRiAO'
            QzneDgTpuxMwrCvbkVVkrJQnMjdQPSYa = FqoVVWCAigTEiKrxTHTSUNsqCWGaYRim
        else:
            QzneDgTpuxMwrCvbkVVkrJQnMjdQPSYa = 'jiqijsKlmeoxZFGNCGcBIxDNbOjrRiAO'
            QzneDgTpuxMwrCvbkVVkrJQnMjdQPSYa = 'wqgGlTQHorigYwWxguJstMrEuScBQDbR'
        return 'Error: URL must begin with http:// or https:// .'
    WUetfBAbhvHorsheRaCajunshIBsTtEY = uEeycrPvTKJsHsbxlUNfEFHcvBGqkffT.split('/')[-1]
    if not WUetfBAbhvHorsheRaCajunshIBsTtEY:

        bHCxbdcGDCeoivlWYJOZgirUYkQjqxxK = 'IGkBYZzKtRJFeMgOYMtetroCfTbRNRvr'
        JKohdCLTxeAPLMgKrketmUaBmJTEVkFN = 'vLrpZkfmRjLijProeGAUKAKtphZLfhyI'
        FeEKnShwFrqgPVDuUoLiqWGndRpsajdv = 'PUZkWQrFNtsOUnJjXBgTiVzYdpcCjmqy'
        kBcjSiBKvWbkzIKLudTUOGQYyWonUZlK = 'hBqZhjcWfpJSlnGJloqdXlqSkoJonvFa'
        NddQrIRHosyFsuctyBNbQVfsXGKcewBv = 'iwloOrtxwXPATilNGvKcjQNZsCcsepKJ'
        if bHCxbdcGDCeoivlWYJOZgirUYkQjqxxK in JKohdCLTxeAPLMgKrketmUaBmJTEVkFN:
            bHCxbdcGDCeoivlWYJOZgirUYkQjqxxK = NddQrIRHosyFsuctyBNbQVfsXGKcewBv
            if JKohdCLTxeAPLMgKrketmUaBmJTEVkFN in FeEKnShwFrqgPVDuUoLiqWGndRpsajdv:
                JKohdCLTxeAPLMgKrketmUaBmJTEVkFN = kBcjSiBKvWbkzIKLudTUOGQYyWonUZlK
        elif JKohdCLTxeAPLMgKrketmUaBmJTEVkFN in bHCxbdcGDCeoivlWYJOZgirUYkQjqxxK:
            FeEKnShwFrqgPVDuUoLiqWGndRpsajdv = JKohdCLTxeAPLMgKrketmUaBmJTEVkFN
            if FeEKnShwFrqgPVDuUoLiqWGndRpsajdv in JKohdCLTxeAPLMgKrketmUaBmJTEVkFN:
                JKohdCLTxeAPLMgKrketmUaBmJTEVkFN = NddQrIRHosyFsuctyBNbQVfsXGKcewBv
        WUetfBAbhvHorsheRaCajunshIBsTtEY = 'file-'.format(str(datetime.datetime.now()).replace(' ', '-'))
    try:

        NCDazyqlhRLptpnOLtSgJdTMjrNocRNX = 'TbztMYrAtcZPntGZspOEUJQFOovkTUac'
        qDpvmBkCMWoMbAZlgsQeAUDLywjrIdsa = 'XdwGsHeeVkzotvDXPZlvgywgSjSrEwWc'
        YesUdHhXruTsbExwehYbHGrSoXovrgXU = 'acZMdgdLnpxZvzbNIIJFMLNqfSIziHRC'
        YHCsAJsYRzJArcthWADtHkiNBROsvvPt = 'NDhuWCwXarREAcrRhAFneasCIDrUewon'
        AHyBJbgYaylshlREywcsWGAHDKSrDkqZ = 'OXcBEylaUGlSjtuUOPskBmTGnDrllJZC'
        if NCDazyqlhRLptpnOLtSgJdTMjrNocRNX in qDpvmBkCMWoMbAZlgsQeAUDLywjrIdsa:
            NCDazyqlhRLptpnOLtSgJdTMjrNocRNX = AHyBJbgYaylshlREywcsWGAHDKSrDkqZ
            if qDpvmBkCMWoMbAZlgsQeAUDLywjrIdsa in YesUdHhXruTsbExwehYbHGrSoXovrgXU:
                qDpvmBkCMWoMbAZlgsQeAUDLywjrIdsa = YHCsAJsYRzJArcthWADtHkiNBROsvvPt
        elif qDpvmBkCMWoMbAZlgsQeAUDLywjrIdsa in NCDazyqlhRLptpnOLtSgJdTMjrNocRNX:
            YesUdHhXruTsbExwehYbHGrSoXovrgXU = qDpvmBkCMWoMbAZlgsQeAUDLywjrIdsa
            if YesUdHhXruTsbExwehYbHGrSoXovrgXU in qDpvmBkCMWoMbAZlgsQeAUDLywjrIdsa:
                qDpvmBkCMWoMbAZlgsQeAUDLywjrIdsa = AHyBJbgYaylshlREywcsWGAHDKSrDkqZ
        urllib.urlretrieve(uEeycrPvTKJsHsbxlUNfEFHcvBGqkffT, WUetfBAbhvHorsheRaCajunshIBsTtEY)
    except IOError:

        WVXHgYyMLbmiSbHtRyKyzMMzYhjqwoSN = 'AWtnOwvFPzxVkAuhXyRcVJJOTSXvWqxc'
        VvaOhFNGsIoYvOYEkDPpaFFvuaiHlyqx = 'fDGUmpbmQCrilsBtMYbWLScsMYuDEiNQ'
        FCeWuXiCVDzHuJYYhMzouQGCtTDBKoHk = 'CxYUFZZhJKktkswNaekbXjFmvdAjqTBM'
        nmpFzFVxJlCEcGieRjkqvNefxKNqQlzx = 'fglZqZhYJfkQcMLiNYNdWmPwQHEcZMBn'
        nGhlESqUQEScnLUiDBcuVYKqgyJGoXAi = 'KqtHhJlhXOEGkRpyRHoEsvrjXDksbXbh'
        SFEUHNpSxxNkpIpPXmpbeVDtrKBptoIy = 'GkPRBChuZLUhHbfqhSBdOIUUWyzdqPir'
        if FCeWuXiCVDzHuJYYhMzouQGCtTDBKoHk == nmpFzFVxJlCEcGieRjkqvNefxKNqQlzx:
            for SFEUHNpSxxNkpIpPXmpbeVDtrKBptoIy in nGhlESqUQEScnLUiDBcuVYKqgyJGoXAi:
                if SFEUHNpSxxNkpIpPXmpbeVDtrKBptoIy == nmpFzFVxJlCEcGieRjkqvNefxKNqQlzx:
                    nGhlESqUQEScnLUiDBcuVYKqgyJGoXAi = WVXHgYyMLbmiSbHtRyKyzMMzYhjqwoSN
                else:
                    nmpFzFVxJlCEcGieRjkqvNefxKNqQlzx = VvaOhFNGsIoYvOYEkDPpaFFvuaiHlyqx
        return 'Error: Download failed.'
    return 'File {} downloaded.'.format(WUetfBAbhvHorsheRaCajunshIBsTtEY)
