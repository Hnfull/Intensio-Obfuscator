# -*- coding: utf-8 -*-

try:
    hYgOoLzoJFjiJCvqSSmWZEYxfPXVWgpS = 'leGcqkEtZtwgAeKADeeUxXPMGzsRDhnJ'
    egEIbuqYuLEDuqRjtBuUtxDIfTVGaFdR = 'NxiTWSRPMaXvmOcwZZqDQdqydVvckUVY'
    tebTPQanVlVtLxcIAOBZqSIgdXZYOQam = 'hHHYEydkpQEwdOcpCTtuGdwNvbziABRn'
    RaJybfUIHcCVUGGGfKdVPzjhotpmIYaf = 'TMcEAapXoqCQSHfxWSHRtcrxWpbcduEr'
    ulFHvxDXcykbPmlYgMcPHzgQQFqKrWGe = 'flkEoCvxjitCtwmzcSzwpqMMrknKcsBY'
    NinZGKQKROtoxIbhSGfAKcOsGaccteTh = 'tfafhPcAMnSApGUdruPEPffcLJqCplfc'
    NZwRMoKQwkYwKqdTdrNOlPzffUGHdofM = [
            'leGcqkEtZtwgAeKADeeUxXPMGzsRDhnJ',
            'hHHYEydkpQEwdOcpCTtuGdwNvbziABRn',
            'flkEoCvxjitCtwmzcSzwpqMMrknKcsBY',
            'HroVRwdeONqUsubrEUrLHsNeckHyREDZ'
    ]
    for hYgOoLzoJFjiJCvqSSmWZEYxfPXVWgpS in NinZGKQKROtoxIbhSGfAKcOsGaccteTh:
        for egEIbuqYuLEDuqRjtBuUtxDIfTVGaFdR in tebTPQanVlVtLxcIAOBZqSIgdXZYOQam:
            if RaJybfUIHcCVUGGGfKdVPzjhotpmIYaf == ulFHvxDXcykbPmlYgMcPHzgQQFqKrWGe:
                egEIbuqYuLEDuqRjtBuUtxDIfTVGaFdR = hYgOoLzoJFjiJCvqSSmWZEYxfPXVWgpS
            elif ulFHvxDXcykbPmlYgMcPHzgQQFqKrWGe == egEIbuqYuLEDuqRjtBuUtxDIfTVGaFdR:
                egEIbuqYuLEDuqRjtBuUtxDIfTVGaFdR = NinZGKQKROtoxIbhSGfAKcOsGaccteTh
            else:
                ulFHvxDXcykbPmlYgMcPHzgQQFqKrWGe = NinZGKQKROtoxIbhSGfAKcOsGaccteTh
                for egEIbuqYuLEDuqRjtBuUtxDIfTVGaFdR in NZwRMoKQwkYwKqdTdrNOlPzffUGHdofM:
                    tebTPQanVlVtLxcIAOBZqSIgdXZYOQam = egEIbuqYuLEDuqRjtBuUtxDIfTVGaFdR
except Exception:
    pass
import socket

PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq = 'nbByeGXoIZZiUQVQpktmFYBqMsiaovJE'
JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe = 'YquYmVSlerkLQZQgbYURjfTJamSECCHX'
bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW = 'bKbOeOTKIcPwQTUllvlcHCLjNwlAbwFB'
RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz = 'orJuCYpgNTOgyXsjnbFPGabsostsdKVI'
if JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe == PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq:
    for PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq in JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe:
        if JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe == JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe:
            bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW = 'RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz'
        elif bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW == RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz:
            RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz = PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq
        else:
            PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq = JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe
elif bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW == bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW:
    for bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW in JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe:
        if RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz == JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe:
            bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW = 'RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz'
        elif bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW == RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz:
            RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz = PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq
        else:
            PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq = JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe
            for bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW in JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe:
                if RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz == JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe:
                    bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW = 'RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz'
                elif bRfhkfMBRlfsTrdRhcuGeQVAdeHwAAvW == RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz:
                    RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz = PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq
                else:
                    PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq = RrdbXSJdSWjYiEyzoeMWLXbnnRUhNbTz
else:
    PjjHQuwHDbmHZEJFhcguWKMxjkxWdzpq = JpQWbnRSovOhVLbxtQMYlfeWNUTNsjXe
KcQIvgcBYsFcvvYBaeWGYySfgZWodiTb = [ 
            21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 179, 443, 445,
            514, 993, 995, 1723, 3306, 3389, 5900, 8000, 8080, 8443, 8888
]
def RIIkeigBsFnPYhEAbeKPinkIHRCmtEsM(ip):
    try:

        kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN = 'RcZhtGhUcKkuxOJtapVmOXiFBKthAfCL'
        gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ = 'zfbzcaEqVnzqFQVOkYBkqGPkbPrRTqGc'
        mbyImCRCSkYplljNRJTxJdrUZlREeaSZ = 'YWICXynXbURrpxpfKBvksGkhgjXcetlV'
        adUDbViQhwVpedCHNzZcchkpBNowribC = 'YwjvghHZwujkupjmOmyxAosBfsaKayUS'
        if gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ == kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN:
            for kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN in gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ:
                if gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ == gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ:
                    mbyImCRCSkYplljNRJTxJdrUZlREeaSZ = 'adUDbViQhwVpedCHNzZcchkpBNowribC'
                elif mbyImCRCSkYplljNRJTxJdrUZlREeaSZ == adUDbViQhwVpedCHNzZcchkpBNowribC:
                    adUDbViQhwVpedCHNzZcchkpBNowribC = kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN
                else:
                    kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN = gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ
        elif mbyImCRCSkYplljNRJTxJdrUZlREeaSZ == mbyImCRCSkYplljNRJTxJdrUZlREeaSZ:
            for mbyImCRCSkYplljNRJTxJdrUZlREeaSZ in gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ:
                if adUDbViQhwVpedCHNzZcchkpBNowribC == gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ:
                    mbyImCRCSkYplljNRJTxJdrUZlREeaSZ = 'adUDbViQhwVpedCHNzZcchkpBNowribC'
                elif mbyImCRCSkYplljNRJTxJdrUZlREeaSZ == adUDbViQhwVpedCHNzZcchkpBNowribC:
                    adUDbViQhwVpedCHNzZcchkpBNowribC = kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN
                else:
                    kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN = gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ
                    for mbyImCRCSkYplljNRJTxJdrUZlREeaSZ in gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ:
                        if adUDbViQhwVpedCHNzZcchkpBNowribC == gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ:
                            mbyImCRCSkYplljNRJTxJdrUZlREeaSZ = 'adUDbViQhwVpedCHNzZcchkpBNowribC'
                        elif mbyImCRCSkYplljNRJTxJdrUZlREeaSZ == adUDbViQhwVpedCHNzZcchkpBNowribC:
                            adUDbViQhwVpedCHNzZcchkpBNowribC = kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN
                        else:
                            kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN = adUDbViQhwVpedCHNzZcchkpBNowribC
        else:
            kBiuGLOKbArRIDOHdcKCMcUDPMTatyDN = gUcwZPYDbxgWEGliJpdBptCifGlsjDYJ
        socket.inet_aton(ip)
    except socket.error:

        vGOBXWknXTehRBeyumaYCpUoDUnJotpw = 'JVrAsXKoKSSZzGCKIozuNwWTtiBzKZRW'
        YUHXDoJoPQSXaomEOVfpBmWDjKCtCxpO = 'ZhBfLlNDBqIabNaXpTuPsTWCUHXRLGGk'
        if vGOBXWknXTehRBeyumaYCpUoDUnJotpw != YUHXDoJoPQSXaomEOVfpBmWDjKCtCxpO:
            vGOBXWknXTehRBeyumaYCpUoDUnJotpw = 'ZhBfLlNDBqIabNaXpTuPsTWCUHXRLGGk'
            YUHXDoJoPQSXaomEOVfpBmWDjKCtCxpO = vGOBXWknXTehRBeyumaYCpUoDUnJotpw
            vGOBXWknXTehRBeyumaYCpUoDUnJotpw = 'JVrAsXKoKSSZzGCKIozuNwWTtiBzKZRW'
        return 'Error: Invalid IP address.'
    VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = ''

    QmpjVhUOfCyOzhcPBKqzwfjfoJnvYxpJ = 'KxvuLzUhvyVfuIefdFoEYEqGadpJjhVL'
    vhsUZtsOuVAXwkmtMJrjXnHKFGYjhDup = 'atdejCscBsyytXyxvPbKLDapakxaCmYD'
    xJkdCMGgZPkTOxJGgArqKQBKLnPZDZWE = 'ItwPYWrrnokGnVFRPKzfzEGQYZFHUAbY'
    iCFsFjycihzuzWDvJTvpSjviEbOxPiwi = 'INlgrRyTCtbHaxwDAEiOVmgxVpokFgJV'
    rqojSPIVdidffKtljEjxWusllbANywWG = 'dbzdKkntfrpwDojxAjjKrFbZFhmZuQkn'
    if QmpjVhUOfCyOzhcPBKqzwfjfoJnvYxpJ in vhsUZtsOuVAXwkmtMJrjXnHKFGYjhDup:
        QmpjVhUOfCyOzhcPBKqzwfjfoJnvYxpJ = rqojSPIVdidffKtljEjxWusllbANywWG
        if vhsUZtsOuVAXwkmtMJrjXnHKFGYjhDup in xJkdCMGgZPkTOxJGgArqKQBKLnPZDZWE:
            vhsUZtsOuVAXwkmtMJrjXnHKFGYjhDup = iCFsFjycihzuzWDvJTvpSjviEbOxPiwi
    elif vhsUZtsOuVAXwkmtMJrjXnHKFGYjhDup in QmpjVhUOfCyOzhcPBKqzwfjfoJnvYxpJ:
        xJkdCMGgZPkTOxJGgArqKQBKLnPZDZWE = vhsUZtsOuVAXwkmtMJrjXnHKFGYjhDup
        if xJkdCMGgZPkTOxJGgArqKQBKLnPZDZWE in vhsUZtsOuVAXwkmtMJrjXnHKFGYjhDup:
            vhsUZtsOuVAXwkmtMJrjXnHKFGYjhDup = rqojSPIVdidffKtljEjxWusllbANywWG
    for WgXeaMiUpUVNAiiNOasYVweZvoXrvcya in KcQIvgcBYsFcvvYBaeWGYySfgZWodiTb:

        arrrImJNkTNLhDOVkAOYCjxymjVcLvyN = 'rdQnbeWSsnIPAWgXngGZKwCjPKHuIMot'
        aiPRshEENkSsaqhUmhNCylFbYTypVlau = 'mMzLnYBdMoXnPrHBbiOadKNIsmNFunXR'
        wREuJeYYmCrCHfDgFsZpceglqhKQhxxC = 'VokIfqlTvvfGEqMvrNRRLBAYgkBoQjBx'
        if arrrImJNkTNLhDOVkAOYCjxymjVcLvyN == aiPRshEENkSsaqhUmhNCylFbYTypVlau:
            wREuJeYYmCrCHfDgFsZpceglqhKQhxxC = 'VokIfqlTvvfGEqMvrNRRLBAYgkBoQjBx'
            wREuJeYYmCrCHfDgFsZpceglqhKQhxxC = arrrImJNkTNLhDOVkAOYCjxymjVcLvyN
        else:
            wREuJeYYmCrCHfDgFsZpceglqhKQhxxC = 'VokIfqlTvvfGEqMvrNRRLBAYgkBoQjBx'
            wREuJeYYmCrCHfDgFsZpceglqhKQhxxC = 'rdQnbeWSsnIPAWgXngGZKwCjPKHuIMot'
        bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sSYYysPVftRzJHHgzYjGhksBTdQnYQhc = bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.connect_ex((ip, WgXeaMiUpUVNAiiNOasYVweZvoXrvcya))
        socket.setdefaulttimeout(0.5)
        fiplOGDZREGlveachxspnxQqTdNbgVYC = 'open' if not sSYYysPVftRzJHHgzYjGhksBTdQnYQhc else 'closed'

        QGojlHTxSNoCKRxMJjbAHnyRxcHcNhwX = 'NFQauIqaDczLSUSlQrBQaWXecDHJKBqe'
        QakUsIlphGQuWWUsfxqCWTlKFIgfahOI = 'mtWOGXImMLXsFbzLNjuQmCitARnPUrFi'
        BcPRfIHRgPjwqEKtWMhIctruSltDsBEO = 'InopbQGjBgJkORqnTUTDHPSWIBDnZkaY'
        CygHAKNXezBPGNKdGJrdaAQZPYeSJkXC = 'iPsyONJaOmemiGRHpxwwzBNNmHngnkfU'
        WDSbrMSwXjnayrZQERmngfWonVfhPfbM = 'giQUYdgMGwRNbloVaJuzvCxMBfWKxTYZ'
        if QGojlHTxSNoCKRxMJjbAHnyRxcHcNhwX in QakUsIlphGQuWWUsfxqCWTlKFIgfahOI:
            QGojlHTxSNoCKRxMJjbAHnyRxcHcNhwX = WDSbrMSwXjnayrZQERmngfWonVfhPfbM
            if QakUsIlphGQuWWUsfxqCWTlKFIgfahOI in BcPRfIHRgPjwqEKtWMhIctruSltDsBEO:
                QakUsIlphGQuWWUsfxqCWTlKFIgfahOI = CygHAKNXezBPGNKdGJrdaAQZPYeSJkXC
        elif QakUsIlphGQuWWUsfxqCWTlKFIgfahOI in QGojlHTxSNoCKRxMJjbAHnyRxcHcNhwX:
            BcPRfIHRgPjwqEKtWMhIctruSltDsBEO = QakUsIlphGQuWWUsfxqCWTlKFIgfahOI
            if BcPRfIHRgPjwqEKtWMhIctruSltDsBEO in QakUsIlphGQuWWUsfxqCWTlKFIgfahOI:
                QakUsIlphGQuWWUsfxqCWTlKFIgfahOI = WDSbrMSwXjnayrZQERmngfWonVfhPfbM
        VCiTfAhlorMIlNVLauEPZyCIMIJODOxX += '{:>5}/tcp {:>7}\n'.format(WgXeaMiUpUVNAiiNOasYVweZvoXrvcya, fiplOGDZREGlveachxspnxQqTdNbgVYC)
    return VCiTfAhlorMIlNVLauEPZyCIMIJODOxX.rstrip()
