# -*- coding: utf-8 -*-

try:
    WSoIzmPgVYnyMamJipSuVqAtlUblWTQX = 'coLphCDmhZtyotnFAtUSNGdgcGuoxhOZ'
    iGXInofBAjgDTLFfjfQWXnRIGwgKRTHV = 'vHjesPoSCFMBIPIIizHbMmgxBNqvXozl'
    fDlLsBRGcTlGYpCtTSlNTrLirnUGWBsB = 'CbRWAIXtlCHgKVNXYlSlXKmXAQeaaEqO'
    WFpggHxukytOJsuJWPGjkusKClYOyRCy = 'reTFLwJnssslyDdQaRMDuKUEQvxWpyeC'
    nocpFDePPtqZfALMSCzhpklWbnsKuoVU = 'DZcaeiGvtouqZsAlSVmafGaLhhOwOMnB'
    dKNuQxRYjcTVBRUlFctaSdZuIhkMIupT = 'KYTYneyVJjlFeJGCBLpoOBIYbVforUCG'
    yTLwxDmwIzamLaFiGKHjunraPLDUDznk = [
            'coLphCDmhZtyotnFAtUSNGdgcGuoxhOZ',
            'CbRWAIXtlCHgKVNXYlSlXKmXAQeaaEqO',
            'DZcaeiGvtouqZsAlSVmafGaLhhOwOMnB',
            'RrOlYxZqhklRmJkuIOszXvGHyOGWaExf'
    ]
    for WSoIzmPgVYnyMamJipSuVqAtlUblWTQX in dKNuQxRYjcTVBRUlFctaSdZuIhkMIupT:
        for iGXInofBAjgDTLFfjfQWXnRIGwgKRTHV in fDlLsBRGcTlGYpCtTSlNTrLirnUGWBsB:
            if WFpggHxukytOJsuJWPGjkusKClYOyRCy == nocpFDePPtqZfALMSCzhpklWbnsKuoVU:
                iGXInofBAjgDTLFfjfQWXnRIGwgKRTHV = WSoIzmPgVYnyMamJipSuVqAtlUblWTQX
            elif nocpFDePPtqZfALMSCzhpklWbnsKuoVU == iGXInofBAjgDTLFfjfQWXnRIGwgKRTHV:
                iGXInofBAjgDTLFfjfQWXnRIGwgKRTHV = dKNuQxRYjcTVBRUlFctaSdZuIhkMIupT
            else:
                nocpFDePPtqZfALMSCzhpklWbnsKuoVU = dKNuQxRYjcTVBRUlFctaSdZuIhkMIupT
                for iGXInofBAjgDTLFfjfQWXnRIGwgKRTHV in yTLwxDmwIzamLaFiGKHjunraPLDUDznk:
                    fDlLsBRGcTlGYpCtTSlNTrLirnUGWBsB = iGXInofBAjgDTLFfjfQWXnRIGwgKRTHV
except Exception:
    pass
import os

try:
    aSrmAJpCFtLMyoYuxjyllBZJGsuTQcEt = 'DTBBCToDuIZOAxtcXZVdoOAwrbFOZoOW'
    OgJbkdNtISwYXEdXGXpygYdyjnubCuYo = 'ZHZbztTEwCsyVvdogGWOeWvxLarQCjaO'
    maEkCBTSbJnzLhgYUXSfECvrXzapoSkg = 'PRhHgsZhyqbDkJjtcmiBitQnOiSCtiId'
    ftARYTvBvruPxbnTfIDoxGOcNhcCnfZg = 'pXMbbcocYoHVwHHWPxdmuYIWSvBzcnrv'
    FgfOaBiKyxLSrAswRzpoLkwoMDSfsWzM = 'oehnzKogwtDPcDXFJNoRNlgMbQNsERLW'
    PnoIrpEMbsOFPNDwWBTIfnyKQSwvoKXt = 'XLoaziPNfFPOQnmTZLXFcVMUYQcCKKiE'
    rNtpibnahLlwHbGXAdKmYDuwgldCdekg = [
            'DTBBCToDuIZOAxtcXZVdoOAwrbFOZoOW',
            'PRhHgsZhyqbDkJjtcmiBitQnOiSCtiId',
            'oehnzKogwtDPcDXFJNoRNlgMbQNsERLW',
            'VdXIOPaJlPKaDxVYtwQLhTdNjLEgxvsr'
    ]
    for aSrmAJpCFtLMyoYuxjyllBZJGsuTQcEt in PnoIrpEMbsOFPNDwWBTIfnyKQSwvoKXt:
        for OgJbkdNtISwYXEdXGXpygYdyjnubCuYo in maEkCBTSbJnzLhgYUXSfECvrXzapoSkg:
            if ftARYTvBvruPxbnTfIDoxGOcNhcCnfZg == FgfOaBiKyxLSrAswRzpoLkwoMDSfsWzM:
                OgJbkdNtISwYXEdXGXpygYdyjnubCuYo = aSrmAJpCFtLMyoYuxjyllBZJGsuTQcEt
            elif FgfOaBiKyxLSrAswRzpoLkwoMDSfsWzM == OgJbkdNtISwYXEdXGXpygYdyjnubCuYo:
                OgJbkdNtISwYXEdXGXpygYdyjnubCuYo = PnoIrpEMbsOFPNDwWBTIfnyKQSwvoKXt
            else:
                FgfOaBiKyxLSrAswRzpoLkwoMDSfsWzM = PnoIrpEMbsOFPNDwWBTIfnyKQSwvoKXt
                for OgJbkdNtISwYXEdXGXpygYdyjnubCuYo in rNtpibnahLlwHbGXAdKmYDuwgldCdekg:
                    maEkCBTSbJnzLhgYUXSfECvrXzapoSkg = OgJbkdNtISwYXEdXGXpygYdyjnubCuYo
except Exception:
    pass
from Crypto import Random

yJOsRAUNKFsjbdIACbaWNDdquZEZlsoJ = 'lsfbVbZqRdswFjzJFBkYdisbGdamLsYC'
WsRVZQKozjQNhFGLKLXmizsMvmIzGBHO = 'TmDDKOAlUxVjtPHoBLkWHscnWyPBoYqo'
zFUjPXccEsxwxhMGhNuWWVFeUwWcoOPj = 'LSsvompfFSjbMMmkCHdQQdUskVFaLxkD'
yvrFmFaeFdRPYJUMkqCkDeJRJegYXCdF = 'siXiRjJtaJiLiKuFvLLWLAJtrymVMeeb'
wvypUfPLrXeIBnTiCOdxBQoBklJtRbWj = 'dIRoEFQpbfvYqLOxoLbVpBOjRRWLETgM'
DYAAnETiKIGHjTBcezeWxRxUcQNJUYqK = 'wfxUfGDyniaNttAySWHxNmxCDPWIWAup'
if yJOsRAUNKFsjbdIACbaWNDdquZEZlsoJ != yvrFmFaeFdRPYJUMkqCkDeJRJegYXCdF:
    WsRVZQKozjQNhFGLKLXmizsMvmIzGBHO = zFUjPXccEsxwxhMGhNuWWVFeUwWcoOPj
    for DYAAnETiKIGHjTBcezeWxRxUcQNJUYqK in yvrFmFaeFdRPYJUMkqCkDeJRJegYXCdF:
        if DYAAnETiKIGHjTBcezeWxRxUcQNJUYqK != zFUjPXccEsxwxhMGhNuWWVFeUwWcoOPj:
            WsRVZQKozjQNhFGLKLXmizsMvmIzGBHO = WsRVZQKozjQNhFGLKLXmizsMvmIzGBHO
        else:
            wvypUfPLrXeIBnTiCOdxBQoBklJtRbWj = yJOsRAUNKFsjbdIACbaWNDdquZEZlsoJ
else:
    zFUjPXccEsxwxhMGhNuWWVFeUwWcoOPj = yJOsRAUNKFsjbdIACbaWNDdquZEZlsoJ
    yJOsRAUNKFsjbdIACbaWNDdquZEZlsoJ = wvypUfPLrXeIBnTiCOdxBQoBklJtRbWj
    if zFUjPXccEsxwxhMGhNuWWVFeUwWcoOPj == yJOsRAUNKFsjbdIACbaWNDdquZEZlsoJ:
        for DYAAnETiKIGHjTBcezeWxRxUcQNJUYqK in yJOsRAUNKFsjbdIACbaWNDdquZEZlsoJ:
            if DYAAnETiKIGHjTBcezeWxRxUcQNJUYqK == zFUjPXccEsxwxhMGhNuWWVFeUwWcoOPj:
                zFUjPXccEsxwxhMGhNuWWVFeUwWcoOPj = yJOsRAUNKFsjbdIACbaWNDdquZEZlsoJ
            else:
                zFUjPXccEsxwxhMGhNuWWVFeUwWcoOPj = wvypUfPLrXeIBnTiCOdxBQoBklJtRbWj
from Crypto.Cipher import AES

LWbuvuCLvSuHsjoXZJVBzbTCipPETzIH = 'OEBKSiyiPCCsdYveScnRFLtxsUpIqHql'
OnAKLBNAnEyXAGviIvieWjLBqPeksWVy = 'XsRUEJivqsqttiEWIVZXiIKvJLveAtPP'
AUanfghrlJeejKBZDmMEjvbGNLnCXNNf = 'rbHfdZpKIADgGbykrBMfQrBYYqRIXKRx'
if LWbuvuCLvSuHsjoXZJVBzbTCipPETzIH == OnAKLBNAnEyXAGviIvieWjLBqPeksWVy:
    AUanfghrlJeejKBZDmMEjvbGNLnCXNNf = 'rbHfdZpKIADgGbykrBMfQrBYYqRIXKRx'
    AUanfghrlJeejKBZDmMEjvbGNLnCXNNf = LWbuvuCLvSuHsjoXZJVBzbTCipPETzIH
else:
    AUanfghrlJeejKBZDmMEjvbGNLnCXNNf = 'rbHfdZpKIADgGbykrBMfQrBYYqRIXKRx'
    AUanfghrlJeejKBZDmMEjvbGNLnCXNNf = 'OEBKSiyiPCCsdYveScnRFLtxsUpIqHql'
from Crypto.Hash import SHA256

LquwIvAyqtKqWobCUhGNljlXhRkaNiJm = 'BfJbnUNzSraPBagyaPrnRQorzIuPpnoH'
ICuTrDRYirJkQVUVLjqeBCIKdIvieLXE = 'UyWsnPbRghNyovgJxhzleYsFvFskiFqs'
ruwMrpHgEQwUSXyEGOjLUFvgyEOmeTgT = 'nNcCnKyjfIsaXJCwmayQGykdFqyFQxHX'
if LquwIvAyqtKqWobCUhGNljlXhRkaNiJm == ICuTrDRYirJkQVUVLjqeBCIKdIvieLXE:
    ruwMrpHgEQwUSXyEGOjLUFvgyEOmeTgT = 'nNcCnKyjfIsaXJCwmayQGykdFqyFQxHX'
    ruwMrpHgEQwUSXyEGOjLUFvgyEOmeTgT = LquwIvAyqtKqWobCUhGNljlXhRkaNiJm
else:
    ruwMrpHgEQwUSXyEGOjLUFvgyEOmeTgT = 'nNcCnKyjfIsaXJCwmayQGykdFqyFQxHX'
    ruwMrpHgEQwUSXyEGOjLUFvgyEOmeTgT = 'BfJbnUNzSraPBagyaPrnRQorzIuPpnoH'
from EYBbTgzttUVNJeaFoTQAigWyRNerSJJI import TmTSutmFIHdRrAOhGAzlNFhPzNDevirQ, peNsdNqpqIpCSZKCkGdTGcBYeqonlkiY

xQEnXSnlqRgqUvXsbOwajZDlKfPDTEzd = 'AnNjzoLBFuQYiNWlUWTTOEbukJjoeQBW'
DhYUVRhXlMIvfTyYRKZoFvUsoAFHYVkF = 'mAKlaIeTNzailJTWXIkInEIZqdGxWQHd'
FPDxWhBxOGIIwZCjREInNuiNRgULAbKf = 'rRGBnCyAoTPdIBRpaoUvmAFSsevJTaqj'
CAZtaHTOAAQcgkPOVEiUXzgWSnllgKxX = 'kTkIgmefNfzvLGvLxfaTyKJAaWBDuJQv'
vkStBqTioOxIahuNLKejXCEOVORxdsJz = 'dBMguIXClNGSDLdbWBpuLjIUJOluPPnG'
if xQEnXSnlqRgqUvXsbOwajZDlKfPDTEzd in DhYUVRhXlMIvfTyYRKZoFvUsoAFHYVkF:
    xQEnXSnlqRgqUvXsbOwajZDlKfPDTEzd = vkStBqTioOxIahuNLKejXCEOVORxdsJz
    if DhYUVRhXlMIvfTyYRKZoFvUsoAFHYVkF in FPDxWhBxOGIIwZCjREInNuiNRgULAbKf:
        DhYUVRhXlMIvfTyYRKZoFvUsoAFHYVkF = CAZtaHTOAAQcgkPOVEiUXzgWSnllgKxX
elif DhYUVRhXlMIvfTyYRKZoFvUsoAFHYVkF in xQEnXSnlqRgqUvXsbOwajZDlKfPDTEzd:
    FPDxWhBxOGIIwZCjREInNuiNRgULAbKf = DhYUVRhXlMIvfTyYRKZoFvUsoAFHYVkF
    if FPDxWhBxOGIIwZCjREInNuiNRgULAbKf in DhYUVRhXlMIvfTyYRKZoFvUsoAFHYVkF:
        DhYUVRhXlMIvfTyYRKZoFvUsoAFHYVkF = vkStBqTioOxIahuNLKejXCEOVORxdsJz
WEYvrZXfDBbbJxZGyNyCHkMhJTSHoawx = 'b14ce95fa4c33ac2803782d18341869f'

hQFCyMnhzBrcbuCCqTanaPEzzNOEguKi = 'iMVWupBSmviVGDxqnzgWjaXmRAzzbzJu'
RzqsYNExlPWFHKfiFeDORdqupoECOiFO = 'NqEgCQEaFnFstpNtyRrkURlxncruDFFv'
PmPuzPqvPPaEQBwhlljesOkYMPuTGTsX = 'iBxPIQNFYeXLwCMxPamgwWztBgYTREuj'
if hQFCyMnhzBrcbuCCqTanaPEzzNOEguKi == RzqsYNExlPWFHKfiFeDORdqupoECOiFO:
    PmPuzPqvPPaEQBwhlljesOkYMPuTGTsX = 'iBxPIQNFYeXLwCMxPamgwWztBgYTREuj'
    PmPuzPqvPPaEQBwhlljesOkYMPuTGTsX = hQFCyMnhzBrcbuCCqTanaPEzzNOEguKi
else:
    PmPuzPqvPPaEQBwhlljesOkYMPuTGTsX = 'iBxPIQNFYeXLwCMxPamgwWztBgYTREuj'
    PmPuzPqvPPaEQBwhlljesOkYMPuTGTsX = 'iMVWupBSmviVGDxqnzgWjaXmRAzzbzJu'
class qRXkwmjZipeaEafWHLiQRLpoAluFMsOi(Exception):
    pass

    try:
        GMCmlxtKvOMXhwmmVaHwOfSsibMunBFk = 'fJZxYUAkupKdrJzPamUSQgxDRJFRbzQP'
        cdNbGhHBJNohELFpbnVVWrxgjnzEvbSQ = 'xwUIKXeNusAqcDzpooeDhxPOXHmQtlKC'
        ybzIVuCmmLoiAVMimacrozPGyXZwwgUD = 'rRwkFvOWjzXRyKPHMxgHpnbiQheNsgmq'
        nzXTQdJojXONoIDDwziKHAwAHOOzokta = 'JBvkDZIJWwskurRXjgQURIJJwrSyLvEZ'
        owAtuwDAaatEraKrGFUyPqjCoXLHeXOO = 'kiKTTPdOFLFIjehelyNtfjzYDehIeHZq'
        qGUJufIWZfPPBtMTEBSOeNRlhzXOsCOG = 'tBJFMjeOKtDrlCdJtXTjQrxVNhtXarkU'
        CwgoSJIoJbEjDwaEjmwKTJuCDNOTwosD = [
                'fJZxYUAkupKdrJzPamUSQgxDRJFRbzQP',
                'rRwkFvOWjzXRyKPHMxgHpnbiQheNsgmq',
                'kiKTTPdOFLFIjehelyNtfjzYDehIeHZq',
                'fSzqFrvNbyooCsnTbdLkEzKpsHSfltIW'
        ]
        for GMCmlxtKvOMXhwmmVaHwOfSsibMunBFk in qGUJufIWZfPPBtMTEBSOeNRlhzXOsCOG:
            for cdNbGhHBJNohELFpbnVVWrxgjnzEvbSQ in ybzIVuCmmLoiAVMimacrozPGyXZwwgUD:
                if nzXTQdJojXONoIDDwziKHAwAHOOzokta == owAtuwDAaatEraKrGFUyPqjCoXLHeXOO:
                    cdNbGhHBJNohELFpbnVVWrxgjnzEvbSQ = GMCmlxtKvOMXhwmmVaHwOfSsibMunBFk
                elif owAtuwDAaatEraKrGFUyPqjCoXLHeXOO == cdNbGhHBJNohELFpbnVVWrxgjnzEvbSQ:
                    cdNbGhHBJNohELFpbnVVWrxgjnzEvbSQ = qGUJufIWZfPPBtMTEBSOeNRlhzXOsCOG
                else:
                    owAtuwDAaatEraKrGFUyPqjCoXLHeXOO = qGUJufIWZfPPBtMTEBSOeNRlhzXOsCOG
                    for cdNbGhHBJNohELFpbnVVWrxgjnzEvbSQ in CwgoSJIoJbEjDwaEjmwKTJuCDNOTwosD:
                        ybzIVuCmmLoiAVMimacrozPGyXZwwgUD = cdNbGhHBJNohELFpbnVVWrxgjnzEvbSQ
    except Exception:
        pass
def mGITNgSbBMutVAlJzbuTzfQENMRozNqy(bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv, crueQJJJuDSxEoVSoUQqvhtKdljWfahH=AES.block_size):
    ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI = (crueQJJJuDSxEoVSoUQqvhtKdljWfahH - (len(bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv) % crueQJJJuDSxEoVSoUQqvhtKdljWfahH))
    return bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv + (chr(ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI)*ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI)
def rJdKMEwYcvoCJsKYjdHBLsoPrvZJnMhJ(bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv):
    ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI = bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv[-1]
    if bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.endswith(ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI*ord(ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI)):

        YDTfQDsNCSjZXyXplnaKJDRvJZVLFIuA = 'oRjWvKunvHlFyqjSIcewkSnDMvTaOlyC'
        tiBQoBUzasUYXirLetZIJKCgZNlRKiGq = 'rQJQZlXmxHwAvRcecbmLbEDsiZPglisp'
        if YDTfQDsNCSjZXyXplnaKJDRvJZVLFIuA != tiBQoBUzasUYXirLetZIJKCgZNlRKiGq:
            YDTfQDsNCSjZXyXplnaKJDRvJZVLFIuA = 'rQJQZlXmxHwAvRcecbmLbEDsiZPglisp'
            tiBQoBUzasUYXirLetZIJKCgZNlRKiGq = YDTfQDsNCSjZXyXplnaKJDRvJZVLFIuA
            YDTfQDsNCSjZXyXplnaKJDRvJZVLFIuA = 'oRjWvKunvHlFyqjSIcewkSnDMvTaOlyC'
        return bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv[:-ord(ZtZphMLIBRKhfmGXFtBJEyVKGtjKoWNI)]
    raise qRXkwmjZipeaEafWHLiQRLpoAluFMsOi("PKCS7 improper padding {}".format(repr(bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv[-32:])))
def oNZYiYHmYKBhkOiCodDdHRZcATGFPzLg(sock, server=True, bits=2048):
    WgXeaMiUpUVNAiiNOasYVweZvoXrvcya = 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF;

    try:
        gjJMlUluskjdYcoaLxukKTlVXfzBvfSb = 'irxEqylSpxlPlPNasLRdxyFjfghUreUE'
        SegsCpYgcvnCfzHRsOgDijpszXNuVZzh = 'mVReCkgabUfRBwyRDqtECPMZNPlkcYBb'
        TjnsImSOUrrPPhdaghrMFRftMJxVGyYG = 'jRysvVmGjYHEZCIMloPHWeIkdBJpmggT'
        XZbjrJGETmjvOnsvrwpxjjPCIQXySdvK = 'qnhsJPGrczXPpciPyYfBwoKJpxolCYGc'
        fCBKRexhupGfCSZPWtjpIBYRFKrHggil = 'PTfQIYZfoGadLGzbmgzUkGsVPmfHcHwz'
        EOVGwKHnadtkISWAoxZGdtNofenrtfiA = 'pHnKHxeomWTkJNBxkrQfblgvDhJdnQDh'
        mVVfhVtOqpFrmRcjKcKNEdgBmlUWNEPi = [
                'irxEqylSpxlPlPNasLRdxyFjfghUreUE',
                'jRysvVmGjYHEZCIMloPHWeIkdBJpmggT',
                'PTfQIYZfoGadLGzbmgzUkGsVPmfHcHwz',
                'sVGllGTUavcKqELQFBcLPtvnmtatoIdg'
        ]
        for gjJMlUluskjdYcoaLxukKTlVXfzBvfSb in EOVGwKHnadtkISWAoxZGdtNofenrtfiA:
            for SegsCpYgcvnCfzHRsOgDijpszXNuVZzh in TjnsImSOUrrPPhdaghrMFRftMJxVGyYG:
                if XZbjrJGETmjvOnsvrwpxjjPCIQXySdvK == fCBKRexhupGfCSZPWtjpIBYRFKrHggil:
                    SegsCpYgcvnCfzHRsOgDijpszXNuVZzh = gjJMlUluskjdYcoaLxukKTlVXfzBvfSb
                elif fCBKRexhupGfCSZPWtjpIBYRFKrHggil == SegsCpYgcvnCfzHRsOgDijpszXNuVZzh:
                    SegsCpYgcvnCfzHRsOgDijpszXNuVZzh = EOVGwKHnadtkISWAoxZGdtNofenrtfiA
                else:
                    fCBKRexhupGfCSZPWtjpIBYRFKrHggil = EOVGwKHnadtkISWAoxZGdtNofenrtfiA
                    for SegsCpYgcvnCfzHRsOgDijpszXNuVZzh in mVVfhVtOqpFrmRcjKcKNEdgBmlUWNEPi:
                        TjnsImSOUrrPPhdaghrMFRftMJxVGyYG = SegsCpYgcvnCfzHRsOgDijpszXNuVZzh
    except Exception:
        pass
    FzCrarPVOCrQnRheyAYqJBRaPeTWzYgw = 2

    VfzJfDNvmvuJManrZSqFORhzGUFTVETK = 'TuUhqJhFfhpmUqfJdQCYaoABTBJVdVpF'
    OSHmkXblvFWOHflIKiXNvyJiMOBtyuJg = 'oRHjPeBbGOaLghdfzKWGLsZsfxzddAmb'
    QqPPGomIdSUoqCjBfCMjsoogvMrjAoms = 'eQdiyWDLNWZZLhOdzqZrEweEtggVQlQX'
    FmLCggMEkKgcERtYXVtRBUntCeUBvkNn = 'xSnpoMaPvRiebOReVNbdEQzsTajJQDOc'
    FlyJYdnmMOZGoKmMCVbxPSgcwxHYJqez = 'gLDOOkIkwobfzUqNditaFyRBSeMlHxlK'
    oHGvxitrqMeoepNBanoCdWXshwalYQmj = 'mdrtbeDkhnfeCvdgkRyqQyseDWOGKvwn'
    if QqPPGomIdSUoqCjBfCMjsoogvMrjAoms == FmLCggMEkKgcERtYXVtRBUntCeUBvkNn:
        for oHGvxitrqMeoepNBanoCdWXshwalYQmj in FlyJYdnmMOZGoKmMCVbxPSgcwxHYJqez:
            if oHGvxitrqMeoepNBanoCdWXshwalYQmj == FmLCggMEkKgcERtYXVtRBUntCeUBvkNn:
                FlyJYdnmMOZGoKmMCVbxPSgcwxHYJqez = VfzJfDNvmvuJManrZSqFORhzGUFTVETK
            else:
                FmLCggMEkKgcERtYXVtRBUntCeUBvkNn = OSHmkXblvFWOHflIKiXNvyJiMOBtyuJg
    gxOFKmPBXnkCwLBFhlRRNpoPpJfHvNBS = peNsdNqpqIpCSZKCkGdTGcBYeqonlkiY(os.urandom(32))
    UozxudQjIyvAViNiiIDfFHXbScAnwGlQ = pow(FzCrarPVOCrQnRheyAYqJBRaPeTWzYgw, gxOFKmPBXnkCwLBFhlRRNpoPpJfHvNBS, WgXeaMiUpUVNAiiNOasYVweZvoXrvcya)
    if server:

        IofovHyDZvBSXuBrWsxxDXvxbJCyPuul = 'GIIZRacPXzDtbsuaQBxblAZCTjyvsJrr'
        xniJFMvfnYFAxCnGTFOyUmeYIQkCzyeG = 'VsBQcTwVrYQWEnkJmZETqJQgyFfuqfxS'
        if IofovHyDZvBSXuBrWsxxDXvxbJCyPuul != xniJFMvfnYFAxCnGTFOyUmeYIQkCzyeG:
            IofovHyDZvBSXuBrWsxxDXvxbJCyPuul = 'VsBQcTwVrYQWEnkJmZETqJQgyFfuqfxS'
            xniJFMvfnYFAxCnGTFOyUmeYIQkCzyeG = IofovHyDZvBSXuBrWsxxDXvxbJCyPuul
            IofovHyDZvBSXuBrWsxxDXvxbJCyPuul = 'GIIZRacPXzDtbsuaQBxblAZCTjyvsJrr'
        sock.send(TmTSutmFIHdRrAOhGAzlNFhPzNDevirQ(UozxudQjIyvAViNiiIDfFHXbScAnwGlQ))
        b = peNsdNqpqIpCSZKCkGdTGcBYeqonlkiY(sock.recv(4096))
    else:

        HsOqJRRNUoKAyyvwdYPacbKyXqpxJFla = 'EPpRZLcqCchwJeTpSClbtQHaHlUzqHIi'
        ROulUjkaHYLhbPlIndtRMDuStfOmpKrK = 'tquGQtiSQdyPFJbPGAkepMRIYjJgWPlv'
        wFaaIUmDLWdOxlnrZIcwceFShDlZwwnA = 'ytitoVjaVhyrKKzrmiDpUbUJraSVSuJN'
        jgGaRonTKjjtBCnYHBnkaKGEtiOikovg = 'kPOeAsrqhxLUWYWfFWcZCxRiiblTXqtq'
        kNIYOFKIjxjLVgLVfaGiMyPsIpoYHhim = 'EGCzRpzaEdEXYBtXqcehyldUHmRIRqZF'
        eiFxezbEypnzAtryzSzTACaAuKrOJHwC = 'AyhrnoHQmHJOMEsQeajPyWxbbBYnKhDV'
        if HsOqJRRNUoKAyyvwdYPacbKyXqpxJFla != jgGaRonTKjjtBCnYHBnkaKGEtiOikovg:
            ROulUjkaHYLhbPlIndtRMDuStfOmpKrK = wFaaIUmDLWdOxlnrZIcwceFShDlZwwnA
            for eiFxezbEypnzAtryzSzTACaAuKrOJHwC in jgGaRonTKjjtBCnYHBnkaKGEtiOikovg:
                if eiFxezbEypnzAtryzSzTACaAuKrOJHwC != wFaaIUmDLWdOxlnrZIcwceFShDlZwwnA:
                    ROulUjkaHYLhbPlIndtRMDuStfOmpKrK = ROulUjkaHYLhbPlIndtRMDuStfOmpKrK
                else:
                    kNIYOFKIjxjLVgLVfaGiMyPsIpoYHhim = HsOqJRRNUoKAyyvwdYPacbKyXqpxJFla
        else:
            wFaaIUmDLWdOxlnrZIcwceFShDlZwwnA = HsOqJRRNUoKAyyvwdYPacbKyXqpxJFla
            HsOqJRRNUoKAyyvwdYPacbKyXqpxJFla = kNIYOFKIjxjLVgLVfaGiMyPsIpoYHhim
            if wFaaIUmDLWdOxlnrZIcwceFShDlZwwnA == HsOqJRRNUoKAyyvwdYPacbKyXqpxJFla:
                for eiFxezbEypnzAtryzSzTACaAuKrOJHwC in HsOqJRRNUoKAyyvwdYPacbKyXqpxJFla:
                    if eiFxezbEypnzAtryzSzTACaAuKrOJHwC == wFaaIUmDLWdOxlnrZIcwceFShDlZwwnA:
                        wFaaIUmDLWdOxlnrZIcwceFShDlZwwnA = HsOqJRRNUoKAyyvwdYPacbKyXqpxJFla
                    else:
                        wFaaIUmDLWdOxlnrZIcwceFShDlZwwnA = kNIYOFKIjxjLVgLVfaGiMyPsIpoYHhim
        b = peNsdNqpqIpCSZKCkGdTGcBYeqonlkiY(sock.recv(4096))
        sock.send(TmTSutmFIHdRrAOhGAzlNFhPzNDevirQ(UozxudQjIyvAViNiiIDfFHXbScAnwGlQ))
    bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv = pow(b, gxOFKmPBXnkCwLBFhlRRNpoPpJfHvNBS, WgXeaMiUpUVNAiiNOasYVweZvoXrvcya)
    return SHA256.new(TmTSutmFIHdRrAOhGAzlNFhPzNDevirQ(bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv)).digest()
def PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib(VREnzMSuhOCLglAEDzkdovzalyxgeMYg, KEY):
    VREnzMSuhOCLglAEDzkdovzalyxgeMYg = mGITNgSbBMutVAlJzbuTzfQENMRozNqy(VREnzMSuhOCLglAEDzkdovzalyxgeMYg)
    NYdkrxohSZrPGxuMHUBySNIcjJZOLIqE = Random.new().read(AES.block_size)
    IhBiPWGogFrpkERPuFqdPIiHOIfonjOy = AES.new(KEY, AES.MODE_CBC, NYdkrxohSZrPGxuMHUBySNIcjJZOLIqE)
    return NYdkrxohSZrPGxuMHUBySNIcjJZOLIqE + IhBiPWGogFrpkERPuFqdPIiHOIfonjOy.encrypt(VREnzMSuhOCLglAEDzkdovzalyxgeMYg)
def VZGbVmtqTmDOEQHhKIeKvmdxXyGUEXLA(ciphertext, KEY):
    NYdkrxohSZrPGxuMHUBySNIcjJZOLIqE = ciphertext[:AES.block_size]
    IhBiPWGogFrpkERPuFqdPIiHOIfonjOy = AES.new(KEY, AES.MODE_CBC, NYdkrxohSZrPGxuMHUBySNIcjJZOLIqE)
    VREnzMSuhOCLglAEDzkdovzalyxgeMYg = IhBiPWGogFrpkERPuFqdPIiHOIfonjOy.decrypt(ciphertext[AES.block_size:])
    return rJdKMEwYcvoCJsKYjdHBLsoPrvZJnMhJ(VREnzMSuhOCLglAEDzkdovzalyxgeMYg)
