# Actions can be performed by users

- Exclude `variables/classes/functions/strings/parameter-of-function` from [words exclusion](../../intensio/exclude/string_to_string_mixed/exclude_word_by_user.txt)
- Exclude `file name` from [file names exclusion](../../intensio/exclude/file_name/exclude_file_name_by_user.txt)