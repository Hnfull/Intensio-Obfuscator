# -*- coding: utf-8 -*-
def QMIXxMDrdPYrFspdzYjyJWmsnlXDChxB(skPZXAlscSTzoMuxPLMHeNcDldoueTxd):
    XDvTtxydQeJRnYjckFghcOeUmYrzPBWl = 0
    while skPZXAlscSTzoMuxPLMHeNcDldoueTxd:
        XDvTtxydQeJRnYjckFghcOeUmYrzPBWl = XDvTtxydQeJRnYjckFghcOeUmYrzPBWl << 8
        XDvTtxydQeJRnYjckFghcOeUmYrzPBWl += ord(skPZXAlscSTzoMuxPLMHeNcDldoueTxd[-1])
        skPZXAlscSTzoMuxPLMHeNcDldoueTxd = skPZXAlscSTzoMuxPLMHeNcDldoueTxd[:-1]
    return XDvTtxydQeJRnYjckFghcOeUmYrzPBWl
def AXWwBuyAOMQCqbhUQYMcxInOQhTaHDye(XDvTtxydQeJRnYjckFghcOeUmYrzPBWl):
    otVeesgvjJIGsNCzQXfcPlxfyvkGUCpg = ''
    while XDvTtxydQeJRnYjckFghcOeUmYrzPBWl:
        otVeesgvjJIGsNCzQXfcPlxfyvkGUCpg += chr(XDvTtxydQeJRnYjckFghcOeUmYrzPBWl & 0xff)
        XDvTtxydQeJRnYjckFghcOeUmYrzPBWl = XDvTtxydQeJRnYjckFghcOeUmYrzPBWl >> 8
    return otVeesgvjJIGsNCzQXfcPlxfyvkGUCpg
