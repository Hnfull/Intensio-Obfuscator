#!/usr/bin/env python
# -*- coding: utf-8 -*-
import socket
rbXQzISKNSMEmtUcIWwdVyDusHLKLIVc = 'pQtLiXIatYHaWpJUclgxlRkYgeujxcjb'
HQgqJQTCNSGkmQxilScMsGtKvNlerlJp = 'MXIPBPjKVcESbDRzASqOipPbqxfCMuzh'
if rbXQzISKNSMEmtUcIWwdVyDusHLKLIVc != HQgqJQTCNSGkmQxilScMsGtKvNlerlJp:
    ZYSFSMiEZqpvbJMeCRfwauctyGNeuyRp = 'HvJptoXBfrqjQoTGYHlOzphWCfGYQIwr'
    lKFAyaRXaWwUwJhlgPgRvRQJXnXqcTpt = 'MOqFhcZzdpYRKldexiuQVEGgBLwLDCkE'
    lKFAyaRXaWwUwJhlgPgRvRQJXnXqcTpt = ZYSFSMiEZqpvbJMeCRfwauctyGNeuyRp
import subprocess
qBabwppBudiUjCNPRnzzZAOhrkkomnfZ = 'XAVGnXmBADjeyZMkgImPCZfvMwdWNeDq'
oumCYDUALSCEnpfCvMVPHVnfcoXFIetj = 'CSeAiGCuVAVnXsErUPdRAuejySIMiLsP'
if qBabwppBudiUjCNPRnzzZAOhrkkomnfZ != oumCYDUALSCEnpfCvMVPHVnfcoXFIetj:
    zvEuMYLweAbGOcEALJDjbnxriOAaGIoi = 'JfOaJppOSmsEAITQQAZxDnXUXsJRJvpb'
    SjONvPjvcTBtoAlGqoENXandxlWIemgn = 'LsZnEEemGMwDbuoPIsHTSotftXmCrgPQ'
    SjONvPjvcTBtoAlGqoENXandxlWIemgn = zvEuMYLweAbGOcEALJDjbnxriOAaGIoi
import struct
KxfFZLFazxvjbaRLwmRLYhQuTinpJqeR = 'fWSpglvGkWlXIctZxFtYyOqwKBCLIwpt'
VzLbCwSxfaGwbpWyxOyuKAQOtPGZxKdp = 'RkbydXNLkYsTAKSBJczxvpPeuQRZqbto'
OlGIEBAeIEtVwRKoJDrVfTvBQZBiaejP = 'TytQFulVSFUHKNtCXaquFDMxrNxGzoro'
xjsENrlghUldVeWDKDJiqzZZtkgURdIn = 'jTKXZfPExROAEsrbXrjrhRStWphxsxFT'
bdXxLTLgBlAQIUeZLACiNtqcfqVwKgYb = 'ZKZXdKgdRduOVqnKcGSEQJjhiYcxsLyY'
CzbjtcviDFnUVcfESDYWabxeyyNWoDqx = 'TbeJCZxzEjziLucgldARvAVGdvtovyuZ'
if OlGIEBAeIEtVwRKoJDrVfTvBQZBiaejP == xjsENrlghUldVeWDKDJiqzZZtkgURdIn:
    for CzbjtcviDFnUVcfESDYWabxeyyNWoDqx in bdXxLTLgBlAQIUeZLACiNtqcfqVwKgYb:
        if CzbjtcviDFnUVcfESDYWabxeyyNWoDqx == xjsENrlghUldVeWDKDJiqzZZtkgURdIn:
            bdXxLTLgBlAQIUeZLACiNtqcfqVwKgYb = KxfFZLFazxvjbaRLwmRLYhQuTinpJqeR
        else:
            xjsENrlghUldVeWDKDJiqzZZtkgURdIn = VzLbCwSxfaGwbpWyxOyuKAQOtPGZxKdp
import sys
oxKupgFAslOXjHnOYZepRZisYNzNOInQ = 'DqCFqfppZHARMJVJgnHeAcLIjWfRtyKF'
BQYrehTegklvWylPBLPHTTOFTfghFdTy = 'UyBEknGMFfYVGwRJwcpFpJmyiJyNMMCx'
if oxKupgFAslOXjHnOYZepRZisYNzNOInQ != BQYrehTegklvWylPBLPHTTOFTfghFdTy:
    oyiFULGeuPahTmJCKoQgUIhcURHQgJVk = 'jGJGddtHLrlNPMQubYdUgheHHpxXRkoR'
    TkZyUojCWPlhQqbzlDrYUtrwsTcPtAWH = 'cyPzrQBCWdPkzqnHjBTCYsHvKIZktigO'
    TkZyUojCWPlhQqbzlDrYUtrwsTcPtAWH = oyiFULGeuPahTmJCKoQgUIhcURHQgJVk
try:
    STEJMqaJsHepAeSTbRWsKDEOkgHMnLGd = 'FgFfhzjnoSlBuYKcpdxKVJeSrsJMnrhB'
    LPjTAOqkEIfagnfeJEeNxqOIqUBerLLB = 'QUqZQgxrilczNRhvcJKVUZxElbRsmtGh'
    ThTRFMxmwYjkHbPJdZCwuSnPRdNncVUD = 'EcoJHntIRTYrsZphIAiAiBIKtNpyeTiH'
    WKTuTquDNlnpsIsEsBnsrcVpoAltkNsk = 'pLrbtzieQoSDNWAnByLGbCNSqEdXTQkl'
    fpRHKgrpHWwQLzwhJIGIHuNUTQctVsMP = 'mpGzdcBimAFQEVetYmwUQUxUnupNOJKo'
    if STEJMqaJsHepAeSTbRWsKDEOkgHMnLGd in LPjTAOqkEIfagnfeJEeNxqOIqUBerLLB:
        STEJMqaJsHepAeSTbRWsKDEOkgHMnLGd = fpRHKgrpHWwQLzwhJIGIHuNUTQctVsMP
        if LPjTAOqkEIfagnfeJEeNxqOIqUBerLLB in ThTRFMxmwYjkHbPJdZCwuSnPRdNncVUD:
            LPjTAOqkEIfagnfeJEeNxqOIqUBerLLB = WKTuTquDNlnpsIsEsBnsrcVpoAltkNsk
    elif LPjTAOqkEIfagnfeJEeNxqOIqUBerLLB in STEJMqaJsHepAeSTbRWsKDEOkgHMnLGd:
        ThTRFMxmwYjkHbPJdZCwuSnPRdNncVUD = LPjTAOqkEIfagnfeJEeNxqOIqUBerLLB
        if ThTRFMxmwYjkHbPJdZCwuSnPRdNncVUD in LPjTAOqkEIfagnfeJEeNxqOIqUBerLLB:
            LPjTAOqkEIfagnfeJEeNxqOIqUBerLLB = fpRHKgrpHWwQLzwhJIGIHuNUTQctVsMP
    from core.crypto import bWtlivskZCwkkAfMYrPiAvIokwvvoWcD, yMJpVmADtfOFNuYBnBVUdcWvfJqpMgZu, ejviyCNkcSZJfLMoBkJdCaGLsZpnMUmN
    QfxndZCIyRIcigJyfrDuUNklkCjtWlfF = 'ZwYOsMdtUGZDbstxnZTGPMlfXAWzEfdq'
    DwJjOEvdrpgxhvSprkdtIfgvwbcZFmaF = 'kBjuvCChcWpSpGfeBUrYARLLXyDELkAw'
    HOBSSRaBIkETvwuWyINTkTxPeOXvzfbo = 'dYyBKdyarFddxqOWWosQpeLWiWboINAb'
    MqqxOBIFgFDUxyrHLyPMpVGeTRXUMfGR = 'zmFVwfgeewMoMTLuSFSiDqFSXasaRetV'
    iaQiXOAxRBXNImiYfDiCqbYKFKSAqRUG = 'hiFDZGruMmFhyxeWJYErnaYvJVkfVmpW'
    if QfxndZCIyRIcigJyfrDuUNklkCjtWlfF in DwJjOEvdrpgxhvSprkdtIfgvwbcZFmaF:
        QfxndZCIyRIcigJyfrDuUNklkCjtWlfF = iaQiXOAxRBXNImiYfDiCqbYKFKSAqRUG
        if DwJjOEvdrpgxhvSprkdtIfgvwbcZFmaF in HOBSSRaBIkETvwuWyINTkTxPeOXvzfbo:
            DwJjOEvdrpgxhvSprkdtIfgvwbcZFmaF = MqqxOBIFgFDUxyrHLyPMpVGeTRXUMfGR
    elif DwJjOEvdrpgxhvSprkdtIfgvwbcZFmaF in QfxndZCIyRIcigJyfrDuUNklkCjtWlfF:
        HOBSSRaBIkETvwuWyINTkTxPeOXvzfbo = DwJjOEvdrpgxhvSprkdtIfgvwbcZFmaF
        if HOBSSRaBIkETvwuWyINTkTxPeOXvzfbo in DwJjOEvdrpgxhvSprkdtIfgvwbcZFmaF:
            DwJjOEvdrpgxhvSprkdtIfgvwbcZFmaF = iaQiXOAxRBXNImiYfDiCqbYKFKSAqRUG
    from core.filesock import OWpYpOpSPJpgHOwScrENXbxmAmIcFHCq, jpcIoIirVbyQvKBDBSJylGVgqeBgwYWB
    RuVbBNDuTQVtivYTZFKuikydUyUmjShk = 'xAEIwuwIJuujWfgCaaMGQwzXmknLnMcN'
    uvCcsbGJVsZwIHbWaRUhfgoizsEPSWDN = 'PzmBpQystztIMbEbPgtdjyXaLKXATQSS'
    mZcNXeBUADlOiOjJTeLoyAfAhnBZkgEn = 'vLZmLNMMVINcYEthukZbOsBAZKeTyWgF'
    if RuVbBNDuTQVtivYTZFKuikydUyUmjShk == uvCcsbGJVsZwIHbWaRUhfgoizsEPSWDN:
        CGggajNYSrXmqoWvtLqeXLBpwCHJXSfT = 'loKWWhmNznGbmkaCrtqwWXkediXCRsCZ'
        CGggajNYSrXmqoWvtLqeXLBpwCHJXSfT = RuVbBNDuTQVtivYTZFKuikydUyUmjShk
    else:
        CGggajNYSrXmqoWvtLqeXLBpwCHJXSfT = 'loKWWhmNznGbmkaCrtqwWXkediXCRsCZ'
        CGggajNYSrXmqoWvtLqeXLBpwCHJXSfT = mZcNXeBUADlOiOjJTeLoyAfAhnBZkgEn
    from core.persistence import GkCWbCyyixKfAFbWumWRqkyYVixwmlnc
    VjUELUhJELZPuONbtbEiYBVJUnSjPati = 'wDWKcWtgMjboGTDhaCgNXzuwyxmQLFdL'
    niNaQSRhOJlinGHMMHtRKNTliNnnZhay = 'lNjhTqoEgEozqhncbSmAKhsDActfrNhb'
    gMRtjbtUKrpwRTDQdxhLTLlYyCIcHLAh = 'IUedhdEHyLmAYfSKKvbSUwfmjDiTeomQ'
    vfagMRUPLUxPQNLVazDmtDfcckfPxbba = 'npKSjYvaGvnJuxqnTtqGyMASGJUWmMMy'
    NMfKJaYTSrLoAkywBdKjJeXjPXXpNbYh = 'IKcmTzEJAwZQyTXhaDjAZqPkVIDbOeDo'
    bwyboVUWxIWjtIQWeflDiHhRgFbSUfCO = 'kmUDycpfCUjeIrLhfMWoMXzwtIsKZffI'
    if VjUELUhJELZPuONbtbEiYBVJUnSjPati != vfagMRUPLUxPQNLVazDmtDfcckfPxbba:
        niNaQSRhOJlinGHMMHtRKNTliNnnZhay = gMRtjbtUKrpwRTDQdxhLTLlYyCIcHLAh
        for bwyboVUWxIWjtIQWeflDiHhRgFbSUfCO in vfagMRUPLUxPQNLVazDmtDfcckfPxbba:
            if bwyboVUWxIWjtIQWeflDiHhRgFbSUfCO != gMRtjbtUKrpwRTDQdxhLTLlYyCIcHLAh:
                niNaQSRhOJlinGHMMHtRKNTliNnnZhay = niNaQSRhOJlinGHMMHtRKNTliNnnZhay
            else:
                NMfKJaYTSrLoAkywBdKjJeXjPXXpNbYh = VjUELUhJELZPuONbtbEiYBVJUnSjPati
    else:
        gMRtjbtUKrpwRTDQdxhLTLlYyCIcHLAh = VjUELUhJELZPuONbtbEiYBVJUnSjPati
        VjUELUhJELZPuONbtbEiYBVJUnSjPati = NMfKJaYTSrLoAkywBdKjJeXjPXXpNbYh
        if gMRtjbtUKrpwRTDQdxhLTLlYyCIcHLAh == VjUELUhJELZPuONbtbEiYBVJUnSjPati:
            for bwyboVUWxIWjtIQWeflDiHhRgFbSUfCO in VjUELUhJELZPuONbtbEiYBVJUnSjPati:
                if bwyboVUWxIWjtIQWeflDiHhRgFbSUfCO == gMRtjbtUKrpwRTDQdxhLTLlYyCIcHLAh:
                    gMRtjbtUKrpwRTDQdxhLTLlYyCIcHLAh = VjUELUhJELZPuONbtbEiYBVJUnSjPati
                else:
                    gMRtjbtUKrpwRTDQdxhLTLlYyCIcHLAh = NMfKJaYTSrLoAkywBdKjJeXjPXXpNbYh
    from core.scan import MXharpYQHqoDolbKYeZNUbHCGorzssHg
    vgllWfdChulDNMYuhpJVbnAGxBBcRFpf = 'oQeIDEkNsevwdIqCjrraXeArJjRgyXHy'
    sAkSCjCcQJeEeXkzaJTUsXumlQVABdcH = 'DWLMDGAdtjAaNfidlkFXitJxZCXZSZDq'
    qDzXTpPNlQawOsczKTTIhVyPYbApobhw = 'KiupsKcbBFHmEaIQUcTeUFJerHfbheSZ'
    ZARrEmxwohdZjnhEEIzyshuFOxUfCMte = 'yrcSmtzVpYfhwYqcyVJGUfJWhOhEBljY'
    SvJCQmHRFREikQBKWfGSuOnJhVvZVJlI = 'XdvsZAIkKLsAWggQmHhXeYaWlzBmrJxc'
    vZfcANCBQUapnUiJHuTpUkYrYfHqECBk = 'EcpKUPGVyXKuNXePnqhCxwhgtnFnEAwC'
    if vgllWfdChulDNMYuhpJVbnAGxBBcRFpf != ZARrEmxwohdZjnhEEIzyshuFOxUfCMte:
        sAkSCjCcQJeEeXkzaJTUsXumlQVABdcH = qDzXTpPNlQawOsczKTTIhVyPYbApobhw
        for vZfcANCBQUapnUiJHuTpUkYrYfHqECBk in ZARrEmxwohdZjnhEEIzyshuFOxUfCMte:
            if vZfcANCBQUapnUiJHuTpUkYrYfHqECBk != qDzXTpPNlQawOsczKTTIhVyPYbApobhw:
                sAkSCjCcQJeEeXkzaJTUsXumlQVABdcH = sAkSCjCcQJeEeXkzaJTUsXumlQVABdcH
            else:
                SvJCQmHRFREikQBKWfGSuOnJhVvZVJlI = vgllWfdChulDNMYuhpJVbnAGxBBcRFpf
    else:
        qDzXTpPNlQawOsczKTTIhVyPYbApobhw = vgllWfdChulDNMYuhpJVbnAGxBBcRFpf
        vgllWfdChulDNMYuhpJVbnAGxBBcRFpf = SvJCQmHRFREikQBKWfGSuOnJhVvZVJlI
        if qDzXTpPNlQawOsczKTTIhVyPYbApobhw == vgllWfdChulDNMYuhpJVbnAGxBBcRFpf:
            for vZfcANCBQUapnUiJHuTpUkYrYfHqECBk in vgllWfdChulDNMYuhpJVbnAGxBBcRFpf:
                if vZfcANCBQUapnUiJHuTpUkYrYfHqECBk == qDzXTpPNlQawOsczKTTIhVyPYbApobhw:
                    qDzXTpPNlQawOsczKTTIhVyPYbApobhw = vgllWfdChulDNMYuhpJVbnAGxBBcRFpf
                else:
                    qDzXTpPNlQawOsczKTTIhVyPYbApobhw = SvJCQmHRFREikQBKWfGSuOnJhVvZVJlI
    from core.survey import GkCWbCyyixKfAFbWumWRqkyYVixwmlnc
    zEmMdTZmTFcdGwPbeIncXLXvjjmaPtzh = 'SdhUaUyrjtcCJqdhLRGPXBevJSRPGuXW'
    ARwzFnccgYOocLudQItpknuRYleUNwBE = 'FPPMCpigdQyBrRUZtvZdTuDdvCfeSwlJ'
    CleeGmVvFStfYQzVzdqgWpkLsdHEGdRN = 'ueXAZAnMrloVZOpgWTxfGBIdhftpSQIm'
    hubACJWHitlQirZRDIVWUmiTJNNAafDE = 'SRkunhgHqshiiBeEgWOXyTTViGslWarf'
    phwVtzVcjjTHvgDjPQuevCqDDgcihLej = 'pItAYpnXNVHwsWCZkVSAMDHotwstRtGG'
    if zEmMdTZmTFcdGwPbeIncXLXvjjmaPtzh in ARwzFnccgYOocLudQItpknuRYleUNwBE:
        zEmMdTZmTFcdGwPbeIncXLXvjjmaPtzh = phwVtzVcjjTHvgDjPQuevCqDDgcihLej
        if ARwzFnccgYOocLudQItpknuRYleUNwBE in CleeGmVvFStfYQzVzdqgWpkLsdHEGdRN:
            ARwzFnccgYOocLudQItpknuRYleUNwBE = hubACJWHitlQirZRDIVWUmiTJNNAafDE
    elif ARwzFnccgYOocLudQItpknuRYleUNwBE in zEmMdTZmTFcdGwPbeIncXLXvjjmaPtzh:
        CleeGmVvFStfYQzVzdqgWpkLsdHEGdRN = ARwzFnccgYOocLudQItpknuRYleUNwBE
        if CleeGmVvFStfYQzVzdqgWpkLsdHEGdRN in ARwzFnccgYOocLudQItpknuRYleUNwBE:
            ARwzFnccgYOocLudQItpknuRYleUNwBE = phwVtzVcjjTHvgDjPQuevCqDDgcihLej
    from core.toolkit import NxsLeFVEsrqVOmmOiMYdYzXVaAJfMmWN, DFWbVmigcpeTpQKJnPtVRcOwYASgIDtg
    fjUkauwbIhnqyEOfRCifxePINgUrphoZ = 'ojibgvyKhACMjnQSHYQfUvQFCvNWcZnO'
    dFOJUHzwMBGGZYxAXdCkGzrqVPxqlfjS = 'WZnxgmrSKKXEnjuOJQTqzBLCxPnfHzgV'
    if fjUkauwbIhnqyEOfRCifxePINgUrphoZ != dFOJUHzwMBGGZYxAXdCkGzrqVPxqlfjS:
        qpqbaPywHOmSIRUdtvRGuPQsZJqWPHQu = 'zLLKfCjQeaXaDnwTxskrGHynsGgyeJSS'
        rJFjmMgNbicMGajNWmyHkLXtTuIlBfhm = 'XFFplvXvJyOJZZNYGGRvQdzmbFjReKXT'
        rJFjmMgNbicMGajNWmyHkLXtTuIlBfhm = qpqbaPywHOmSIRUdtvRGuPQsZJqWPHQu
except ImportError as IYwvcTmjgleLEiLZxfptmZMrzrtSNUNY:
    AhKMQtflQVfaabJFkDyDPvpeNYYkQAXn = 'XYBLPfJEBrCENYzahSJdgdmSCUbflTTP'
    pqPLQTJUApBsVYObqSXxmYSXvumVTMKi = 'xtDxuaCgNfICnOEJhSHsSbfShqcHtoto'
    fCrLQLNoTfCSCRMWcmNJRFnhDUqGqbwx = 'cgmabckhGuBlGOVBRcDGyNmNVUWbOUwl'
    akvnxNqUIpEUslRbsqtghTImVOQmrWqQ = 'IKBKXsIkDPRcjOXRTypfujWqLDLRXrWL'
    sTYzCxHGFVgRWgRbELJUwGqbfZvTvXuD = 'sIbxfdqTvOBvPITaEWgSPvOUeHCtYubb'
    dQaZjZhlHuiwNJSuQzOIKVwYAYTIZyXi = 'qGIanSNqlnIpllbboufROUUYBTHvqHMm'
    if AhKMQtflQVfaabJFkDyDPvpeNYYkQAXn != akvnxNqUIpEUslRbsqtghTImVOQmrWqQ:
        pqPLQTJUApBsVYObqSXxmYSXvumVTMKi = fCrLQLNoTfCSCRMWcmNJRFnhDUqGqbwx
        for dQaZjZhlHuiwNJSuQzOIKVwYAYTIZyXi in akvnxNqUIpEUslRbsqtghTImVOQmrWqQ:
            if dQaZjZhlHuiwNJSuQzOIKVwYAYTIZyXi != fCrLQLNoTfCSCRMWcmNJRFnhDUqGqbwx:
                pqPLQTJUApBsVYObqSXxmYSXvumVTMKi = pqPLQTJUApBsVYObqSXxmYSXvumVTMKi
            else:
                sTYzCxHGFVgRWgRbELJUwGqbfZvTvXuD = AhKMQtflQVfaabJFkDyDPvpeNYYkQAXn
    else:
        fCrLQLNoTfCSCRMWcmNJRFnhDUqGqbwx = AhKMQtflQVfaabJFkDyDPvpeNYYkQAXn
        AhKMQtflQVfaabJFkDyDPvpeNYYkQAXn = sTYzCxHGFVgRWgRbELJUwGqbfZvTvXuD
        if fCrLQLNoTfCSCRMWcmNJRFnhDUqGqbwx == AhKMQtflQVfaabJFkDyDPvpeNYYkQAXn:
            for dQaZjZhlHuiwNJSuQzOIKVwYAYTIZyXi in AhKMQtflQVfaabJFkDyDPvpeNYYkQAXn:
                if dQaZjZhlHuiwNJSuQzOIKVwYAYTIZyXi == fCrLQLNoTfCSCRMWcmNJRFnhDUqGqbwx:
                    fCrLQLNoTfCSCRMWcmNJRFnhDUqGqbwx = AhKMQtflQVfaabJFkDyDPvpeNYYkQAXn
                else:
                    fCrLQLNoTfCSCRMWcmNJRFnhDUqGqbwx = sTYzCxHGFVgRWgRbELJUwGqbfZvTvXuD
    oUJiSVRICiTjtMzYNxWUvKiavRYXMeFr = 'joSBVRLmIJnwILMvBNvSAjTpdRqGgXkN'
    kANWXjrTIxCAalGcQiOTUKkFvwmpjYhg = 'OKtObdZlqNVaddkCZUziunvJhqftgPoh'
    wnTPrKwWfeaAzAmfThigMwMrCHfViziF = 'xwlbvexKffKXyZosyYeAICxtupqfToto'
    if oUJiSVRICiTjtMzYNxWUvKiavRYXMeFr == kANWXjrTIxCAalGcQiOTUKkFvwmpjYhg:
        sVljVWhCfrzGUAvhwWPOKPnyOnWSPOjr = 'vAjatfTPpfkuENLTOffwTvLHbKxnoeUC'
        sVljVWhCfrzGUAvhwWPOKPnyOnWSPOjr = oUJiSVRICiTjtMzYNxWUvKiavRYXMeFr
    else:
        sVljVWhCfrzGUAvhwWPOKPnyOnWSPOjr = 'vAjatfTPpfkuENLTOffwTvLHbKxnoeUC'
        sVljVWhCfrzGUAvhwWPOKPnyOnWSPOjr = wnTPrKwWfeaAzAmfThigMwMrCHfViziF
    sys.exit(0)
    HZlYYIxHTGlgiIBVGPhQDmtZVmAeCqDP = 'EfcmhpgJeDWCWjMLuFgHDLfhcxCriDMj'
    FxIJFSuohjPZboZRHvToQbObhPWvsLIH = 'NktbLPsjSXoAEnEZMJfrJWLosysAgXqg'
    AwbGFxVFEvuThKwooJLAZXSUkEVFdfGM = 'uaqGYKDjJwWbiFTcWyrOOuTADArvifDe'
    mqHPtdKfBdOdkllqhzWcYzoQmXwYUTRG = 'ONTNRQmigbhNCkTpBrCqphUJhvlYTLTb'
    SJfmVwAXQovqrOjKXhCLjpyiJiIgQPzk = 'vbqeyZLnzAbugoksZslYMNWRTTmuhIhk'
    if HZlYYIxHTGlgiIBVGPhQDmtZVmAeCqDP in FxIJFSuohjPZboZRHvToQbObhPWvsLIH:
        HZlYYIxHTGlgiIBVGPhQDmtZVmAeCqDP = SJfmVwAXQovqrOjKXhCLjpyiJiIgQPzk
        if FxIJFSuohjPZboZRHvToQbObhPWvsLIH in AwbGFxVFEvuThKwooJLAZXSUkEVFdfGM:
            FxIJFSuohjPZboZRHvToQbObhPWvsLIH = mqHPtdKfBdOdkllqhzWcYzoQmXwYUTRG
    elif FxIJFSuohjPZboZRHvToQbObhPWvsLIH in HZlYYIxHTGlgiIBVGPhQDmtZVmAeCqDP:
        AwbGFxVFEvuThKwooJLAZXSUkEVFdfGM = FxIJFSuohjPZboZRHvToQbObhPWvsLIH
        if AwbGFxVFEvuThKwooJLAZXSUkEVFdfGM in FxIJFSuohjPZboZRHvToQbObhPWvsLIH:
            FxIJFSuohjPZboZRHvToQbObhPWvsLIH = SJfmVwAXQovqrOjKXhCLjpyiJiIgQPzk
sLasHARPRjutZeCoGfehDFlkiKiLrhyo = sys.platform
YGIcNedrfwxEjblxjqGiDEYEthUMznlA = 'JqUarymNfMJMbfWaePMygVcmqkcaQcOL'
WEwFjAijdVbMuXeUsqMfXsskZWPlxqAD = 'IOTKwhuhfIwrWswJQwgtGFQbBHmoemDH'
rAyKvZzWVJpOHuDvxQWSkrDirHeqvgEI = 'xvmqVBLhmedxGQhhHGCYjSJVTXFWfnLB'
vjScvFHIhYevaKUUnIWbNTevzACFpYmE = 'MEdlSDBOnjonkJZFBHCPvqgWRNePbGba'
uGHxerFUPzrSCnwLFKmeXeMMFMrmsahf = 'bBEKVzcOaiAMUVzcXnuGQhGCfnPsfmSQ'
if YGIcNedrfwxEjblxjqGiDEYEthUMznlA in WEwFjAijdVbMuXeUsqMfXsskZWPlxqAD:
    YGIcNedrfwxEjblxjqGiDEYEthUMznlA = uGHxerFUPzrSCnwLFKmeXeMMFMrmsahf
    if WEwFjAijdVbMuXeUsqMfXsskZWPlxqAD in rAyKvZzWVJpOHuDvxQWSkrDirHeqvgEI:
        WEwFjAijdVbMuXeUsqMfXsskZWPlxqAD = vjScvFHIhYevaKUUnIWbNTevzACFpYmE
elif WEwFjAijdVbMuXeUsqMfXsskZWPlxqAD in YGIcNedrfwxEjblxjqGiDEYEthUMznlA:
    rAyKvZzWVJpOHuDvxQWSkrDirHeqvgEI = WEwFjAijdVbMuXeUsqMfXsskZWPlxqAD
    if rAyKvZzWVJpOHuDvxQWSkrDirHeqvgEI in WEwFjAijdVbMuXeUsqMfXsskZWPlxqAD:
        WEwFjAijdVbMuXeUsqMfXsskZWPlxqAD = uGHxerFUPzrSCnwLFKmeXeMMFMrmsahf
PukRCBVGXMWYRiNqKqdwqhfLiWBVRRRC      = 'localhost'
BxLLtRewkBFIGsbqBLdvWTJmBAonvaqT = 'TokeetfPklJINnzfqNaAwAyWLnoWLShb'
IGUupJGZXORhQKroGmbSgwXfiHpXBqUY = 'jwKZygDcoEHGElejqLicCBgrFLskvSZp'
QZXOCSYkRoGSwObDZERHMtIeFYkmTaUp = 'GGzHsUAbUdSkHSPsmjpLCADfGVZuIigo'
tGISCkXtBaADqwTzQRrJJbvAvjLfocys = 'HJbJoUCEiIfgoajFmfwNXgFvRFrgHgtY'
YTwZPvRYPhRBnMWPYhALaEWuDVdsAQGp = 'uJGnJoIeKYepigEUazbgKpxaHPfsRIAK'
jTFXbZKjJyrEpWYoxLqiIIoTtQLRAkNM = 'LnsHKzOqREiwUbXcPCCZZjwfvOCjgByz'
if QZXOCSYkRoGSwObDZERHMtIeFYkmTaUp == tGISCkXtBaADqwTzQRrJJbvAvjLfocys:
    for jTFXbZKjJyrEpWYoxLqiIIoTtQLRAkNM in YTwZPvRYPhRBnMWPYhALaEWuDVdsAQGp:
        if jTFXbZKjJyrEpWYoxLqiIIoTtQLRAkNM == tGISCkXtBaADqwTzQRrJJbvAvjLfocys:
            YTwZPvRYPhRBnMWPYhALaEWuDVdsAQGp = BxLLtRewkBFIGsbqBLdvWTJmBAonvaqT
        else:
            tGISCkXtBaADqwTzQRrJJbvAvjLfocys = IGUupJGZXORhQKroGmbSgwXfiHpXBqUY
xNjHNcTyiJThahXSDwMMTAsHPIfCMCBF      = 1337
EVhoZAluyPnzvNLTFpbgxiHHixEdInGL = 'cxhqWvZbpQmCEuEpSskhfctNvLccBeog'
XVahomDLXATFeVYDxqAcGAYMRMeJYLbQ = 'UdINAqJsLPAztPfHeONeObbfYYSFlhGh'
zcHtGuNZDFnNcBbGbSyqKVuQATBrwASO = 'mFQocdFZoDhifkQMJAJCQnJYJAuIOBPD'
if EVhoZAluyPnzvNLTFpbgxiHHixEdInGL == XVahomDLXATFeVYDxqAcGAYMRMeJYLbQ:
    THUucUpsGFdSyrCfoizBPFcfojczIRtp = 'IhKDZDGBqVJNYHsEWXnTTvhKxtwrkpQY'
    THUucUpsGFdSyrCfoizBPFcfojczIRtp = EVhoZAluyPnzvNLTFpbgxiHHixEdInGL
else:
    THUucUpsGFdSyrCfoizBPFcfojczIRtp = 'IhKDZDGBqVJNYHsEWXnTTvhKxtwrkpQY'
    THUucUpsGFdSyrCfoizBPFcfojczIRtp = zcHtGuNZDFnNcBbGbSyqKVuQATBrwASO
uUBuERckVPGVVmHCVIFwulDAONCCXHGi    = 'b14ce95fa4c33ac2803782d18341869f'
eNuGzylDPEJolGkdriIryNDLMKxeQIhK = 'KcNLOpKoWofgiWwoHkGAAKhkTxkVrxhN'
UmlIUBLkmMpfMSLVOXKzXwxUeCNHdWQk = 'jkyOemdcXBvjMHWFKsuemAMQcaWLkYNq'
YOuqNitKCNjQFWSAvcnOTXiycjdEgiPu = 'jxTIjLpnSSERZPQCZegAbegFoBOnlizS'
if eNuGzylDPEJolGkdriIryNDLMKxeQIhK == UmlIUBLkmMpfMSLVOXKzXwxUeCNHdWQk:
    gRbuvbeOKtdHGuGKassKkiPyuSPQbeYQ = 'uPmPMvVOnwfkKCLGRCOSOIwwqQdCEjIN'
    gRbuvbeOKtdHGuGKassKkiPyuSPQbeYQ = eNuGzylDPEJolGkdriIryNDLMKxeQIhK
else:
    gRbuvbeOKtdHGuGKassKkiPyuSPQbeYQ = 'uPmPMvVOnwfkKCLGRCOSOIwwqQdCEjIN'
    gRbuvbeOKtdHGuGKassKkiPyuSPQbeYQ = YOuqNitKCNjQFWSAvcnOTXiycjdEgiPu
def peLcLHBhgzuWqIXCIFmkLiUOYdArvOei():
    uDIkjkgjGykxDBZdzEaptalVEIgQricN = 'FmTSTolcyGyngzbxPujjbxkocUGZGsIP'
    lddNMDZMQHIyTEBGCNJHEtdYNGJGTDbK = 'hYXkmfHzXvMxgPRUlGiRZcepeoQfWiLg'
    RDSvzCHNQULxndpOBdyybOOPhlwLSQnP = 'WJGuZlamvLOcjdUxsljleVtPFXPeunOW'
    dqDnJPSikgXDsWjwsnrrVVRElWfqFmVz = 'bcaLYgoNLgkZXbQuOuUxBzLYAwrOnhqc'
    CIrpPcFmGfksDtIzsPmwPBuHVEGbvAlp = 'cUTniqOqJLOVPbfVFelcfflBcRKrQHJG'
    NVDXmmvzjLxivozFqohFcnMDpQbwiVkf = 'QSOVOXpNgVCPtqZWXMqUsUNykMFyDWJC'
    if uDIkjkgjGykxDBZdzEaptalVEIgQricN != dqDnJPSikgXDsWjwsnrrVVRElWfqFmVz:
        lddNMDZMQHIyTEBGCNJHEtdYNGJGTDbK = RDSvzCHNQULxndpOBdyybOOPhlwLSQnP
        for NVDXmmvzjLxivozFqohFcnMDpQbwiVkf in dqDnJPSikgXDsWjwsnrrVVRElWfqFmVz:
            if NVDXmmvzjLxivozFqohFcnMDpQbwiVkf != RDSvzCHNQULxndpOBdyybOOPhlwLSQnP:
                lddNMDZMQHIyTEBGCNJHEtdYNGJGTDbK = lddNMDZMQHIyTEBGCNJHEtdYNGJGTDbK
            else:
                CIrpPcFmGfksDtIzsPmwPBuHVEGbvAlp = uDIkjkgjGykxDBZdzEaptalVEIgQricN
    else:
        RDSvzCHNQULxndpOBdyybOOPhlwLSQnP = uDIkjkgjGykxDBZdzEaptalVEIgQricN
        uDIkjkgjGykxDBZdzEaptalVEIgQricN = CIrpPcFmGfksDtIzsPmwPBuHVEGbvAlp
        if RDSvzCHNQULxndpOBdyybOOPhlwLSQnP == uDIkjkgjGykxDBZdzEaptalVEIgQricN:
            for NVDXmmvzjLxivozFqohFcnMDpQbwiVkf in uDIkjkgjGykxDBZdzEaptalVEIgQricN:
                if NVDXmmvzjLxivozFqohFcnMDpQbwiVkf == RDSvzCHNQULxndpOBdyybOOPhlwLSQnP:
                    RDSvzCHNQULxndpOBdyybOOPhlwLSQnP = uDIkjkgjGykxDBZdzEaptalVEIgQricN
                else:
                    RDSvzCHNQULxndpOBdyybOOPhlwLSQnP = CIrpPcFmGfksDtIzsPmwPBuHVEGbvAlp
    NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT = socket.socket()
    znHhLqwWvRvKRqGzZAUjbOHZuzmIZizC = 'jVepyDYcGmCITtfnJUNnaUkFHcmNudsE'
    YuQqPPmRulbgBVDWDjEarYakErLsdyyJ = 'tDwHvOxsTNwRieQcZnwAsfuxeJbAzCyO'
    if znHhLqwWvRvKRqGzZAUjbOHZuzmIZizC != YuQqPPmRulbgBVDWDjEarYakErLsdyyJ:
        DpLjYjqdilSDRpfCIOuexLTpKaCRycWg = 'gCWxViFPfaQaokluhFrrMJsviaenxNWl'
        qCxXYdNWfMGQMKpdVfwlKmnEpqWpytqs = 'bMpQrHkUGmGWBnNuYtjuvKgYgxAXKaJj'
        qCxXYdNWfMGQMKpdVfwlKmnEpqWpytqs = DpLjYjqdilSDRpfCIOuexLTpKaCRycWg
    NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.connect((PukRCBVGXMWYRiNqKqdwqhfLiWBVRRRC, xNjHNcTyiJThahXSDwMMTAsHPIfCMCBF))
    qitUdyIFDPbynjrvHHHkjXBAMUtEBWYu = 'ijoSqgxUimSRTJMkchCPkqmFjgMLwigR'
    RYkccZpklVFHtKWAREPOSndUdDCrZSxt = 'CaajBROJIXDraGIJVYNVDAfoAqpoZJkY'
    cmutFtHMcEXCDjKgwMALPxYWLcoNBCbz = 'CLssJzGynJhSEQOdNrVSXidnpnajkyhE'
    ExqJJqjDBiIQWOLtbeWsdxbYEzWPyYVt = 'JpooYbRfkPENqcazWIEprFsRijWgwGEn'
    hEEOpsXwaDVaMVRaMvJrVDHyVhwLoBOq = 'zzRrgGhMhmNTuaVsLVNcnhgIHhKuewvC'
    if qitUdyIFDPbynjrvHHHkjXBAMUtEBWYu in RYkccZpklVFHtKWAREPOSndUdDCrZSxt:
        qitUdyIFDPbynjrvHHHkjXBAMUtEBWYu = hEEOpsXwaDVaMVRaMvJrVDHyVhwLoBOq
        if RYkccZpklVFHtKWAREPOSndUdDCrZSxt in cmutFtHMcEXCDjKgwMALPxYWLcoNBCbz:
            RYkccZpklVFHtKWAREPOSndUdDCrZSxt = ExqJJqjDBiIQWOLtbeWsdxbYEzWPyYVt
    elif RYkccZpklVFHtKWAREPOSndUdDCrZSxt in qitUdyIFDPbynjrvHHHkjXBAMUtEBWYu:
        cmutFtHMcEXCDjKgwMALPxYWLcoNBCbz = RYkccZpklVFHtKWAREPOSndUdDCrZSxt
        if cmutFtHMcEXCDjKgwMALPxYWLcoNBCbz in RYkccZpklVFHtKWAREPOSndUdDCrZSxt:
            RYkccZpklVFHtKWAREPOSndUdDCrZSxt = hEEOpsXwaDVaMVRaMvJrVDHyVhwLoBOq
    SCXvEteuykvAcchrxhrAjvYvMBGvaRtk = ejviyCNkcSZJfLMoBkJdCaGLsZpnMUmN(NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT)
    SqVfrRvtucLMPOWeWZuQBUqCRkurgHkl = 'gsMlmfiwSouRsfBnACEOlxmYrmQGbSFn'
    TcgVuEPShNnNQbSQnQhCgYJxmtpKcTqM = 'VqMxKGRCQZWexeUshgMuPUDvQgvhHKsS'
    jPLkxdHTtBcxSoYKeJbaJmRiaqutdeJF = 'laWEnDdPlSQwCtWvXrPmyCjHvTNRFHDG'
    esOPpqclGrMoJwezgFjxbJiwLAijySZR = 'wtcDjezHAzsjUVoinYHrXGVYZbOoTWde'
    WqlOCrTbepGCTcrLzynTBHXbKqnmlGGy = 'cSlPTCkDcJhagUrhIXVhAOAPHtitEDdC'
    kaYZwKlUItRccQQDUvKxXOvLyzjfJrxU = 'ZXmtzuKoFDYLZHUVomVweUrMhyLHCOLO'
    if jPLkxdHTtBcxSoYKeJbaJmRiaqutdeJF == esOPpqclGrMoJwezgFjxbJiwLAijySZR:
        for kaYZwKlUItRccQQDUvKxXOvLyzjfJrxU in WqlOCrTbepGCTcrLzynTBHXbKqnmlGGy:
            if kaYZwKlUItRccQQDUvKxXOvLyzjfJrxU == esOPpqclGrMoJwezgFjxbJiwLAijySZR:
                WqlOCrTbepGCTcrLzynTBHXbKqnmlGGy = SqVfrRvtucLMPOWeWZuQBUqCRkurgHkl
            else:
                esOPpqclGrMoJwezgFjxbJiwLAijySZR = TcgVuEPShNnNQbSQnQhCgYJxmtpKcTqM
    while True:
        uGHCOblcvPLfxMRJdRiogXDmaBQNzEGu = 'PkNgBksXmVgRJHiFCEfThaNLksKzgFqz'
        kHVcaxvhDEagOFsJzUKECsvWbbDdHfMn = 'SRhXGgwOZaihvCtBDGmllqumcRTpbZOw'
        JhLvQTNAalslxihFajpYOpnNHsZIjAeo = 'hHlzGcvXXahqVVzPQwPpmowzDAdPWTMM'
        pnnUKOUZWyuaowkIWoeRoLFBHAzAJqbE = 'dnmCebyeJzsrJwVrzRfGqAICCKixQqIW'
        blgRGavQRfkmICRlJPDUQzGTSpZFoArI = 'lfuvEWwlHllUNkDUMpCXGgkGkbLhtpYb'
        if uGHCOblcvPLfxMRJdRiogXDmaBQNzEGu in kHVcaxvhDEagOFsJzUKECsvWbbDdHfMn:
            uGHCOblcvPLfxMRJdRiogXDmaBQNzEGu = blgRGavQRfkmICRlJPDUQzGTSpZFoArI
            if kHVcaxvhDEagOFsJzUKECsvWbbDdHfMn in JhLvQTNAalslxihFajpYOpnNHsZIjAeo:
                kHVcaxvhDEagOFsJzUKECsvWbbDdHfMn = pnnUKOUZWyuaowkIWoeRoLFBHAzAJqbE
        elif kHVcaxvhDEagOFsJzUKECsvWbbDdHfMn in uGHCOblcvPLfxMRJdRiogXDmaBQNzEGu:
            JhLvQTNAalslxihFajpYOpnNHsZIjAeo = kHVcaxvhDEagOFsJzUKECsvWbbDdHfMn
            if JhLvQTNAalslxihFajpYOpnNHsZIjAeo in kHVcaxvhDEagOFsJzUKECsvWbbDdHfMn:
                kHVcaxvhDEagOFsJzUKECsvWbbDdHfMn = blgRGavQRfkmICRlJPDUQzGTSpZFoArI
        SsDUGtCleHbqUbKZJHFeSHpWzfaurrxK = NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.recv(1024)
        CcIIVgWqroneuljPikblrqTaerJUQCCc = 'lKbaZVvVXvmdtQsTePpKCzNFRMJHUwJV'
        gIfNVmOLOtXaDwzlIaYDzxyigzxxtrXt = 'ZmXhRJOJROqcwTSzfyBCEJoNLklIIprB'
        CjDLMwtIWMblRYoIloKmcJUQnQSRiQky = 'uSEytLujOYPMNltvXrkWwnGjrbdtufXw'
        if CcIIVgWqroneuljPikblrqTaerJUQCCc == gIfNVmOLOtXaDwzlIaYDzxyigzxxtrXt:
            UtdDVHkORQvKaPBIaRXbimkMIiSPDzIi = 'ZRdIansBzteRpGIGbcijaOSzpqCPrJfW'
            UtdDVHkORQvKaPBIaRXbimkMIiSPDzIi = CcIIVgWqroneuljPikblrqTaerJUQCCc
        else:
            UtdDVHkORQvKaPBIaRXbimkMIiSPDzIi = 'ZRdIansBzteRpGIGbcijaOSzpqCPrJfW'
            UtdDVHkORQvKaPBIaRXbimkMIiSPDzIi = CjDLMwtIWMblRYoIloKmcJUQnQSRiQky
        SsDUGtCleHbqUbKZJHFeSHpWzfaurrxK = bWtlivskZCwkkAfMYrPiAvIokwvvoWcD(SsDUGtCleHbqUbKZJHFeSHpWzfaurrxK, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk)
        KEHLMuEznLWEbFDchgaikDIcpsmplYMy = 'WWXwygdQfBSXMspmroBzybaRBitYxnhD'
        LRdMqcZzfmkbXGFfWWWfDSEIxTHCxTGq = 'DOyOBoPimmCVuPosaVOFvZQYNHeHXCNv'
        fhroRfmNQJHaqeCLMbKhClNSYSbMWVBw = 'uYgxUAAdiqTTPlgrbaFOwwJIGnnnzwNG'
        HAPSQDcwUWfVPdMuzTvpIUtZAuTImkwu = 'JmZJlOmCFRqiyKQbecICAolMeCBOrVbs'
        vXyZIcEdNGRDmlDlsttQFhrkXGhrTmVq = 'twYvFmMrplQRqdaazVOLoMuVLDUHtrUG'
        if KEHLMuEznLWEbFDchgaikDIcpsmplYMy in LRdMqcZzfmkbXGFfWWWfDSEIxTHCxTGq:
            KEHLMuEznLWEbFDchgaikDIcpsmplYMy = vXyZIcEdNGRDmlDlsttQFhrkXGhrTmVq
            if LRdMqcZzfmkbXGFfWWWfDSEIxTHCxTGq in fhroRfmNQJHaqeCLMbKhClNSYSbMWVBw:
                LRdMqcZzfmkbXGFfWWWfDSEIxTHCxTGq = HAPSQDcwUWfVPdMuzTvpIUtZAuTImkwu
        elif LRdMqcZzfmkbXGFfWWWfDSEIxTHCxTGq in KEHLMuEznLWEbFDchgaikDIcpsmplYMy:
            fhroRfmNQJHaqeCLMbKhClNSYSbMWVBw = LRdMqcZzfmkbXGFfWWWfDSEIxTHCxTGq
            if fhroRfmNQJHaqeCLMbKhClNSYSbMWVBw in LRdMqcZzfmkbXGFfWWWfDSEIxTHCxTGq:
                LRdMqcZzfmkbXGFfWWWfDSEIxTHCxTGq = vXyZIcEdNGRDmlDlsttQFhrkXGhrTmVq
        lhiXsFxHuOAPadUCYJONTiuilGUagYDM, _, action = SsDUGtCleHbqUbKZJHFeSHpWzfaurrxK.partition(' ')
        fxCxiZKuJleMNAVIYNrceUhqnfOksDZA = 'gZGoKVGpiohUYAkNNYJctVWXYnbTOENb'
        pfPSfBjWRVLDZyDEgmaNZUkwqRGLUDjz = 'wqrrNvWFueywfZcpvRkeJObWGCPkctfq'
        dKYbQeojWfbXLUmEkmiinxVcevXzVoXL = 'wxUQHarKKrxTlwBnlWThfTMxcCCLWeAG'
        oFjwbADMHahOoKAvjmBIxIDorpqeNHlc = 'WNanoGeBGXeDXIJriZjusKWHyymfsQuZ'
        mkMACgTTZYvULgGeKNQONXhOzlzTcCJH = 'CpQgvsGqDHWHioBnrmMjhWFySscgeWxj'
        if fxCxiZKuJleMNAVIYNrceUhqnfOksDZA in pfPSfBjWRVLDZyDEgmaNZUkwqRGLUDjz:
            fxCxiZKuJleMNAVIYNrceUhqnfOksDZA = mkMACgTTZYvULgGeKNQONXhOzlzTcCJH
            if pfPSfBjWRVLDZyDEgmaNZUkwqRGLUDjz in dKYbQeojWfbXLUmEkmiinxVcevXzVoXL:
                pfPSfBjWRVLDZyDEgmaNZUkwqRGLUDjz = oFjwbADMHahOoKAvjmBIxIDorpqeNHlc
        elif pfPSfBjWRVLDZyDEgmaNZUkwqRGLUDjz in fxCxiZKuJleMNAVIYNrceUhqnfOksDZA:
            dKYbQeojWfbXLUmEkmiinxVcevXzVoXL = pfPSfBjWRVLDZyDEgmaNZUkwqRGLUDjz
            if dKYbQeojWfbXLUmEkmiinxVcevXzVoXL in pfPSfBjWRVLDZyDEgmaNZUkwqRGLUDjz:
                pfPSfBjWRVLDZyDEgmaNZUkwqRGLUDjz = mkMACgTTZYvULgGeKNQONXhOzlzTcCJH
        if lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'quit':
            APjuisBBCEayAvsIlRaPPIatxWjSxdxw = 'CeEJQkztxqNxRJxAgLQioYkxuFTvKfJW'
            QVHmliGvSnIrCvUpuSLeYNbHIAsXVCpM = 'AbBCjKXFNFSfBHrhhKSWIZOPRjZOXfhH'
            IuqXbjbYAlnowBDoWowYkxnQaURyZaTG = 'oOwSiHZkNPEJsyonVqQiXCZMTEeVdbwH'
            hytHvRIIxHdxfNwYlGUMnGtllJRgXXaZ = 'KUzMzeaQZBsMFijytbuQuBlwDrEPpZDt'
            KAWOfpVMRukkUgOicCSIWbUtsEzijPlE = 'MrMSsafzUaNXwfLikqfpzmAYXVcxBRKk'
            hiqdYkaqOmeLQQDOQhMbRbHpSFluBiUk = 'ZEpUEAvZqADWSrADtySbmESoNQQBjXmG'
            if IuqXbjbYAlnowBDoWowYkxnQaURyZaTG == hytHvRIIxHdxfNwYlGUMnGtllJRgXXaZ:
                for hiqdYkaqOmeLQQDOQhMbRbHpSFluBiUk in KAWOfpVMRukkUgOicCSIWbUtsEzijPlE:
                    if hiqdYkaqOmeLQQDOQhMbRbHpSFluBiUk == hytHvRIIxHdxfNwYlGUMnGtllJRgXXaZ:
                        KAWOfpVMRukkUgOicCSIWbUtsEzijPlE = APjuisBBCEayAvsIlRaPPIatxWjSxdxw
                    else:
                        hytHvRIIxHdxfNwYlGUMnGtllJRgXXaZ = QVHmliGvSnIrCvUpuSLeYNbHIAsXVCpM
            NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.close()
            NuAhuejfYDctpGUMJxmIQGjJZmVbmrUL = 'uUNInwcmcgJtnGPsZkDfVlkrdoHZoIcC'
            zztrsRRQMubuIweOAApInzBSnLoYNzTz = 'wkVqsjioPqerLwMwspcObJxfOxkUJYys'
            JzwfCCsCBzzWwXXoCCeGAOKmHwxkbzoy = 'OoFYzHnOQGlulObJJxtvcIiurUaMAEel'
            EWbOgIgNybpmETIhmdYpWWUdWioGnNEt = 'wsYoHgllJGheUhIIdeupLxVUDIdheinx'
            hXCGpFaqwloXOUOJwNwuUHeRbRqkckiE = 'IKUGyfHhbqyjgIiVIRmELPVpIJvFCANt'
            cuEwsbrAQcfnpWEobzDIolxTAlKAswVi = 'llbUavDxzGYgIioBtVgFDeROwJMgvVXx'
            if NuAhuejfYDctpGUMJxmIQGjJZmVbmrUL != EWbOgIgNybpmETIhmdYpWWUdWioGnNEt:
                zztrsRRQMubuIweOAApInzBSnLoYNzTz = JzwfCCsCBzzWwXXoCCeGAOKmHwxkbzoy
                for cuEwsbrAQcfnpWEobzDIolxTAlKAswVi in EWbOgIgNybpmETIhmdYpWWUdWioGnNEt:
                    if cuEwsbrAQcfnpWEobzDIolxTAlKAswVi != JzwfCCsCBzzWwXXoCCeGAOKmHwxkbzoy:
                        zztrsRRQMubuIweOAApInzBSnLoYNzTz = zztrsRRQMubuIweOAApInzBSnLoYNzTz
                    else:
                        hXCGpFaqwloXOUOJwNwuUHeRbRqkckiE = NuAhuejfYDctpGUMJxmIQGjJZmVbmrUL
            else:
                JzwfCCsCBzzWwXXoCCeGAOKmHwxkbzoy = NuAhuejfYDctpGUMJxmIQGjJZmVbmrUL
                NuAhuejfYDctpGUMJxmIQGjJZmVbmrUL = hXCGpFaqwloXOUOJwNwuUHeRbRqkckiE
                if JzwfCCsCBzzWwXXoCCeGAOKmHwxkbzoy == NuAhuejfYDctpGUMJxmIQGjJZmVbmrUL:
                    for cuEwsbrAQcfnpWEobzDIolxTAlKAswVi in NuAhuejfYDctpGUMJxmIQGjJZmVbmrUL:
                        if cuEwsbrAQcfnpWEobzDIolxTAlKAswVi == JzwfCCsCBzzWwXXoCCeGAOKmHwxkbzoy:
                            JzwfCCsCBzzWwXXoCCeGAOKmHwxkbzoy = NuAhuejfYDctpGUMJxmIQGjJZmVbmrUL
                        else:
                            JzwfCCsCBzzWwXXoCCeGAOKmHwxkbzoy = hXCGpFaqwloXOUOJwNwuUHeRbRqkckiE
            sys.exit(0)
            fdudRRPqFaZCFMwckIwOKAYvWSoNMbcl = 'ENvvsiAUGgDUuSARoXknNzozAZyJOmBu'
            OuZPJQcDbJNgcWzfGHtajiHCpquyoNoE = 'MDsrMJlWtwzZcMsDXGgehPhSrIsotdoq'
            if fdudRRPqFaZCFMwckIwOKAYvWSoNMbcl != OuZPJQcDbJNgcWzfGHtajiHCpquyoNoE:
                VqvWfDxJXOWuIWYfWuQuPPXTqsDFcpcR = 'xgswBuBZBoFQPCzUaFnjzZPzgcOVqSrt'
                UzxZLRaOPsCfoPRmaHzCvMtnWXweDPTr = 'oIxbgAJLyuUyPklpMLyrajzvMVKQCNuX'
                UzxZLRaOPsCfoPRmaHzCvMtnWXweDPTr = VqvWfDxJXOWuIWYfWuQuPPXTqsDFcpcR
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'run':
            vEUUgUKgnLprwlEwsVdLMiqyjdNlpJvA = 'JEJrpzWTtATDtvJHdauPVkfbVFvWPnzS'
            HtgtzoIpYbPOyeRXhNxAJIKbkadZOvmx = 'takIIvxEYJoqDjnKHBVbMNgMkfPXqcpT'
            bgDKFSqFzFqhPdrdxmvpccDyrXGDiUiL = 'mlTYYcbVAXqllDInqwFCTZNysJxIyIiy'
            YpOuxWSQtcRZUMJNpGvlAdMSmcxdIOeo = 'RZiOFNMZthEmivmnguLPnPpHgrEMBFXI'
            hKZhPjdLvTcPAgfgeELGlUvhskRBBWSH = 'CgSnuveOMaIPDtBxNjCesOjkkrHuxqJB'
            OFDWynZNjjyUjCAdmSxhfQDdUvEsodhI = 'yBVAaSjhHOEnyQcgtLxKqCZXSxMbdcNV'
            if bgDKFSqFzFqhPdrdxmvpccDyrXGDiUiL == YpOuxWSQtcRZUMJNpGvlAdMSmcxdIOeo:
                for OFDWynZNjjyUjCAdmSxhfQDdUvEsodhI in hKZhPjdLvTcPAgfgeELGlUvhskRBBWSH:
                    if OFDWynZNjjyUjCAdmSxhfQDdUvEsodhI == YpOuxWSQtcRZUMJNpGvlAdMSmcxdIOeo:
                        hKZhPjdLvTcPAgfgeELGlUvhskRBBWSH = vEUUgUKgnLprwlEwsVdLMiqyjdNlpJvA
                    else:
                        YpOuxWSQtcRZUMJNpGvlAdMSmcxdIOeo = HtgtzoIpYbPOyeRXhNxAJIKbkadZOvmx
            XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP = subprocess.Popen(action, shell=True,
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                      stdin=subprocess.PIPE)
            XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP = XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP.stdout.read() + XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP.stderr.read()
            VVZftDaAERVgRnwTyJErGdaraSGDwIXb = 'khAOyNCHKbfFpUTGJjIOORZbHxcQhODD'
            fMYeqGhkiEdETbSvKbEtxoBjtUgVFBoZ = 'pSPOYRSbZgOOIokeGDPRTqxqVHjXOIRD'
            if VVZftDaAERVgRnwTyJErGdaraSGDwIXb != fMYeqGhkiEdETbSvKbEtxoBjtUgVFBoZ:
                nYhtLXHPvWArPVOetgdojoopGDIjKLUA = 'yCglxflRhIgSaIqAlLEEyhiwzsbZFmgL'
                qzpXGbIWNdHLBlHLaRRCegPjsoVGNWDn = 'llXMzlPHruKCzMBNapXMCpXmtdaRLKJl'
                qzpXGbIWNdHLBlHLaRRCegPjsoVGNWDn = nYhtLXHPvWArPVOetgdojoopGDIjKLUA
            NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.sendall(yMJpVmADtfOFNuYBnBVUdcWvfJqpMgZu(XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk))
            RUcdAYqAPzPkZxpcQYaVYZbRTvhjliRd = 'ecMeWCTsOSLBboSrhEnMikjVDILhIUPR'
            WXscdxJuIzNRmdplqATFbjHYfFRvRchZ = 'bvzLdmBOUovPVaKiCBiUaIqWSxmEjIge'
            NrcFmYmIwybRLUhFPNVTWCkYwzyzUoMr = 'ZStQFogtCqJqlNBRCWjaLqsfwEVIGcUz'
            if RUcdAYqAPzPkZxpcQYaVYZbRTvhjliRd == WXscdxJuIzNRmdplqATFbjHYfFRvRchZ:
                ASpPugNPEGcxEVeTlluAwbOjNBegTHzK = 'xHjcLlaOGtrEaCvXEtpaHsceyNeRHPtk'
                ASpPugNPEGcxEVeTlluAwbOjNBegTHzK = RUcdAYqAPzPkZxpcQYaVYZbRTvhjliRd
            else:
                ASpPugNPEGcxEVeTlluAwbOjNBegTHzK = 'xHjcLlaOGtrEaCvXEtpaHsceyNeRHPtk'
                ASpPugNPEGcxEVeTlluAwbOjNBegTHzK = NrcFmYmIwybRLUhFPNVTWCkYwzyzUoMr
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'download':
            xIVWLJpcjbAQLyTrGoUmhMLOFCGWWDSr = 'isyIweYxaezjoSjsGozaVGnGEFmhDZWi'
            RboZJRINNNsTPfykvclrCbijvkEbVZZV = 'XaGCNwrnybHjcMRhYSobxxhsBPtoFlTU'
            zmWoMxdzeYmHtTipIYrRjdhMDFZkfeSG = 'ayjKTYBsqNSYCdxKFSlNgantuLHDRpHn'
            DCLTwbRlYSUGZzfMkJTKOzUUCPukvQYn = 'CYGLHPVpZoLFyiMhMGCBcjdqGxkUmNic'
            aEZcvCJgZaOBNWEapIzeSybJcFpCacNU = 'MPKLOiMUbzDjwzPrnJwqtPHWUVlpSnlu'
            if xIVWLJpcjbAQLyTrGoUmhMLOFCGWWDSr in RboZJRINNNsTPfykvclrCbijvkEbVZZV:
                xIVWLJpcjbAQLyTrGoUmhMLOFCGWWDSr = aEZcvCJgZaOBNWEapIzeSybJcFpCacNU
                if RboZJRINNNsTPfykvclrCbijvkEbVZZV in zmWoMxdzeYmHtTipIYrRjdhMDFZkfeSG:
                    RboZJRINNNsTPfykvclrCbijvkEbVZZV = DCLTwbRlYSUGZzfMkJTKOzUUCPukvQYn
            elif RboZJRINNNsTPfykvclrCbijvkEbVZZV in xIVWLJpcjbAQLyTrGoUmhMLOFCGWWDSr:
                zmWoMxdzeYmHtTipIYrRjdhMDFZkfeSG = RboZJRINNNsTPfykvclrCbijvkEbVZZV
                if zmWoMxdzeYmHtTipIYrRjdhMDFZkfeSG in RboZJRINNNsTPfykvclrCbijvkEbVZZV:
                    RboZJRINNNsTPfykvclrCbijvkEbVZZV = aEZcvCJgZaOBNWEapIzeSybJcFpCacNU
            for JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq in action.split():
                KWLrXomwYDczqmgVZyfBAYOPfrMunMsT = 'pqnRHboNvnPgKRIxXeHXOQCtENMhIwCL'
                TgmeMxFcODWNDYtEBZpvpgmmhFiQSqrS = 'vnpvduMldFNvIBckdVvBOpvCrpPRdKNp'
                kKskrRdcUJBIBaQkfMZBMluchbvDYjBd = 'UTeLcAkaeaGsLxEdUNirTWeECLOnbdia'
                tgBzIwYeufVPNDbxofSfXWKJsYiYmBIY = 'lANtvIImNQfFpfJcmGvGhRvhxdFFmdaC'
                nSBDUhOUzeTgfgozXfukqYmmrkcQKoai = 'DPdQUAIHQlZeRXbqEVzTQXTUUbANwqrE'
                if KWLrXomwYDczqmgVZyfBAYOPfrMunMsT in TgmeMxFcODWNDYtEBZpvpgmmhFiQSqrS:
                    KWLrXomwYDczqmgVZyfBAYOPfrMunMsT = nSBDUhOUzeTgfgozXfukqYmmrkcQKoai
                    if TgmeMxFcODWNDYtEBZpvpgmmhFiQSqrS in kKskrRdcUJBIBaQkfMZBMluchbvDYjBd:
                        TgmeMxFcODWNDYtEBZpvpgmmhFiQSqrS = tgBzIwYeufVPNDbxofSfXWKJsYiYmBIY
                elif TgmeMxFcODWNDYtEBZpvpgmmhFiQSqrS in KWLrXomwYDczqmgVZyfBAYOPfrMunMsT:
                    kKskrRdcUJBIBaQkfMZBMluchbvDYjBd = TgmeMxFcODWNDYtEBZpvpgmmhFiQSqrS
                    if kKskrRdcUJBIBaQkfMZBMluchbvDYjBd in TgmeMxFcODWNDYtEBZpvpgmmhFiQSqrS:
                        TgmeMxFcODWNDYtEBZpvpgmmhFiQSqrS = nSBDUhOUzeTgfgozXfukqYmmrkcQKoai
                JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq = JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq.strip()
                jpcIoIirVbyQvKBDBSJylGVgqeBgwYWB(NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT, JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk)
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'upload':
            kaFxoXdMUXiBPmbARCilSGVyNykdPLFx = 'fNYUIoDcXOYQkDNzGOrmbHNNquMpMoIY'
            zDeArDBtjEYOXmrZaXGQpWfuHtIImgkO = 'AiRYryjfQoSROGLELfGBAzPvYDfkpWRd'
            MbDtKfZImcHSlnsHTNHgnCqlBrjqAnRH = 'sZIyhahGkKrbjrkfhqbZeJkjYCDLeVyM'
            if kaFxoXdMUXiBPmbARCilSGVyNykdPLFx == zDeArDBtjEYOXmrZaXGQpWfuHtIImgkO:
                NWmMYVFEwCNTnlWJjSJTSlEKIYPaVSuT = 'qmlQjdXgZiEzXxxVPYoIEfOleZazVWRf'
                NWmMYVFEwCNTnlWJjSJTSlEKIYPaVSuT = kaFxoXdMUXiBPmbARCilSGVyNykdPLFx
            else:
                NWmMYVFEwCNTnlWJjSJTSlEKIYPaVSuT = 'qmlQjdXgZiEzXxxVPYoIEfOleZazVWRf'
                NWmMYVFEwCNTnlWJjSJTSlEKIYPaVSuT = MbDtKfZImcHSlnsHTNHgnCqlBrjqAnRH
            for JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq in action.split():
                ZmtJOYsZLqrBCZjlABdDwDxOyfIPqBgO = 'BLcdnOtwSaGqrxQelvIGLOHaKPPKHiak'
                TUtiiiHZINoXDhexqDtFKSJSzebfEQYH = 'pFBXesyNeJUeucbXzStmqJKWqQSZKZlE'
                qgqizdvZBaCTDGEPEgAxlHEXirfZUGdQ = 'ZkNHLZzJeLsHxWLrMKmxRDTiTbYyGeJW'
                BJOwoQMiThPAUftrtgmgPMpTeKgdGKSB = 'vKBghcZRIqRiReIHSgnsAyOViVYMiagz'
                ytLgmkwGAsBjhxmFJufuiCnwwUKgSbov = 'oTXnEHskqxwcXGbEkgazSxhRqgxtoPmu'
                gYzTIZDtDbeRPGkazRghqmxtLNKjQVbq = 'rsQUwfGANgTXbewipbMDlXHSqyftjRcc'
                if ZmtJOYsZLqrBCZjlABdDwDxOyfIPqBgO != BJOwoQMiThPAUftrtgmgPMpTeKgdGKSB:
                    TUtiiiHZINoXDhexqDtFKSJSzebfEQYH = qgqizdvZBaCTDGEPEgAxlHEXirfZUGdQ
                    for gYzTIZDtDbeRPGkazRghqmxtLNKjQVbq in BJOwoQMiThPAUftrtgmgPMpTeKgdGKSB:
                        if gYzTIZDtDbeRPGkazRghqmxtLNKjQVbq != qgqizdvZBaCTDGEPEgAxlHEXirfZUGdQ:
                            TUtiiiHZINoXDhexqDtFKSJSzebfEQYH = TUtiiiHZINoXDhexqDtFKSJSzebfEQYH
                        else:
                            ytLgmkwGAsBjhxmFJufuiCnwwUKgSbov = ZmtJOYsZLqrBCZjlABdDwDxOyfIPqBgO
                else:
                    qgqizdvZBaCTDGEPEgAxlHEXirfZUGdQ = ZmtJOYsZLqrBCZjlABdDwDxOyfIPqBgO
                    ZmtJOYsZLqrBCZjlABdDwDxOyfIPqBgO = ytLgmkwGAsBjhxmFJufuiCnwwUKgSbov
                    if qgqizdvZBaCTDGEPEgAxlHEXirfZUGdQ == ZmtJOYsZLqrBCZjlABdDwDxOyfIPqBgO:
                        for gYzTIZDtDbeRPGkazRghqmxtLNKjQVbq in ZmtJOYsZLqrBCZjlABdDwDxOyfIPqBgO:
                            if gYzTIZDtDbeRPGkazRghqmxtLNKjQVbq == qgqizdvZBaCTDGEPEgAxlHEXirfZUGdQ:
                                qgqizdvZBaCTDGEPEgAxlHEXirfZUGdQ = ZmtJOYsZLqrBCZjlABdDwDxOyfIPqBgO
                            else:
                                qgqizdvZBaCTDGEPEgAxlHEXirfZUGdQ = ytLgmkwGAsBjhxmFJufuiCnwwUKgSbov
                JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq = JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq.strip()
                OWpYpOpSPJpgHOwScrENXbxmAmIcFHCq(NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT, JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk)
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'rekey':
            ZTrPTgjOmtfmYdsDhoFJzQepBywvyiEf = 'xpftZFJVqoxiFzjPLyAAXHoTYdachVcn'
            yHsStxqqvAXMVzyujrspkDOWDtWpQLiy = 'xftWQbQPVnUlYAyIKOSEulPJaHcJoThv'
            if ZTrPTgjOmtfmYdsDhoFJzQepBywvyiEf != yHsStxqqvAXMVzyujrspkDOWDtWpQLiy:
                vEHlSSLIIGfCFGWnHgYZhbmLkMMGuhDk = 'XwodmrNAVPyRrpPuzesCvkcQekXQyjUY'
                UdxRgRAtbZQWvJPQJESuagnxgOouZXaE = 'dKtOCbFTcTbHaDnOnGbptzenSjLyFtMt'
                UdxRgRAtbZQWvJPQJESuagnxgOouZXaE = vEHlSSLIIGfCFGWnHgYZhbmLkMMGuhDk
            SCXvEteuykvAcchrxhrAjvYvMBGvaRtk = ejviyCNkcSZJfLMoBkJdCaGLsZpnMUmN(NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT)
            jwTWaISOhnMJhiZCdICtinwqpAFOFZgl = 'azODAsBJQIQvqiTSZWjQVvaHSmTYoxrl'
            EreJmEUSmCivEVVDkUOAkwZhOzqOfAck = 'GAhhTBprmKjzHeldBAngAAQIxQwGdIAQ'
            fQqzRSIeZnuqXEWGXmWtrtlAhmEQSeXS = 'xByvcTGlwFTOAbHvwdakSJUhmBXmYZbf'
            if jwTWaISOhnMJhiZCdICtinwqpAFOFZgl == EreJmEUSmCivEVVDkUOAkwZhOzqOfAck:
                cIMmmpqjWrezpmtsRuBQXudYAwCMokhX = 'YMFjPWavyKOxIBKCzdVaeYViziuVdnIT'
                cIMmmpqjWrezpmtsRuBQXudYAwCMokhX = jwTWaISOhnMJhiZCdICtinwqpAFOFZgl
            else:
                cIMmmpqjWrezpmtsRuBQXudYAwCMokhX = 'YMFjPWavyKOxIBKCzdVaeYViziuVdnIT'
                cIMmmpqjWrezpmtsRuBQXudYAwCMokhX = fQqzRSIeZnuqXEWGXmWtrtlAhmEQSeXS
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'persistence':
            wMXMnNvaYrLizscrJJxGjRufjiNrLTMm = 'kHbToFKwSBhazyiVddpTuQlYlRjqqycr'
            YMNGUPPtmopHaxLhVBrVSfDNRRiXBBZu = 'xaUHQzXoKTxeQKBxDEPzmBnlAlAWFXqp'
            qBzvcfOZFLJAaQOEQwHBISKgnLFDykwL = 'gSdSWjhLHpTqWZauLiqQyTOwEmMxejni'
            lUzIDnjjZwsLieQUpUNMjXDmrcSNGfdq = 'WXiZJBqzhlrFkkPAgjAWozrSmpVhHqOY'
            panPtOWvoNeprCPTbPxUgXpyHLtNVbry = 'tDNiRdPBHbRttviZRUDZCsDKkjoTdpBq'
            tXXVbBcYApcSijMECTEgjAuboykbrgqT = 'CVjDnNbLuEpqQIGBKZWUwwYsddCBKzrO'
            if wMXMnNvaYrLizscrJJxGjRufjiNrLTMm != lUzIDnjjZwsLieQUpUNMjXDmrcSNGfdq:
                YMNGUPPtmopHaxLhVBrVSfDNRRiXBBZu = qBzvcfOZFLJAaQOEQwHBISKgnLFDykwL
                for tXXVbBcYApcSijMECTEgjAuboykbrgqT in lUzIDnjjZwsLieQUpUNMjXDmrcSNGfdq:
                    if tXXVbBcYApcSijMECTEgjAuboykbrgqT != qBzvcfOZFLJAaQOEQwHBISKgnLFDykwL:
                        YMNGUPPtmopHaxLhVBrVSfDNRRiXBBZu = YMNGUPPtmopHaxLhVBrVSfDNRRiXBBZu
                    else:
                        panPtOWvoNeprCPTbPxUgXpyHLtNVbry = wMXMnNvaYrLizscrJJxGjRufjiNrLTMm
            else:
                qBzvcfOZFLJAaQOEQwHBISKgnLFDykwL = wMXMnNvaYrLizscrJJxGjRufjiNrLTMm
                wMXMnNvaYrLizscrJJxGjRufjiNrLTMm = panPtOWvoNeprCPTbPxUgXpyHLtNVbry
                if qBzvcfOZFLJAaQOEQwHBISKgnLFDykwL == wMXMnNvaYrLizscrJJxGjRufjiNrLTMm:
                    for tXXVbBcYApcSijMECTEgjAuboykbrgqT in wMXMnNvaYrLizscrJJxGjRufjiNrLTMm:
                        if tXXVbBcYApcSijMECTEgjAuboykbrgqT == qBzvcfOZFLJAaQOEQwHBISKgnLFDykwL:
                            qBzvcfOZFLJAaQOEQwHBISKgnLFDykwL = wMXMnNvaYrLizscrJJxGjRufjiNrLTMm
                        else:
                            qBzvcfOZFLJAaQOEQwHBISKgnLFDykwL = panPtOWvoNeprCPTbPxUgXpyHLtNVbry
            XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP = GkCWbCyyixKfAFbWumWRqkyYVixwmlnc(sLasHARPRjutZeCoGfehDFlkiKiLrhyo)
            FFQrCkPHPQmtflSzNTnJuUpSTPmCRZIa = 'ehBVmztHPhRaKHjyBvAjbIVCgHuVrwzi'
            EyyWdddnpVLdfvCkiMVJHdsBnKoFmXuQ = 'cjqfvVPbuAyTdBMpczJAwQxBlMIqYhoO'
            jnEZHmQZRNWDvQhrrsezhSBwjlLQyBjo = 'GkEMugBbEHatlnjfrxYltTibWUbtzZdi'
            if FFQrCkPHPQmtflSzNTnJuUpSTPmCRZIa == EyyWdddnpVLdfvCkiMVJHdsBnKoFmXuQ:
                aWbIDXtYEbkdinVSdqDIufDRmFPXnLNN = 'ViwGJOrxluZANOsKqUJidStAuLKOqmkD'
                aWbIDXtYEbkdinVSdqDIufDRmFPXnLNN = FFQrCkPHPQmtflSzNTnJuUpSTPmCRZIa
            else:
                aWbIDXtYEbkdinVSdqDIufDRmFPXnLNN = 'ViwGJOrxluZANOsKqUJidStAuLKOqmkD'
                aWbIDXtYEbkdinVSdqDIufDRmFPXnLNN = jnEZHmQZRNWDvQhrrsezhSBwjlLQyBjo
            NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.send(yMJpVmADtfOFNuYBnBVUdcWvfJqpMgZu(XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk))
            AthXJtZXVxNGIvLDtdDfBOdVRdSxDWHC = 'ItVcVPbbLmHAxtJDijdJtZLPobEqUffS'
            QavLZrIUABEocOtOsyROTuIMgqfmvUHs = 'ImeNxOVImNtRjzROltkVtuJZgTXwWwUN'
            tenJKdFrFzuWWcLYuNMSeEMZMymibWjE = 'uvJskyLNIdInVccHjzHAzOtdYRJMdSbD'
            XbKNkTuJuWzJRGVwcjWJcvqUiTTcFwgM = 'lyHpPxmARLMioEUqAgcYYpAnzkdscFTR'
            GTOIIXWXcQqwRbWyKdZLAlvHBpIvQLWD = 'CqAspRkLclrUBKFjfchHqiLcZQDOCZAj'
            PvGlDPlPhgjSmMwVobLdwmJydZqdcLvF = 'fbnQllkQTgHKQzqzZSFAJBxiRBAIAnRy'
            if AthXJtZXVxNGIvLDtdDfBOdVRdSxDWHC != XbKNkTuJuWzJRGVwcjWJcvqUiTTcFwgM:
                QavLZrIUABEocOtOsyROTuIMgqfmvUHs = tenJKdFrFzuWWcLYuNMSeEMZMymibWjE
                for PvGlDPlPhgjSmMwVobLdwmJydZqdcLvF in XbKNkTuJuWzJRGVwcjWJcvqUiTTcFwgM:
                    if PvGlDPlPhgjSmMwVobLdwmJydZqdcLvF != tenJKdFrFzuWWcLYuNMSeEMZMymibWjE:
                        QavLZrIUABEocOtOsyROTuIMgqfmvUHs = QavLZrIUABEocOtOsyROTuIMgqfmvUHs
                    else:
                        GTOIIXWXcQqwRbWyKdZLAlvHBpIvQLWD = AthXJtZXVxNGIvLDtdDfBOdVRdSxDWHC
            else:
                tenJKdFrFzuWWcLYuNMSeEMZMymibWjE = AthXJtZXVxNGIvLDtdDfBOdVRdSxDWHC
                AthXJtZXVxNGIvLDtdDfBOdVRdSxDWHC = GTOIIXWXcQqwRbWyKdZLAlvHBpIvQLWD
                if tenJKdFrFzuWWcLYuNMSeEMZMymibWjE == AthXJtZXVxNGIvLDtdDfBOdVRdSxDWHC:
                    for PvGlDPlPhgjSmMwVobLdwmJydZqdcLvF in AthXJtZXVxNGIvLDtdDfBOdVRdSxDWHC:
                        if PvGlDPlPhgjSmMwVobLdwmJydZqdcLvF == tenJKdFrFzuWWcLYuNMSeEMZMymibWjE:
                            tenJKdFrFzuWWcLYuNMSeEMZMymibWjE = AthXJtZXVxNGIvLDtdDfBOdVRdSxDWHC
                        else:
                            tenJKdFrFzuWWcLYuNMSeEMZMymibWjE = GTOIIXWXcQqwRbWyKdZLAlvHBpIvQLWD
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'wget':
            lFqfewBnaFsmzPYzalFtWQVzHlNslsjU = 'AmcTvfVKOCngQrwmUDGimmLbmcoqeQOw'
            BIqbPdPTiFUPRiINxLObcQTFDaxYyJeL = 'homkXwwXKxjFkjdBWBnrMlTxbxPnxAng'
            FsudAaqUpUXdLMTbXceGcTcLeFibrNmX = 'LRAimXBJMOhTvMoHWyUTzFVOxiROSHNt'
            JgztjlKOyhHwmeVyfoHteMXHHTdEKcHF = 'WvSZlvCPrUxElNPqEiHXrtefkmbcbOoS'
            wJoXFoRsSUZoxnWIWdLPSmCbxpUwoFUk = 'awTWhyasCnpzhuKXWBPDargNfwSWHHrx'
            if lFqfewBnaFsmzPYzalFtWQVzHlNslsjU in BIqbPdPTiFUPRiINxLObcQTFDaxYyJeL:
                lFqfewBnaFsmzPYzalFtWQVzHlNslsjU = wJoXFoRsSUZoxnWIWdLPSmCbxpUwoFUk
                if BIqbPdPTiFUPRiINxLObcQTFDaxYyJeL in FsudAaqUpUXdLMTbXceGcTcLeFibrNmX:
                    BIqbPdPTiFUPRiINxLObcQTFDaxYyJeL = JgztjlKOyhHwmeVyfoHteMXHHTdEKcHF
            elif BIqbPdPTiFUPRiINxLObcQTFDaxYyJeL in lFqfewBnaFsmzPYzalFtWQVzHlNslsjU:
                FsudAaqUpUXdLMTbXceGcTcLeFibrNmX = BIqbPdPTiFUPRiINxLObcQTFDaxYyJeL
                if FsudAaqUpUXdLMTbXceGcTcLeFibrNmX in BIqbPdPTiFUPRiINxLObcQTFDaxYyJeL:
                    BIqbPdPTiFUPRiINxLObcQTFDaxYyJeL = wJoXFoRsSUZoxnWIWdLPSmCbxpUwoFUk
            XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP = NxsLeFVEsrqVOmmOiMYdYzXVaAJfMmWN(action)
            poBHEfGLYEWwCxFrgkTBBgvEHQQxAjDP = 'crBduBiHVkCzvadrxseeVKVgzmpjIaBv'
            MLjPfUEpKDEXrPXqyLyxsYmiTfiFwubc = 'RbNiwUbjfHtuqzqYchsYZrRRolzJjpUh'
            yZOgxdrQyaFaJyRMEkbxoYLwJWJICtIX = 'PoUJzLmRbmtFTyawIyfUPfrAHjtllsXW'
            SaIISsawsFKHpWTHUzxQpUVKEgsLkiYQ = 'ibackfdjnGPpUxUpFlXFjqGfpJSeHWPT'
            MvMDkFCFUOSNgjcgZgAujbXcNSdfQneO = 'CvVfLSBEudVYvlCYjiUtKMtYMgPTAqBj'
            BonnpDGtmdzLPDhItrlCzTqTiBfTvXWm = 'hozFNuHMWGEmubwlOJfYNFYYydWBVVoB'
            if yZOgxdrQyaFaJyRMEkbxoYLwJWJICtIX == SaIISsawsFKHpWTHUzxQpUVKEgsLkiYQ:
                for BonnpDGtmdzLPDhItrlCzTqTiBfTvXWm in MvMDkFCFUOSNgjcgZgAujbXcNSdfQneO:
                    if BonnpDGtmdzLPDhItrlCzTqTiBfTvXWm == SaIISsawsFKHpWTHUzxQpUVKEgsLkiYQ:
                        MvMDkFCFUOSNgjcgZgAujbXcNSdfQneO = poBHEfGLYEWwCxFrgkTBBgvEHQQxAjDP
                    else:
                        SaIISsawsFKHpWTHUzxQpUVKEgsLkiYQ = MLjPfUEpKDEXrPXqyLyxsYmiTfiFwubc
            NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.send(yMJpVmADtfOFNuYBnBVUdcWvfJqpMgZu(XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk))
            kOWosSJuQGQxTxUEzPhkPahPUOCLiFXX = 'VKCZQXbBhoDaFzbfCayCYdHaJBPMoVrw'
            tujKupkYLYmnofQaxWSHCJcsapYYUbmQ = 'nxiHEWpgCPKSRpJibCbSesQGXwPrUKAV'
            GufdkQNBHOOHSFkOmumMDRnOzMiWZIWN = 'xcayEKqJVnCHcRNJlveAfgnGCHNKDIXs'
            hEnqwiktKdZXqkAHrYNPzqfhaoYVjfjm = 'XHYJXwgaIUjaSZVwbeGCzBdyVYbrzlBc'
            XjxMySiixFyRoRtsGrbnIZcbxpJFYWQH = 'OLdjCxBNAIxwyroqKYcBexlZhqgvTUJn'
            TCztuCjcINpGxoDxHSLFLnnYMYwcOoMv = 'ZZoQhXHNvMAUFHqSXbTplGIFFUXIfdCW'
            if GufdkQNBHOOHSFkOmumMDRnOzMiWZIWN == hEnqwiktKdZXqkAHrYNPzqfhaoYVjfjm:
                for TCztuCjcINpGxoDxHSLFLnnYMYwcOoMv in XjxMySiixFyRoRtsGrbnIZcbxpJFYWQH:
                    if TCztuCjcINpGxoDxHSLFLnnYMYwcOoMv == hEnqwiktKdZXqkAHrYNPzqfhaoYVjfjm:
                        XjxMySiixFyRoRtsGrbnIZcbxpJFYWQH = kOWosSJuQGQxTxUEzPhkPahPUOCLiFXX
                    else:
                        hEnqwiktKdZXqkAHrYNPzqfhaoYVjfjm = tujKupkYLYmnofQaxWSHCJcsapYYUbmQ
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'unzip':
            myGNtyesaZjllAxJaYSPTUMQEqCtbspq = 'uGaKeehfyqsdXhcAEsZXQTlqsLNuVJUi'
            lOvvXTFfVeAiUMymtiijZyemfmSYnyqr = 'HOSkRJmADCUFavbRFJozseAdqCVLBdEr'
            hQXhMBWiEkKvkCGqnAwpohzYVqYOFQvX = 'yVsIJsvszINmJNrsCNWPnyJzzvSoqImv'
            gzcsYqLFElWhmPVmcaRexvbKHdElVGVO = 'xHBAWkPQjfaGTkIaXCzPuzFGWaklhdoO'
            jILBwfBwTRPsPFSqWUhZwBmxHUQYLGJN = 'NxgtQqgnViIoEUJQVRmGpCwhJwIDajBk'
            if myGNtyesaZjllAxJaYSPTUMQEqCtbspq in lOvvXTFfVeAiUMymtiijZyemfmSYnyqr:
                myGNtyesaZjllAxJaYSPTUMQEqCtbspq = jILBwfBwTRPsPFSqWUhZwBmxHUQYLGJN
                if lOvvXTFfVeAiUMymtiijZyemfmSYnyqr in hQXhMBWiEkKvkCGqnAwpohzYVqYOFQvX:
                    lOvvXTFfVeAiUMymtiijZyemfmSYnyqr = gzcsYqLFElWhmPVmcaRexvbKHdElVGVO
            elif lOvvXTFfVeAiUMymtiijZyemfmSYnyqr in myGNtyesaZjllAxJaYSPTUMQEqCtbspq:
                hQXhMBWiEkKvkCGqnAwpohzYVqYOFQvX = lOvvXTFfVeAiUMymtiijZyemfmSYnyqr
                if hQXhMBWiEkKvkCGqnAwpohzYVqYOFQvX in lOvvXTFfVeAiUMymtiijZyemfmSYnyqr:
                    lOvvXTFfVeAiUMymtiijZyemfmSYnyqr = jILBwfBwTRPsPFSqWUhZwBmxHUQYLGJN
            XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP = DFWbVmigcpeTpQKJnPtVRcOwYASgIDtg(action)
            QSIMDdvabqmLeQowXKTwntymfVrsKJiI = 'hGzpPbxejeKYPzAjKOnQuuDMWPyeJVkg'
            SVcOgmagcpfRzYzwDqLgzurXXtPVDigP = 'IkioAmBImJzzbDYIWvDaEyfHZfQtofRy'
            OLMEkwOkogrvKJAIPOVtBUtvJYthpUda = 'UNbNQZBrUhTApSxRmSCLlYDgamKLQGHb'
            ZuRYmUpfBKbxdyPIDJeAfcaLCPPLipsy = 'OrFeeexEZkytiSVmyjbhqAAlECfVXSCi'
            ogwantGKiBjanjpqzTuqhpKYZfayUutO = 'VxMbUXGmJvVxYPPFfIoPcdenKNoIbPxY'
            EpoXadExprbLNPRaNCrTVrwnPtTRHeTC = 'WbrgZRfSzNEajOxbWfdJfSAmImMpCwjB'
            if QSIMDdvabqmLeQowXKTwntymfVrsKJiI != ZuRYmUpfBKbxdyPIDJeAfcaLCPPLipsy:
                SVcOgmagcpfRzYzwDqLgzurXXtPVDigP = OLMEkwOkogrvKJAIPOVtBUtvJYthpUda
                for EpoXadExprbLNPRaNCrTVrwnPtTRHeTC in ZuRYmUpfBKbxdyPIDJeAfcaLCPPLipsy:
                    if EpoXadExprbLNPRaNCrTVrwnPtTRHeTC != OLMEkwOkogrvKJAIPOVtBUtvJYthpUda:
                        SVcOgmagcpfRzYzwDqLgzurXXtPVDigP = SVcOgmagcpfRzYzwDqLgzurXXtPVDigP
                    else:
                        ogwantGKiBjanjpqzTuqhpKYZfayUutO = QSIMDdvabqmLeQowXKTwntymfVrsKJiI
            else:
                OLMEkwOkogrvKJAIPOVtBUtvJYthpUda = QSIMDdvabqmLeQowXKTwntymfVrsKJiI
                QSIMDdvabqmLeQowXKTwntymfVrsKJiI = ogwantGKiBjanjpqzTuqhpKYZfayUutO
                if OLMEkwOkogrvKJAIPOVtBUtvJYthpUda == QSIMDdvabqmLeQowXKTwntymfVrsKJiI:
                    for EpoXadExprbLNPRaNCrTVrwnPtTRHeTC in QSIMDdvabqmLeQowXKTwntymfVrsKJiI:
                        if EpoXadExprbLNPRaNCrTVrwnPtTRHeTC == OLMEkwOkogrvKJAIPOVtBUtvJYthpUda:
                            OLMEkwOkogrvKJAIPOVtBUtvJYthpUda = QSIMDdvabqmLeQowXKTwntymfVrsKJiI
                        else:
                            OLMEkwOkogrvKJAIPOVtBUtvJYthpUda = ogwantGKiBjanjpqzTuqhpKYZfayUutO
            NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.send(yMJpVmADtfOFNuYBnBVUdcWvfJqpMgZu(XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk))
            whSVYPLWMtSceMbBXofHGYdTwsoHuqGG = 'DtIvcIgNYNgzAGFFnyOWdWQWFyYBjgBE'
            xAKUZqwRXvfSbOjxlvKXsGDPZcmlEYnB = 'ULqBGnHFMOHLbPcVtQraNYKSRqlcNxvS'
            haULmehYgGqRqXoHKecJmJZmnmnmFKsT = 'PnHXHckomxxdcExzpjZIVYZbExRxWcPV'
            QoymFvgYqEbSxYmFvrCgnmozgKdTCngw = 'uRHbQlIwDIMQzFSqVKLMOYoVEIckVtMP'
            kFDzurHqbZjKcDGCjAquikKkRBjqgyLw = 'yAeFkAkNAsTeEtJgPbWJOWAwBhYMljlY'
            DwODWPHKLmNAVApGmKiEqoeGbZZqQGfu = 'IbFoEAeZicOGZgxIMdhpmxufpDiDHibf'
            if haULmehYgGqRqXoHKecJmJZmnmnmFKsT == QoymFvgYqEbSxYmFvrCgnmozgKdTCngw:
                for DwODWPHKLmNAVApGmKiEqoeGbZZqQGfu in kFDzurHqbZjKcDGCjAquikKkRBjqgyLw:
                    if DwODWPHKLmNAVApGmKiEqoeGbZZqQGfu == QoymFvgYqEbSxYmFvrCgnmozgKdTCngw:
                        kFDzurHqbZjKcDGCjAquikKkRBjqgyLw = whSVYPLWMtSceMbBXofHGYdTwsoHuqGG
                    else:
                        QoymFvgYqEbSxYmFvrCgnmozgKdTCngw = xAKUZqwRXvfSbOjxlvKXsGDPZcmlEYnB
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'survey':
            YUpcIEEcWrzYpebEIUlONnVVoTbpAvhw = 'qrbxLCHJwFnIWsDzQyyFPQJpgypreUUL'
            SYmcTLufjAVqbnOnVBcaLLcVKrIRYyij = 'sdVXcjYrVCGUQWdhNSiCkXaNCtqtDcRM'
            czeIBzuGNWcpQCuzjkIhtvOifiXdbBAr = 'cJNGmmOVItYNIZHZXjLbysokKAAIyOzr'
            zKBhDIEuqgfkXyBIRdxnshuzHVHBdcuz = 'VKabfPClsAniKNdEADZdbUAayPvvfWkq'
            ZvdOtCrocEIonLBKsMUIONjuAeWSFiQX = 'ZQfttogIfpbrnAqDFHTtXQdWzgRulYoc'
            wHtQWVjaVTDUBFqsVUbuGLdudAXneDvy = 'CLcACafWuaqiKNEoUSrTpoYOAncgqdhs'
            if YUpcIEEcWrzYpebEIUlONnVVoTbpAvhw != zKBhDIEuqgfkXyBIRdxnshuzHVHBdcuz:
                SYmcTLufjAVqbnOnVBcaLLcVKrIRYyij = czeIBzuGNWcpQCuzjkIhtvOifiXdbBAr
                for wHtQWVjaVTDUBFqsVUbuGLdudAXneDvy in zKBhDIEuqgfkXyBIRdxnshuzHVHBdcuz:
                    if wHtQWVjaVTDUBFqsVUbuGLdudAXneDvy != czeIBzuGNWcpQCuzjkIhtvOifiXdbBAr:
                        SYmcTLufjAVqbnOnVBcaLLcVKrIRYyij = SYmcTLufjAVqbnOnVBcaLLcVKrIRYyij
                    else:
                        ZvdOtCrocEIonLBKsMUIONjuAeWSFiQX = YUpcIEEcWrzYpebEIUlONnVVoTbpAvhw
            else:
                czeIBzuGNWcpQCuzjkIhtvOifiXdbBAr = YUpcIEEcWrzYpebEIUlONnVVoTbpAvhw
                YUpcIEEcWrzYpebEIUlONnVVoTbpAvhw = ZvdOtCrocEIonLBKsMUIONjuAeWSFiQX
                if czeIBzuGNWcpQCuzjkIhtvOifiXdbBAr == YUpcIEEcWrzYpebEIUlONnVVoTbpAvhw:
                    for wHtQWVjaVTDUBFqsVUbuGLdudAXneDvy in YUpcIEEcWrzYpebEIUlONnVVoTbpAvhw:
                        if wHtQWVjaVTDUBFqsVUbuGLdudAXneDvy == czeIBzuGNWcpQCuzjkIhtvOifiXdbBAr:
                            czeIBzuGNWcpQCuzjkIhtvOifiXdbBAr = YUpcIEEcWrzYpebEIUlONnVVoTbpAvhw
                        else:
                            czeIBzuGNWcpQCuzjkIhtvOifiXdbBAr = ZvdOtCrocEIonLBKsMUIONjuAeWSFiQX
            XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP = GkCWbCyyixKfAFbWumWRqkyYVixwmlnc(sLasHARPRjutZeCoGfehDFlkiKiLrhyo)
            IVlDeeLRyvizZoOTeKHiEoUUwoAwHMLH = 'gKGpSzurxEeaumLEzmscBNTTrfGIrsHY'
            rsrlNyajNkXCCZsGTRnjruEEmuvDOHOX = 'zZSpRjkKMqBgUYDLLylhtEOKgyrWmSti'
            if IVlDeeLRyvizZoOTeKHiEoUUwoAwHMLH != rsrlNyajNkXCCZsGTRnjruEEmuvDOHOX:
                FQlQbQUJaxAuKZqYHdaOkdMXQRwaycBe = 'nnCRRQHgCErqSywDsQdkYrRIguogSpgz'
                qsNwONoUqGaHVFYLzZazrpLHfFuJgsOA = 'kffJRpPvYfmuDYlyahLpdWyjgOYBnpdc'
                qsNwONoUqGaHVFYLzZazrpLHfFuJgsOA = FQlQbQUJaxAuKZqYHdaOkdMXQRwaycBe
            NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.send(yMJpVmADtfOFNuYBnBVUdcWvfJqpMgZu(XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk))
            qfTTscBtoHlUQJpZoQrkMKLlTGFmRQWo = 'avwsrqVxASctdNxpEPxeHhScceHjvIRF'
            ZGgmXYvIUWCKljCPwuMUwABxANUTlXNB = 'CkLeHrRWqJmFJspSdGyqfmtqIBOtbwwJ'
            mRTGYvlVtxoPZWowhqILtRRpAahUVGID = 'nfTRTZTErAgTmkYaHwYRGUaKyhBQNOgm'
            akLsMqkJIDlFZtFNIbmiMOZeMfSYcxWR = 'xvmSVALLBwFdKltrgaTohXRuIkCsBsnt'
            MzOQTlEdLHRLPhOUVeyenOfZNpvgDAYY = 'ghwgwXJHvvVCmtpGsIeCnkpAxVeWLIVh'
            emEKFOPFjeZBZjginAlbDUAmSjDSfzWM = 'FTwOedrFmPfXLrLFnKwAQitVvJJKttvs'
            if mRTGYvlVtxoPZWowhqILtRRpAahUVGID == akLsMqkJIDlFZtFNIbmiMOZeMfSYcxWR:
                for emEKFOPFjeZBZjginAlbDUAmSjDSfzWM in MzOQTlEdLHRLPhOUVeyenOfZNpvgDAYY:
                    if emEKFOPFjeZBZjginAlbDUAmSjDSfzWM == akLsMqkJIDlFZtFNIbmiMOZeMfSYcxWR:
                        MzOQTlEdLHRLPhOUVeyenOfZNpvgDAYY = qfTTscBtoHlUQJpZoQrkMKLlTGFmRQWo
                    else:
                        akLsMqkJIDlFZtFNIbmiMOZeMfSYcxWR = ZGgmXYvIUWCKljCPwuMUwABxANUTlXNB
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'scan':
            jsYpzQomqOejNrRAYYlxKejMglRMyLHx = 'zBEVuxRTEYzfUjDFxAIXJNvvkeqQLfaM'
            WYwhmcSfLfsiuAZaYKknFwtSJvOZlzcI = 'RuRkrYSWOfAlWWqtlGsxSbEJKvjAYLXk'
            GMQkRfKGcCnuaYjflRlDDFzceJmTkDXP = 'ekXsmeftsaXwGyCpoRIXtWMGmBVrRYcD'
            kARhtPiflTecoNJRdWzTcLDlIWBCtIpg = 'XuqmBPUOiLlIbIKtHLovoBBdaQPRVJpm'
            CwrBWeFguMZyKIgWeYIhYnRMUfJneAab = 'tDPPpbnsvHbxOQupxYwnBGdpzfIThdzc'
            if jsYpzQomqOejNrRAYYlxKejMglRMyLHx in WYwhmcSfLfsiuAZaYKknFwtSJvOZlzcI:
                jsYpzQomqOejNrRAYYlxKejMglRMyLHx = CwrBWeFguMZyKIgWeYIhYnRMUfJneAab
                if WYwhmcSfLfsiuAZaYKknFwtSJvOZlzcI in GMQkRfKGcCnuaYjflRlDDFzceJmTkDXP:
                    WYwhmcSfLfsiuAZaYKknFwtSJvOZlzcI = kARhtPiflTecoNJRdWzTcLDlIWBCtIpg
            elif WYwhmcSfLfsiuAZaYKknFwtSJvOZlzcI in jsYpzQomqOejNrRAYYlxKejMglRMyLHx:
                GMQkRfKGcCnuaYjflRlDDFzceJmTkDXP = WYwhmcSfLfsiuAZaYKknFwtSJvOZlzcI
                if GMQkRfKGcCnuaYjflRlDDFzceJmTkDXP in WYwhmcSfLfsiuAZaYKknFwtSJvOZlzcI:
                    WYwhmcSfLfsiuAZaYKknFwtSJvOZlzcI = CwrBWeFguMZyKIgWeYIhYnRMUfJneAab
            XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP = MXharpYQHqoDolbKYeZNUbHCGorzssHg(action)
            ElCHgLDTUdtxksiwfpoyCOjVpbbJmFlg = 'jMrPNgqXBWbXNjaUUoSmCKcGuKbYlbif'
            aUrlbLdKOhiiIghWfKcPbUQuxkGfwaJh = 'DGpzlUkxNoFotMPdVutQhweXrMkQVMQa'
            dkNMSIqMeVUVeKMUzFVqkvDDnIHrUfkC = 'HIhVWCrmsJJkAEDrZpRIQbUnANeFDxJC'
            if ElCHgLDTUdtxksiwfpoyCOjVpbbJmFlg == aUrlbLdKOhiiIghWfKcPbUQuxkGfwaJh:
                JBYoWrykRbffwdZtEEinOhEWlcxHGWZv = 'XRxwqIgaGJRembZnOJLzNGUhdmIJEUfm'
                JBYoWrykRbffwdZtEEinOhEWlcxHGWZv = ElCHgLDTUdtxksiwfpoyCOjVpbbJmFlg
            else:
                JBYoWrykRbffwdZtEEinOhEWlcxHGWZv = 'XRxwqIgaGJRembZnOJLzNGUhdmIJEUfm'
                JBYoWrykRbffwdZtEEinOhEWlcxHGWZv = dkNMSIqMeVUVeKMUzFVqkvDDnIHrUfkC
            NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.send(yMJpVmADtfOFNuYBnBVUdcWvfJqpMgZu(XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk))
            TiFQJYuuVcINnhbaHyvHohzuducGENcw = 'iIaScAGMMwGvIMDvYNvMbajNaSgGyHun'
            WZkZMWQNmqjcTVfsXZvtEunjvXagFAHi = 'bKZnAbEgvCzMRPrxhpqkqmnUtOPAsQDd'
            if TiFQJYuuVcINnhbaHyvHohzuducGENcw != WZkZMWQNmqjcTVfsXZvtEunjvXagFAHi:
                ZvLdkxATAVziSjgpIPnKxeBXqXjSbBmG = 'yNicGwIuLTcCqWKPVaOTdUNfrPxljDSN'
                ZUpUELPVDKgMPkwAYBLpZbSpVNJrxCHF = 'AXSfZlAzJxPDHbhszqwIVtygfiuAFIBS'
                ZUpUELPVDKgMPkwAYBLpZbSpVNJrxCHF = ZvLdkxATAVziSjgpIPnKxeBXqXjSbBmG
if __name__ == '__main__':
    RKwwVAHGogNIkarJCToHIaStHhcTTXtN = 'ZfvvOeInoeuGOLwVyvUsJTCYHdEOUwgb'
    UTEdmmbZNmznTDtXqLZvGHtrnEiKawxh = 'fIugbiqJNqRhqkuHbPFAeZeWPIlqYand'
    if RKwwVAHGogNIkarJCToHIaStHhcTTXtN != UTEdmmbZNmznTDtXqLZvGHtrnEiKawxh:
        lixJsdLvPmsuJSBGezyNTOHrVeGAMVii = 'toPmbmCPAtuRZtreyLPDtvNtrweYqybZ'
        KaQwtKlSBAOxSWWmsdvECVSglzJPxsEC = 'iQtsYUmlhDaapLIcZlKHxHXQdIlZQtVN'
        KaQwtKlSBAOxSWWmsdvECVSglzJPxsEC = lixJsdLvPmsuJSBGezyNTOHrVeGAMVii
    peLcLHBhgzuWqIXCIFmkLiUOYdArvOei()
    uDUkXyjGGtSduLWujUOWBbIedkyyKAkW = 'RHbyBHowxOQcIRHOwRMzaPXNaQNNGXUG'
    PNmHChncJCyMlEpIbydozWqPZqKjSmRI = 'JMbyrrKfXNignMKtvnUsscTtHtmsYmjQ'
    if uDUkXyjGGtSduLWujUOWBbIedkyyKAkW != PNmHChncJCyMlEpIbydozWqPZqKjSmRI:
        YqmMIlKxyUDWxWtlbtLnCbQJXCNNckTX = 'tGiDvdfOJCzcLqZOIAdWhQrEJUeuIjqw'
        JONqIGbGmZFhxpunVhtxLhJStsduBFbT = 'azfjSnHhQXQWfWnMGwSwxHpQqOFhKXbr'
        JONqIGbGmZFhxpunVhtxLhJStsduBFbT = YqmMIlKxyUDWxWtlbtLnCbQJXCNNckTX
