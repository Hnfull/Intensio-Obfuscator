# -*- coding: utf-8 -*-
import datetime
UaIdTDoHLYrmPZWcpxhVbEXgWGrNXnNq = 'qkjsvrXZcSaMbJWPEYNCvLoOZTQMwHoY'
YkIormvCpCVzkAflIbuLLSbMQPrFxTKE = 'EvDJwstmGRgjxngXWhCtDrTKIVMdVppi'
OmdlBHPbnskJHTsjMaLpxbqqZvlhSPTH = 'DOvoMvJIruZtgOIwbcXIKHptmVAeBgJy'
HXQbMcnbYUsVyXImTuRFTeZWYgwbCyud = 'nchGwyCGIUiNgrrPWVpcbsRTsebcivZL'
RuOsRHWlusgmwZBWPCRfTPQSAFxWwKoC = 'FvJQsSKczinKSCaKTjbKuzIuSxnCeedO'
gelhUryeyOJciZTizpenkvwHQrtEHedQ = 'uEtqJXcRWQTxChStPxMcqlgcHGnPqYox'
if UaIdTDoHLYrmPZWcpxhVbEXgWGrNXnNq != HXQbMcnbYUsVyXImTuRFTeZWYgwbCyud:
    YkIormvCpCVzkAflIbuLLSbMQPrFxTKE = OmdlBHPbnskJHTsjMaLpxbqqZvlhSPTH
    for gelhUryeyOJciZTizpenkvwHQrtEHedQ in HXQbMcnbYUsVyXImTuRFTeZWYgwbCyud:
        if gelhUryeyOJciZTizpenkvwHQrtEHedQ != OmdlBHPbnskJHTsjMaLpxbqqZvlhSPTH:
            YkIormvCpCVzkAflIbuLLSbMQPrFxTKE = YkIormvCpCVzkAflIbuLLSbMQPrFxTKE
        else:
            RuOsRHWlusgmwZBWPCRfTPQSAFxWwKoC = UaIdTDoHLYrmPZWcpxhVbEXgWGrNXnNq
else:
    OmdlBHPbnskJHTsjMaLpxbqqZvlhSPTH = UaIdTDoHLYrmPZWcpxhVbEXgWGrNXnNq
    UaIdTDoHLYrmPZWcpxhVbEXgWGrNXnNq = RuOsRHWlusgmwZBWPCRfTPQSAFxWwKoC
    if OmdlBHPbnskJHTsjMaLpxbqqZvlhSPTH == UaIdTDoHLYrmPZWcpxhVbEXgWGrNXnNq:
        for gelhUryeyOJciZTizpenkvwHQrtEHedQ in UaIdTDoHLYrmPZWcpxhVbEXgWGrNXnNq:
            if gelhUryeyOJciZTizpenkvwHQrtEHedQ == OmdlBHPbnskJHTsjMaLpxbqqZvlhSPTH:
                OmdlBHPbnskJHTsjMaLpxbqqZvlhSPTH = UaIdTDoHLYrmPZWcpxhVbEXgWGrNXnNq
            else:
                OmdlBHPbnskJHTsjMaLpxbqqZvlhSPTH = RuOsRHWlusgmwZBWPCRfTPQSAFxWwKoC
import os
zQrePUrooiqXvcOPnTWQYfdVZdYDuydI = 'tbauCViForbkTfeGaLPCRrsKRbONPThV'
hYhDdWstetLPafgtbkRoovOVscUnpLFw = 'xwSiuqYRJuBDaOQiYtfEqVyVpjdIBsZs'
HWvaivgCCaHUFPvNLybkwIlxVBQTiSXM = 'guXPgFaboBauKixFjlgYSteDZILkairO'
BciLQWGcEefoXWbNqwZPgKLdWbXUOEbw = 'OpcdKxjsFnpocSLqhBtxBXHnvVCibLWT'
OnTOgCJBXlfaKLbzZleVetTKWcCwlkiu = 'QgftHMFkYMVaKOEIeUsxVaWFrxmrVaKB'
if zQrePUrooiqXvcOPnTWQYfdVZdYDuydI in hYhDdWstetLPafgtbkRoovOVscUnpLFw:
    zQrePUrooiqXvcOPnTWQYfdVZdYDuydI = OnTOgCJBXlfaKLbzZleVetTKWcCwlkiu
    if hYhDdWstetLPafgtbkRoovOVscUnpLFw in HWvaivgCCaHUFPvNLybkwIlxVBQTiSXM:
        hYhDdWstetLPafgtbkRoovOVscUnpLFw = BciLQWGcEefoXWbNqwZPgKLdWbXUOEbw
elif hYhDdWstetLPafgtbkRoovOVscUnpLFw in zQrePUrooiqXvcOPnTWQYfdVZdYDuydI:
    HWvaivgCCaHUFPvNLybkwIlxVBQTiSXM = hYhDdWstetLPafgtbkRoovOVscUnpLFw
    if HWvaivgCCaHUFPvNLybkwIlxVBQTiSXM in hYhDdWstetLPafgtbkRoovOVscUnpLFw:
        hYhDdWstetLPafgtbkRoovOVscUnpLFw = OnTOgCJBXlfaKLbzZleVetTKWcCwlkiu
import urllib
DXgdJlaCBxPsYJvgoJdaYzkcrBSXwooO = 'GglKQXgstyVScLVEoHopGbAhXMrlmuDu'
EluYJiLGWzYvpwCCgUUzQNUYsSVUNVkT = 'mdjeTywWHJGyjWMrWOWDhLMwnGMOmGOQ'
YJlZzzAavlEYXFluWvkYBFfzSimtUTYU = 'jljWLgIwuYCcEncXlLfdjmMajzTfBRAQ'
lqWgMHBOVzlIWfNqTaxfoQeLnXZWPIpr = 'VlVInynKiWpYNecZHsIeuLpZZELkbbKy'
UdWWLaBFWcSzazeQGImXTjjzhqEIfcgZ = 'MLOGbvqYwVXCDboBMYoqeQNRrJvgmRDP'
NcMYLgEGRGpZtbCUjPuAkIDbIGQgtoAC = 'ZjgwODgSXGKSMoihmfCYtKbVMJWHGcfG'
if DXgdJlaCBxPsYJvgoJdaYzkcrBSXwooO != lqWgMHBOVzlIWfNqTaxfoQeLnXZWPIpr:
    EluYJiLGWzYvpwCCgUUzQNUYsSVUNVkT = YJlZzzAavlEYXFluWvkYBFfzSimtUTYU
    for NcMYLgEGRGpZtbCUjPuAkIDbIGQgtoAC in lqWgMHBOVzlIWfNqTaxfoQeLnXZWPIpr:
        if NcMYLgEGRGpZtbCUjPuAkIDbIGQgtoAC != YJlZzzAavlEYXFluWvkYBFfzSimtUTYU:
            EluYJiLGWzYvpwCCgUUzQNUYsSVUNVkT = EluYJiLGWzYvpwCCgUUzQNUYsSVUNVkT
        else:
            UdWWLaBFWcSzazeQGImXTjjzhqEIfcgZ = DXgdJlaCBxPsYJvgoJdaYzkcrBSXwooO
else:
    YJlZzzAavlEYXFluWvkYBFfzSimtUTYU = DXgdJlaCBxPsYJvgoJdaYzkcrBSXwooO
    DXgdJlaCBxPsYJvgoJdaYzkcrBSXwooO = UdWWLaBFWcSzazeQGImXTjjzhqEIfcgZ
    if YJlZzzAavlEYXFluWvkYBFfzSimtUTYU == DXgdJlaCBxPsYJvgoJdaYzkcrBSXwooO:
        for NcMYLgEGRGpZtbCUjPuAkIDbIGQgtoAC in DXgdJlaCBxPsYJvgoJdaYzkcrBSXwooO:
            if NcMYLgEGRGpZtbCUjPuAkIDbIGQgtoAC == YJlZzzAavlEYXFluWvkYBFfzSimtUTYU:
                YJlZzzAavlEYXFluWvkYBFfzSimtUTYU = DXgdJlaCBxPsYJvgoJdaYzkcrBSXwooO
            else:
                YJlZzzAavlEYXFluWvkYBFfzSimtUTYU = UdWWLaBFWcSzazeQGImXTjjzhqEIfcgZ
import zipfile
kjRVhSGjHAoVBBVtIIysJOQfQBtVZxXG = 'cBFCkHsuDjPYeSzBPgFOpaXRIgYZuAwq'
IEsNaiqsOsxjyymwGBEfCIaZFwSivTIm = 'YjarZAgOBEMdAXtpLfvDuYxnENmrZShk'
WclSSatWmDiiBrDTVrEvQyDoyQUvmImA = 'isxhsuTlZKxmcXlEUJvGqOEuwPXdezrL'
pzvPOQfPCjOEtALkyLegPunACxzyMtmb = 'jIidxktxtZoTHPxKTrsQzNWuGTwDZNbz'
VsVBGvsktbbjCtRgHIeWdVRkKefWHXxh = 'wCZBwzXBHnaOPeBZpWzRqdUvcPvRfbbk'
GdqgpYneWDMUUoEAAQbzhplEPxUoEQGw = 'nwJqxPtoeiQajYcimtbrffqlGizDKHhR'
if WclSSatWmDiiBrDTVrEvQyDoyQUvmImA == pzvPOQfPCjOEtALkyLegPunACxzyMtmb:
    for GdqgpYneWDMUUoEAAQbzhplEPxUoEQGw in VsVBGvsktbbjCtRgHIeWdVRkKefWHXxh:
        if GdqgpYneWDMUUoEAAQbzhplEPxUoEQGw == pzvPOQfPCjOEtALkyLegPunACxzyMtmb:
            VsVBGvsktbbjCtRgHIeWdVRkKefWHXxh = kjRVhSGjHAoVBBVtIIysJOQfQBtVZxXG
        else:
            pzvPOQfPCjOEtALkyLegPunACxzyMtmb = IEsNaiqsOsxjyymwGBEfCIaZFwSivTIm
def DFWbVmigcpeTpQKJnPtVRcOwYASgIDtg(f):
    dBulwMykWybitxhDqHqfyZEXmJzlGFQv = 'YgdqiWuYqEhbwrgSWgBXJLxPvStmuykE'
    VrCjCbdNHXQlgTNbRJjlItAqOnSBbixG = 'gBCoSwxnSvkYbsSffbuJZcSDtvmWmsIc'
    RwBHJzUXfsXYxDWNzOKJVFTVBqAgzrkA = 'XmsiJHVypCmEaoZtazUiSJKTSFVBXykH'
    OZyQjBuzkkezsSrpKqZrRqAXAebIFjHQ = 'FSVPMnipbFHGzaFsHlDlCCYbYpYuYbFf'
    jiDmkBZugDPNEvNsnrHIilCfDWHOaxpg = 'LZdjJrMcCbKrpNaRcbmiBnmVpYGrPHHw'
    if dBulwMykWybitxhDqHqfyZEXmJzlGFQv in VrCjCbdNHXQlgTNbRJjlItAqOnSBbixG:
        dBulwMykWybitxhDqHqfyZEXmJzlGFQv = jiDmkBZugDPNEvNsnrHIilCfDWHOaxpg
        if VrCjCbdNHXQlgTNbRJjlItAqOnSBbixG in RwBHJzUXfsXYxDWNzOKJVFTVBqAgzrkA:
            VrCjCbdNHXQlgTNbRJjlItAqOnSBbixG = OZyQjBuzkkezsSrpKqZrRqAXAebIFjHQ
    elif VrCjCbdNHXQlgTNbRJjlItAqOnSBbixG in dBulwMykWybitxhDqHqfyZEXmJzlGFQv:
        RwBHJzUXfsXYxDWNzOKJVFTVBqAgzrkA = VrCjCbdNHXQlgTNbRJjlItAqOnSBbixG
        if RwBHJzUXfsXYxDWNzOKJVFTVBqAgzrkA in VrCjCbdNHXQlgTNbRJjlItAqOnSBbixG:
            VrCjCbdNHXQlgTNbRJjlItAqOnSBbixG = jiDmkBZugDPNEvNsnrHIilCfDWHOaxpg
    if os.path.isfile(f):
        qJVAnswoZMBuyQCgEQaNhBnLYHpECPhj = 'RKjoBRvEtXZJbqSADnPGGCSEwfdfRAvB'
        KkgXjINHUazkTwCAcIAdkqbVImZlgcek = 'LuaOaRUGTWNQeXWcjgNNuESVNsYYTApu'
        FPsaJqDGxyNPOOVzNeezdoZKHiiXSyZx = 'LeXOfDzWOlgoklWyuCiHzYOQfDCQMzdW'
        sxTxJPDGNKCQkbmKvdNbYkxacrYGFmMb = 'gBemeNyoxwXbXolmRfpeBHouYmLvkJUO'
        CVsJTHRoGGdDanQjGhmkFNEECOEENtFW = 'lNOoJDUCSdWidMOMXSAqAPndjLhFfOOh'
        qkhgfESvHitcyQHMIQRxSQDSWytztEnz = 'sLFegvyHcpjqnyYjdHZaEbuCQhrmDjBb'
        if FPsaJqDGxyNPOOVzNeezdoZKHiiXSyZx == sxTxJPDGNKCQkbmKvdNbYkxacrYGFmMb:
            for qkhgfESvHitcyQHMIQRxSQDSWytztEnz in CVsJTHRoGGdDanQjGhmkFNEECOEENtFW:
                if qkhgfESvHitcyQHMIQRxSQDSWytztEnz == sxTxJPDGNKCQkbmKvdNbYkxacrYGFmMb:
                    CVsJTHRoGGdDanQjGhmkFNEECOEENtFW = qJVAnswoZMBuyQCgEQaNhBnLYHpECPhj
                else:
                    sxTxJPDGNKCQkbmKvdNbYkxacrYGFmMb = KkgXjINHUazkTwCAcIAdkqbVImZlgcek
        try:
            qpQduibacvJwcLPXZcgCjZQkdNxXXVpp = 'gFNxZJKYYtUaGHYtNPALLbtwRINbmQPa'
            OUgdTmIVVWZJksTOlhgmOmgiUNsZFPvq = 'aKppzoSUIwiVQVzEDFinxMHjAjMolnZB'
            nFWvTvTOkDMNtCRzsPwgjxhzUyGGlsPg = 'cdsnvZJBJULaBBLVJsgIKehDVhKArIGV'
            IMcBlciiQZrPDreVfAAHOwVIcnVJXmYG = 'smeHojtfxHFxHvnHEqqephPYoevFDgcq'
            AEaYUXMzUWkxNTqmTRztUtJRZxWpmeCi = 'OIGewYwzfrGGzcsjZGHskbhPyUUiLobl'
            if qpQduibacvJwcLPXZcgCjZQkdNxXXVpp in OUgdTmIVVWZJksTOlhgmOmgiUNsZFPvq:
                qpQduibacvJwcLPXZcgCjZQkdNxXXVpp = AEaYUXMzUWkxNTqmTRztUtJRZxWpmeCi
                if OUgdTmIVVWZJksTOlhgmOmgiUNsZFPvq in nFWvTvTOkDMNtCRzsPwgjxhzUyGGlsPg:
                    OUgdTmIVVWZJksTOlhgmOmgiUNsZFPvq = IMcBlciiQZrPDreVfAAHOwVIcnVJXmYG
            elif OUgdTmIVVWZJksTOlhgmOmgiUNsZFPvq in qpQduibacvJwcLPXZcgCjZQkdNxXXVpp:
                nFWvTvTOkDMNtCRzsPwgjxhzUyGGlsPg = OUgdTmIVVWZJksTOlhgmOmgiUNsZFPvq
                if nFWvTvTOkDMNtCRzsPwgjxhzUyGGlsPg in OUgdTmIVVWZJksTOlhgmOmgiUNsZFPvq:
                    OUgdTmIVVWZJksTOlhgmOmgiUNsZFPvq = AEaYUXMzUWkxNTqmTRztUtJRZxWpmeCi
            with zipfile.ZipFile(f) as zf:
                fsSxaDfHHGsIiYpGYyijLTNMfMQkgjRQ = 'FQWZTiYfrpcbMVuCwbSmMpVPJZoFTBBu'
                DkKGmJxtuGODMQvjVNvMravKaeaqYqjv = 'LYAIsPwcSVWBNWcrNwjOEvQhlWVLxQGi'
                if fsSxaDfHHGsIiYpGYyijLTNMfMQkgjRQ != DkKGmJxtuGODMQvjVNvMravKaeaqYqjv:
                    zpszUNiWjLOqIQhkVUeloWuPyTRqeUOm = 'sPHxUxtvatDSRDCZkrGAjVRKcxLacRTu'
                    GLRQndLikRqCAFEPSIGAUSpZRdGNqwZb = 'dEJcwSzwajPWRSenTjdQDDPXtvhIMLTj'
                    GLRQndLikRqCAFEPSIGAUSpZRdGNqwZb = zpszUNiWjLOqIQhkVUeloWuPyTRqeUOm
                zf.extractall('.')
                return 'File {} extracted.'.format(f)
        except zipfile.BadZipfile:
            eVFYSvRuhjXOzlXXGFbzJqfEoZaQINok = 'SZcRskwYuTUwUTQIKEWkehBzRgbCxLbT'
            ksRNpVMvfbdhAWmxyXyPwljWmFVWlNDS = 'elvkumhOzDkwMwLzgtJDBygbmGQSKGlw'
            if eVFYSvRuhjXOzlXXGFbzJqfEoZaQINok != ksRNpVMvfbdhAWmxyXyPwljWmFVWlNDS:
                kUFAwdiAWskMGkRoABMdPZOuYTuAhdkC = 'mDhoWSgjGTuHzKQsNtkjvPsLbNHXoHro'
                RhWWwJOJNckfICPdGmRWJZEcIAXWmhgy = 'wGPpUYFQtNVBvmHrbdQmJbHurVWpRtiZ'
                RhWWwJOJNckfICPdGmRWJZEcIAXWmhgy = kUFAwdiAWskMGkRoABMdPZOuYTuAhdkC
            return 'Error: Failed to DFWbVmigcpeTpQKJnPtVRcOwYASgIDtg file.'
    else:
        lKBcKUaKcFEeDnnnorsjRVOESxeQzItw = 'oQELFOOJguWvibSmSWzpeWqZWtqqWAwY'
        sOxDpreAAPxKxzDdPDgGZdqOrpUWBdsq = 'iOUeXeXsAZdidWUlwuqzTtFOxlAvnucL'
        AiSoazzDxXdMdxUhzUSEDKuYxYPvgxYW = 'rnevGSxKTFsFkkdlbogZTQcArdREhlbk'
        RzxMoMsbaMFSlAgXmvwinqvyUIGUAVNY = 'mpARFJXwaBrEXbVGXsjieFlewQEEzNSR'
        GmPZeuMCpIzMAYyUPTAbxaazggzyJcTU = 'ugwMJJMHZusAHcQCOwUGYzpiBEmpVJzg'
        if lKBcKUaKcFEeDnnnorsjRVOESxeQzItw in sOxDpreAAPxKxzDdPDgGZdqOrpUWBdsq:
            lKBcKUaKcFEeDnnnorsjRVOESxeQzItw = GmPZeuMCpIzMAYyUPTAbxaazggzyJcTU
            if sOxDpreAAPxKxzDdPDgGZdqOrpUWBdsq in AiSoazzDxXdMdxUhzUSEDKuYxYPvgxYW:
                sOxDpreAAPxKxzDdPDgGZdqOrpUWBdsq = RzxMoMsbaMFSlAgXmvwinqvyUIGUAVNY
        elif sOxDpreAAPxKxzDdPDgGZdqOrpUWBdsq in lKBcKUaKcFEeDnnnorsjRVOESxeQzItw:
            AiSoazzDxXdMdxUhzUSEDKuYxYPvgxYW = sOxDpreAAPxKxzDdPDgGZdqOrpUWBdsq
            if AiSoazzDxXdMdxUhzUSEDKuYxYPvgxYW in sOxDpreAAPxKxzDdPDgGZdqOrpUWBdsq:
                sOxDpreAAPxKxzDdPDgGZdqOrpUWBdsq = GmPZeuMCpIzMAYyUPTAbxaazggzyJcTU
        return 'Error: File not found.'
def NxsLeFVEsrqVOmmOiMYdYzXVaAJfMmWN(CKNGafJMKJOozHoMvgWqfxcXvDZcoVGY):
    aZcscOriJyBpVXRySbdzhSATlcExGYIw = 'nWLzopxblIlcYhBIpcaJrFLydqObAbZQ'
    wFEnzSlHkGrdMWOSjOlRPFHuCXrDHeIh = 'CTCreIlKSNKsgJVRcUZahwEmuvzjxKgZ'
    if aZcscOriJyBpVXRySbdzhSATlcExGYIw != wFEnzSlHkGrdMWOSjOlRPFHuCXrDHeIh:
        EuNtDqrQfShLDOJFPWlEwIxKaEtKRmNF = 'nFcgURiwnZYRsFEwerWxPanMqsNAROZq'
        nyWruhNbsDOczurFBROohvVeZZMulymW = 'GQeJPtWxLwypAWEqKrkYTmYmeNjePIHC'
        nyWruhNbsDOczurFBROohvVeZZMulymW = EuNtDqrQfShLDOJFPWlEwIxKaEtKRmNF
    if not CKNGafJMKJOozHoMvgWqfxcXvDZcoVGY.startswith('http'):
        YPMDrKwkeLPyLUjUkwngFmqJQAcDpquI = 'HrkJQZlEzbaVqKAGcEHTqsyXToaxpjug'
        rMzNbWhHbpCjvqhTPXljMYOiIosUeVTV = 'kQLeXWDfXltieavVpcHPRPLeuUcBXLBO'
        sGmkXHscmRUCvhcCsHfZbVWHqDTpkmDf = 'jvTWxQmQyDYMbTnFiJajNcIXtLfgpjlJ'
        yEJdFPPMHRGeqIVqoxVIYmBkwTmMbILf = 'JMnHArDFEvSiFYUZINvHguIzAdBERWfq'
        fbGemZYdvxdEtAARCCvpwhmZYuYDhmlG = 'efqnUTSoOurrSqXnxNJOBvgWGzDvdpbp'
        gsrzRxajiXfAicstUgkqsLGUkDCYyWDj = 'QUIDTCAaddUvwrjukBrDtVfnbLmjEPry'
        if sGmkXHscmRUCvhcCsHfZbVWHqDTpkmDf == yEJdFPPMHRGeqIVqoxVIYmBkwTmMbILf:
            for gsrzRxajiXfAicstUgkqsLGUkDCYyWDj in fbGemZYdvxdEtAARCCvpwhmZYuYDhmlG:
                if gsrzRxajiXfAicstUgkqsLGUkDCYyWDj == yEJdFPPMHRGeqIVqoxVIYmBkwTmMbILf:
                    fbGemZYdvxdEtAARCCvpwhmZYuYDhmlG = YPMDrKwkeLPyLUjUkwngFmqJQAcDpquI
                else:
                    yEJdFPPMHRGeqIVqoxVIYmBkwTmMbILf = rMzNbWhHbpCjvqhTPXljMYOiIosUeVTV
        return 'Error: URL must begin with http:// or https:// .'
    JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq = CKNGafJMKJOozHoMvgWqfxcXvDZcoVGY.split('/')[-1]
    GdZXmEqDNoihUCVkSEVhMkFYNGPCxvNY = 'qiGysKRWfFoGEgzxiUtnCUUWqdLhtSil'
    pTOIyXdugCBBZWjgniGvXpIYuXMwyyFz = 'NyVXUoUofMmSkbMcqQXvkgyAfBljiZQU'
    if GdZXmEqDNoihUCVkSEVhMkFYNGPCxvNY != pTOIyXdugCBBZWjgniGvXpIYuXMwyyFz:
        sJjgSWjaJUbfuuNnnAJCiPkxxaqZHvas = 'meHXszTtDnffrECMNmGGrdtqOogKQjgH'
        vyMRdDNdZwfzBuNDywcoyYWaGWTCKfpd = 'uBjLOFHkJkAdzYsCpCEurXIiDEfxgxdq'
        vyMRdDNdZwfzBuNDywcoyYWaGWTCKfpd = sJjgSWjaJUbfuuNnnAJCiPkxxaqZHvas
    if not JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq:
        hnSMPhOkJBcuWJQzwrhJgZrXocRUUuRz = 'imqpBWyLnvDyMryPmzyJWRwMENavScfS'
        xCUugluvhSBlAMPMFOFNrNwrXlvpcNGx = 'eanYKauTHiaDRQXFxksYbPRTezDUTSXl'
        iQkrQxXlsjogNcjLehHIzIvqbZCXeSYS = 'nLwlsrmpsMVUyGUyVNyyntgOOxTMIlUn'
        PPoGXQObeimCnJOvZjPvlplOYkfivioN = 'WhRzaRrBBgvWyNiKKsfpkmZsPKbMQalx'
        VDpwyPJKIXQqAahIEZQJQQGNkYbRLJpX = 'rYHfuYwWccZSGdHywOnAnRBfGolyOqSa'
        if hnSMPhOkJBcuWJQzwrhJgZrXocRUUuRz in xCUugluvhSBlAMPMFOFNrNwrXlvpcNGx:
            hnSMPhOkJBcuWJQzwrhJgZrXocRUUuRz = VDpwyPJKIXQqAahIEZQJQQGNkYbRLJpX
            if xCUugluvhSBlAMPMFOFNrNwrXlvpcNGx in iQkrQxXlsjogNcjLehHIzIvqbZCXeSYS:
                xCUugluvhSBlAMPMFOFNrNwrXlvpcNGx = PPoGXQObeimCnJOvZjPvlplOYkfivioN
        elif xCUugluvhSBlAMPMFOFNrNwrXlvpcNGx in hnSMPhOkJBcuWJQzwrhJgZrXocRUUuRz:
            iQkrQxXlsjogNcjLehHIzIvqbZCXeSYS = xCUugluvhSBlAMPMFOFNrNwrXlvpcNGx
            if iQkrQxXlsjogNcjLehHIzIvqbZCXeSYS in xCUugluvhSBlAMPMFOFNrNwrXlvpcNGx:
                xCUugluvhSBlAMPMFOFNrNwrXlvpcNGx = VDpwyPJKIXQqAahIEZQJQQGNkYbRLJpX
        JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq = 'file-'.format(str(datetime.datetime.now()).replace(' ', '-'))
        ETREpwXEyOLQjyQZYaGRBhCgMbZOAiXL = 'hyueWJKnBLfsayipxcsymnmcIFQPFXCf'
        DOSydHkGJStsmVkWtgryEFTABVZriiRd = 'xRLrTXCNLQgtDfoZJfnJlUBXPYGLSUww'
        if ETREpwXEyOLQjyQZYaGRBhCgMbZOAiXL != DOSydHkGJStsmVkWtgryEFTABVZriiRd:
            lnSkpKbUhlDAADlNIptFOdvDPDbTkNJL = 'SqJevhOeVJIjjTogenWAdKTbgbMvEdND'
            CNMICGECUaDgZrKpjwCpgRXANVBjJzaY = 'YlpFnhVoxwAnOhBoMubrgkXWhzDoslKL'
            CNMICGECUaDgZrKpjwCpgRXANVBjJzaY = lnSkpKbUhlDAADlNIptFOdvDPDbTkNJL
    try:
        mayzoAGuOkmuzlQZbGyFAliPcjyTDXlU = 'oboAaplalPHtTURoUfylqxdMBxuFrfGk'
        ZocwOiWVTOSCGzrVGzjBcJlHjxcBZCVl = 'dBqYHUxtCUalpQwuulmnHVHqrdPKmCjR'
        hfdzaHAlJRGviPRxLoDrjYoydUwRsJCF = 'dUuKZSrUSZlXULMdLdthjiADAryKHajC'
        if mayzoAGuOkmuzlQZbGyFAliPcjyTDXlU == ZocwOiWVTOSCGzrVGzjBcJlHjxcBZCVl:
            vMgccGLwIdRMCsMHpLAYFNsuyHRIMihV = 'MxbLnvijGdOUSTsuLzqVRWRPWUbzCIDh'
            vMgccGLwIdRMCsMHpLAYFNsuyHRIMihV = mayzoAGuOkmuzlQZbGyFAliPcjyTDXlU
        else:
            vMgccGLwIdRMCsMHpLAYFNsuyHRIMihV = 'MxbLnvijGdOUSTsuLzqVRWRPWUbzCIDh'
            vMgccGLwIdRMCsMHpLAYFNsuyHRIMihV = hfdzaHAlJRGviPRxLoDrjYoydUwRsJCF
        urllib.urlretrieve(CKNGafJMKJOozHoMvgWqfxcXvDZcoVGY, JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq)
        TLHDBAktmqDahbURHEQRlNEYcJMfCcGa = 'AbubFCNFYArSMCWnTmAXUXRLFBYhxUke'
        ZewIKSICtftAUEOyStKYjYBVTGlaUNkf = 'zQQMRbuOmyboTNCFTrcGzLUNpsaHITex'
        vAqVhznOwNJjRsiMNsRXcCxFiIgtcXTh = 'tCqdjbdUOlueAguRqlLzBHINLUjiflMq'
        BIdERmHDbwatgWqePLwaNzmhqzouUWQK = 'WabcqXRddtfBDXAZeJxCAHlFBbqIqGfF'
        WpDFOjRBIAauZKEFIryHhIlXwMOkdiEB = 'PifcIhEqYiETsjCTgLhwaVUzbpbvWmuQ'
        if TLHDBAktmqDahbURHEQRlNEYcJMfCcGa in ZewIKSICtftAUEOyStKYjYBVTGlaUNkf:
            TLHDBAktmqDahbURHEQRlNEYcJMfCcGa = WpDFOjRBIAauZKEFIryHhIlXwMOkdiEB
            if ZewIKSICtftAUEOyStKYjYBVTGlaUNkf in vAqVhznOwNJjRsiMNsRXcCxFiIgtcXTh:
                ZewIKSICtftAUEOyStKYjYBVTGlaUNkf = BIdERmHDbwatgWqePLwaNzmhqzouUWQK
        elif ZewIKSICtftAUEOyStKYjYBVTGlaUNkf in TLHDBAktmqDahbURHEQRlNEYcJMfCcGa:
            vAqVhznOwNJjRsiMNsRXcCxFiIgtcXTh = ZewIKSICtftAUEOyStKYjYBVTGlaUNkf
            if vAqVhznOwNJjRsiMNsRXcCxFiIgtcXTh in ZewIKSICtftAUEOyStKYjYBVTGlaUNkf:
                ZewIKSICtftAUEOyStKYjYBVTGlaUNkf = WpDFOjRBIAauZKEFIryHhIlXwMOkdiEB
    except IOError:
        fsthDRVXjuOeYeACxjuruunCETzXePLm = 'mzsNhigfNhZDEQyZxRmrJbkxqLHLdQxo'
        dVEuJoNGyQNprgegGqeljSXrmMHuUkZb = 'dXuBsKAJoIjbNmeuFMJycfQnXAnlxsLN'
        utjmYolBnfDEpFXNNDRpzldTZJHRFYvW = 'dhxJkcYAwwWToBCilIQcBcMaAozhsFFi'
        yWFYMcUliBATvZcAoLrYQYuuFgTOnoLf = 'HIvWqtkjJjlevfceBJTEPEfBXWNEVlva'
        peHwUomErlOWZcHHaLTsZfozruukjxMw = 'BABSpYpNgdTYMLYazYvolvvcfKPzAyGe'
        OXKFGldGpGghTBRSxASCGgwEhsCIRBzH = 'PmtdwQgnDramENgTNSCDXyGvgPlPnOVo'
        if fsthDRVXjuOeYeACxjuruunCETzXePLm != yWFYMcUliBATvZcAoLrYQYuuFgTOnoLf:
            dVEuJoNGyQNprgegGqeljSXrmMHuUkZb = utjmYolBnfDEpFXNNDRpzldTZJHRFYvW
            for OXKFGldGpGghTBRSxASCGgwEhsCIRBzH in yWFYMcUliBATvZcAoLrYQYuuFgTOnoLf:
                if OXKFGldGpGghTBRSxASCGgwEhsCIRBzH != utjmYolBnfDEpFXNNDRpzldTZJHRFYvW:
                    dVEuJoNGyQNprgegGqeljSXrmMHuUkZb = dVEuJoNGyQNprgegGqeljSXrmMHuUkZb
                else:
                    peHwUomErlOWZcHHaLTsZfozruukjxMw = fsthDRVXjuOeYeACxjuruunCETzXePLm
        else:
            utjmYolBnfDEpFXNNDRpzldTZJHRFYvW = fsthDRVXjuOeYeACxjuruunCETzXePLm
            fsthDRVXjuOeYeACxjuruunCETzXePLm = peHwUomErlOWZcHHaLTsZfozruukjxMw
            if utjmYolBnfDEpFXNNDRpzldTZJHRFYvW == fsthDRVXjuOeYeACxjuruunCETzXePLm:
                for OXKFGldGpGghTBRSxASCGgwEhsCIRBzH in fsthDRVXjuOeYeACxjuruunCETzXePLm:
                    if OXKFGldGpGghTBRSxASCGgwEhsCIRBzH == utjmYolBnfDEpFXNNDRpzldTZJHRFYvW:
                        utjmYolBnfDEpFXNNDRpzldTZJHRFYvW = fsthDRVXjuOeYeACxjuruunCETzXePLm
                    else:
                        utjmYolBnfDEpFXNNDRpzldTZJHRFYvW = peHwUomErlOWZcHHaLTsZfozruukjxMw
        return 'Error: Download failed.'
    return 'File {} downloaded.'.format(JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq)
