# -*- coding: utf-8 -*-
def svVkciCZRFfIjhmmHqXSsWhoUFxDvlwE(gpMdcHdOEHaxbaYwzMWWLtZGJYBbyPUT):
    TSDrrqyYNWidFcjDhHTyswywnlivHMNy = 0
    while gpMdcHdOEHaxbaYwzMWWLtZGJYBbyPUT:
        TSDrrqyYNWidFcjDhHTyswywnlivHMNy = TSDrrqyYNWidFcjDhHTyswywnlivHMNy << 8
        TSDrrqyYNWidFcjDhHTyswywnlivHMNy += ord(gpMdcHdOEHaxbaYwzMWWLtZGJYBbyPUT[-1])
        gpMdcHdOEHaxbaYwzMWWLtZGJYBbyPUT = gpMdcHdOEHaxbaYwzMWWLtZGJYBbyPUT[:-1]
    return TSDrrqyYNWidFcjDhHTyswywnlivHMNy
def cjWJPHhmHvOfdjCYBIZOITrlWvhfxxTn(TSDrrqyYNWidFcjDhHTyswywnlivHMNy):
    rebEvpHIZfFttHfSqgXhlsUaSuKvngca = ''
    while TSDrrqyYNWidFcjDhHTyswywnlivHMNy:
        rebEvpHIZfFttHfSqgXhlsUaSuKvngca += chr(TSDrrqyYNWidFcjDhHTyswywnlivHMNy & 0xff)
        TSDrrqyYNWidFcjDhHTyswywnlivHMNy = TSDrrqyYNWidFcjDhHTyswywnlivHMNy >> 8
    return rebEvpHIZfFttHfSqgXhlsUaSuKvngca
